import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Briefcase, TrendingUp, DollarSign, Users, 
  AlertCircle, CheckCircle, Clock, FileText, Award
} from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import BrandLogo from '../components/branding/BrandLogo';
import PartnerOnboardingAssistant from '../components/partner/PartnerOnboardingAssistant';
import CriticalSOSAlert from '../components/security/CriticalSOSAlert';

export default function PartnerPortal() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        window.location.href = createPageUrl('Login');
        return;
      }
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      window.location.href = createPageUrl('Login');
    }
  };

  const { data: partner } = useQuery({
    queryKey: ['partner-profile', user?.email],
    queryFn: async () => {
      const partners = await base44.entities.Partner.filter({ email: user.email });
      return partners[0];
    },
    enabled: !!user
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#FF771D' }}></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!partner) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md">
          <CardContent className="pt-8 text-center">
            <AlertCircle className="w-16 h-16 mx-auto mb-4" style={{ color: '#E52C2D' }} />
            <h2 className="text-xl font-bold mb-2">No Partner Profile Found</h2>
            <p className="text-gray-600 mb-6">
              You don't have a partner profile yet. Would you like to apply?
            </p>
            <Button
              onClick={() => window.location.href = createPageUrl('PartnerRegistration')}
              className="text-white"
              style={{ backgroundColor: '#FF771D' }}
            >
              Apply to Become a Partner
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const statusConfig = {
    pending: {
      icon: Clock,
      color: 'bg-yellow-100 text-yellow-800',
      label: 'Pending Review',
      message: 'Your application is being reviewed by our team.'
    },
    active: {
      icon: CheckCircle,
      color: 'bg-green-100 text-green-800',
      label: 'Active',
      message: 'Your partnership is active! Start referring customers to earn commissions.'
    },
    inactive: {
      icon: AlertCircle,
      color: 'bg-gray-100 text-gray-800',
      label: 'Inactive',
      message: 'Your partnership is currently inactive. Contact support for more information.'
    },
    suspended: {
      icon: AlertCircle,
      color: 'bg-red-100 text-red-800',
      label: 'Suspended',
      message: 'Your partnership has been suspended. Please contact support.'
    }
  };

  const status = statusConfig[partner.status] || statusConfig.pending;
  const StatusIcon = status.icon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <PartnerOnboardingAssistant 
        partner={partner} 
        onboardingStage={partner?.status === 'active' ? 'active' : 'pending'} 
      />
      {/* Header */}
      <div className="text-white p-6 shadow-lg" 
           style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <BrandLogo variant="icon" size="md" />
              <div>
                <h1 className="text-2xl font-bold">Partner Portal</h1>
                <p className="text-sm opacity-90">{partner.company_name}</p>
              </div>
            </div>
            <Badge className={status.color}>
              <StatusIcon className="w-4 h-4 mr-1" />
              {status.label}
            </Badge>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Status Alert */}
        <Card className="mb-6 border-l-4" style={{ borderLeftColor: partner.status === 'active' ? '#3D692B' : '#FF771D' }}>
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <StatusIcon className="w-6 h-6 mt-0.5" style={{ 
                color: partner.status === 'active' ? '#3D692B' : '#FF771D' 
              }} />
              <div>
                <h3 className="font-semibold mb-1">Partnership Status</h3>
                <p className="text-gray-600 text-sm">{status.message}</p>
                {partner.ai_review && partner.ai_review.reasoning && (
                  <div className="mt-3 p-3 bg-gray-50 rounded text-sm">
                    <p className="font-semibold mb-1">Review Notes:</p>
                    <p className="text-gray-700">{partner.ai_review.reasoning}</p>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Referrals</p>
                  <p className="text-3xl font-bold mt-1">{partner.total_referrals || 0}</p>
                </div>
                <Users className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Commission Earned</p>
                  <p className="text-3xl font-bold mt-1" style={{ color: '#3D692B' }}>
                    ${(partner.total_commission_earned || 0).toFixed(2)}
                  </p>
                </div>
                <DollarSign className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Commission Rate</p>
                  <p className="text-3xl font-bold mt-1">{partner.commission_rate}%</p>
                </div>
                <TrendingUp className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Member Since</p>
                  <p className="text-lg font-bold mt-1">
                    {format(new Date(partner.created_date), 'MMM yyyy')}
                  </p>
                </div>
                <Briefcase className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Partner Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Company Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-gray-600">Company Name</p>
                  <p className="font-semibold">{partner.company_name}</p>
                </div>
                <div>
                  <p className="text-gray-600">Contact Person</p>
                  <p className="font-semibold">{partner.contact_name}</p>
                </div>
                <div>
                  <p className="text-gray-600">Email</p>
                  <p className="font-semibold">{partner.email}</p>
                </div>
                <div>
                  <p className="text-gray-600">Phone</p>
                  <p className="font-semibold">{partner.phone}</p>
                </div>
                <div>
                  <p className="text-gray-600">Address</p>
                  <p className="font-semibold">{partner.address || 'Not provided'}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Partnership Terms</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-gray-600">Partner Type</p>
                  <p className="font-semibold capitalize">{partner.partner_type?.replace(/_/g, ' ')}</p>
                </div>
                <div>
                  <p className="text-gray-600">Commission Rate</p>
                  <p className="text-2xl font-bold" style={{ color: '#3D692B' }}>{partner.commission_rate}%</p>
                </div>
                <div>
                  <p className="text-gray-600">Payment Terms</p>
                  <p className="font-semibold">{partner.payment_terms || 'Standard terms apply'}</p>
                </div>
                {partner.contract_start_date && (
                  <div>
                    <p className="text-gray-600">Contract Start</p>
                    <p className="font-semibold">{format(new Date(partner.contract_start_date), 'MMM d, yyyy')}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Stripe Connect Alert */}
        {partner.status === 'active' && !partner.stripe_onboarding_complete && (
          <Card className="mt-6 border-l-4 border-orange-500">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-6 h-6 text-orange-600 mt-0.5" />
                <div className="flex-1">
                  <h3 className="font-semibold mb-1">Connect Your Bank Account</h3>
                  <p className="text-gray-600 text-sm mb-3">
                    To receive commission payouts, please connect your bank account through Stripe.
                  </p>
                  <Button
                    onClick={() => window.location.href = createPageUrl('PartnerStripeConnect')}
                    style={{ backgroundColor: '#FF771D' }}
                    className="text-white"
                  >
                    Connect Bank Account
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Actions */}
        {partner.status === 'active' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
            {partner.has_client_database_access && (
              <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = createPageUrl('PartnerDashboard')}>
                <CardContent className="pt-6 text-center">
                  <Users className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
                  <p className="font-semibold">Client Dashboard</p>
                  <p className="text-sm text-gray-600 mt-1">Manage your clients</p>
                </CardContent>
              </Card>
            )}
            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = createPageUrl('PartnerAnalytics')}>
              <CardContent className="pt-6 text-center">
                <TrendingUp className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
                <p className="font-semibold">Analytics</p>
                <p className="text-sm text-gray-600 mt-1">View performance reports</p>
              </CardContent>
            </Card>
            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = createPageUrl('PartnerReferralDashboard')}>
              <CardContent className="pt-6 text-center">
                <DollarSign className="w-12 h-12 mx-auto mb-3" style={{ color: '#3D692B' }} />
                <p className="font-semibold">Referral Program</p>
                <p className="text-sm text-gray-600 mt-1">Earn rewards</p>
              </CardContent>
            </Card>
            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = createPageUrl('PartnerSettings')}>
              <CardContent className="pt-6 text-center">
                <Award className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
                <p className="font-semibold">Branding</p>
                <p className="text-sm text-gray-600 mt-1">Customize your portal</p>
              </CardContent>
            </Card>
            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = createPageUrl('PartnerContracts')}>
              <CardContent className="pt-6 text-center">
                <FileText className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
                <p className="font-semibold">Contracts</p>
                <p className="text-sm text-gray-600 mt-1">View and manage</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* How to Refer */}
        {partner.status === 'active' && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>How to Refer Customers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-gray-600">
                  Share the ROADSIDE+ service with your customers and earn {partner.commission_rate}% commission on every completed job.
                </p>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm font-semibold mb-2">Your Referral Link:</p>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      readOnly
                      value={`https://roadsideplus.com/register?ref=${partner.id}`}
                      className="flex-1 px-3 py-2 border rounded bg-white text-sm"
                    />
                    <Button
                      onClick={() => {
                        navigator.clipboard.writeText(`https://roadsideplus.com/register?ref=${partner.id}`);
                        alert('Copied to clipboard!');
                      }}
                      style={{ backgroundColor: '#FF771D' }}
                      className="text-white"
                    >
                      Copy
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}