import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Wrench, Battery, Fuel, Key, Truck, HelpCircle, ArrowRight } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function ServiceOptions() {
  const services = [
    {
      id: 'tire_change',
      icon: Wrench,
      title: 'Tire Change',
      description: 'Flat tire? We\'ll get you back on the road',
      color: 'from-orange-500 to-red-600'
    },
    {
      id: 'battery_jump',
      icon: Battery,
      title: 'Jump Start',
      description: 'Dead battery? We\'ll give you a boost',
      color: 'from-yellow-500 to-orange-600'
    },
    {
      id: 'fuel_delivery',
      icon: Fuel,
      title: 'Fuel Delivery',
      description: 'Out of gas? We\'ll bring fuel to you',
      color: 'from-green-500 to-teal-600'
    },
    {
      id: 'lockout',
      icon: Key,
      title: 'Lockout Service',
      description: 'Locked out? We\'ll help you get back in',
      color: 'from-blue-500 to-indigo-600'
    },
    {
      id: 'towing',
      icon: Truck,
      title: 'Towing',
      description: 'Need a tow? We\'ll transport your vehicle',
      color: 'from-purple-500 to-pink-600'
    },
    {
      id: 'other',
      icon: HelpCircle,
      title: 'Other Services',
      description: 'Need something else? Let us know',
      color: 'from-gray-500 to-gray-700'
    }
  ];

  const handleServiceSelect = (serviceType) => {
    window.location.href = createPageUrl(`RequestService?serviceType=${serviceType}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="text-white p-8 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold mb-2">What do you need?</h1>
          <p className="text-lg opacity-90">Select the service you need and we'll find you the right technician</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <Card
                key={service.id}
                className="group cursor-pointer hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-2 hover:border-orange-300"
                onClick={() => handleServiceSelect(service.id)}
              >
                <CardContent className="p-6">
                  <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-gray-900">{service.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">{service.description}</p>
                  <Button
                    variant="ghost"
                    className="w-full justify-between group-hover:bg-orange-50 group-hover:text-orange-700"
                  >
                    Select Service
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-8 text-center">
          <Button
            variant="outline"
            onClick={() => window.history.back()}
            className="border-gray-300 hover:bg-gray-50"
          >
            Back to Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
}