import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  CreditCard, CheckCircle, AlertCircle, ExternalLink, 
  DollarSign, Lock, TrendingUp
} from 'lucide-react';
import { createPageUrl } from '@/utils';
import BrandLogo from '../components/branding/BrandLogo';

export default function PartnerStripeConnect() {
  const [user, setUser] = useState(null);
  const [partner, setPartner] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        window.location.href = createPageUrl('Login');
        return;
      }
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      const partners = await base44.entities.Partner.filter({ email: currentUser.email });
      if (partners.length > 0) {
        setPartner(partners[0]);
      } else {
        window.location.href = createPageUrl('PartnerPortal');
      }
    } catch (error) {
      window.location.href = createPageUrl('Login');
    }
  };

  const connectStripe = useMutation({
    mutationFn: async () => {
      // In production, this would create a Stripe Connect account and return onboarding link
      const stripeAccountId = `acct_${Date.now()}`;
      
      await base44.entities.Partner.update(partner.id, {
        stripe_account_id: stripeAccountId,
        stripe_onboarding_complete: true,
        stripe_charges_enabled: true,
        stripe_payouts_enabled: true
      });

      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partner-profile'] });
      loadUser();
    }
  });

  const disconnectStripe = useMutation({
    mutationFn: async () => {
      await base44.entities.Partner.update(partner.id, {
        stripe_account_id: null,
        stripe_onboarding_complete: false,
        stripe_charges_enabled: false,
        stripe_payouts_enabled: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partner-profile'] });
      loadUser();
    }
  });

  if (!user || !partner) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#FF771D' }}></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  const isConnected = partner.stripe_onboarding_complete && partner.stripe_account_id;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" 
           style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <BrandLogo variant="icon" size="md" />
              <div>
                <h1 className="text-2xl font-bold">Payment Setup</h1>
                <p className="text-sm opacity-90">Connect your bank account for commission payouts</p>
              </div>
            </div>
            <Button
              onClick={() => window.location.href = createPageUrl('PartnerPortal')}
              variant="outline"
              className="text-white border-white/30 hover:bg-white/20"
            >
              Back to Portal
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6">
        {/* Connection Status */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Stripe Connect Status
              </CardTitle>
              {isConnected ? (
                <Badge className="bg-green-100 text-green-800">
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Connected
                </Badge>
              ) : (
                <Badge className="bg-yellow-100 text-yellow-800">
                  <AlertCircle className="w-4 h-4 mr-1" />
                  Not Connected
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {isConnected ? (
              <div className="space-y-4">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                    <div className="flex-1">
                      <h3 className="font-semibold text-green-900 mb-1">Account Connected</h3>
                      <p className="text-sm text-green-800">
                        Your bank account is connected and ready to receive payouts. Commission payments will be automatically transferred to your account.
                      </p>
                      <div className="mt-3 p-3 bg-white rounded border border-green-200">
                        <p className="text-xs text-gray-600 mb-1">Account ID</p>
                        <p className="font-mono text-sm">{partner.stripe_account_id}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-semibold">Onboarding</span>
                    </div>
                    <p className="text-xs text-gray-600">Complete</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-semibold">Payouts</span>
                    </div>
                    <p className="text-xs text-gray-600">Enabled</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Lock className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-semibold">Secure</span>
                    </div>
                    <p className="text-xs text-gray-600">Verified</p>
                  </div>
                </div>

                <Button
                  variant="outline"
                  onClick={() => disconnectStripe.mutate()}
                  disabled={disconnectStripe.isLoading}
                  className="w-full"
                >
                  Disconnect Account
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <h3 className="font-semibold text-blue-900 mb-1">Connect Your Bank Account</h3>
                      <p className="text-sm text-blue-800">
                        To receive commission payouts, you need to connect your bank account through Stripe Connect. This is a secure, one-time setup.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold">What you'll need:</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                      Business bank account details
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                      Tax identification number (EIN or SSN)
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                      Business owner information
                    </li>
                  </ul>
                </div>

                <Button
                  onClick={() => connectStripe.mutate()}
                  disabled={connectStripe.isLoading}
                  className="w-full text-white"
                  style={{ backgroundColor: '#FF771D' }}
                >
                  {connectStripe.isLoading ? (
                    'Connecting...'
                  ) : (
                    <>
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Connect with Stripe
                    </>
                  )}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="pt-6 text-center">
              <DollarSign className="w-12 h-12 mx-auto mb-3" style={{ color: '#3D692B' }} />
              <h3 className="font-semibold mb-2">Automatic Payouts</h3>
              <p className="text-sm text-gray-600">
                Receive monthly commission payments automatically
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6 text-center">
              <Lock className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
              <h3 className="font-semibold mb-2">Secure & Verified</h3>
              <p className="text-sm text-gray-600">
                Bank-level security powered by Stripe
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6 text-center">
              <TrendingUp className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
              <h3 className="font-semibold mb-2">Track Everything</h3>
              <p className="text-sm text-gray-600">
                Full transparency on all commission payments
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}