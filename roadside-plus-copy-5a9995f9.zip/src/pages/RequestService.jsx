import React, { useState, useEffect, lazy, Suspense, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQueryWithTimeout } from '../components/common/useQueryWithTimeout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, MapPin, Loader2, CreditCard, AlertCircle } from 'lucide-react';
import { createPageUrl } from '@/utils';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import { calculateDynamicPrice } from '../components/pricing/DynamicPricingEngine';
import PriceBreakdown from '../components/pricing/PriceBreakdown';
import { Car } from 'lucide-react';
import AIServiceTypeDetectorMemo from '../components/service/AIServiceTypeDetectorMemo';
import PriceBreakdownMemo from '../components/pricing/PriceBreakdownMemo';
import { cacheVehicles } from '../components/offline/cacheVehicles';
import { useNetworkStatus } from '../components/offline/NetworkMonitor';

const RealTimeTechniciansMap = lazy(() => import('../components/map/RealTimeTechniciansMap'));

const serviceTypes = [
  { value: 'tire_change', label: 'Tire Change' },
  { value: 'battery_jump', label: 'Battery Jump Start' },
  { value: 'fuel_delivery', label: 'Fuel Delivery' },
  { value: 'lockout', label: 'Lockout Service' },
  { value: 'towing', label: 'Towing' },
  { value: 'other', label: 'Other' }
];

export default function RequestService() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);
  const [gettingLocation, setGettingLocation] = useState(false);
  const [geocoding, setGeocoding] = useState(false);
  const [calculatingPrice, setCalculatingPrice] = useState(false);
  const [dynamicPricing, setDynamicPricing] = useState(null);
  const [detectedPriority, setDetectedPriority] = useState('normal');
  const [selectedVehicleId, setSelectedVehicleId] = useState('');
  const [showMap, setShowMap] = useState(false);
  const { isOnline } = useNetworkStatus();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    service_type: '',
    location_lat: '',
    location_lng: '',
    location_address: '',
    vehicle_id: '',
    vehicle_make: '',
    vehicle_model: '',
    vehicle_year: '',
    vehicle_color: '',
    vehicle_vin: '',
    vehicle_license_plate: '',
    description: '',
    service_description: ''
  });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const preSelectedService = params.get('serviceType');
    
    if (preSelectedService) {
      setFormData(prev => ({ ...prev, service_type: preSelectedService }));
    }
    
    loadUser();
  }, []);

  useEffect(() => {
    if (formData.location_lat && formData.location_lng) {
      const timer = setTimeout(() => setShowMap(true), 300);
      return () => clearTimeout(timer);
    }
  }, [formData.location_lat, formData.location_lng]);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error('Auth error:', error);
      base44.auth.redirectToLogin();
    }
  };

  const { data: activeRequests = [], isLoading: loadingRequests } = useQueryWithTimeout({
    queryKey: ['active-requests', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const requests = await base44.entities.ServiceRequest.filter({ customer_id: user.id }, '-created_date', 3);
      return requests;
    },
    enabled: !!user,
    staleTime: 60000,
    retry: 1,
    retryDelay: 3000
  }, 8000);

  const { data: paymentMethods = [], isLoading: loadingPayments } = useQueryWithTimeout({
    queryKey: ['payment-methods', user?.id],
    queryFn: async () => {
      if (!user) return [];
      return await base44.entities.PaymentMethod.filter({ user_id: user.id }, '-created_date', 3);
    },
    enabled: !!user,
    staleTime: 120000,
    retry: 1
  }, 8000);

  const { data: vehicles = [], isLoading: loadingVehicles } = useQueryWithTimeout({
    queryKey: ['vehicles', user?.id],
    queryFn: async () => {
      if (!user) return [];
      if (!isOnline) {
        return await cacheVehicles.getMyVehicles(user.id);
      }
      const freshVehicles = await base44.entities.Vehicle.filter({ customer_id: user.id }, '-created_date', 5);
      await cacheVehicles.saveMultipleVehicles(freshVehicles);
      return freshVehicles;
    },
    enabled: !!user,
    staleTime: 120000,
    retry: 1
  }, 8000);

  useEffect(() => {
    if (vehicles.length > 0 && !selectedVehicleId) {
      const defaultVehicle = vehicles.find(v => v.is_default);
      if (defaultVehicle) {
        handleVehicleSelect(defaultVehicle.id);
      }
    }
  }, [vehicles]);



  const pageLoading = loadingRequests || loadingPayments || loadingVehicles || !user;

  const handleVehicleSelect = useCallback((vehicleId) => {
    const vehicle = vehicles.find(v => v.id === vehicleId);
    if (vehicle) {
      setSelectedVehicleId(vehicleId);
      setFormData(prev => ({
        ...prev,
        vehicle_id: vehicle.id,
        vehicle_make: vehicle.make,
        vehicle_model: vehicle.model,
        vehicle_year: vehicle.year || '',
        vehicle_color: vehicle.color || '',
        vehicle_vin: vehicle.vin || '',
        vehicle_license_plate: vehicle.license_plate || ''
      }));
    }
  }, [vehicles]);

  const geocodeAddress = async (address) => {
    if (!address.trim()) return;

    setGeocoding(true);
    try {
      const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN;
      const response = await fetch(
        `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(address)}.json?access_token=${MAPBOX_TOKEN}`
      );
      const data = await response.json();
      
      if (data.features && data.features.length > 0) {
        const [lng, lat] = data.features[0].center;
        setFormData(prev => ({
          ...prev,
          location_lat: lat,
          location_lng: lng,
          location_address: data.features[0].place_name
        }));
      } else {
        alert('Location not found. Try a different address or use GPS location.');
      }
    } catch (error) {
      console.error('Geocoding failed:', error);
      alert('Could not find location. Try being more specific (e.g., "Main Street, Georgetown, Guyana")');
    } finally {
      setGeocoding(false);
    }
  };

  const getCurrentLocation = () => {
    setGettingLocation(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          let address = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
          
          // Reverse geocode to get human-readable address
          const MAPBOX_ACCESS_TOKEN = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN;
          if (MAPBOX_ACCESS_TOKEN) {
            try {
              const response = await fetch(
                `https://api.mapbox.com/geocoding/v5/mapbox.places/${longitude},${latitude}.json?access_token=${MAPBOX_ACCESS_TOKEN}`
              );
              const data = await response.json();
              if (data.features && data.features.length > 0) {
                address = data.features[0].place_name;
              }
            } catch (error) {
              console.error('Reverse geocoding failed:', error);
            }
          }

          setFormData(prev => ({
            ...prev,
            location_lat: latitude,
            location_lng: longitude,
            location_address: address
          }));
          setGettingLocation(false);
        },
        (error) => {
          console.error('Error getting location:', error);
          setGettingLocation(false);
          // Silently fail - user can enter address manually
        },
        {
          enableHighAccuracy: false,
          timeout: 5000,
          maximumAge: 30000
        }
      );
    } else {
      alert('Geolocation is not supported by your browser');
      setGettingLocation(false);
    }
  };

  const handleAIDetection = async (detectionResult) => {
    setFormData(prev => ({
      ...prev,
      service_type: detectionResult.serviceType
    }));
    
    setDetectedPriority(detectionResult.priority);
    
    // Calculate price after detecting service type
    await calculatePriceForService(detectionResult.serviceType);
  };

  const calculatePriceForService = useCallback(async (serviceType) => {
    if (!serviceType) return;
    
    setCalculatingPrice(true);
    try {
      const pricing = await calculateDynamicPrice({
        serviceType: serviceType,
        location: formData.location_lat && formData.location_lng ? {
          lat: formData.location_lat,
          lng: formData.location_lng
        } : null,
        timeOfDay: new Date(),
        description: formData.description
      });
      setDynamicPricing(pricing);
    } catch (error) {
      console.error('Pricing calculation error:', error);
      setDynamicPricing({ price: 75, breakdown: { base: 75 } });
    } finally {
      setCalculatingPrice(false);
    }
  }, [formData.location_lat, formData.location_lng, formData.description]);

  const calculateDistance = (lat1, lng1, lat2, lng2) => {
    const R = 3959; // Earth radius in miles
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    setLoading(true);
    
    try {
      // Step 1: Check if customer has an active job (excluding completed/cancelled)
      const activeStatuses = ['pending_payment', 'pending_dispatch', 'dispatched', 'assigned', 'en_route', 'in_progress', 'awaiting_review'];
      const hasActiveJob = activeRequests.some(req => activeStatuses.includes(req.status));
      
      if (hasActiveJob) {
        const activeJob = activeRequests.find(req => activeStatuses.includes(req.status));
        alert(`You already have an active service request (${activeJob.service_type.replace(/_/g, ' ')}). Please wait for it to complete and rate the service before requesting another.`);
        setLoading(false);
        navigate(createPageUrl('CustomerDashboard'));
        return;
      }
      
      // Validate
      if (!formData.service_type || !formData.location_lat || !formData.location_lng) {
        throw new Error('Please fill in service type and location');
      }

      if (formData.service_type === 'other' && !formData.service_description.trim()) {
        throw new Error('Please describe the service you need');
      }

      if (paymentMethods.length === 0) {
        navigate(createPageUrl('Settings?addPayment=true'));
        return;
      }
      
      // Step 2: Create job request
      const requestData = {
        service_type: formData.service_type,
        location_lat: formData.location_lat,
        location_lng: formData.location_lng,
        location_address: formData.location_address || `${formData.location_lat}, ${formData.location_lng}`,
        description: formData.service_description || formData.description || '',
        customer_id: user.id,
        status: 'pending_dispatch',
        payment_status: 'pending',
        price: dynamicPricing?.price || 75,
        priority: detectedPriority || 'normal',
        vehicle_make: formData.vehicle_make || '',
        vehicle_model: formData.vehicle_model || '',
        vehicle_year: formData.vehicle_year || '',
        vehicle_color: formData.vehicle_color || ''
      };
      
      const request = await base44.entities.ServiceRequest.create(requestData);
      
      // Step 3: Lock customer and navigate to search UI
      sessionStorage.setItem('lastRequestId', request.id);
      
      // Note: We trigger dispatch from ServiceConfirmation page to ensure reliability 
      // and avoid race conditions where page navigation cancels the request
      navigate(createPageUrl(`ServiceConfirmation?id=${request.id}`), { replace: true });
      
    } catch (error) {
      console.error('Submit error:', error);
      alert(error.message || 'Failed to submit. Please try again.');
      setLoading(false);
    }
  };

  if (pageLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
          <div className="max-w-3xl mx-auto flex items-center gap-4">
            <div className="h-10 w-10 bg-white/20 rounded animate-pulse"></div>
            <div>
              <div className="h-6 w-36 bg-white/30 rounded mb-2 animate-pulse"></div>
              <div className="h-4 w-24 bg-white/20 rounded animate-pulse"></div>
            </div>
          </div>
        </div>
        <div className="max-w-3xl mx-auto p-6 space-y-6">
          {/* Service Details Skeleton */}
          <Card>
            <CardHeader>
              <div className="h-6 w-32 bg-gray-200 rounded animate-pulse"></div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="h-4 w-40 bg-gray-200 rounded mb-2 animate-pulse"></div>
                <div className="h-24 bg-gray-100 rounded animate-pulse"></div>
              </div>
              <div>
                <div className="h-4 w-32 bg-gray-200 rounded mb-2 animate-pulse"></div>
                <div className="h-10 bg-gray-100 rounded animate-pulse"></div>
              </div>
              <div>
                <div className="h-4 w-24 bg-gray-200 rounded mb-2 animate-pulse"></div>
                <div className="h-10 bg-gray-100 rounded animate-pulse"></div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="h-10 bg-gray-100 rounded animate-pulse"></div>
                <div className="h-10 bg-gray-100 rounded animate-pulse"></div>
              </div>
              <div className="h-12 bg-orange-100 rounded animate-pulse"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-3xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20"
            onClick={() => navigate(createPageUrl('CustomerDashboard'))}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Request Service</h1>
            <p className="text-sm opacity-90">Tell us what you need</p>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto p-6">
        {/* Payment Method Required Notice */}
        {paymentMethods.length === 0 && (
          <Card className="mb-6 border-2" style={{ borderColor: '#FF771D' }}>
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-full bg-orange-100">
                  <CreditCard className="w-6 h-6" style={{ color: '#FF771D' }} />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold mb-2">Payment Method Required</h3>
                  <p className="text-gray-600 mb-4">
                    You need to add a payment method before requesting service. This ensures a seamless experience once your technician arrives.
                  </p>
                  <Button
                    onClick={() => navigate(createPageUrl('AddPaymentCard'))}
                    style={{ backgroundColor: '#FF771D' }}
                    className="text-white hover:opacity-90"
                  >
                    <CreditCard className="w-4 h-4 mr-2" />
                    Add Payment Method
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Lazy Load Map */}
        {showMap && formData.location_lat && formData.location_lng && (
          <Suspense fallback={<div className="h-64 bg-gray-100 animate-pulse rounded-lg mb-6 flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-gray-400" /></div>}>
            <div className="mb-6">
              <RealTimeTechniciansMap 
                customerLocation={[formData.location_lat, formData.location_lng]}
                showCustomer={true}
                serviceType={formData.service_type}
                highlightClosest={true}
              />
            </div>
          </Suspense>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Service Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Issue Description */}
              <div>
                <Label htmlFor="description">Describe Your Issue *</Label>
                <Textarea
                  id="description"
                  placeholder="What's happening with your vehicle? Be as specific as possible..."
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="mt-2 h-24"
                />
              </div>

              {/* AI Service Type Detector */}
              <div>
                <Label className="text-base font-semibold mb-2 block">AI-Powered Service Detection</Label>
                <AIServiceTypeDetectorMemo
                  description={formData.description}
                  onDetectionComplete={handleAIDetection}
                />
              </div>

              {/* Service Type */}
              <div>
                <Label htmlFor="service_type">Service Type *</Label>
                <Select 
                  value={formData.service_type} 
                  onValueChange={(value) => {
                    setFormData({...formData, service_type: value});
                    calculatePriceForService(value);
                  }}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select service type or use auto-detect" />
                  </SelectTrigger>
                  <SelectContent>
                    {serviceTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center gap-2">
                          <ServiceTypeIcon type={type.value} className="w-4 h-4" />
                          {type.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Service Description - Visible when service type is selected */}
              {formData.service_type && (
                <div>
                  <Label htmlFor="service_description" className="text-base font-semibold">
                    {formData.service_type === 'other' ? 'Service Description *' : 'Additional Service Details'}
                  </Label>
                  <Textarea
                    id="service_description"
                    value={formData.service_description}
                    onChange={(e) => setFormData({ ...formData, service_description: e.target.value })}
                    placeholder={
                      formData.service_type === 'other'
                        ? 'Please describe the service you need in detail...'
                        : 'Add any additional details about your service request (optional)'
                    }
                    required={formData.service_type === 'other'}
                    className="mt-2 min-h-[100px] resize-y"
                    style={{ borderColor: formData.service_type === 'other' ? '#FF771D' : undefined }}
                  />
                  {formData.service_type === 'other' && !formData.service_description.trim() && (
                    <p className="text-sm mt-1" style={{ color: '#E52C2D' }}>
                      * Required - Please provide a detailed description
                    </p>
                  )}
                </div>
              )}

              {/* Dynamic Price Display */}
              {calculatingPrice && (
                <Card className="border-orange-200">
                  <CardContent className="p-4 flex items-center gap-3">
                    <Loader2 className="w-5 h-5 animate-spin" style={{ color: '#FF771D' }} />
                    <span className="text-sm text-gray-600">Calculating optimal price based on current demand...</span>
                  </CardContent>
                </Card>
              )}

              {dynamicPricing && !calculatingPrice && (
                <PriceBreakdownMemo pricing={dynamicPricing} />
              )}

              {/* Location */}
              <div>
                <Label>Your Location *</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    placeholder="Type your address (e.g., Main Street, Georgetown, Guyana)"
                    value={formData.location_address}
                    onChange={(e) => setFormData({...formData, location_address: e.target.value})}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        geocodeAddress(e.target.value);
                      }
                    }}
                    className="flex-1"
                    disabled={geocoding}
                    required
                  />
                  <Button 
                    type="button"
                    onClick={getCurrentLocation}
                    disabled={gettingLocation || geocoding}
                    variant="outline"
                    className="border-orange-300 hover:bg-orange-50"
                    title="Use my current location"
                  >
                    {gettingLocation ? (
                      <Loader2 className="w-4 h-4 animate-spin text-orange-600" />
                    ) : (
                      <MapPin className="w-4 h-4 text-orange-600" />
                    )}
                  </Button>
                </div>
                {geocoding ? (
                  <p className="text-xs text-blue-600 mt-1 font-medium flex items-center gap-1">
                    <Loader2 className="w-3 h-3 animate-spin" />
                    Finding location...
                  </p>
                ) : formData.location_lat && formData.location_lng ? (
                  <p className="text-xs text-green-600 mt-1 font-medium">
                    ✓ Location confirmed
                  </p>
                ) : (
                  <p className="text-xs text-gray-600 mt-1">
                    Type your address and press Enter, or click <MapPin className="w-3 h-3 inline mx-1" /> to auto-detect
                  </p>
                )}
              </div>

              {/* Vehicle Selection */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Vehicle Information</h3>
                
                {vehicles.length > 0 && (
                  <div>
                    <Label>Select Your Vehicle</Label>
                    <Select value={selectedVehicleId} onValueChange={handleVehicleSelect}>
                      <SelectTrigger className="mt-2">
                        <SelectValue placeholder="Choose a saved vehicle or enter manually" />
                      </SelectTrigger>
                      <SelectContent>
                        {vehicles.map(vehicle => (
                          <SelectItem key={vehicle.id} value={vehicle.id}>
                            <div className="flex items-center gap-2">
                              <Car className="w-4 h-4" />
                              {vehicle.nickname || `${vehicle.year} ${vehicle.make} ${vehicle.model}`}
                              {vehicle.license_plate && ` - ${vehicle.license_plate}`}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="vehicle_make">Make</Label>
                    <Input
                      id="vehicle_make"
                      placeholder="e.g., Toyota"
                      value={formData.vehicle_make}
                      onChange={(e) => setFormData({...formData, vehicle_make: e.target.value})}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="vehicle_model">Model</Label>
                    <Input
                      id="vehicle_model"
                      placeholder="e.g., Camry"
                      value={formData.vehicle_model}
                      onChange={(e) => setFormData({...formData, vehicle_model: e.target.value})}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="vehicle_year">Year</Label>
                    <Input
                      id="vehicle_year"
                      placeholder="e.g., 2020"
                      value={formData.vehicle_year}
                      onChange={(e) => setFormData({...formData, vehicle_year: e.target.value})}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="vehicle_color">Color</Label>
                    <Input
                      id="vehicle_color"
                      placeholder="e.g., Silver"
                      value={formData.vehicle_color}
                      onChange={(e) => setFormData({...formData, vehicle_color: e.target.value})}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="space-y-3">
                <Button 
                  type="submit"
                  disabled={loading}
                  className="w-full text-white py-6 text-lg font-semibold hover:opacity-90"
                  style={{ backgroundColor: '#FF771D' }}
                >
                  {loading ? (
                    <div className="flex items-center justify-center gap-2">
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Submitting...</span>
                    </div>
                  ) : (
                    'Request Service'
                  )}
                </Button>
                

              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}