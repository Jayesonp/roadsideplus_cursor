import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  DollarSign, Users, TrendingUp, AlertCircle, 
  CheckCircle, Clock, Send, XCircle, Search, Filter
} from 'lucide-react';
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import BrandLogo from '../components/branding/BrandLogo';
import { createPageUrl } from '@/utils';

export default function AdminPartnerPayouts() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPayout, setSelectedPayout] = useState(null);
  const [statusFilter, setStatusFilter] = useState('all');
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        window.location.href = createPageUrl('Login');
        return;
      }
      const currentUser = await base44.auth.me();
      if (currentUser.role !== 'admin') {
        window.location.href = createPageUrl('CustomerDashboard');
        return;
      }
      setUser(currentUser);
    } catch (error) {
      window.location.href = createPageUrl('Login');
    }
  };

  const { data: payouts = [] } = useQuery({
    queryKey: ['all-payouts'],
    queryFn: async () => {
      return await base44.entities.PartnerPayout.list('-created_date');
    },
    enabled: !!user,
    refetchInterval: 10000
  });

  const { data: partners = [] } = useQuery({
    queryKey: ['all-partners'],
    queryFn: async () => {
      return await base44.entities.Partner.list();
    },
    enabled: !!user
  });

  const { data: serviceRequests = [] } = useQuery({
    queryKey: ['partner-service-requests'],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter({ status: 'completed' });
    },
    enabled: !!user
  });

  const generatePayouts = useMutation({
    mutationFn: async () => {
      const now = new Date();
      const periodStart = startOfMonth(subMonths(now, 1));
      const periodEnd = endOfMonth(subMonths(now, 1));

      const results = [];

      for (const partner of partners) {
        if (partner.status !== 'active' || !partner.stripe_payouts_enabled) continue;

        // Calculate commissions from service requests
        const partnerRequests = serviceRequests.filter(
          r => r.partner_id === partner.id &&
          new Date(r.completed_at) >= periodStart &&
          new Date(r.completed_at) <= periodEnd
        );

        const totalRevenue = partnerRequests.reduce((sum, r) => sum + (r.price || 0), 0);
        const commissionAmount = totalRevenue * (partner.commission_rate / 100);

        // Check if meets minimum payout threshold
        if (commissionAmount < (partner.minimum_payout_amount || 100)) continue;

        // Create payout record
        const payout = await base44.entities.PartnerPayout.create({
          partner_id: partner.id,
          period_start: periodStart.toISOString(),
          period_end: periodEnd.toISOString(),
          total_jobs: partnerRequests.length,
          total_revenue: totalRevenue,
          commission_rate: partner.commission_rate,
          commission_amount: commissionAmount,
          status: 'pending',
          payment_method: 'stripe_connect',
          job_ids: partnerRequests.map(r => r.id)
        });

        results.push(payout);
      }

      return results;
    },
    onSuccess: (results) => {
      queryClient.invalidateQueries({ queryKey: ['all-payouts'] });
      alert(`Generated ${results.length} payouts for processing`);
    }
  });

  const processPayoutMutation = useMutation({
    mutationFn: async ({ payoutId, status, notes }) => {
      const payout = payouts.find(p => p.id === payoutId);
      const updates = { status, notes };

      if (status === 'paid') {
        updates.paid_at = new Date().toISOString();
        updates.stripe_transfer_id = `tr_${Date.now()}`;

        // Update partner total commission
        const partner = partners.find(p => p.id === payout.partner_id);
        if (partner) {
          await base44.entities.Partner.update(partner.id, {
            total_commission_earned: (partner.total_commission_earned || 0) + payout.commission_amount
          });
        }
      }

      await base44.entities.PartnerPayout.update(payoutId, updates);

      // Notify partner
      const partner = partners.find(p => p.id === payout.partner_id);
      if (partner) {
        await base44.integrations.Core.SendEmail({
          to: partner.email,
          subject: status === 'paid' ? '💰 Commission Payment Processed' : 'Commission Payout Update',
          body: `Your commission payout of $${payout.commission_amount.toFixed(2)} has been ${status}.${notes ? `\n\nNotes: ${notes}` : ''}`
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-payouts'] });
      setSelectedPayout(null);
    }
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2" style={{ borderColor: '#FF771D' }}></div>
      </div>
    );
  }

  const filteredPayouts = payouts.filter(p => {
    const partner = partners.find(par => par.id === p.partner_id);
    const matchesSearch = !searchTerm || partner?.company_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const pendingPayouts = payouts.filter(p => p.status === 'pending');
  const totalPending = pendingPayouts.reduce((sum, p) => sum + p.commission_amount, 0);
  const totalPaid = payouts.filter(p => p.status === 'paid').reduce((sum, p) => sum + p.commission_amount, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <BrandLogo variant="icon" size="md" />
            <div>
              <h1 className="text-2xl font-bold">Partner Payouts</h1>
              <p className="text-sm text-gray-600">Manage commission payments</p>
            </div>
          </div>
          <Button
            onClick={() => generatePayouts.mutate()}
            disabled={generatePayouts.isLoading}
            className="text-white"
            style={{ backgroundColor: '#FF771D' }}
          >
            {generatePayouts.isLoading ? 'Generating...' : 'Generate Monthly Payouts'}
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Payouts</p>
                  <p className="text-3xl font-bold mt-1">{pendingPayouts.length}</p>
                </div>
                <Clock className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Amount</p>
                  <p className="text-3xl font-bold mt-1" style={{ color: '#FF771D' }}>
                    ${totalPending.toFixed(0)}
                  </p>
                </div>
                <DollarSign className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Paid</p>
                  <p className="text-3xl font-bold mt-1" style={{ color: '#3D692B' }}>
                    ${totalPaid.toFixed(0)}
                  </p>
                </div>
                <CheckCircle className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Payouts</p>
                  <p className="text-3xl font-bold mt-1">{payouts.length}</p>
                </div>
                <TrendingUp className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-wrap gap-4">
              <div className="flex-1 min-w-[200px]">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Search partners..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                {['all', 'pending', 'processing', 'paid', 'failed'].map(status => (
                  <Button
                    key={status}
                    variant={statusFilter === status ? 'default' : 'outline'}
                    onClick={() => setStatusFilter(status)}
                    size="sm"
                    style={statusFilter === status ? { backgroundColor: '#FF771D', color: 'white' } : {}}
                  >
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payouts List */}
        <Card>
          <CardHeader>
            <CardTitle>Payout Records ({filteredPayouts.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredPayouts.map(payout => {
                const partner = partners.find(p => p.id === payout.partner_id);
                return (
                  <Card key={payout.id} className="border">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: '#FF771D' }}>
                            {partner?.company_name?.[0]?.toUpperCase() || 'P'}
                          </div>
                          <div>
                            <p className="font-semibold">{partner?.company_name || 'Unknown'}</p>
                            <p className="text-sm text-gray-600">
                              {format(new Date(payout.period_start), 'MMM d')} - {format(new Date(payout.period_end), 'MMM d, yyyy')}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className={
                            payout.status === 'paid' ? 'bg-green-100 text-green-800' :
                            payout.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                            payout.status === 'failed' ? 'bg-red-100 text-red-800' :
                            'bg-yellow-100 text-yellow-800'
                          }>
                            {payout.status}
                          </Badge>
                          <p className="text-2xl font-bold mt-1" style={{ color: '#3D692B' }}>
                            ${payout.commission_amount.toFixed(2)}
                          </p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 mb-3 text-sm">
                        <div>
                          <p className="text-gray-600">Jobs</p>
                          <p className="font-semibold">{payout.total_jobs}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Revenue</p>
                          <p className="font-semibold">${payout.total_revenue?.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Rate</p>
                          <p className="font-semibold">{payout.commission_rate}%</p>
                        </div>
                      </div>

                      {payout.status === 'pending' && (
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => processPayoutMutation.mutate({ payoutId: payout.id, status: 'processing' })}
                            className="flex-1"
                            style={{ backgroundColor: '#FF771D', color: 'white' }}
                          >
                            <Send className="w-4 h-4 mr-2" />
                            Process
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedPayout(payout)}
                            className="flex-1"
                          >
                            Details
                          </Button>
                        </div>
                      )}

                      {payout.paid_at && (
                        <p className="text-xs text-gray-600 mt-2">
                          Paid on {format(new Date(payout.paid_at), 'MMM d, yyyy h:mm a')}
                        </p>
                      )}
                    </CardContent>
                  </Card>
                );
              })}

              {filteredPayouts.length === 0 && (
                <div className="text-center py-12">
                  <DollarSign className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <p className="text-gray-600">No payouts found</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payout Details Modal */}
      {selectedPayout && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <Card className="max-w-2xl w-full">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Payout Details</CardTitle>
              <Button variant="ghost" size="icon" onClick={() => setSelectedPayout(null)}>
                <XCircle className="w-5 h-5" />
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Partner</p>
                    <p className="font-semibold">{partners.find(p => p.id === selectedPayout.partner_id)?.company_name}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Amount</p>
                    <p className="font-semibold text-lg" style={{ color: '#3D692B' }}>
                      ${selectedPayout.commission_amount.toFixed(2)}
                    </p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => processPayoutMutation.mutate({ payoutId: selectedPayout.id, status: 'paid' })}
                    disabled={processPayoutMutation.isLoading}
                    className="flex-1 text-white"
                    style={{ backgroundColor: '#3D692B' }}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Mark as Paid
                  </Button>
                  <Button
                    onClick={() => processPayoutMutation.mutate({ payoutId: selectedPayout.id, status: 'failed', notes: 'Payment failed' })}
                    disabled={processPayoutMutation.isLoading}
                    variant="outline"
                    className="flex-1"
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Mark as Failed
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}