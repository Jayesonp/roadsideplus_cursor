import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Shield, MapPin, Clock, User, Phone, Battery, Signal, Camera, AlertTriangle, ArrowLeft, CheckCircle, X } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { format } from 'date-fns';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import SecurityChatPanel from '../components/security/SecurityChatPanel';

export default function SecurityIncidentDetail() {
  const [incidentId, setIncidentId] = useState(null);
  const [dispatcherNotes, setDispatcherNotes] = useState('');
  const queryClient = useQueryClient();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setIncidentId(params.get('id'));
  }, []);

  const { data: incident } = useQuery({
    queryKey: ['sos-incident', incidentId],
    queryFn: async () => {
      const incidents = await base44.entities.SOSIncident.list();
      return incidents.find(i => i.id === incidentId);
    },
    enabled: !!incidentId,
    refetchInterval: 3000
  });

  const { data: customer } = useQuery({
    queryKey: ['customer', incident?.customer_id],
    queryFn: async () => {
      const users = await base44.entities.User.list();
      return users.find(u => u.id === incident.customer_id);
    },
    enabled: !!incident?.customer_id
  });

  const { data: availableOfficers = [] } = useQuery({
    queryKey: ['available-officers'],
    queryFn: () => base44.entities.SecurityOfficer.filter({ status: 'available' }),
    enabled: !!incident
  });

  const { data: assignedOfficer } = useQuery({
    queryKey: ['assigned-officer', incident?.assigned_officer_id],
    queryFn: async () => {
      if (!incident?.assigned_officer_id) return null;
      const officers = await base44.entities.SecurityOfficer.list();
      return officers.find(o => o.id === incident.assigned_officer_id);
    },
    enabled: !!incident?.assigned_officer_id
  });

  const { data: events = [] } = useQuery({
    queryKey: ['incident-events', incidentId],
    queryFn: () => base44.entities.SecurityEvent.filter({ incident_id: incidentId }, '-created_date'),
    enabled: !!incidentId
  });

  const assignOfficer = useMutation({
    mutationFn: async (officerId) => {
      // Find nearest officer
      const officer = availableOfficers[0];
      if (!officer) throw new Error('No available officers');

      // Create offer
      await base44.entities.SOSIncident.update(incident.id, {
        current_offered_officer_id: officer.id,
        offer_expires_at: new Date(Date.now() + 30000).toISOString()
      });

      // Log event
      await base44.entities.SecurityEvent.create({
        incident_id: incident.id,
        officer_id: officer.id,
        event_type: 'officer_offered',
        event_data: { officer_badge: officer.officer_badge_number }
      });

      // Send notification to officer
      await base44.entities.Notification.create({
        user_id: officer.user_id,
        type: 'new_service_request',
        title: 'EMERGENCY SOS ALERT',
        message: `Critical incident requires immediate response. Click to accept.`,
        related_id: incident.id
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sos-incident'] });
      alert('Officer has been notified. Waiting for response...');
    }
  });

  const updateStatus = useMutation({
    mutationFn: async (newStatus) => {
      await base44.entities.SOSIncident.update(incident.id, { status: newStatus });
      await base44.entities.SecurityEvent.create({
        incident_id: incident.id,
        event_type: 'status_changed',
        event_data: { from: incident.status, to: newStatus }
      });
    },
    onSuccess: () => queryClient.invalidateQueries()
  });

  const escalateToPolice = useMutation({
    mutationFn: async () => {
      await base44.entities.SOSIncident.update(incident.id, { escalated_to_police: true });
      await base44.entities.SecurityEvent.create({
        incident_id: incident.id,
        event_type: 'escalated',
        event_data: { reason: 'Manual escalation by dispatcher' }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
      alert('Incident escalated to police. Emergency services notified.');
    }
  });

  const markFraudulent = useMutation({
    mutationFn: async () => {
      await base44.entities.SOSIncident.update(incident.id, {
        is_fraudulent: true,
        status: 'fraudulent'
      });
      await base44.entities.SecurityEvent.create({
        incident_id: incident.id,
        event_type: 'cancelled',
        event_data: { reason: 'Marked as fraudulent' }
      });
    },
    onSuccess: () => queryClient.invalidateQueries()
  });

  if (!incident) {
    return <div className="min-h-screen bg-gray-900 flex items-center justify-center text-white">Loading...</div>;
  }

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return '#E52C2D';
      case 'high': return '#FF771D';
      default: return '#FFA500';
    }
  };

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <Button
            variant="outline"
            className="text-white border-gray-600"
            onClick={() => window.location.href = createPageUrl('SecurityCommandCenter')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-8 h-8" style={{ color: getSeverityColor(incident.severity) }} />
            <div>
              <h1 className="text-xl font-bold text-white">SOS Incident Detail</h1>
              <p className="text-sm text-gray-400">ID: {incident.id}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Incident Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Status & Actions */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <span>Status & Actions</span>
                  <Badge style={{ backgroundColor: getSeverityColor(incident.severity), color: 'white' }}>
                    {incident.severity.toUpperCase()}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2 mb-4">
                  {!incident.assigned_officer_id && (
                    <Button
                      className="text-white"
                      style={{ backgroundColor: '#3D692B' }}
                      onClick={() => assignOfficer.mutate()}
                      disabled={availableOfficers.length === 0}
                    >
                      <Shield className="w-4 h-4 mr-2" />
                      Dispatch Officer
                    </Button>
                  )}
                  <Button
                    className="text-white"
                    style={{ backgroundColor: '#E52C2D' }}
                    onClick={() => escalateToPolice.mutate()}
                  >
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    Escalate to 911
                  </Button>
                  <Button
                    variant="outline"
                    className="text-white border-gray-600"
                    onClick={() => updateStatus.mutate('resolved')}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Mark Resolved
                  </Button>
                  <Button
                    variant="outline"
                    className="text-red-400 border-red-600"
                    onClick={() => markFraudulent.mutate()}
                  >
                    <X className="w-4 h-4 mr-2" />
                    Mark Fraudulent
                  </Button>
                </div>

                <div className="grid grid-cols-3 gap-3 text-sm">
                  <div>
                    <p className="text-gray-400">Status</p>
                    <p className="text-white font-semibold">{incident.status}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Time Elapsed</p>
                    <p className="text-white font-semibold">
                      {Math.floor((Date.now() - new Date(incident.created_date)) / 60000)} min
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400">Escalated</p>
                    <p className="text-white font-semibold">{incident.escalated_to_police ? 'Yes' : 'No'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Map */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <MapPin className="w-5 h-5" style={{ color: '#FF771D' }} />
                  Location
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[400px] rounded-lg overflow-hidden mb-4">
                  <MapContainer
                    center={[incident.location_lat, incident.location_lng]}
                    zoom={15}
                    style={{ height: '100%', width: '100%' }}
                  >
                    <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                    <Marker position={[incident.location_lat, incident.location_lng]}>
                      <Popup>SOS Location</Popup>
                    </Marker>
                  </MapContainer>
                </div>
                <p className="text-gray-300 text-sm">{incident.location_address}</p>
                <p className="text-gray-500 text-xs mt-1">
                  {incident.location_lat.toFixed(6)}, {incident.location_lng.toFixed(6)}
                </p>
              </CardContent>
            </Card>

            {/* Evidence */}
            {(incident.evidence_photos?.length > 0 || incident.evidence_videos?.length > 0) && (
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Camera className="w-5 h-5" style={{ color: '#FF771D' }} />
                    Evidence
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-3">
                    {incident.evidence_photos?.map((photo, idx) => (
                      <img key={idx} src={photo} alt="Evidence" className="rounded-lg w-full h-32 object-cover" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Timeline */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Event Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {events.map(event => (
                    <div key={event.id} className="flex gap-3 text-sm">
                      <div className="w-2 h-2 rounded-full mt-2 flex-shrink-0" style={{ backgroundColor: '#FF771D' }}></div>
                      <div className="flex-1">
                        <p className="text-white font-semibold">{event.event_type.replace(/_/g, ' ')}</p>
                        <p className="text-gray-400 text-xs">{format(new Date(event.created_date), 'MMM d, h:mm:ss a')}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right: Customer & Officer Info */}
          <div className="space-y-6">
            {/* Customer Info */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Customer
                </CardTitle>
              </CardHeader>
              <CardContent>
                {customer && (
                  <div className="space-y-3">
                    <div className="text-center mb-4">
                      <div className="w-20 h-20 rounded-full mx-auto mb-3 flex items-center justify-center" style={{ backgroundColor: '#FF771D' }}>
                        <User className="w-10 h-10 text-white" />
                      </div>
                      <p className="font-semibold text-white">{customer.full_name}</p>
                      <p className="text-sm text-gray-400">{customer.email}</p>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-gray-300">
                        <Phone className="w-4 h-4" />
                        <span>{customer.phone || 'N/A'}</span>
                      </div>
                      {incident.customer_device_battery && (
                        <div className="flex items-center gap-2 text-gray-300">
                          <Battery className="w-4 h-4" />
                          <span>{incident.customer_device_battery}%</span>
                        </div>
                      )}
                      {incident.customer_device_signal && (
                        <div className="flex items-center gap-2 text-gray-300">
                          <Signal className="w-4 h-4" />
                          <span>{incident.customer_device_signal}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Assigned Officer */}
            {assignedOfficer && (
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Shield className="w-5 h-5" style={{ color: '#3D692B' }} />
                    Assigned Officer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center" style={{ backgroundColor: '#3D692B' }}>
                      <Shield className="w-8 h-8 text-white" />
                    </div>
                    <p className="font-semibold text-white">Badge #{assignedOfficer.officer_badge_number}</p>
                    <p className="text-sm text-gray-400">{assignedOfficer.role}</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Customer Communication */}
            {customer && (
              <SecurityChatPanel
                companyId={incident.company_id}
                userId={localStorage.getItem('security_officer_id')}
                userRole={localStorage.getItem('security_role')}
                incidentId={incident.id}
                chatType="officer_customer"
                recipientId={customer.id}
              />
            )}

            {/* Dispatcher Notes */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Dispatcher Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={dispatcherNotes}
                  onChange={(e) => setDispatcherNotes(e.target.value)}
                  placeholder="Add notes about this incident..."
                  className="bg-gray-900 text-white border-gray-700 min-h-[120px]"
                />
                <Button
                  className="w-full mt-3 text-white"
                  style={{ backgroundColor: '#FF771D' }}
                  onClick={async () => {
                    await base44.entities.SOSIncident.update(incident.id, {
                      dispatcher_notes: dispatcherNotes
                    });
                    alert('Notes saved');
                  }}
                >
                  Save Notes
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}