import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Clock, CheckCircle, XCircle, AlertCircle, Navigation, Search } from 'lucide-react';
import { format } from 'date-fns';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import StatusBadge from '../components/common/StatusBadge';

export default function AdminDispatchMonitor() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [eventFilter, setEventFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const { data: events = [], refetch: refetchEvents } = useQuery({
    queryKey: ['admin-events'],
    queryFn: async () => {
      return await base44.entities.Event.list('-created_date', 200);
    },
    enabled: !!user,
    refetchInterval: 5000
  });

  const { data: serviceRequests = [], refetch: refetchRequests } = useQuery({
    queryKey: ['admin-requests'],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.list('-created_date', 100);
    },
    enabled: !!user,
    refetchInterval: 5000
  });

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <h2 className="text-xl font-bold mb-2">Access Denied</h2>
          <p className="text-gray-600">This page is only accessible to administrators.</p>
        </Card>
      </div>
    );
  }

  // Filter events
  const filteredEvents = events.filter(event => {
    if (eventFilter !== 'all' && event.type !== eventFilter) return false;
    if (searchTerm && !event.request_id?.includes(searchTerm)) return false;
    return true;
  });

  // Filter requests
  const filteredRequests = serviceRequests.filter(req => {
    if (statusFilter !== 'all' && req.status !== statusFilter) return false;
    if (searchTerm && !req.id?.includes(searchTerm) && !req.customer_id?.includes(searchTerm)) return false;
    return true;
  });

  // Event type configurations
  const eventConfig = {
    REQUEST_CREATED: { icon: AlertCircle, color: 'text-blue-600', bg: 'bg-blue-50' },
    PAYMENT_AUTHORIZED: { icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-50' },
    DISPATCH_STARTED: { icon: Navigation, color: 'text-orange-600', bg: 'bg-orange-50' },
    OFFER_SENT: { icon: Clock, color: 'text-yellow-600', bg: 'bg-yellow-50' },
    OFFER_ACCEPTED: { icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-50' },
    OFFER_REJECTED: { icon: XCircle, color: 'text-red-600', bg: 'bg-red-50' },
    OFFER_TIMEOUT: { icon: Clock, color: 'text-gray-600', bg: 'bg-gray-50' },
    STATUS_CHANGED: { icon: AlertCircle, color: 'text-blue-600', bg: 'bg-blue-50' },
    JOB_COMPLETED: { icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-50' },
    JOB_CANCELED: { icon: XCircle, color: 'text-red-600', bg: 'bg-red-50' }
  };

  // Calculate dispatch metrics
  const dispatchMetrics = {
    total: events.filter(e => e.type === 'DISPATCH_STARTED').length,
    offersSent: events.filter(e => e.type === 'OFFER_SENT').length,
    accepted: events.filter(e => e.type === 'OFFER_ACCEPTED').length,
    rejected: events.filter(e => e.type === 'OFFER_REJECTED').length,
    timeouts: events.filter(e => e.type === 'OFFER_TIMEOUT').length
  };

  const acceptanceRate = dispatchMetrics.offersSent > 0 
    ? Math.round((dispatchMetrics.accepted / dispatchMetrics.offersSent) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold mb-2">Dispatch Monitor</h1>
          <p className="text-sm opacity-90">Real-time event tracking and service request monitoring</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Metrics */}
        <div className="grid md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <p className="text-sm text-gray-500 mb-1">Total Dispatches</p>
              <p className="text-2xl font-bold">{dispatchMetrics.total}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <p className="text-sm text-gray-500 mb-1">Offers Sent</p>
              <p className="text-2xl font-bold">{dispatchMetrics.offersSent}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <p className="text-sm text-gray-500 mb-1">Accepted</p>
              <p className="text-2xl font-bold text-green-600">{dispatchMetrics.accepted}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <p className="text-sm text-gray-500 mb-1">Rejected/Timeout</p>
              <p className="text-2xl font-bold text-red-600">{dispatchMetrics.rejected + dispatchMetrics.timeouts}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <p className="text-sm text-gray-500 mb-1">Accept Rate</p>
              <p className="text-2xl font-bold" style={{ color: '#FF771D' }}>{acceptanceRate}%</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search by request ID or customer ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="events" className="space-y-6">
          <TabsList>
            <TabsTrigger value="events">Event Log</TabsTrigger>
            <TabsTrigger value="requests">Service Requests</TabsTrigger>
          </TabsList>

          <TabsContent value="events">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Dispatch Events</CardTitle>
                  <Select value={eventFilter} onValueChange={setEventFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Events</SelectItem>
                      <SelectItem value="DISPATCH_STARTED">Dispatch Started</SelectItem>
                      <SelectItem value="OFFER_SENT">Offer Sent</SelectItem>
                      <SelectItem value="OFFER_ACCEPTED">Accepted</SelectItem>
                      <SelectItem value="OFFER_REJECTED">Rejected</SelectItem>
                      <SelectItem value="OFFER_TIMEOUT">Timeout</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                  {filteredEvents.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">No events found</p>
                  ) : (
                    filteredEvents.map((event) => {
                      const config = eventConfig[event.type] || { icon: AlertCircle, color: 'text-gray-600', bg: 'bg-gray-50' };
                      const Icon = config.icon;
                      
                      return (
                        <div key={event.id} className={`p-4 rounded-lg border ${config.bg}`}>
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3 flex-1">
                              <Icon className={`w-5 h-5 mt-0.5 ${config.color}`} />
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className={`font-semibold ${config.color}`}>
                                    {event.type.replace(/_/g, ' ')}
                                  </span>
                                  <span className="text-xs text-gray-500">
                                    {format(new Date(event.created_date), 'MMM d, h:mm:ss a')}
                                  </span>
                                </div>
                                <div className="text-sm text-gray-600 space-y-1">
                                  {event.request_id && (
                                    <p>Request: <span className="font-mono text-xs">{event.request_id}</span></p>
                                  )}
                                  {event.technician_id && (
                                    <p>Technician: <span className="font-mono text-xs">{event.technician_id.slice(0, 12)}...</span></p>
                                  )}
                                  {event.payload && typeof event.payload === 'object' && Object.keys(event.payload).length > 0 && (
                                    <details className="mt-2">
                                      <summary className="cursor-pointer text-xs text-gray-500 hover:text-gray-700">
                                        View details
                                      </summary>
                                      <pre className="mt-2 p-2 bg-white rounded text-xs overflow-x-auto">
                                        {JSON.stringify(event.payload, null, 2)}
                                      </pre>
                                    </details>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="requests">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Service Requests</CardTitle>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="pending_dispatch">Pending Dispatch</SelectItem>
                      <SelectItem value="dispatched">Dispatched</SelectItem>
                      <SelectItem value="assigned">Assigned</SelectItem>
                      <SelectItem value="en_route">En Route</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-[600px] overflow-y-auto">
                  {filteredRequests.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">No requests found</p>
                  ) : (
                    filteredRequests.map((req) => (
                      <div key={req.id} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <ServiceTypeIcon type={req.service_type} />
                            <div>
                              <p className="font-semibold">
                                {req.service_type.replace(/_/g, ' ').toUpperCase()}
                              </p>
                              <p className="text-xs text-gray-500">
                                {format(new Date(req.created_date), 'MMM d, h:mm a')}
                              </p>
                            </div>
                          </div>
                          <StatusBadge status={req.status} />
                        </div>
                        
                        <div className="grid md:grid-cols-2 gap-2 text-sm text-gray-600">
                          <p>ID: <span className="font-mono text-xs">{req.id.slice(0, 12)}...</span></p>
                          <p>Customer: <span className="font-mono text-xs">{req.customer_id.slice(0, 12)}...</span></p>
                          {req.technician_id && (
                            <p>Technician: <span className="font-mono text-xs">{req.technician_id.slice(0, 12)}...</span></p>
                          )}
                          {req.location_address && (
                            <p className="col-span-2">Location: {req.location_address}</p>
                          )}
                        </div>
                        
                        {req.current_offered_technician_id && (
                          <div className="mt-3 p-2 bg-yellow-50 rounded border border-yellow-200">
                            <p className="text-xs text-yellow-800">
                              ⏱️ Offer pending to technician {req.current_offered_technician_id.slice(0, 12)}...
                              {req.offer_expires_at && ` (expires ${format(new Date(req.offer_expires_at), 'h:mm:ss a')})`}
                            </p>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}