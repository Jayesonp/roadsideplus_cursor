import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Star, User, Calendar, Flag, CheckCircle, XCircle, Eye, EyeOff, AlertCircle, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function AdminReviewManagement() {
  const [selectedReview, setSelectedReview] = useState(null);
  const [adminNotes, setAdminNotes] = useState('');
  const [actionDialogOpen, setActionDialogOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState(null);
  const queryClient = useQueryClient();

  const { data: flaggedReviews = [], isLoading: loadingFlagged } = useQuery({
    queryKey: ['admin-flagged-reviews'],
    queryFn: async () => {
      const reviews = await base44.entities.Rating.filter(
        { is_flagged: true },
        '-flagged_at'
      );

      // Get customer and technician details
      const reviewsWithDetails = await Promise.all(
        reviews.map(async (review) => {
          try {
            const [customers, technicians] = await Promise.all([
              base44.entities.User.filter({ id: review.customer_id }),
              base44.entities.User.filter({ id: review.technician_id })
            ]);
            return {
              ...review,
              customerName: customers[0]?.full_name || 'Customer',
              technicianName: technicians[0]?.full_name || 'Technician'
            };
          } catch {
            return {
              ...review,
              customerName: 'Customer',
              technicianName: 'Technician'
            };
          }
        })
      );

      return reviewsWithDetails;
    },
    refetchInterval: 60000,
    staleTime: 55000
  });

  const { data: allReviews = [], isLoading: loadingAll } = useQuery({
    queryKey: ['admin-all-reviews'],
    queryFn: async () => {
      const reviews = await base44.entities.Rating.filter({}, '-created_date', 100);

      const reviewsWithDetails = await Promise.all(
        reviews.map(async (review) => {
          try {
            const [customers, technicians] = await Promise.all([
              base44.entities.User.filter({ id: review.customer_id }),
              base44.entities.User.filter({ id: review.technician_id })
            ]);
            return {
              ...review,
              customerName: customers[0]?.full_name || 'Customer',
              technicianName: technicians[0]?.full_name || 'Technician'
            };
          } catch {
            return {
              ...review,
              customerName: 'Customer',
              technicianName: 'Technician'
            };
          }
        })
      );

      return reviewsWithDetails;
    }
  });

  const handleReviewAction = useMutation({
    mutationFn: async ({ reviewId, action, notes }) => {
      const updateData = {
        admin_reviewed: true,
        admin_action: action,
        admin_notes: notes
      };

      if (action === 'removed') {
        updateData.is_visible = false;
      }

      await base44.entities.Rating.update(reviewId, updateData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-flagged-reviews']);
      queryClient.invalidateQueries(['admin-all-reviews']);
      setSelectedReview(null);
      setAdminNotes('');
      setActionDialogOpen(false);
      setPendingAction(null);
    }
  });

  const unflagReview = useMutation({
    mutationFn: async (reviewId) => {
      await base44.entities.Rating.update(reviewId, {
        is_flagged: false,
        flag_reason: null,
        flagged_by: null,
        flagged_at: null
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-flagged-reviews']);
    }
  });

  const handleAction = (review, action) => {
    setSelectedReview(review);
    setPendingAction(action);
    setActionDialogOpen(true);
  };

  const confirmAction = () => {
    if (selectedReview && pendingAction) {
      handleReviewAction.mutate({
        reviewId: selectedReview.id,
        action: pendingAction,
        notes: adminNotes
      });
    }
  };

  const ReviewCard = ({ review, showActions = true }) => (
    <Card className={`${review.is_flagged && !review.admin_reviewed ? 'border-2 border-red-300 bg-red-50' : ''}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-gray-600" />
              </div>
              <div>
                <p className="font-semibold">{review.customerName}</p>
                <p className="text-sm text-gray-600">reviewed {review.technicianName}</p>
                <div className="flex items-center gap-1 mt-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-4 h-4 ${
                        star <= review.rating
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                  <span className="text-sm text-gray-600 ml-2">
                    {review.rating}/5
                  </span>
                </div>
              </div>
            </div>

            {review.comment && (
              <div className="bg-white rounded-lg p-3 mb-3">
                <p className="text-sm text-gray-700">{review.comment}</p>
              </div>
            )}

            {review.is_flagged && (
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-3">
                <div className="flex items-start gap-2">
                  <Flag className="w-4 h-4 text-orange-600 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-orange-900">Flagged as Inappropriate</p>
                    <p className="text-xs text-orange-700 mt-1">{review.flag_reason}</p>
                    {review.flagged_at && (
                      <p className="text-xs text-orange-600 mt-1">
                        Flagged on {format(new Date(review.flagged_at), 'MMM d, yyyy h:mm a')}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {review.admin_reviewed && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-blue-900">
                      Admin Action: {review.admin_action}
                    </p>
                    {review.admin_notes && (
                      <p className="text-xs text-blue-700 mt-1">{review.admin_notes}</p>
                    )}
                  </div>
                </div>
              </div>
            )}

            <div className="flex items-center gap-4 text-xs text-gray-500">
              <div className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {format(new Date(review.created_date), 'MMM d, yyyy h:mm a')}
              </div>
              {!review.is_visible && (
                <Badge variant="outline" className="text-red-600 border-red-300">
                  <EyeOff className="w-3 h-3 mr-1" />
                  Hidden
                </Badge>
              )}
            </div>
          </div>
        </div>

        {showActions && (
          <div className="flex gap-2 pt-4 border-t">
            {review.is_flagged && !review.admin_reviewed && (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1 border-green-300 text-green-700 hover:bg-green-50"
                  onClick={() => handleAction(review, 'approved')}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Approve
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1 border-red-300 text-red-700 hover:bg-red-50"
                  onClick={() => handleAction(review, 'removed')}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Remove
                </Button>
              </>
            )}
            {review.is_flagged && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => unflagReview.mutate(review.id)}
                disabled={unflagReview.isLoading}
              >
                Unflag
              </Button>
            )}
            {!review.is_visible && (
              <Button
                size="sm"
                variant="outline"
                className="border-blue-300 text-blue-700 hover:bg-blue-50"
                onClick={() => handleReviewAction.mutate({ reviewId: review.id, action: 'approved', notes: 'Restored by admin' })}
              >
                <Eye className="w-4 h-4 mr-2" />
                Restore
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );

  if (loadingFlagged) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-orange-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Review Management</h1>
          <p className="text-gray-600">Moderate customer reviews and handle flagged content</p>
        </div>

        <Tabs defaultValue="flagged" className="space-y-6">
          <TabsList>
            <TabsTrigger value="flagged" className="flex items-center gap-2">
              <Flag className="w-4 h-4" />
              Flagged Reviews
              {flaggedReviews.filter(r => !r.admin_reviewed).length > 0 && (
                <Badge variant="destructive" className="ml-2">
                  {flaggedReviews.filter(r => !r.admin_reviewed).length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="all">All Reviews</TabsTrigger>
            <TabsTrigger value="hidden">Hidden Reviews</TabsTrigger>
          </TabsList>

          <TabsContent value="flagged" className="space-y-4">
            {flaggedReviews.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
                  <h3 className="text-xl font-semibold mb-2">No Flagged Reviews</h3>
                  <p className="text-gray-600">All reviews are looking good!</p>
                </CardContent>
              </Card>
            ) : (
              <>
                <Card className="bg-orange-50 border-orange-200">
                  <CardContent className="p-4 flex items-center gap-3">
                    <AlertCircle className="w-5 h-5 text-orange-600" />
                    <div>
                      <p className="font-semibold text-orange-900">
                        {flaggedReviews.filter(r => !r.admin_reviewed).length} reviews need your attention
                      </p>
                      <p className="text-sm text-orange-700">
                        Review flagged content and take appropriate action
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {flaggedReviews.map((review) => (
                  <ReviewCard key={review.id} review={review} />
                ))}
              </>
            )}
          </TabsContent>

          <TabsContent value="all" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>All Customer Reviews</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {loadingAll ? (
                  <div className="text-center py-8">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto text-gray-400" />
                  </div>
                ) : allReviews.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No reviews yet
                  </div>
                ) : (
                  allReviews.map((review) => (
                    <ReviewCard key={review.id} review={review} showActions={false} />
                  ))
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="hidden" className="space-y-4">
            {allReviews.filter(r => !r.is_visible).length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Eye className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-xl font-semibold mb-2">No Hidden Reviews</h3>
                  <p className="text-gray-600">All reviews are currently visible</p>
                </CardContent>
              </Card>
            ) : (
              allReviews
                .filter(r => !r.is_visible)
                .map((review) => (
                  <ReviewCard key={review.id} review={review} />
                ))
            )}
          </TabsContent>
        </Tabs>

        {/* Action Dialog */}
        <AlertDialog open={actionDialogOpen} onOpenChange={setActionDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                {pendingAction === 'approved' ? 'Approve Review' : 'Remove Review'}
              </AlertDialogTitle>
              <AlertDialogDescription>
                {pendingAction === 'approved'
                  ? 'This review will be marked as approved and remain visible to users.'
                  : 'This review will be hidden from public view. You can restore it later if needed.'}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <div>
              <label className="text-sm font-semibold mb-2 block">Admin Notes (Optional)</label>
              <Textarea
                placeholder="Add any notes about this decision..."
                value={adminNotes}
                onChange={(e) => setAdminNotes(e.target.value)}
                className="min-h-[100px]"
              />
            </div>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => { setActionDialogOpen(false); setAdminNotes(''); }}>
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={confirmAction}
                disabled={handleReviewAction.isLoading}
                className={pendingAction === 'removed' ? 'bg-red-600 hover:bg-red-700' : ''}
              >
                {handleReviewAction.isLoading ? 'Processing...' : 'Confirm'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}