import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { ArrowLeft, BookOpen, MessageSquare, HelpCircle } from 'lucide-react';
import { createPageUrl } from '@/utils';
import KnowledgeBaseSearch from '../components/support/KnowledgeBaseSearch';
import CustomerSupportChat from '../components/customer/CustomerSupportChat';
import AISupportBot from '../components/support/AISupportBot';

export default function SupportCenter() {
  const [user, setUser] = useState(null);
  const [userType, setUserType] = useState('customer');

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
    
    // Check if technician
    const profiles = await base44.entities.TechnicianProfile.filter({ user_id: currentUser.id });
    if (profiles.length > 0) {
      setUserType('technician');
    }
  };

  const { data: conversations = [] } = useQuery({
    queryKey: ['support-conversations', user?.id],
    queryFn: async () => {
      return await base44.entities.SupportConversation.filter(
        { customer_id: user.id },
        '-last_message_at',
        50
      );
    },
    enabled: !!user
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-6xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20"
            onClick={() => window.location.href = createPageUrl(userType === 'technician' ? 'TechnicianDashboard' : 'CustomerDashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Support Center</h1>
            <p className="text-sm opacity-90">Find answers and get help</p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        <Tabs defaultValue="knowledge" className="w-full">
          <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-3 mb-6">
            <TabsTrigger value="knowledge">
              <BookOpen className="w-4 h-4 mr-2" />
              Knowledge Base
            </TabsTrigger>
            <TabsTrigger value="tickets">
              <MessageSquare className="w-4 h-4 mr-2" />
              My Tickets
            </TabsTrigger>
            <TabsTrigger value="faq">
              <HelpCircle className="w-4 h-4 mr-2" />
              FAQ
            </TabsTrigger>
          </TabsList>

          <TabsContent value="knowledge">
            <KnowledgeBaseSearch userType={userType} />
          </TabsContent>

          <TabsContent value="tickets">
            <CustomerSupportChat userId={user?.id} />
          </TabsContent>

          <TabsContent value="faq">
            <KnowledgeBaseSearch userType={userType} />
          </TabsContent>
        </Tabs>
      </div>

      {/* AI Support Bot */}
      <AISupportBot userId={user?.id} userType={userType} />
    </div>
  );
}