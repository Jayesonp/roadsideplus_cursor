import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { getCachedUser } from '@/components/utils/userCache';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Bell, MessageSquare, MapPin, CreditCard, Briefcase, Loader2, Plus, Battery, Zap, Smartphone } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import SavedPaymentMethods from '../components/payments/SavedPaymentMethods';
import AddPaymentMethodForm from '../components/payments/AddPaymentMethodForm';

export default function Settings() {
  const [user, setUser] = useState(null);
  const [isTechnician, setIsTechnician] = useState(false);
  const [showAddPayment, setShowAddPayment] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(null);
  const [pageLoading, setPageLoading] = useState(true);
  const [returnToService, setReturnToService] = useState(false);
  const [techProfile, setTechProfile] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
    
    const params = new URLSearchParams(window.location.search);
    if (params.get('addPayment') === 'true') {
      setShowAddPayment(true);
      setReturnToService(true);
    }
  }, []);

  const loadUser = async () => {
    try {
      setPageLoading(true);
      const currentUser = await getCachedUser();
      setUser(currentUser);
      
      const profiles = await base44.entities.TechnicianProfile.filter({ user_id: currentUser.id });
      setIsTechnician(profiles.length > 0);
      if (profiles.length > 0) {
        setTechProfile(profiles[0]);
      }
    } catch (error) {
      console.error('Load user error:', error);
    } finally {
      setPageLoading(false);
    }
  };

  const { data: preferences, isLoading } = useQuery({
    queryKey: ['notification-preferences', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const prefs = await base44.entities.NotificationPreferences.filter({ user_id: user.id });
      return prefs[0] || null;
    },
    enabled: !!user,
    staleTime: 300000, // 5 minutes
    gcTime: 600000, // 10 minutes
    retry: 1,
    refetchOnWindowFocus: false
  });

  const updatePreferences = useMutation({
    mutationFn: async (updates) => {
      if (preferences) {
        return await base44.entities.NotificationPreferences.update(preferences.id, updates);
      } else {
        return await base44.entities.NotificationPreferences.create({
          user_id: user.id,
          ...updates
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['notification-preferences', user?.id]);
    }
  });

  const togglePreference = (key, value) => {
    updatePreferences.mutate({ [key]: value });
  };

  const updateLocationAccuracy = useMutation({
    mutationFn: async (preference) => {
      return await base44.entities.TechnicianProfile.update(techProfile.id, {
        location_accuracy_preference: preference
      });
    },
    onSuccess: (updated) => {
      setTechProfile(updated);
    }
  });

  if (pageLoading || isLoading || !user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="text-white p-6 shadow-lg animate-pulse" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
          <div className="max-w-4xl mx-auto">
            <div className="h-8 w-48 bg-white/20 rounded"></div>
          </div>
        </div>
        <div className="max-w-4xl mx-auto p-6">
          <Card className="animate-pulse">
            <CardHeader>
              <div className="h-6 w-40 bg-gray-200 rounded"></div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="h-16 bg-gray-200 rounded"></div>
              <div className="h-16 bg-gray-200 rounded"></div>
              <div className="h-16 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const defaultPrefs = {
    new_messages: true,
    job_status_updates: true,
    technician_arrival: true,
    payment_reminders: true,
    new_job_assignments: true,
    push_enabled: true
  };

  const currentPrefs = preferences || defaultPrefs;

  // Memoized options moved outside or used with useMemo
  const filteredOptions = React.useMemo(() => {
    const notificationOptions = [
      {
        key: 'push_enabled',
        label: 'Push Notifications',
        description: 'Enable all push notifications',
        icon: Bell,
        roles: ['customer', 'technician']
      },
      {
        key: 'new_messages',
        label: 'New Messages',
        description: 'Get notified when you receive a new message',
        icon: MessageSquare,
        roles: ['customer', 'technician']
      },
      {
        key: 'job_status_updates',
        label: 'Job Status Updates',
        description: 'Receive updates when job status changes',
        icon: Briefcase,
        roles: ['customer', 'technician']
      },
      {
        key: 'technician_arrival',
        label: 'Technician Arrival',
        description: 'Know when the technician is on the way or has arrived',
        icon: MapPin,
        roles: ['customer']
      },
      {
        key: 'payment_reminders',
        label: 'Payment Reminders',
        description: 'Receive reminders for pending payments',
        icon: CreditCard,
        roles: ['customer']
      },
      {
        key: 'new_job_assignments',
        label: 'New Job Assignments',
        description: 'Get notified when new jobs are available',
        icon: Briefcase,
        roles: ['technician']
      }
    ];

    return notificationOptions.filter(option => 
      option.roles.includes(isTechnician ? 'technician' : 'customer')
    );
  }, [isTechnician]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20"
            onClick={() => window.location.href = createPageUrl(isTechnician ? 'TechnicianDashboard' : 'CustomerDashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Notification Settings</h1>
            <p className="text-sm opacity-90">Manage your notification preferences</p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5" style={{ color: '#FF771D' }} />
                  Notification Preferences
                </CardTitle>
                <p className="text-sm text-gray-600 mt-2">
                  Choose which notifications you want to receive. You can change these settings at any time.
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() => window.location.href = createPageUrl('NotificationSettings')}
              >
                View All Settings
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {filteredOptions.map((option) => {
              const Icon = option.icon;
              const isEnabled = currentPrefs[option.key];
              
              return (
                <div 
                  key={option.key}
                  className="flex items-start justify-between pb-6 border-b last:border-b-0 last:pb-0"
                >
                  <div className="flex items-start gap-4 flex-1">
                    <div className="mt-1">
                      <Icon className="w-5 h-5" style={{ color: isEnabled ? '#FF771D' : '#9CA3AF' }} />
                    </div>
                    <div className="flex-1">
                      <Label className="text-base font-semibold cursor-pointer">
                        {option.label}
                      </Label>
                      <p className="text-sm text-gray-600 mt-1">
                        {option.description}
                      </p>
                    </div>
                  </div>
                  <Switch
                    checked={isEnabled}
                    onCheckedChange={(checked) => togglePreference(option.key, checked)}
                    style={{ 
                      backgroundColor: isEnabled ? '#FF771D' : '#D1D5DB'
                    }}
                  />
                </div>
              );
            })}

            <div className="pt-4 border-t bg-blue-50 rounded-lg p-4">
              <p className="text-sm text-blue-900 font-semibold mb-2">💡 Tips:</p>
              <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
                <li>Turn off notifications to reduce distractions</li>
                <li>Keep "Job Status Updates" on to stay informed</li>
                <li>Enable push notifications for real-time alerts</li>
              </ul>
            </div>

            <Button
              className="w-full text-white hover:opacity-90"
              style={{ backgroundColor: '#3D692B' }}
              onClick={() => window.location.href = createPageUrl(isTechnician ? 'TechnicianDashboard' : 'CustomerDashboard')}
            >
              Done
            </Button>
          </CardContent>
        </Card>

        {/* Device Notification Permission */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-base">Browser Notification Permission</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              To receive push notifications, you need to allow notifications in your browser settings.
            </p>
            {typeof Notification !== 'undefined' && (
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-sm">
                  <span className="font-semibold">Status: </span>
                  <span className={`${
                    Notification.permission === 'granted' ? 'text-green-600' : 
                    Notification.permission === 'denied' ? 'text-red-600' : 'text-yellow-600'
                  }`}>
                    {Notification.permission === 'granted' ? '✓ Enabled' : 
                     Notification.permission === 'denied' ? '✗ Blocked' : '⚠ Not Set'}
                  </span>
                </p>
                {Notification.permission !== 'granted' && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-3"
                    style={{ borderColor: '#FF771D', color: '#FF771D' }}
                    onClick={async () => {
                      if (Notification.permission === 'denied') {
                        alert('Notifications are blocked. Please enable them in your browser settings:\n\n1. Click the lock/info icon in your address bar\n2. Find "Notifications" settings\n3. Change to "Allow"');
                        return;
                      }
                      const permission = await Notification.requestPermission();
                      if (permission === 'granted') {
                        new Notification('Notifications Enabled!', {
                          body: 'You will now receive push notifications from ROADSIDE+',
                          icon: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/691eeb450226ebe322bf3832/11a901661_icon_512_512.png'
                        });
                        window.location.reload();
                      }
                    }}
                  >
                    {Notification.permission === 'denied' ? 'How to Unblock' : 'Enable Notifications'}
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Location Accuracy - Technicians Only */}
        {isTechnician && techProfile && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" style={{ color: '#FF771D' }} />
                Location Accuracy
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Choose how your location is tracked. This affects battery usage and accuracy.
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-semibold mb-2 block">Accuracy Mode</Label>
                  <Select
                    value={techProfile.location_accuracy_preference || 'high_accuracy'}
                    onValueChange={(value) => updateLocationAccuracy.mutate(value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high_accuracy">
                        <div className="flex items-center gap-2">
                          <Zap className="w-4 h-4" />
                          <span>High Accuracy</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="battery_saving">
                        <div className="flex items-center gap-2">
                          <Battery className="w-4 h-4" />
                          <span>Battery Saving</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="device_only">
                        <div className="flex items-center gap-2">
                          <Smartphone className="w-4 h-4" />
                          <span>Device Only</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3 pt-3 border-t">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                    <div className="flex items-start gap-2 mb-1">
                      <Zap className="w-4 h-4 text-green-600 mt-0.5" />
                      <p className="text-sm font-semibold text-green-900">High Accuracy</p>
                    </div>
                    <p className="text-xs text-green-800 ml-6">
                      <strong>Uses:</strong> GPS + Wi-Fi + Cellular networks
                    </p>
                    <p className="text-xs text-green-700 ml-6 mt-1">
                      ✓ Most precise location<br />
                      ✓ Best for emergency response<br />
                      ✗ Higher battery usage
                    </p>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                    <div className="flex items-start gap-2 mb-1">
                      <Battery className="w-4 h-4 text-yellow-600 mt-0.5" />
                      <p className="text-sm font-semibold text-yellow-900">Battery Saving</p>
                    </div>
                    <p className="text-xs text-yellow-800 ml-6">
                      <strong>Uses:</strong> Wi-Fi + Cellular networks (no GPS)
                    </p>
                    <p className="text-xs text-yellow-700 ml-6 mt-1">
                      ✓ Lower battery consumption<br />
                      ✓ Good accuracy in urban areas<br />
                      ✗ Less accurate in rural areas
                    </p>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                    <div className="flex items-start gap-2 mb-1">
                      <Smartphone className="w-4 h-4 text-blue-600 mt-0.5" />
                      <p className="text-sm font-semibold text-blue-900">Device Only</p>
                    </div>
                    <p className="text-xs text-blue-800 ml-6">
                      <strong>Uses:</strong> GPS only
                    </p>
                    <p className="text-xs text-blue-700 ml-6 mt-1">
                      ✓ Works without internet<br />
                      ✓ Good for outdoor locations<br />
                      ✗ Slower initial fix<br />
                      ✗ May not work well indoors
                    </p>
                  </div>
                </div>

                <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mt-4">
                  <p className="text-sm text-orange-900 font-semibold mb-1">💡 Recommendation</p>
                  <p className="text-xs text-orange-800">
                    For emergency roadside service, we recommend <strong>High Accuracy</strong> to ensure customers can find you quickly and accurately.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Payment Methods - Customers Only */}
        {!isTechnician && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" style={{ color: '#FF771D' }} />
                Payment Methods
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Manage your saved payment methods. A payment method is required to request services.
              </p>
            </CardHeader>
            <CardContent>
              {showAddPayment ? (
                <div>
                  {returnToService && (
                    <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                      <p className="text-sm text-orange-800">
                        Add a payment method to continue requesting service
                      </p>
                    </div>
                  )}
                  <AddPaymentMethodForm
                    userId={user?.id}
                    onClose={() => {
                      setShowAddPayment(false);
                      if (returnToService) {
                        window.location.href = createPageUrl('CustomerDashboard');
                      }
                    }}
                    onSuccess={() => {
                      setShowAddPayment(false);
                      queryClient.invalidateQueries(['payment-methods']);
                      if (returnToService) {
                        setTimeout(() => {
                          window.location.href = createPageUrl('RequestService');
                        }, 500);
                      }
                    }}
                  />
                </div>
              ) : (
                <>
                  <SavedPaymentMethods
                    userId={user?.id}
                    selectedMethodId={selectedPaymentMethod?.id}
                    onSelectMethod={setSelectedPaymentMethod}
                  />
                  <Button
                    variant="outline"
                    className="w-full mt-4"
                    onClick={() => setShowAddPayment(true)}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Payment Method
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}