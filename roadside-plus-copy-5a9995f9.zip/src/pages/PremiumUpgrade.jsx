import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Check, Star, Crown, Zap, Shield } from 'lucide-react';
import { launchRevenueCatPaywall } from '../components/despia/DespiaSDK';
import { createPageUrl } from '@/utils';

export default function PremiumUpgrade() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpgrade = (offering) => {
    if (!user) return;
    launchRevenueCatPaywall(user.id, offering);
  };

  if (loading) return <div className="p-8 text-center">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50 pb-10">
      {/* Safe Area Top Spacer */}
      <div style={{ height: 'var(--safe-area-top)', backgroundColor: '#FF771D' }} />

      {/* Header */}
      <div className="bg-gradient-to-br from-orange-500 to-red-600 text-white p-8 text-center rounded-b-3xl shadow-lg mb-8">
        <div className="flex justify-center mb-4">
          <div className="p-3 bg-white/20 rounded-full backdrop-blur-sm">
            <Crown className="w-10 h-10 text-yellow-300" />
          </div>
        </div>
        <h1 className="text-3xl font-bold mb-2">Upgrade to Premium</h1>
        <p className="text-white/90 max-w-md mx-auto">
          Get priority service, exclusive discounts, and advanced features.
        </p>
      </div>

      <div className="max-w-4xl mx-auto px-4 space-y-6">
        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="p-6 text-center">
              <Zap className="w-8 h-8 text-orange-500 mx-auto mb-3" />
              <h3 className="font-bold mb-2">Priority Dispatch</h3>
              <p className="text-sm text-gray-600">Jump to the front of the queue for faster service.</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Shield className="w-8 h-8 text-blue-500 mx-auto mb-3" />
              <h3 className="font-bold mb-2">Extended Warranty</h3>
              <p className="text-sm text-gray-600">Double the warranty on all repairs and parts.</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Star className="w-8 h-8 text-yellow-500 mx-auto mb-3" />
              <h3 className="font-bold mb-2">Zero Booking Fees</h3>
              <p className="text-sm text-gray-600">Save $5 on every service booking.</p>
            </CardContent>
          </Card>
        </div>

        {/* Plans */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Monthly Plan */}
          <Card className="relative overflow-hidden border-2 border-transparent hover:border-orange-500 transition-all">
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>Monthly</span>
                <span className="text-2xl font-bold">$9.99<span className="text-sm font-normal text-gray-500">/mo</span></span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-green-500" /> Priority Dispatch</li>
                <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-green-500" /> No Booking Fees</li>
                <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-green-500" /> 5% Discount on Services</li>
              </ul>
              <Button 
                className="w-full bg-orange-600 hover:bg-orange-700 text-white"
                onClick={() => handleUpgrade('default')}
              >
                Subscribe Monthly
              </Button>
            </CardContent>
          </Card>

          {/* Annual Plan */}
          <Card className="relative overflow-hidden border-2 border-orange-500 shadow-xl transform scale-105 md:scale-100">
            <div className="absolute top-0 right-0 bg-yellow-400 text-yellow-900 text-xs font-bold px-3 py-1 rounded-bl-lg">
              BEST VALUE
            </div>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>Annual</span>
                <span className="text-2xl font-bold">$89.99<span className="text-sm font-normal text-gray-500">/yr</span></span>
              </CardTitle>
              <p className="text-sm text-green-600 font-medium">Save 25% compared to monthly</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-green-500" /> All Monthly Features</li>
                <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-green-500" /> <span className="font-bold">10% Discount</span> on Services</li>
                <li className="flex items-center gap-2 text-sm"><Check className="w-4 h-4 text-green-500" /> Free Annual Inspection</li>
              </ul>
              <Button 
                className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white shadow-lg hover:shadow-xl"
                onClick={() => handleUpgrade('annual_sale')}
              >
                Subscribe Annually
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-6">
          <p className="text-xs text-gray-400">
            Subscriptions auto-renew. Cancel anytime in your store settings.
            By subscribing, you agree to our Terms of Service and Privacy Policy.
          </p>
        </div>
      </div>

      {/* Safe Area Bottom Spacer */}
      <div style={{ height: 'var(--safe-area-bottom)' }} />
    </div>
  );
}