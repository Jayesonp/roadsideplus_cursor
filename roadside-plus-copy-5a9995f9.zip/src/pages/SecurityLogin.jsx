import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Shield, Lock, Mail, Building2, AlertCircle } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function SecurityLogin() {
  const [companyId, setCompanyId] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [twoFACode, setTwoFACode] = useState('');
  const [step, setStep] = useState('credentials');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Verify company exists
      const companies = await base44.entities.SecurityCompany.filter({ company_id: companyId });
      if (companies.length === 0) {
        setError('Invalid Company ID');
        setLoading(false);
        return;
      }

      const company = companies[0];
      if (company.status !== 'active') {
        setError('Company account is suspended');
        setLoading(false);
        return;
      }

      // Authenticate user
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        await base44.auth.redirectToLogin(createPageUrl('SecurityLogin'));
        return;
      }

      const user = await base44.auth.me();

      // Verify officer exists
      const officers = await base44.entities.SecurityOfficer.filter({
        user_id: user.id,
        company_id: company.id
      });

      if (officers.length === 0) {
        setError('You are not authorized to access this security portal');
        setLoading(false);
        return;
      }

      const officer = officers[0];

      // Log security event
      await base44.entities.SecurityEvent.create({
        company_id: company.id,
        officer_id: officer.id,
        event_type: 'officer_accepted',
        event_data: { action: 'login', email: user.email }
      });

      // Update last active
      await base44.entities.SecurityOfficer.update(officer.id, {
        last_active: new Date().toISOString()
      });

      // Store session
      localStorage.setItem('security_company_id', company.id);
      localStorage.setItem('security_officer_id', officer.id);
      localStorage.setItem('security_role', officer.role);

      // Redirect based on role
      if (officer.role === 'officer') {
        window.location.href = createPageUrl('SecurityOfficerDashboard');
      } else {
        window.location.href = createPageUrl('SecurityCommandCenter');
      }
    } catch (err) {
      setError('Login failed: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
         style={{ background: 'linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)' }}>
      <Card className="w-full max-w-md border-2" style={{ borderColor: '#FF771D' }}>
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 w-20 h-20 rounded-full flex items-center justify-center"
               style={{ backgroundColor: '#FF771D' }}>
            <Shield className="w-12 h-12 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold">Security Portal</CardTitle>
          <p className="text-gray-600 text-sm">ROADSIDE+ Command Center</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg flex items-center gap-2" style={{ backgroundColor: '#FEE2E2', color: '#E52C2D' }}>
                <AlertCircle className="w-5 h-5" />
                <p className="text-sm">{error}</p>
              </div>
            )}

            <div>
              <Label className="flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                Company ID
              </Label>
              <Input
                type="text"
                value={companyId}
                onChange={(e) => setCompanyId(e.target.value)}
                placeholder="SEC-XXXX-XXXX"
                required
                className="mt-1"
              />
            </div>

            <div>
              <Label className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Email
              </Label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="officer@security.com"
                required
                className="mt-1"
              />
            </div>

            <div>
              <Label className="flex items-center gap-2">
                <Lock className="w-4 h-4" />
                Password
              </Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="mt-1"
              />
            </div>

            <Button
              type="submit"
              className="w-full text-white font-semibold"
              style={{ backgroundColor: '#FF771D' }}
              disabled={loading}
            >
              {loading ? 'Authenticating...' : 'Secure Login'}
            </Button>

            <div className="text-center text-sm text-gray-600">
              <a href="#" className="hover:underline" style={{ color: '#FF771D' }}>Forgot Password?</a>
              {' • '}
              <a href="#" className="hover:underline" style={{ color: '#FF771D' }}>Reset Access</a>
            </div>
          </form>

          <div className="mt-6 pt-4 border-t text-center text-xs text-gray-500">
            <Lock className="w-4 h-4 inline mr-1" />
            Enterprise-grade security • All actions are logged
          </div>
        </CardContent>
      </Card>
    </div>
  );
}