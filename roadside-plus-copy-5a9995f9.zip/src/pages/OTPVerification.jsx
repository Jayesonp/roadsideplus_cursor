import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { createPageUrl } from '@/utils';
import { Mail, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import BrandLogo from '../components/branding/BrandLogo';
import { redirectToRoleDashboard } from '../components/auth/RoleBasedRouter';

export default function OTPVerification() {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const emailParam = params.get('email');
    
    if (emailParam) setEmail(emailParam);
    
    if (!emailParam) {
      setError('No email provided. Please register again.');
    }
  }, []);

  const handleVerify = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Step 1: Verify OTP
      // Backend expects otp_code
      await base44.auth.verifyOtp({
        email,
        token: otp,
        otp_code: otp,
        type: 'signup'
      });

      setSuccess(true);

      // Step 2: Wait for session to establish with retry mechanism
      let user = null;
      let attempts = 0;
      const maxAttempts = 5;
      
      while (!user && attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        try {
          user = await base44.auth.me();
          if (user) break;
        } catch (authError) {
          console.log(`Attempt ${attempts + 1}: Session not ready yet...`);
        }
        
        attempts++;
      }

      if (!user) {
        throw new Error('Session could not be established. Please try logging in.');
      }

      // Step 3: Redirect
      const params = new URLSearchParams(window.location.search);
      const redirectTo = params.get('redirect_to');

      if (redirectTo) {
        window.location.href = redirectTo;
      } else {
        await redirectToRoleDashboard();
      }
    } catch (err) {
      // Handle various error formats
      let errorMsg = 'Invalid code. Please try again.';
      
      if (typeof err === 'string') {
        errorMsg = err;
      } else if (err?.message) {
        errorMsg = err.message;
      } else if (err?.error) {
        errorMsg = typeof err.error === 'string' ? err.error : JSON.stringify(err.error);
      } else if (err?.response?.data?.message) {
        errorMsg = err.response.data.message;
      } else if (err?.response?.data?.error) {
        errorMsg = err.response.data.error;
      } else if (err?.detail) {
        errorMsg = typeof err.detail === 'string' ? err.detail : JSON.stringify(err.detail);
      } else if (typeof err === 'object') {
        errorMsg = JSON.stringify(err);
      }
      
      setError(errorMsg);
      setLoading(false);
      setSuccess(false);
    }
  };

  const handleResend = async () => {
    setError('');
    setResending(true);

    try {
      await base44.auth.resendOtp({
        email,
        type: 'signup'
      });
      
      alert('✅ New verification code sent! Please check your email.');
    } catch (err) {
      let errorMsg = 'Failed to resend code. Please try again.';
      
      if (typeof err === 'string') {
        errorMsg = err;
      } else if (err?.message) {
        errorMsg = err.message;
      } else if (err?.error) {
        errorMsg = typeof err.error === 'string' ? err.error : JSON.stringify(err.error);
      } else if (err?.response?.data?.message) {
        errorMsg = err.response.data.message;
      } else if (err?.response?.data?.error) {
        errorMsg = err.response.data.error;
      } else if (err?.detail) {
        errorMsg = typeof err.detail === 'string' ? err.detail : JSON.stringify(err.detail);
      } else if (typeof err === 'object') {
        errorMsg = JSON.stringify(err);
      }
      
      setError(errorMsg);
    } finally {
      setResending(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" 
        style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-8 pb-8">
            <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Email Verified!</h2>
            <p className="text-gray-600 mb-4">
              Redirecting you to your dashboard...
            </p>
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 mx-auto" 
                 style={{ borderColor: '#FF771D' }}></div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4" 
      style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
      <Card className="w-full max-w-md">
        <CardHeader className="text-center pb-4">
          <div className="flex justify-center mb-4">
            <BrandLogo variant="icon" size="xl" />
          </div>
          <CardTitle className="text-2xl font-bold">Verify Your Email</CardTitle>
          <p className="text-sm text-gray-500 mt-2">
            We've sent a verification code to
          </p>
          <p className="text-sm font-semibold" style={{ color: '#FF771D' }}>
            {email}
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleVerify} className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-start gap-2">
                <Mail className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-sm text-blue-900 font-semibold mb-1">
                    Check your email inbox
                  </p>
                  <p className="text-xs text-blue-800">
                    Enter the 6-digit code we sent to your email address
                  </p>
                </div>
              </div>
            </div>

            <div>
              <Input
                type="text"
                placeholder="Enter code"
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                className="text-center text-2xl tracking-widest font-bold"
                required
                autoFocus
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-red-800">{error}</p>
              </div>
            )}

            <Button
              type="submit"
              className="w-full text-white hover:opacity-90"
              style={{ backgroundColor: '#FF771D' }}
              disabled={loading || !otp}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Verifying...
                </>
              ) : (
                'Verify Email'
              )}
            </Button>

            <div className="text-center pt-2">
              <p className="text-sm text-gray-600 mb-2">
                Didn't receive the code?
              </p>
              <button
                type="button"
                onClick={handleResend}
                disabled={resending}
                className="text-sm font-semibold hover:underline"
                style={{ color: '#FF771D' }}
              >
                {resending ? 'Sending...' : 'Resend Code'}
              </button>
            </div>

            <div className="text-center pt-2 border-t">
              <p className="text-xs text-gray-500">
                Wrong email?{' '}
                <a
                  href={createPageUrl('RegisterSelection')}
                  className="font-semibold hover:underline"
                  style={{ color: '#FF771D' }}
                >
                  Register again
                </a>
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}