import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, CreditCard, CheckCircle2, Loader2 } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function Payment() {
  const [user, setUser] = useState(null);
  const [serviceId, setServiceId] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [paymentComplete, setPaymentComplete] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);

    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('serviceId');
    setServiceId(id);
  };

  const { data: serviceRequest } = useQuery({
    queryKey: ['service', serviceId],
    queryFn: () => base44.entities.ServiceRequest.filter({ id: serviceId }).then(r => r[0]),
    enabled: !!serviceId
  });

  const handlePayment = async () => {
    setProcessing(true);

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    // In production, integrate with Stripe/PayPal here
    // For now, just mark as paid
    try {
      await base44.entities.ServiceRequest.update(serviceId, {
        payment_status: 'paid',
        paid_at: new Date().toISOString()
      });

      // Create notification for technician
      if (serviceRequest?.technician_id) {
        await base44.entities.Notification.create({
          user_id: serviceRequest.technician_id,
          type: 'payment_received',
          title: 'Payment Received',
          message: `Payment of $${serviceRequest.price} has been received`,
          related_id: serviceId
        });
      }

      setPaymentComplete(true);
    } catch (error) {
      alert('Payment failed. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  if (!serviceRequest) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF771D' }} />
      </div>
    );
  }

  if (paymentComplete) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-md mx-auto">
          <Card className="text-center">
            <CardContent className="pt-12 pb-12">
              <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center"
                style={{ backgroundColor: '#3D692B' }}>
                <CheckCircle2 className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
              <p className="text-gray-600 mb-6">
                Your payment of ${serviceRequest.price} has been processed.
              </p>
              <Button
                onClick={() => window.location.href = createPageUrl('CustomerDashboard')}
                style={{ backgroundColor: '#FF771D' }}
                className="text-white hover:opacity-90"
              >
                Back to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-md mx-auto">
        <Button
          variant="ghost"
          onClick={() => window.history.back()}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Payment Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-600">Service Type:</span>
                <span className="font-semibold">
                  {serviceRequest.service_type?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Location:</span>
                <span className="font-semibold text-sm">
                  {serviceRequest.location_address || 'Service location'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Vehicle:</span>
                <span className="font-semibold">
                  {serviceRequest.vehicle_year} {serviceRequest.vehicle_make} {serviceRequest.vehicle_model}
                </span>
              </div>
              <div className="border-t pt-4 flex justify-between items-center">
                <span className="text-xl font-bold">Total Amount:</span>
                <span className="text-3xl font-bold" style={{ color: '#FF771D' }}>
                  ${serviceRequest.price}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <Button
              onClick={handlePayment}
              disabled={processing}
              className="w-full text-white hover:opacity-90 h-14 text-lg"
              style={{ backgroundColor: '#FF771D' }}
            >
              {processing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Processing Payment...
                </>
              ) : (
                <>
                  <CreditCard className="w-5 h-5 mr-2" />
                  Proceed to Pay
                </>
              )}
            </Button>
            <p className="text-xs text-center text-gray-500 mt-4">
              Secure payment powered by ROADSIDEPLUS
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}