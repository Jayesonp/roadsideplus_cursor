import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { 
  Bell, BellOff, Smartphone, CheckCircle, 
  AlertCircle, MessageSquare, Car, MapPin, FileText
} from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function NotificationSettings() {
  const [user, setUser] = useState(null);
  const [isTechnician, setIsTechnician] = useState(false);
  const [pushSupported, setPushSupported] = useState(false);
  const [pushEnabled, setPushEnabled] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
    checkPushSupport();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      const techProfiles = await base44.entities.TechnicianProfile.filter({ 
        user_id: currentUser.id 
      });
      setIsTechnician(techProfiles.length > 0);
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const checkPushSupport = () => {
    const supported = 'Notification' in window && 'serviceWorker' in navigator;
    setPushSupported(supported);
    if (supported) {
      setPushEnabled(Notification.permission === 'granted');
    }
  };

  // Fetch notification preferences
  const { data: preferences } = useQuery({
    queryKey: ['notification-preferences', user?.id],
    queryFn: async () => {
      const prefs = await base44.entities.NotificationPreferences.filter({
        user_id: user.id
      });
      return prefs.length > 0 ? prefs[0] : null;
    },
    enabled: !!user
  });

  // Update preferences mutation
  const updatePreferences = useMutation({
    mutationFn: async (updates) => {
      if (preferences) {
        return await base44.entities.NotificationPreferences.update(
          preferences.id, 
          updates
        );
      } else {
        return await base44.entities.NotificationPreferences.create({
          user_id: user.id,
          ...updates
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['notification-preferences']);
    }
  });

  const requestPushPermission = async () => {
    if (!pushSupported) return;
    
    try {
      const permission = await Notification.requestPermission();
      setPushEnabled(permission === 'granted');
      
      if (permission === 'granted') {
        await updatePreferences.mutateAsync({ push_enabled: true });
      }
    } catch (error) {
      console.error('Error requesting push permission:', error);
    }
  };

  const togglePreference = (key) => {
    const currentValue = preferences?.[key] ?? true;
    updatePreferences.mutate({ [key]: !currentValue });
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2" 
             style={{ borderColor: '#FF771D' }}></div>
      </div>
    );
  }

  const technicianSettings = [
    {
      key: 'new_job_assignments',
      title: 'New Job Assignments',
      description: 'Get notified when a new job is assigned to you',
      icon: Car,
      color: '#FF771D',
      critical: true
    },
    {
      key: 'job_status_updates',
      title: 'Job Status Updates',
      description: 'Alerts when job status changes or requires action',
      icon: AlertCircle,
      color: '#E52C2D'
    },
    {
      key: 'new_messages',
      title: 'New Messages',
      description: 'Customer messages and chat notifications',
      icon: MessageSquare,
      color: '#3D692B'
    },
    {
      key: 'payment_reminders',
      title: 'Payment Updates',
      description: 'Payment received and earning notifications',
      icon: CheckCircle,
      color: '#3D692B'
    }
  ];

  const customerSettings = [
    {
      key: 'technician_arrival',
      title: 'Technician En Route',
      description: 'When technician starts journey to your location',
      icon: MapPin,
      color: '#FF771D',
      critical: true
    },
    {
      key: 'technician_arrival',
      title: 'Technician Arrived',
      description: 'When technician arrives at your location',
      icon: CheckCircle,
      color: '#3D692B',
      critical: true
    },
    {
      key: 'job_status_updates',
      title: 'Service Updates',
      description: 'Status changes and job completion alerts',
      icon: AlertCircle,
      color: '#E52C2D'
    },
    {
      key: 'new_messages',
      title: 'New Messages',
      description: 'Messages from your technician',
      icon: MessageSquare,
      color: '#3D692B'
    },
    {
      key: 'payment_reminders',
      title: 'Payment Reminders',
      description: 'Payment due and invoice ready notifications',
      icon: FileText,
      color: '#FF771D'
    }
  ];

  const settings = isTechnician ? technicianSettings : customerSettings;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <Button
            variant="outline"
            onClick={() => window.location.href = createPageUrl('Settings')}
            className="mb-4"
          >
            ← Back to Settings
          </Button>
          <h1 className="text-3xl font-bold mb-2">Notification Preferences</h1>
          <p className="text-gray-600">
            Customize how and when you receive notifications
          </p>
        </div>

        {/* Push Notifications Card */}
        <Card className="mb-6 border-2" style={{ borderColor: '#FF771D' }}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Smartphone className="w-5 h-5" style={{ color: '#FF771D' }} />
              Push Notifications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="font-semibold mb-1">Browser Push Notifications</p>
                <p className="text-sm text-gray-600">
                  Receive notifications even when the app is closed
                </p>
                {!pushSupported && (
                  <p className="text-xs text-red-600 mt-1">
                    Push notifications are not supported in your browser
                  </p>
                )}
              </div>
              <div className="flex items-center gap-3">
                {pushEnabled ? (
                  <Badge className="bg-green-600">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Enabled
                  </Badge>
                ) : pushSupported ? (
                  <Button
                    onClick={requestPushPermission}
                    style={{ backgroundColor: '#FF771D' }}
                    className="text-white"
                  >
                    Enable Push
                  </Button>
                ) : (
                  <Badge variant="outline" className="text-gray-500">
                    Not Supported
                  </Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notification Types */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" style={{ color: '#FF771D' }} />
              Notification Types
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {settings.map((setting) => {
                const Icon = setting.icon;
                const isEnabled = preferences?.[setting.key] ?? true;
                
                return (
                  <div 
                    key={setting.key}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-start gap-3 flex-1">
                      <div 
                        className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: setting.color + '20' }}
                      >
                        <Icon className="w-5 h-5" style={{ color: setting.color }} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-semibold">{setting.title}</p>
                          {setting.critical && (
                            <Badge variant="outline" className="text-xs">
                              Critical
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600">{setting.description}</p>
                      </div>
                    </div>
                    <Switch
                      checked={isEnabled}
                      onCheckedChange={() => togglePreference(setting.key)}
                      disabled={updatePreferences.isLoading}
                    />
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Info Card */}
        <Card className="mt-6 bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-900">
                <p className="font-semibold mb-1">About Notifications</p>
                <ul className="space-y-1 text-xs">
                  <li>• Critical notifications (marked above) are highly recommended to stay enabled</li>
                  <li>• Push notifications require browser permission and work even when app is closed</li>
                  <li>• In-app notifications will still appear regardless of push notification settings</li>
                  <li>• You can change these preferences at any time</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Test Notification Button */}
        <Card className="mt-6">
          <CardContent className="pt-6">
            <Button
              onClick={() => {
                if (pushEnabled) {
                  new Notification('Test Notification', {
                    body: 'Your notifications are working perfectly!',
                    icon: '/icon-192.png',
                    badge: '/icon-192.png'
                  });
                } else {
                  alert('Please enable push notifications first');
                }
              }}
              variant="outline"
              className="w-full"
            >
              <Bell className="w-4 h-4 mr-2" />
              Send Test Notification
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}