import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Sparkles, TrendingUp, TrendingDown, AlertCircle, Loader2, RefreshCw } from 'lucide-react';

export default function FeedbackAnalytics() {
  const [analysis, setAnalysis] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);

  const { data: ratings = [] } = useQuery({
    queryKey: ['all-ratings'],
    queryFn: () => base44.entities.Rating.list('-created_date', 200)
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['all-messages'],
    queryFn: () => base44.entities.Message.list('-created_date', 200)
  });

  useEffect(() => {
    if (ratings.length > 0 || messages.length > 0) {
      analyzeFeedback();
    }
  }, [ratings.length, messages.length]);

  const analyzeFeedback = async () => {
    setAnalyzing(true);
    try {
      const feedbackData = {
        ratings: ratings.map(r => ({
          rating: r.rating,
          comment: r.comment,
          date: r.created_date
        })),
        messages: messages.map(m => ({
          message: m.message,
          sender_role: m.sender_role,
          date: m.created_date
        })).filter(m => m.sender_role === 'customer')
      };

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this customer feedback data from a roadside assistance service and provide comprehensive insights.

Ratings (1-5 scale): ${JSON.stringify(feedbackData.ratings.slice(0, 50))}
Customer Messages: ${JSON.stringify(feedbackData.messages.slice(0, 50))}

Provide a detailed analysis including:
1. Overall sentiment breakdown (positive %, neutral %, negative %)
2. Top 5 common themes with frequency counts
3. Top 3 areas of concern requiring immediate attention
4. Top 3 strengths to maintain
5. Specific actionable recommendations for management
6. Technician performance insights
7. Trends over time if patterns emerge

Be specific and data-driven.`,
        response_json_schema: {
          type: 'object',
          properties: {
            sentiment_breakdown: {
              type: 'object',
              properties: {
                positive: { type: 'number' },
                neutral: { type: 'number' },
                negative: { type: 'number' }
              }
            },
            common_themes: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  theme: { type: 'string' },
                  frequency: { type: 'number' },
                  sentiment: { type: 'string' },
                  description: { type: 'string' }
                }
              }
            },
            areas_of_concern: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  issue: { type: 'string' },
                  severity: { type: 'string' },
                  impact: { type: 'string' },
                  recommendation: { type: 'string' }
                }
              }
            },
            strengths: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  strength: { type: 'string' },
                  impact: { type: 'string' },
                  maintain_strategy: { type: 'string' }
                }
              }
            },
            management_recommendations: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  action: { type: 'string' },
                  priority: { type: 'string' },
                  expected_outcome: { type: 'string' }
                }
              }
            },
            technician_insights: {
              type: 'object',
              properties: {
                overall_performance: { type: 'string' },
                training_needs: { type: 'array', items: { type: 'string' } },
                recognition_opportunities: { type: 'array', items: { type: 'string' } }
              }
            },
            summary: { type: 'string' }
          }
        }
      });

      setAnalysis(result);
    } catch (error) {
      console.error('Error analyzing feedback:', error);
    } finally {
      setAnalyzing(false);
    }
  };

  const getSentimentColor = (sentiment) => {
    switch (sentiment?.toLowerCase()) {
      case 'positive': return 'bg-green-100 text-green-800 border-green-300';
      case 'negative': return 'bg-red-100 text-red-800 border-red-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Feedback Analytics</h1>
              <p className="text-gray-600">AI-powered insights from customer feedback</p>
            </div>
            <Button
              onClick={analyzeFeedback}
              disabled={analyzing}
              className="text-white hover:opacity-90"
              style={{ backgroundColor: '#FF771D' }}
            >
              {analyzing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh Analysis
                </>
              )}
            </Button>
          </div>
        </div>

        {analyzing && !analysis ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Loader2 className="w-12 h-12 animate-spin mb-4" style={{ color: '#FF771D' }} />
              <p className="text-gray-600">Analyzing feedback data...</p>
            </CardContent>
          </Card>
        ) : analysis ? (
          <>
            {/* Summary */}
            <Card className="mb-6 border-2" style={{ borderColor: '#FF771D' }}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5" style={{ color: '#FF771D' }} />
                  Executive Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">{analysis.summary}</p>
              </CardContent>
            </Card>

            {/* Sentiment Breakdown */}
            <div className="grid md:grid-cols-3 gap-6 mb-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">Positive</span>
                    <TrendingUp className="w-5 h-5 text-green-600" />
                  </div>
                  <div className="text-3xl font-bold text-green-600">
                    {analysis.sentiment_breakdown?.positive?.toFixed(1)}%
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">Neutral</span>
                    <div className="w-5 h-5 rounded-full bg-gray-400" />
                  </div>
                  <div className="text-3xl font-bold text-gray-600">
                    {analysis.sentiment_breakdown?.neutral?.toFixed(1)}%
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">Negative</span>
                    <TrendingDown className="w-5 h-5 text-red-600" />
                  </div>
                  <div className="text-3xl font-bold text-red-600">
                    {analysis.sentiment_breakdown?.negative?.toFixed(1)}%
                  </div>
                </CardContent>
              </Card>
            </div>

            <Tabs defaultValue="themes" className="space-y-6">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="themes">Themes</TabsTrigger>
                <TabsTrigger value="concerns">Concerns</TabsTrigger>
                <TabsTrigger value="strengths">Strengths</TabsTrigger>
                <TabsTrigger value="actions">Actions</TabsTrigger>
                <TabsTrigger value="technicians">Technicians</TabsTrigger>
              </TabsList>

              {/* Common Themes */}
              <TabsContent value="themes">
                <Card>
                  <CardHeader>
                    <CardTitle>Common Themes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {analysis.common_themes?.map((theme, idx) => (
                        <div key={idx} className="border rounded-lg p-4">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-semibold text-lg">{theme.theme}</h4>
                            <div className="flex items-center gap-2">
                              <Badge className={getSentimentColor(theme.sentiment)}>
                                {theme.sentiment}
                              </Badge>
                              <Badge variant="outline">{theme.frequency} mentions</Badge>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600">{theme.description}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Areas of Concern */}
              <TabsContent value="concerns">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <AlertCircle className="w-5 h-5 text-red-600" />
                      Areas Requiring Attention
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {analysis.areas_of_concern?.map((concern, idx) => (
                        <div key={idx} className="border-l-4 border-red-500 bg-red-50 rounded-r-lg p-4">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-semibold text-red-900">{concern.issue}</h4>
                            <Badge className="bg-red-600 text-white">{concern.severity}</Badge>
                          </div>
                          <p className="text-sm text-red-800 mb-2">
                            <strong>Impact:</strong> {concern.impact}
                          </p>
                          <p className="text-sm text-red-900 bg-white rounded p-2">
                            <strong>Recommendation:</strong> {concern.recommendation}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Strengths */}
              <TabsContent value="strengths">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-green-600" />
                      Key Strengths
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {analysis.strengths?.map((strength, idx) => (
                        <div key={idx} className="border-l-4 border-green-500 bg-green-50 rounded-r-lg p-4">
                          <h4 className="font-semibold text-green-900 mb-2">{strength.strength}</h4>
                          <p className="text-sm text-green-800 mb-2">
                            <strong>Impact:</strong> {strength.impact}
                          </p>
                          <p className="text-sm text-green-900 bg-white rounded p-2">
                            <strong>Maintain:</strong> {strength.maintain_strategy}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Management Actions */}
              <TabsContent value="actions">
                <Card>
                  <CardHeader>
                    <CardTitle>Recommended Actions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {analysis.management_recommendations?.map((rec, idx) => (
                        <div key={idx} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-semibold">{rec.action}</h4>
                            <Badge className={getPriorityColor(rec.priority)}>
                              {rec.priority} Priority
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">
                            <strong>Expected Outcome:</strong> {rec.expected_outcome}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Technician Insights */}
              <TabsContent value="technicians">
                <Card>
                  <CardHeader>
                    <CardTitle>Technician Performance Insights</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <h4 className="font-semibold mb-2">Overall Performance</h4>
                      <p className="text-gray-700">{analysis.technician_insights?.overall_performance}</p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Training Needs</h4>
                      <ul className="space-y-2">
                        {analysis.technician_insights?.training_needs?.map((need, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm">
                            <AlertCircle className="w-4 h-4 text-orange-500 mt-0.5 flex-shrink-0" />
                            <span>{need}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Recognition Opportunities</h4>
                      <ul className="space-y-2">
                        {analysis.technician_insights?.recognition_opportunities?.map((opp, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm">
                            <TrendingUp className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>{opp}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        ) : (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-gray-500">No analysis available yet</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}