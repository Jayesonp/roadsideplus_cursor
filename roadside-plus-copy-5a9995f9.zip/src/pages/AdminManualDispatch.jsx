import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { AlertCircle, Search, MapPin, User, Phone, Loader2, RefreshCw } from 'lucide-react';
import { createPageUrl } from '@/utils';
import IntelligentDispatchSuggestions from '../components/dispatch/IntelligentDispatchSuggestions';
import StatusBadge from '../components/common/StatusBadge';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import { format } from 'date-fns';

export default function AdminManualDispatch() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRequest, setSelectedRequest] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const { data: pendingRequests = [], isLoading } = useQuery({
    queryKey: ['pending-dispatch-requests'],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter(
        { status: ['pending_dispatch', 'dispatched'] },
        '-created_date'
      );
    },
    refetchInterval: 5000
  });

  const { data: allTechnicians = [] } = useQuery({
    queryKey: ['all-technicians-dispatch'],
    queryFn: async () => {
      const profiles = await base44.entities.TechnicianProfile.list();
      const users = await base44.entities.User.list();
      return profiles.map(profile => ({
        ...profile,
        name: users.find(u => u.id === profile.user_id)?.full_name || 'Technician'
      }));
    }
  });

  const assignTechnician = useMutation({
    mutationFn: async ({ request, technician }) => {
      const expiresAt = new Date(Date.now() + 60000).toISOString();
      const eta = new Date(Date.now() + 30 * 60000).toISOString();

      // Update service request
      await base44.entities.ServiceRequest.update(request.id, {
        technician_id: technician.user_id,
        current_offered_technician_id: technician.user_id,
        status: 'assigned',
        offer_expires_at: expiresAt,
        estimated_arrival: eta
      });

      // Update technician availability
      await base44.entities.TechnicianProfile.update(technician.id, {
        availability_status: 'on_job'
      });

      // Log event
      await base44.entities.Event.create({
        type: 'OFFER_SENT',
        request_id: request.id,
        customer_id: request.customer_id,
        technician_id: technician.user_id,
        payload: {
          assigned_by: 'admin_manual',
          admin_id: user.id,
          expires_at: expiresAt
        }
      });

      // Notify technician with urgent push
      await base44.entities.Notification.create({
        user_id: technician.user_id,
        type: 'new_service_request',
        title: '🚨 New Job Assigned',
        message: `Admin assigned you to a ${request.service_type.replace(/_/g, ' ')} job. Please respond immediately.`,
        related_id: request.id
      });

      // Immediate push for manual assignments
      if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
        new Notification('🚨 New Job Assigned', {
          body: `Admin assigned: ${request.service_type.replace(/_/g, ' ')}`,
          icon: '/icon-192.png',
          tag: `manual-assign-${request.id}`,
          requireInteraction: true,
          vibrate: [300, 100, 300, 100, 300]
        });
      }

      // Notify customer
      await base44.entities.Notification.create({
        user_id: request.customer_id,
        type: 'technician_assigned',
        title: '✅ Technician Assigned',
        message: `A technician has been assigned to your service request.`,
        related_id: request.id
      });

      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['pending-dispatch-requests']);
      setSelectedRequest(null);
      alert('Technician assigned successfully!');
    }
  });

  const reassignJob = useMutation({
    mutationFn: async ({ request, newTechnician, oldTechnician }) => {
      // Update service request
      await base44.entities.ServiceRequest.update(request.id, {
        technician_id: newTechnician.user_id,
        current_offered_technician_id: newTechnician.user_id,
        status: 'assigned'
      });

      // Free up old technician
      if (oldTechnician) {
        await base44.entities.TechnicianProfile.update(oldTechnician.id, {
          availability_status: 'available'
        });

        // Notify old technician
        await base44.entities.Notification.create({
          user_id: oldTechnician.user_id,
          type: 'job_completed',
          title: 'Job Reassigned',
          message: 'This job has been reassigned to another technician.',
          related_id: request.id
        });
      }

      // Update new technician
      await base44.entities.TechnicianProfile.update(newTechnician.id, {
        availability_status: 'on_job'
      });

      // Log event
      await base44.entities.Event.create({
        type: 'JOB_REASSIGNED',
        request_id: request.id,
        customer_id: request.customer_id,
        technician_id: newTechnician.user_id,
        payload: {
          previous_technician: oldTechnician?.user_id,
          reassigned_by: 'admin',
          admin_id: user.id
        }
      });

      // Notify new technician with urgent push
      await base44.entities.Notification.create({
        user_id: newTechnician.user_id,
        type: 'new_service_request',
        title: '🔄 Job Reassigned to You',
        message: `You've been assigned a ${request.service_type.replace(/_/g, ' ')} job.`,
        related_id: request.id
      });

      // Immediate push for reassignments
      if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
        new Notification('🔄 Job Reassigned to You', {
          body: `New assignment: ${request.service_type.replace(/_/g, ' ')}`,
          icon: '/icon-192.png',
          tag: `reassign-${request.id}`,
          requireInteraction: true,
          vibrate: [200, 100, 200, 100, 200]
        });
      }

      // Notify customer
      await base44.entities.Notification.create({
        user_id: request.customer_id,
        type: 'technician_assigned',
        title: 'Technician Updated',
        message: 'A new technician has been assigned to your service.',
        related_id: request.id
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['pending-dispatch-requests']);
      setSelectedRequest(null);
      alert('Job reassigned successfully!');
    }
  });

  const filteredRequests = pendingRequests.filter(req =>
    req.service_type?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.location_address?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="p-8 text-center">
          <AlertCircle className="w-16 h-16 mx-auto mb-4" style={{ color: '#E52C2D' }} />
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-gray-600">Admin access required</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold mb-2">Manual Job Dispatch</h1>
          <p className="text-sm opacity-90">Assign and reassign technicians to service requests</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Left: Pending Requests */}
          <div>
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Pending Requests ({filteredRequests.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative mb-4">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Search by service type or location..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>

                {isLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF771D' }} />
                  </div>
                ) : filteredRequests.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No pending dispatch requests
                  </div>
                ) : (
                  <div className="space-y-3 max-h-[600px] overflow-y-auto">
                    {filteredRequests.map(request => (
                      <div
                        key={request.id}
                        onClick={() => setSelectedRequest(request)}
                        className={`border rounded-lg p-4 cursor-pointer transition-all ${
                          selectedRequest?.id === request.id
                            ? 'border-2 shadow-md'
                            : 'hover:shadow-md'
                        }`}
                        style={selectedRequest?.id === request.id ? { borderColor: '#FF771D' } : {}}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <ServiceTypeIcon type={request.service_type} />
                            <div>
                              <h4 className="font-semibold">
                                {request.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                              </h4>
                              <p className="text-xs text-gray-500">
                                {format(new Date(request.created_date), 'MMM d, h:mm a')}
                              </p>
                            </div>
                          </div>
                          <StatusBadge status={request.status} />
                        </div>

                        <div className="text-sm text-gray-600 space-y-1">
                          <div className="flex items-start gap-2">
                            <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5" />
                            <span>{request.location_address || 'Location set'}</span>
                          </div>
                          {request.technician_id && (
                            <Badge variant="outline" className="text-xs">
                              Currently assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right: Assignment Panel */}
          <div>
            {selectedRequest ? (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Selected Request Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-sm text-gray-600 mb-1">Service Type</h4>
                      <div className="flex items-center gap-2">
                        <ServiceTypeIcon type={selectedRequest.service_type} />
                        <span className="font-medium">
                          {selectedRequest.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </span>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-sm text-gray-600 mb-1">Location</h4>
                      <p className="text-sm">{selectedRequest.location_address}</p>
                    </div>

                    {selectedRequest.description && (
                      <div>
                        <h4 className="font-semibold text-sm text-gray-600 mb-1">Description</h4>
                        <p className="text-sm">{selectedRequest.description}</p>
                      </div>
                    )}

                    {selectedRequest.vehicle_make && (
                      <div>
                        <h4 className="font-semibold text-sm text-gray-600 mb-1">Vehicle</h4>
                        <p className="text-sm">
                          {selectedRequest.vehicle_year} {selectedRequest.vehicle_make} {selectedRequest.vehicle_model}
                        </p>
                      </div>
                    )}

                    {selectedRequest.technician_id && (
                      <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                        <div className="flex items-center gap-2 mb-2">
                          <RefreshCw className="w-4 h-4 text-yellow-700" />
                          <span className="font-semibold text-yellow-900">Currently Assigned</span>
                        </div>
                        <p className="text-sm text-yellow-800">
                          This job is already assigned. You can reassign it to a different technician.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <IntelligentDispatchSuggestions
                  serviceRequest={selectedRequest}
                  onAssign={(tech) => {
                    if (selectedRequest.technician_id) {
                      const oldTech = allTechnicians.find(t => t.user_id === selectedRequest.technician_id);
                      reassignJob.mutate({ request: selectedRequest, newTechnician: tech, oldTechnician: oldTech });
                    } else {
                      assignTechnician.mutate({ request: selectedRequest, technician: tech });
                    }
                  }}
                />
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <User className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Select a Request</h3>
                  <p className="text-gray-600 text-sm">
                    Choose a service request from the list to see dispatch suggestions
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}