import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Save, Wrench, Loader2, Star, X, Upload, Award, CheckCircle, Plus, FileText, Trash2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { createPageUrl } from '@/utils';
import TechnicianReviews from '../components/reviews/TechnicianReviews';
import WorkZoneManager from '../components/technician/WorkZoneManager';
import RoutePreferencesPanel from '../components/technician/RoutePreferencesPanel';

const availableSpecialties = [
  'Tire Change',
  'Battery Jump',
  'Fuel Delivery',
  'Lockout Service',
  'Towing',
  'Engine Diagnostics',
  'Brake Service',
  'Oil Change'
];

const availableSkills = [
  'Brake Repair',
  'Engine Diagnostics',
  'Electrical Systems',
  'Transmission Repair',
  'Air Conditioning',
  'Oil Change',
  'Tire Service',
  'Battery Service',
  'Suspension Repair',
  'Exhaust Systems',
  'Fuel Systems',
  'Cooling Systems',
  'Steering Systems',
  'Hybrid/Electric Vehicles',
  'Diesel Engines'
];

const serviceTypeOptions = [
  { value: 'tire_change', label: 'Tire Change' },
  { value: 'battery_jump', label: 'Battery Jump' },
  { value: 'fuel_delivery', label: 'Fuel Delivery' },
  { value: 'lockout', label: 'Lockout Service' },
  { value: 'towing', label: 'Towing' },
  { value: 'other', label: 'Other' }
];

export default function TechnicianProfile() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    phone: '',
    vehicle_type: '',
    license_plate: '',
    specialties: [],
    bio: '',
    skills: [],
    certifications: [],
    preferred_service_types: [],
    skills_certifications: [],
    availability_status: 'offline',
    profile_picture: '',
    drivers_license_url: '',
    insurance_url: '',
    service_area_radius_miles: 25
  });
  const [uploadingImage, setUploadingImage] = useState(false);
  const [uploadingCert, setUploadingCert] = useState(false);
  const [uploadingLicense, setUploadingLicense] = useState(false);
  const [uploadingInsurance, setUploadingInsurance] = useState(false);
  const [newCert, setNewCert] = useState({
    name: '',
    issuer: '',
    issue_date: '',
    expiry_date: '',
    document_url: ''
  });
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      // Load technician profile
      const profiles = await base44.entities.TechnicianProfile.filter({ user_id: currentUser.id });
      if (profiles.length > 0) {
        const profile = profiles[0];
        setFormData({
          phone: profile.phone || '',
          vehicle_type: profile.vehicle_type || '',
          license_plate: profile.license_plate || '',
          specialties: profile.specialties || [],
          bio: profile.bio || '',
          skills: profile.skills || [],
          certifications: profile.certifications || [],
          preferred_service_types: profile.preferred_service_types || [],
          skills_certifications: profile.skills_certifications || [],
          availability_status: profile.availability_status || 'offline',
          profile_picture: profile.profile_picture || '',
          drivers_license_url: profile.drivers_license_url || '',
          insurance_url: profile.insurance_url || '',
          service_area_radius_miles: profile.service_area_radius_miles || 25
        });
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const { data: profile } = useQuery({
    queryKey: ['tech-profile', user?.id],
    queryFn: async () => {
      const profiles = await base44.entities.TechnicianProfile.filter({ user_id: user.id });
      return profiles[0];
    },
    enabled: !!user
  });

  const updateProfile = useMutation({
    mutationFn: async () => {
      if (profile) {
        return await base44.entities.TechnicianProfile.update(profile.id, formData);
      } else {
        return await base44.entities.TechnicianProfile.create({
          ...formData,
          user_id: user.id
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['tech-profile', user?.id]);
      alert('Profile updated successfully!');
    }
  });

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingImage(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, profile_picture: file_url });
    } catch (error) {
      alert('Failed to upload image');
    } finally {
      setUploadingImage(false);
    }
  };

  const toggleSkill = (skill) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.includes(skill)
        ? prev.skills.filter(s => s !== skill)
        : [...prev.skills, skill]
    }));
  };

  const toggleServiceType = (serviceType) => {
    setFormData(prev => ({
      ...prev,
      preferred_service_types: prev.preferred_service_types.includes(serviceType)
        ? prev.preferred_service_types.filter(s => s !== serviceType)
        : [...prev.preferred_service_types, serviceType]
    }));
  };

  const handleCertFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingCert(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setNewCert({ ...newCert, document_url: file_url });
    } catch (error) {
      alert('Failed to upload document');
    } finally {
      setUploadingCert(false);
    }
  };

  const addCertification = () => {
    if (newCert.name.trim() && newCert.issuer.trim()) {
      setFormData({
        ...formData,
        certifications: [...(formData.certifications || []), newCert]
      });
      setNewCert({
        name: '',
        issuer: '',
        issue_date: '',
        expiry_date: '',
        document_url: ''
      });
    }
  };

  const removeCertification = (index) => {
    setFormData({
      ...formData,
      certifications: formData.certifications.filter((_, i) => i !== index)
    });
  };

  const toggleSpecialty = (specialty) => {
    setFormData(prev => ({
      ...prev,
      specialties: prev.specialties.includes(specialty)
        ? prev.specialties.filter(s => s !== specialty)
        : [...prev.specialties, specialty]
    }));
  };

  const handleLicenseUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingLicense(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, drivers_license_url: file_url });
    } catch (error) {
      alert('Failed to upload driver\'s license');
    } finally {
      setUploadingLicense(false);
    }
  };

  const handleInsuranceUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingInsurance(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, insurance_url: file_url });
    } catch (error) {
      alert('Failed to upload insurance document');
    } finally {
      setUploadingInsurance(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#E52C2D' }} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #E52C2D 0%, #FF771D 100%)' }}>
        <div className="max-w-3xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20"
            onClick={() => window.location.href = createPageUrl('TechnicianDashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Technician Profile</h1>
            <p className="text-sm opacity-90">Manage your professional information</p>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto p-6 space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold mb-1" style={{ color: '#E52C2D' }}>
                {profile?.total_jobs || 0}
              </div>
              <div className="text-sm text-gray-600">Total Jobs</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center gap-2 mb-1">
                <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                <span className="text-3xl font-bold">{profile?.rating?.toFixed(1) || '5.0'}</span>
              </div>
              <div className="text-sm text-gray-600">Average Rating</div>
              <div className="text-xs text-gray-500 mt-1">
                Based on {profile?.total_jobs || 0} completed jobs
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Profile Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: '#E52C2D' }}>
                <Wrench className="w-6 h-6 text-white" />
              </div>
              <span>Professional Details</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={(e) => { e.preventDefault(); updateProfile.mutate(); }} className="space-y-6">
              {/* Bio */}
              <div>
                <Label htmlFor="bio">Professional Bio</Label>
                <Textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) => setFormData({...formData, bio: e.target.value})}
                  className="mt-2"
                  placeholder="Tell customers about your experience, expertise, and what makes you stand out..."
                  rows={4}
                />
                <p className="text-xs text-gray-500 mt-1">
                  This will be displayed on your public profile to help customers get to know you
                </p>
              </div>

              {/* Profile Picture */}
              <div>
                <Label>Profile Picture</Label>
                <div className="flex items-center gap-4 mt-2">
                  {formData.profile_picture ? (
                    <img
                      src={formData.profile_picture}
                      alt="Profile"
                      className="w-20 h-20 rounded-full object-cover border-4"
                      style={{ borderColor: '#E52C2D' }}
                    />
                  ) : (
                    <div
                      className="w-20 h-20 rounded-full flex items-center justify-center text-white text-2xl font-bold"
                      style={{ backgroundColor: '#E52C2D' }}
                    >
                      {user?.full_name?.[0] || 'T'}
                    </div>
                  )}
                  <div>
                    <label className="cursor-pointer">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        disabled={uploadingImage}
                        className="flex items-center gap-2"
                        onClick={(e) => e.currentTarget.previousElementSibling.click()}
                      >
                        <Upload className="w-4 h-4" />
                        {uploadingImage ? 'Uploading...' : 'Upload Photo'}
                      </Button>
                    </label>
                  </div>
                </div>
              </div>

              {/* Availability Status */}
              <div>
                <Label htmlFor="availability">Availability Status</Label>
                <Select
                  value={formData.availability_status}
                  onValueChange={(value) => setFormData({ ...formData, availability_status: value })}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="available">Available</SelectItem>
                    <SelectItem value="on_job">On Job</SelectItem>
                    <SelectItem value="break">On Break</SelectItem>
                    <SelectItem value="offline">Offline</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="mt-2"
                  placeholder="Enter your phone number"
                  required
                />
              </div>

              <div>
                <Label htmlFor="vehicle_type">Vehicle Type</Label>
                <Input
                  id="vehicle_type"
                  value={formData.vehicle_type}
                  onChange={(e) => setFormData({...formData, vehicle_type: e.target.value})}
                  className="mt-2"
                  placeholder="e.g., Van, Truck, SUV"
                />
              </div>

              <div>
                <Label htmlFor="license_plate">License Plate</Label>
                <Input
                  id="license_plate"
                  value={formData.license_plate}
                  onChange={(e) => setFormData({...formData, license_plate: e.target.value})}
                  className="mt-2"
                  placeholder="Enter license plate number"
                />
              </div>

              <div>
                <Label className="mb-3 block">Specialties</Label>
                <div className="flex flex-wrap gap-2">
                  {availableSpecialties.map(specialty => {
                    const isSelected = formData.specialties.includes(specialty);
                    return (
                      <Badge
                        key={specialty}
                        className={`cursor-pointer px-4 py-2 text-sm transition-all ${
                          isSelected 
                            ? 'text-white border-2' 
                            : 'bg-gray-100 text-gray-700 border-2 border-gray-200 hover:border-gray-300'
                        }`}
                        style={isSelected ? { backgroundColor: '#E52C2D', borderColor: '#E52C2D' } : {}}
                        onClick={() => toggleSpecialty(specialty)}
                      >
                        {specialty}
                        {isSelected && <X className="w-3 h-3 ml-2" />}
                      </Badge>
                    );
                  })}
                </div>
                <p className="text-xs text-gray-500 mt-2">Click to select your service specialties</p>
              </div>

              {/* Technical Skills */}
              <div>
                <Label className="mb-3 block flex items-center gap-2">
                  <Wrench className="w-4 h-4" />
                  Technical Skills
                </Label>
                <div className="flex flex-wrap gap-2">
                  {availableSkills.map(skill => {
                    const isSelected = formData.skills.includes(skill);
                    return (
                      <Badge
                        key={skill}
                        className={`cursor-pointer px-4 py-2 text-sm transition-all ${
                          isSelected 
                            ? 'text-white border-2' 
                            : 'bg-gray-100 text-gray-700 border-2 border-gray-200 hover:border-gray-300'
                        }`}
                        style={isSelected ? { backgroundColor: '#3D692B', borderColor: '#3D692B' } : {}}
                        onClick={() => toggleSkill(skill)}
                      >
                        {skill}
                        {isSelected && <CheckCircle className="w-3 h-3 ml-2" />}
                      </Badge>
                    );
                  })}
                </div>
                <p className="text-xs text-gray-500 mt-2">Select all technical skills you're proficient in</p>
              </div>

              {/* Preferred Service Types */}
              <div>
                <Label className="mb-3 block">Preferred Service Types</Label>
                <div className="flex flex-wrap gap-2">
                  {serviceTypeOptions.map(({ value, label }) => {
                    const isSelected = formData.preferred_service_types.includes(value);
                    return (
                      <Badge
                        key={value}
                        className={`cursor-pointer px-4 py-2 text-sm transition-all ${
                          isSelected 
                            ? 'text-white border-2' 
                            : 'bg-gray-100 text-gray-700 border-2 border-gray-200 hover:border-gray-300'
                        }`}
                        style={isSelected ? { backgroundColor: '#FF771D', borderColor: '#FF771D' } : {}}
                        onClick={() => toggleServiceType(value)}
                      >
                        {label}
                        {isSelected && <CheckCircle className="w-3 h-3 ml-2" />}
                      </Badge>
                    );
                  })}
                </div>
                <p className="text-xs text-gray-500 mt-2">Choose the types of service jobs you prefer</p>
              </div>

              {/* Required Documents */}
              <div className="space-y-4 border-t pt-6">
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Required Documents
                </h3>
                
                {/* Driver's License */}
                <div>
                  <Label>Driver's License *</Label>
                  <div className="mt-2">
                    {formData.drivers_license_url ? (
                      <div className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        <div className="flex-1">
                          <p className="text-sm font-semibold text-green-900">Document Uploaded</p>
                          <a
                            href={formData.drivers_license_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-green-700 hover:underline"
                          >
                            View Document
                          </a>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => setFormData({ ...formData, drivers_license_url: '' })}
                          className="text-red-600"
                        >
                          Remove
                        </Button>
                      </div>
                    ) : (
                      <label className="block">
                        <input
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png"
                          onChange={handleLicenseUpload}
                          className="hidden"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          disabled={uploadingLicense}
                          className="w-full"
                          onClick={(e) => e.currentTarget.previousElementSibling.click()}
                        >
                          <Upload className="w-4 h-4 mr-2" />
                          {uploadingLicense ? 'Uploading...' : 'Upload Driver\'s License'}
                        </Button>
                      </label>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Required to accept jobs</p>
                </div>

                {/* Insurance */}
                <div>
                  <Label>Insurance Documents *</Label>
                  <div className="mt-2">
                    {formData.insurance_url ? (
                      <div className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        <div className="flex-1">
                          <p className="text-sm font-semibold text-green-900">Document Uploaded</p>
                          <a
                            href={formData.insurance_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-green-700 hover:underline"
                          >
                            View Document
                          </a>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => setFormData({ ...formData, insurance_url: '' })}
                          className="text-red-600"
                        >
                          Remove
                        </Button>
                      </div>
                    ) : (
                      <label className="block">
                        <input
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png"
                          onChange={handleInsuranceUpload}
                          className="hidden"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          disabled={uploadingInsurance}
                          className="w-full"
                          onClick={(e) => e.currentTarget.previousElementSibling.click()}
                        >
                          <Upload className="w-4 h-4 mr-2" />
                          {uploadingInsurance ? 'Uploading...' : 'Upload Insurance Documents'}
                        </Button>
                      </label>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Required for liability coverage</p>
                </div>
              </div>

              {/* Service Area */}
              <div className="space-y-3 border-t pt-6">
                <Label htmlFor="service_area_radius">Service Area Radius (miles)</Label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    id="service_area_radius"
                    min="5"
                    max="100"
                    step="5"
                    value={formData.service_area_radius_miles}
                    onChange={(e) => setFormData({ ...formData, service_area_radius_miles: parseInt(e.target.value) })}
                    className="flex-1"
                  />
                  <div className="text-2xl font-bold min-w-[80px] text-center" style={{ color: '#E52C2D' }}>
                    {formData.service_area_radius_miles} mi
                  </div>
                </div>
                <p className="text-xs text-gray-500">
                  You'll receive job offers within this radius from your location
                </p>
              </div>

              {/* Certifications */}
              <div className="border-t pt-6">
                <Label className="mb-3 block flex items-center gap-2">
                  <Award className="w-4 h-4" />
                  Professional Certifications (Optional)
                </Label>
                
                {/* Add New Certification */}
                <Card className="mb-4 bg-gray-50">
                  <CardContent className="pt-4 space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label className="text-xs">Certification Name *</Label>
                        <Input
                          placeholder="e.g., ASE Master Technician"
                          value={newCert.name}
                          onChange={(e) => setNewCert({...newCert, name: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Issuing Organization *</Label>
                        <Input
                          placeholder="e.g., ASE"
                          value={newCert.issuer}
                          onChange={(e) => setNewCert({...newCert, issuer: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label className="text-xs">Issue Date</Label>
                        <Input
                          type="date"
                          value={newCert.issue_date}
                          onChange={(e) => setNewCert({...newCert, issue_date: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Expiry Date</Label>
                        <Input
                          type="date"
                          value={newCert.expiry_date}
                          onChange={(e) => setNewCert({...newCert, expiry_date: e.target.value})}
                          className="mt-1"
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs">Certificate Document</Label>
                      <div className="flex gap-2 mt-1">
                        <label className="flex-1">
                          <input
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={handleCertFileUpload}
                            className="hidden"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            disabled={uploadingCert}
                            className="w-full"
                            onClick={(e) => e.currentTarget.previousElementSibling.click()}
                          >
                            <Upload className="w-4 h-4 mr-2" />
                            {uploadingCert ? 'Uploading...' : newCert.document_url ? 'Document Uploaded' : 'Upload Document'}
                          </Button>
                        </label>
                      </div>
                    </div>
                    <Button
                      type="button"
                      onClick={addCertification}
                      className="w-full"
                      style={{ backgroundColor: '#3D692B' }}
                      disabled={!newCert.name.trim() || !newCert.issuer.trim()}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Certification
                    </Button>
                  </CardContent>
                </Card>

                {/* List of Certifications */}
                <div className="space-y-2">
                  {(formData.certifications || []).map((cert, index) => (
                    <Card key={index} className="border-2">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Award className="w-4 h-4 text-green-600" />
                              <h4 className="font-semibold">{cert.name}</h4>
                            </div>
                            <p className="text-sm text-gray-600 mb-1">Issued by: {cert.issuer}</p>
                            <div className="flex gap-4 text-xs text-gray-500">
                              {cert.issue_date && <span>Issued: {new Date(cert.issue_date).toLocaleDateString()}</span>}
                              {cert.expiry_date && <span>Expires: {new Date(cert.expiry_date).toLocaleDateString()}</span>}
                            </div>
                            {cert.document_url && (
                              <a
                                href={cert.document_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-xs text-blue-600 hover:underline flex items-center gap-1 mt-2"
                              >
                                <FileText className="w-3 h-3" />
                                View Document
                              </a>
                            )}
                          </div>
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => removeCertification(index)}
                            className="text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              <div className="pt-4">
                <Button
                  type="submit"
                  disabled={updateProfile.isLoading}
                  className="w-full text-white py-6 text-lg font-semibold hover:opacity-90"
                  style={{ backgroundColor: '#E52C2D' }}
                >
                  {updateProfile.isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="w-5 h-5 mr-2" />
                      Save Profile
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Work Zone Manager */}
        <WorkZoneManager profile={profile} />

        {/* Route Preferences */}
        <RoutePreferencesPanel profile={profile} />

        {/* Customer Reviews */}
        {user && <TechnicianReviews technicianId={user.id} limit={10} allowFlagging={true} />}

        {/* User Info Link */}
        <Card className="hover:shadow-md transition-shadow cursor-pointer"
          onClick={() => window.location.href = createPageUrl('Profile')}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold mb-1">Personal Information</h3>
                <p className="text-sm text-gray-600">Update name, email, and contact details</p>
              </div>
              <ArrowLeft className="w-5 h-5 text-gray-400 rotate-180" />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}