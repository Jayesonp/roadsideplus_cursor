import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Users, Plus, Trash2, Shield } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function PartnerStaffManagement() {
  const [user, setUser] = useState(null);
  const [partner, setPartner] = useState(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newStaff, setNewStaff] = useState({ email: '', role: 'viewer' });
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
    const partners = await base44.entities.Partner.filter({ email: currentUser.email });
    if (partners[0]) setPartner(partners[0]);
  };

  const { data: staff = [] } = useQuery({
    queryKey: ['partner-staff', partner?.id],
    queryFn: async () => {
      return await base44.entities.PartnerStaff.filter({ partner_id: partner.id });
    },
    enabled: !!partner
  });

  const addStaff = useMutation({
    mutationFn: async (staffData) => {
      const allUsers = await base44.entities.User.list();
      const existingUser = allUsers.find(u => u.email === staffData.email);
      
      if (!existingUser) {
        throw new Error('User not found');
      }

      const permissions = {
        view_clients: true,
        add_clients: staffData.role !== 'viewer',
        edit_clients: staffData.role !== 'viewer',
        view_analytics: true,
        manage_staff: staffData.role === 'admin'
      };

      return await base44.entities.PartnerStaff.create({
        partner_id: partner.id,
        user_id: existingUser.id,
        role: staffData.role,
        permissions,
        status: 'active'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['partner-staff']);
      setShowAddDialog(false);
      setNewStaff({ email: '', role: 'viewer' });
    }
  });

  const removeStaff = useMutation({
    mutationFn: async (staffId) => {
      await base44.entities.PartnerStaff.delete(staffId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['partner-staff']);
    }
  });

  if (!partner) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  const primaryColor = partner.white_label_primary_color || '#FF771D';

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold">Staff Management</h1>
            <p className="text-gray-600 mt-1">Manage your team's access and permissions</p>
          </div>
          <Button onClick={() => setShowAddDialog(true)} className="text-white" style={{ backgroundColor: primaryColor }}>
            <Plus className="w-4 h-4 mr-2" />
            Add Staff
          </Button>
        </div>

        {/* Role Descriptions */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Role Permissions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3">
              <Badge style={{ backgroundColor: primaryColor }} className="text-white">Admin</Badge>
              <p className="text-sm text-gray-600">Full access - manage staff, clients, analytics</p>
            </div>
            <div className="flex items-start gap-3">
              <Badge className="bg-blue-600 text-white">Manager</Badge>
              <p className="text-sm text-gray-600">Add/edit clients, view analytics</p>
            </div>
            <div className="flex items-start gap-3">
              <Badge className="bg-gray-600 text-white">Viewer</Badge>
              <p className="text-sm text-gray-600">View-only access to clients and analytics</p>
            </div>
          </CardContent>
        </Card>

        {/* Staff List */}
        <Card>
          <CardHeader>
            <CardTitle>Team Members ({staff.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {staff.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-gray-500">No staff members added yet</p>
                </div>
              ) : (
                staff.map(member => (
                  <Card key={member.id} className="border">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-bold">{member.user_id}</h3>
                            <Badge 
                              className={
                                member.role === 'admin' ? 'text-white' : 
                                member.role === 'manager' ? 'bg-blue-600 text-white' : 
                                'bg-gray-600 text-white'
                              }
                              style={member.role === 'admin' ? { backgroundColor: primaryColor } : {}}
                            >
                              {member.role}
                            </Badge>
                            {member.status === 'inactive' && (
                              <Badge variant="outline">Inactive</Badge>
                            )}
                          </div>
                          <div className="flex gap-4 text-sm text-gray-600">
                            {member.permissions?.view_clients && <span>✓ View Clients</span>}
                            {member.permissions?.add_clients && <span>✓ Add Clients</span>}
                            {member.permissions?.view_analytics && <span>✓ Analytics</span>}
                            {member.permissions?.manage_staff && <span>✓ Manage Staff</span>}
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeStaff.mutate(member.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Add Staff Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Staff Member</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Email</label>
              <Input
                type="email"
                value={newStaff.email}
                onChange={(e) => setNewStaff({...newStaff, email: e.target.value})}
                placeholder="staff@example.com"
              />
              <p className="text-xs text-gray-500 mt-1">User must have an existing account</p>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Role</label>
              <Select value={newStaff.role} onValueChange={(value) => setNewStaff({...newStaff, role: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin - Full Access</SelectItem>
                  <SelectItem value="manager">Manager - Add/Edit Clients</SelectItem>
                  <SelectItem value="viewer">Viewer - Read Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={() => addStaff.mutate(newStaff)}
              disabled={!newStaff.email || addStaff.isLoading}
              className="w-full text-white"
              style={{ backgroundColor: primaryColor }}
            >
              {addStaff.isLoading ? 'Adding...' : 'Add Staff Member'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}