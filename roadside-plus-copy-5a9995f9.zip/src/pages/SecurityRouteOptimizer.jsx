import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Route, Navigation, Clock, MapPin, ArrowLeft, Zap } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Polyline, Popup } from 'react-leaflet';
import { createPageUrl } from '@/utils';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const officerIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxNiIgY3k9IjE2IiByPSIxMiIgZmlsbD0iIzNENjkyQiIvPjxwYXRoIGQ9Ik0xNiA4QzEyLjcgOCAxMCAxMC43IDEwIDE0QzEwIDE4IDEzIDE5LjUgMTYgMjRDMTkgMTkuNSAyMiAxOCAyMiAxNEMyMiAxMC43IDE5LjMgOCAxNiA4WiIgZmlsbD0id2hpdGUiLz48L3N2Zz4=',
  iconSize: [32, 32],
  iconAnchor: [16, 32]
});

const incidentIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxNiIgY3k9IjE2IiByPSIxMiIgZmlsbD0iI0U1MkMyRCIvPjxwYXRoIGQ9Ik0xNiA4QzEyLjcgOCAxMCAxMC43IDEwIDE0QzEwIDE4IDEzIDE5LjUgMTYgMjRDMTkgMTkuNSAyMiAxOCAyMiAxNEMyMiAxMC43IDE5LjMgOCAxNiA4WiIgZmlsbD0id2hpdGUiLz48L3N2Zz4=',
  iconSize: [32, 32],
  iconAnchor: [16, 32]
});

export default function SecurityRouteOptimizer() {
  const [companyId] = useState(localStorage.getItem('security_company_id'));
  const [selectedOfficer, setSelectedOfficer] = useState(null);
  const [optimizedRoute, setOptimizedRoute] = useState(null);
  const [calculating, setCalculating] = useState(false);

  const { data: officers = [] } = useQuery({
    queryKey: ['officers', companyId],
    queryFn: () => base44.entities.SecurityOfficer.filter({ company_id: companyId }),
    enabled: !!companyId
  });

  const { data: incidents = [] } = useQuery({
    queryKey: ['pending-incidents', companyId],
    queryFn: () => base44.entities.SOSIncident.filter({ company_id: companyId, status: 'pending' }),
    enabled: !!companyId
  });

  const calculateOptimalRoute = async () => {
    if (!selectedOfficer) return;

    setCalculating(true);
    const officer = officers.find(o => o.id === selectedOfficer);
    
    // Simple nearest neighbor algorithm
    const start = { lat: officer.current_lat, lng: officer.current_lng };
    const unvisited = [...incidents];
    const route = [start];
    let current = start;

    while (unvisited.length > 0) {
      let nearest = null;
      let minDist = Infinity;

      unvisited.forEach((incident, idx) => {
        const dist = calculateDistance(
          current.lat, current.lng,
          incident.location_lat, incident.location_lng
        );
        if (dist < minDist) {
          minDist = dist;
          nearest = idx;
        }
      });

      if (nearest !== null) {
        const nextIncident = unvisited[nearest];
        route.push({ 
          lat: nextIncident.location_lat, 
          lng: nextIncident.location_lng,
          incident: nextIncident
        });
        current = { lat: nextIncident.location_lat, lng: nextIncident.location_lng };
        unvisited.splice(nearest, 1);
      }
    }

    const totalDistance = route.reduce((sum, point, idx) => {
      if (idx === 0) return 0;
      return sum + calculateDistance(
        route[idx-1].lat, route[idx-1].lng,
        point.lat, point.lng
      );
    }, 0);

    const estimatedTime = (totalDistance / 50) * 60; // Assuming 50 km/h average

    setOptimizedRoute({
      route,
      totalDistance: totalDistance.toFixed(2),
      estimatedTime: Math.round(estimatedTime),
      incidentCount: route.length - 1
    });

    setCalculating(false);
  };

  const calculateDistance = (lat1, lng1, lat2, lng2) => {
    const R = 6371; // Earth radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const routeCoordinates = optimizedRoute?.route.map(p => [p.lat, p.lng]) || [];

  return (
    <div className="min-h-screen bg-gray-900 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 flex items-center gap-4">
          <Button
            variant="outline"
            className="text-white border-gray-600"
            onClick={() => window.location.href = createPageUrl('SecurityCommandCenter')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-2">
              <Route className="w-8 h-8" style={{ color: '#FF771D' }} />
              Route Optimizer
            </h1>
            <p className="text-gray-400 mt-1">Optimize officer routes for multiple incidents</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Controls */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-white text-sm font-medium mb-2 block">Select Officer</label>
                <select
                  className="w-full bg-gray-900 text-white border-gray-600 rounded px-3 py-2"
                  value={selectedOfficer || ''}
                  onChange={(e) => setSelectedOfficer(e.target.value)}
                >
                  <option value="">Choose officer...</option>
                  {officers.filter(o => o.current_lat && o.current_lng).map(o => (
                    <option key={o.id} value={o.id}>
                      Badge #{o.officer_badge_number} - {o.status}
                    </option>
                  ))}
                </select>
              </div>

              <div className="p-3 bg-gray-900 rounded">
                <p className="text-gray-400 text-sm mb-1">Pending Incidents</p>
                <p className="text-2xl font-bold text-white">{incidents.length}</p>
              </div>

              <Button
                className="w-full text-white"
                style={{ backgroundColor: '#FF771D' }}
                onClick={calculateOptimalRoute}
                disabled={!selectedOfficer || incidents.length === 0 || calculating}
              >
                <Zap className="w-4 h-4 mr-2" />
                {calculating ? 'Calculating...' : 'Optimize Route'}
              </Button>

              {optimizedRoute && (
                <div className="space-y-3 pt-4 border-t border-gray-700">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Total Distance</span>
                    <span className="text-white font-semibold">{optimizedRoute.totalDistance} km</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Est. Time</span>
                    <span className="text-white font-semibold">{optimizedRoute.estimatedTime} min</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Incidents</span>
                    <span className="text-white font-semibold">{optimizedRoute.incidentCount}</span>
                  </div>
                </div>
              )}

              {optimizedRoute && (
                <div className="space-y-2">
                  <p className="text-white font-semibold text-sm">Route Order:</p>
                  {optimizedRoute.route.map((point, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-sm">
                      <Badge className="mt-0.5" style={{ backgroundColor: idx === 0 ? '#3D692B' : '#FF771D' }}>
                        {idx === 0 ? 'START' : idx}
                      </Badge>
                      <div className="flex-1">
                        {idx === 0 ? (
                          <p className="text-gray-300">Officer Location</p>
                        ) : (
                          <>
                            <p className="text-white">Incident {point.incident?.id.slice(0, 8)}</p>
                            <p className="text-xs text-gray-400">{point.incident?.severity} priority</p>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Map */}
          <Card className="lg:col-span-2 bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Navigation className="w-5 h-5" />
                Optimized Route Map
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[600px] rounded-lg overflow-hidden">
                <MapContainer
                  center={
                    officers.find(o => o.id === selectedOfficer)
                      ? [
                          officers.find(o => o.id === selectedOfficer).current_lat,
                          officers.find(o => o.id === selectedOfficer).current_lng
                        ]
                      : [37.7749, -122.4194]
                  }
                  zoom={12}
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

                  {/* Officer */}
                  {selectedOfficer && officers.find(o => o.id === selectedOfficer)?.current_lat && (
                    <Marker
                      position={[
                        officers.find(o => o.id === selectedOfficer).current_lat,
                        officers.find(o => o.id === selectedOfficer).current_lng
                      ]}
                      icon={officerIcon}
                    >
                      <Popup>Officer Start Position</Popup>
                    </Marker>
                  )}

                  {/* Incidents */}
                  {incidents.map((incident, idx) => (
                    <Marker
                      key={incident.id}
                      position={[incident.location_lat, incident.location_lng]}
                      icon={incidentIcon}
                    >
                      <Popup>
                        <div className="text-sm">
                          <p className="font-bold">Incident {idx + 1}</p>
                          <p>Severity: {incident.severity}</p>
                        </div>
                      </Popup>
                    </Marker>
                  ))}

                  {/* Optimized Route */}
                  {optimizedRoute && routeCoordinates.length > 1 && (
                    <Polyline
                      positions={routeCoordinates}
                      pathOptions={{ color: '#3D692B', weight: 3, opacity: 0.8 }}
                    />
                  )}
                </MapContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}