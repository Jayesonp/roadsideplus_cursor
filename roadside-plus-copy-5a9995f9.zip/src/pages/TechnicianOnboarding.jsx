import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  ArrowLeft, ArrowRight, Save, Upload, CheckCircle, 
  Loader2, Shield, Truck, Briefcase, Wrench, User, FileText
} from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

// Helper to upload file
const FileUpload = ({ label, value, onChange, id }) => {
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      onChange(file_url);
    } catch (error) {
      alert('Upload failed');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="mb-4">
      <Label>{label}</Label>
      {value ? (
        <div className="flex items-center gap-3 mt-2 p-3 bg-green-50 border border-green-200 rounded-lg">
          <CheckCircle className="w-5 h-5 text-green-600" />
          <span className="text-sm text-green-800 truncate flex-1">Uploaded</span>
          <a href={value} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 hover:underline">View</a>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-red-500 hover:bg-red-50"
            onClick={() => onChange('')}
          >
            Remove
          </Button>
        </div>
      ) : (
        <div className="mt-2">
          <label className="cursor-pointer block">
            <input 
              id={id} 
              type="file" 
              className="hidden" 
              onChange={handleUpload} 
              accept="image/*,.pdf"
            />
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center hover:bg-gray-50 transition-colors">
              {uploading ? (
                <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
              ) : (
                <Upload className="w-6 h-6 text-gray-400" />
              )}
              <span className="text-sm text-gray-600 mt-2">
                {uploading ? 'Uploading...' : 'Click to upload'}
              </span>
            </div>
          </label>
        </div>
      )}
    </div>
  );
};

export default function TechnicianOnboarding() {
  const [step, setStep] = useState(1);
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const queryClient = useQueryClient();

  // Form State
  const [formData, setFormData] = useState({});

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      const profiles = await base44.entities.TechnicianProfile.filter({ user_id: currentUser.id });
      if (profiles.length > 0) {
        setProfile(profiles[0]);
        setFormData(profiles[0]);
        // Determine step based on completion? For now start at 1 or where they left off if we tracked it.
      }
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = useMutation({
    mutationFn: async (data) => {
      if (profile) {
        return await base44.entities.TechnicianProfile.update(profile.id, data);
      } else {
        return await base44.entities.TechnicianProfile.create({ ...data, user_id: user.id });
      }
    },
    onSuccess: (updated) => {
      setProfile(updated);
      setFormData(updated);
      queryClient.invalidateQueries(['technician-profile']);
    }
  });

  const handleNext = async () => {
    await updateProfile.mutateAsync(formData);
    if (step < 6) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = async () => {
    await updateProfile.mutateAsync({
      ...formData,
      onboarding_status: 'submitted',
      onboarding_completed: true // Legacy support
    });
    window.location.href = createPageUrl('TechnicianDashboard');
  };

  if (loading) {
    return <div className="flex items-center justify-center h-screen"><Loader2 className="w-8 h-8 animate-spin" /></div>;
  }

  const steps = [
    { id: 1, title: 'Identity', icon: User },
    { id: 2, title: 'Driving', icon: Shield },
    { id: 3, title: 'Vehicle', icon: Truck },
    { id: 4, title: 'Business', icon: Briefcase },
    { id: 5, title: 'Skills', icon: Wrench },
    { id: 6, title: 'Review', icon: FileText },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Top Bar */}
      <div className="bg-white border-b px-4 py-3 sticky top-0 z-10 safe-area-top">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => window.location.href = createPageUrl('TechnicianDashboard')}>
            Close
          </Button>
          <div className="text-sm font-semibold">
            Step {step} of 6
          </div>
          <div className="w-16"></div> {/* Spacer */}
        </div>
        {/* Progress Bar */}
        <div className="max-w-3xl mx-auto mt-3 h-1 bg-gray-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-[#FF771D] transition-all duration-300"
            style={{ width: `${(step / 6) * 100}%` }}
          />
        </div>
      </div>

      <div className="flex-1 p-4 max-w-3xl mx-auto w-full pb-24">
        <h1 className="text-2xl font-bold mb-2">{steps[step-1].title}</h1>
        <p className="text-gray-500 mb-6">Please provide accurate information for verification.</p>

        {/* Step 1: Identity Verification */}
        {step === 1 && (
          <div className="space-y-4">
            <div>
              <Label>Full Legal Name</Label>
              <Input 
                value={user?.full_name || ''} 
                disabled 
                className="bg-gray-50" 
              />
              <p className="text-xs text-gray-500 mt-1">Matches your account name</p>
            </div>
            
            <div>
              <Label>Date of Birth *</Label>
              <Input 
                type="date" 
                value={formData.dob || ''} 
                onChange={(e) => setFormData({...formData, dob: e.target.value})}
              />
            </div>

            <div>
              <Label>Home Address *</Label>
              <Textarea 
                value={formData.address || ''} 
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                placeholder="Full street address, city, state, zip"
              />
            </div>

            <FileUpload 
              label="Photo ID (Front) *" 
              id="id_front"
              value={formData.photo_id_front_url}
              onChange={(url) => setFormData({...formData, photo_id_front_url: url})}
            />

            <FileUpload 
              label="Photo ID (Back) *" 
              id="id_back"
              value={formData.photo_id_back_url}
              onChange={(url) => setFormData({...formData, photo_id_back_url: url})}
            />

            <FileUpload 
              label="Selfie Photo *" 
              id="selfie"
              value={formData.selfie_url}
              onChange={(url) => setFormData({...formData, selfie_url: url})}
            />

            <FileUpload 
              label="Police Clearance / Background Check *" 
              id="bg_check"
              value={formData.police_clearance_url}
              onChange={(url) => setFormData({...formData, police_clearance_url: url})}
            />
          </div>
        )}

        {/* Step 2: Driving & Licensing */}
        {step === 2 && (
          <div className="space-y-4">
            <div>
              <Label>Driver's License Number *</Label>
              <Input 
                value={formData.drivers_license_number || ''} 
                onChange={(e) => setFormData({...formData, drivers_license_number: e.target.value})}
                placeholder="Enter license number"
              />
            </div>

            <div>
              <Label>License Expiry Date *</Label>
              <Input 
                type="date" 
                value={formData.drivers_license_expiry || ''} 
                onChange={(e) => setFormData({...formData, drivers_license_expiry: e.target.value})}
              />
            </div>

            <FileUpload 
              label="Driver's License Photo *" 
              id="license_photo"
              value={formData.drivers_license_url}
              onChange={(url) => setFormData({...formData, drivers_license_url: url})}
            />

            <FileUpload 
              label="Driving Record (Optional)" 
              id="driving_record"
              value={formData.driving_record_url}
              onChange={(url) => setFormData({...formData, driving_record_url: url})}
            />
          </div>
        )}

        {/* Step 3: Vehicle & Equipment */}
        {step === 3 && (
          <div className="space-y-4">
            <div>
              <Label>Vehicle Type *</Label>
              <Select 
                value={formData.vehicle_type} 
                onValueChange={(val) => setFormData({...formData, vehicle_type: val})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select vehicle type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Tow Truck">Tow Truck</SelectItem>
                  <SelectItem value="Service Car">Service Car</SelectItem>
                  <SelectItem value="Motorcycle">Motorcycle</SelectItem>
                  <SelectItem value="Van">Van</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Make</Label>
                <Input 
                  value={formData.vehicle_make || ''} 
                  onChange={(e) => setFormData({...formData, vehicle_make: e.target.value})} 
                />
              </div>
              <div>
                <Label>Model</Label>
                <Input 
                  value={formData.vehicle_model || ''} 
                  onChange={(e) => setFormData({...formData, vehicle_model: e.target.value})} 
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Year</Label>
                <Input 
                  value={formData.vehicle_year || ''} 
                  onChange={(e) => setFormData({...formData, vehicle_year: e.target.value})} 
                />
              </div>
              <div>
                <Label>License Plate</Label>
                <Input 
                  value={formData.license_plate || ''} 
                  onChange={(e) => setFormData({...formData, license_plate: e.target.value})} 
                />
              </div>
            </div>

            <div>
              <Label>VIN / Registration Number *</Label>
              <Input 
                value={formData.vehicle_registration_number || ''} 
                onChange={(e) => setFormData({...formData, vehicle_registration_number: e.target.value})} 
              />
            </div>

            <FileUpload 
              label="Vehicle Registration Document *" 
              id="reg_doc"
              value={formData.vehicle_registration_url}
              onChange={(url) => setFormData({...formData, vehicle_registration_url: url})}
            />

            <FileUpload 
              label="Vehicle Insurance Document *" 
              id="ins_doc"
              value={formData.insurance_url}
              onChange={(url) => setFormData({...formData, insurance_url: url})}
            />

            <div>
              <Label>Vehicle Photos (Front/Back/Sides)</Label>
              <p className="text-xs text-gray-500 mb-2">Upload multiple photos showing condition</p>
              {/* Simple multi-upload implementation for MVP */}
              <div className="grid grid-cols-2 gap-2">
                {[0, 1, 2, 3].map(idx => (
                  <FileUpload 
                    key={idx}
                    label={`Photo ${idx+1}`}
                    id={`veh_photo_${idx}`}
                    value={formData.vehicle_photos?.[idx]}
                    onChange={(url) => {
                      const newPhotos = [...(formData.vehicle_photos || [])];
                      newPhotos[idx] = url;
                      setFormData({...formData, vehicle_photos: newPhotos});
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Business & Payout */}
        {step === 4 && (
          <div className="space-y-4">
            <Alert className="bg-blue-50 border-blue-200">
              <Briefcase className="h-4 w-4" />
              <AlertTitle>Payout Information</AlertTitle>
              <AlertDescription>
                We use Stripe for secure payouts. Please provide your business details.
              </AlertDescription>
            </Alert>

            <div>
              <Label>Bank Account / Payout Info *</Label>
              <Textarea 
                value={formData.bank_account_info || ''} 
                onChange={(e) => setFormData({...formData, bank_account_info: e.target.value})}
                placeholder="Bank Name, Account Number, Routing Number (or IBAN)"
              />
            </div>

            <FileUpload 
              label="Business Registration (If Applicable)" 
              id="biz_reg"
              value={formData.business_registration_url}
              onChange={(url) => setFormData({...formData, business_registration_url: url})}
            />

            <FileUpload 
              label="Liability Insurance *" 
              id="liab_ins"
              value={formData.liability_insurance_url}
              onChange={(url) => setFormData({...formData, liability_insurance_url: url})}
            />
          </div>
        )}

        {/* Step 5: Skills & Services */}
        {step === 5 && (
          <div className="space-y-6">
            <div>
              <Label className="mb-2 block">Services Offered *</Label>
              <div className="grid grid-cols-2 gap-2">
                {['Tire Change', 'Battery Jump', 'Fuel Delivery', 'Lockout', 'Towing', 'Winching'].map(svc => (
                  <div 
                    key={svc}
                    className={`p-3 border rounded-lg cursor-pointer flex items-center gap-2 ${
                      formData.specialties?.includes(svc) ? 'bg-[#FF771D]/10 border-[#FF771D]' : 'hover:bg-gray-50'
                    }`}
                    onClick={() => {
                      const current = formData.specialties || [];
                      const updated = current.includes(svc) 
                        ? current.filter(s => s !== svc) 
                        : [...current, svc];
                      setFormData({...formData, specialties: updated});
                    }}
                  >
                    <div className={`w-4 h-4 border rounded flex items-center justify-center ${
                      formData.specialties?.includes(svc) ? 'bg-[#FF771D] border-[#FF771D]' : 'border-gray-400'
                    }`}>
                      {formData.specialties?.includes(svc) && <CheckCircle className="w-3 h-3 text-white" />}
                    </div>
                    <span className="text-sm">{svc}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label className="mb-2 block">Technical Skills</Label>
              <div className="flex flex-wrap gap-2">
                {[
                  "Brake Repair", "Engine Diagnostics", "Electrical Systems", 
                  "Transmission Repair", "Air Conditioning", "Oil Change"
                ].map(skill => (
                  <div 
                    key={skill}
                    className={`px-3 py-1 rounded-full text-sm border cursor-pointer ${
                      formData.skills?.includes(skill) ? 'bg-green-100 text-green-800 border-green-200' : 'bg-gray-50'
                    }`}
                    onClick={() => {
                      const current = formData.skills || [];
                      const updated = current.includes(skill) 
                        ? current.filter(s => s !== skill) 
                        : [...current, skill];
                      setFormData({...formData, skills: updated});
                    }}
                  >
                    {skill}
                  </div>
                ))}
              </div>
            </div>

            <FileUpload 
              label="Upload Certifications (ASE, etc.)" 
              id="certs"
              value={formData.certifications?.[0]?.document_url} // Simplified for MVP
              onChange={(url) => {
                // Just adding one generic cert for now
                const certs = [{
                  name: "Uploaded Certification",
                  issuer: "User Uploaded",
                  document_url: url,
                  issue_date: new Date().toISOString()
                }];
                setFormData({...formData, certifications: certs});
              }}
            />
          </div>
        )}

        {/* Step 6: Review */}
        {step === 6 && (
          <div className="space-y-6">
            <Alert className="bg-yellow-50 border-yellow-200">
              <AlertTitle>Review Your Information</AlertTitle>
              <AlertDescription>
                Please ensure all information is correct. False information may lead to account suspension.
              </AlertDescription>
            </Alert>

            <div className="space-y-4">
              <div className="bg-white p-4 rounded-lg border">
                <h3 className="font-bold mb-2">Identity</h3>
                <p className="text-sm text-gray-600">DOB: {formData.dob}</p>
                <p className="text-sm text-gray-600">Address: {formData.address}</p>
                <div className="flex gap-2 mt-2">
                  {formData.photo_id_front_url && <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">ID Front</span>}
                  {formData.photo_id_back_url && <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">ID Back</span>}
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg border">
                <h3 className="font-bold mb-2">Vehicle</h3>
                <p className="text-sm text-gray-600">{formData.vehicle_year} {formData.vehicle_make} {formData.vehicle_model}</p>
                <p className="text-sm text-gray-600">Plate: {formData.license_plate}</p>
              </div>

              <div className="bg-white p-4 rounded-lg border">
                <h3 className="font-bold mb-2">Services</h3>
                <div className="flex flex-wrap gap-1">
                  {formData.specialties?.map(s => (
                    <span key={s} className="text-xs bg-gray-100 px-2 py-1 rounded">{s}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Bar */}
      <div className="bg-white border-t p-4 sticky bottom-0 safe-area-bottom flex gap-3">
        {step > 1 && (
          <Button variant="outline" onClick={handleBack} className="flex-1">
            Back
          </Button>
        )}
        {step < 6 ? (
          <Button 
            onClick={handleNext} 
            className="flex-1 bg-[#FF771D] hover:bg-[#E52C2D]"
            disabled={updateProfile.isLoading}
          >
            {updateProfile.isLoading ? <Loader2 className="animate-spin w-4 h-4" /> : 'Next'}
          </Button>
        ) : (
          <Button 
            onClick={handleSubmit} 
            className="flex-1 bg-[#3D692B] hover:bg-[#2A4B1E]"
            disabled={updateProfile.isLoading}
          >
            {updateProfile.isLoading ? <Loader2 className="animate-spin w-4 h-4" /> : 'Submit Application'}
          </Button>
        )}
      </div>
    </div>
  );
}