import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Gift, Users, TrendingUp, DollarSign, Share2, 
  Copy, CheckCircle, Award, Trophy, Star
} from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import BrandLogo from '../components/branding/BrandLogo';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import CustomerReferralManager from '../components/partner/CustomerReferralManager';

export default function PartnerReferralDashboard() {
  const [user, setUser] = useState(null);
  const [partner, setPartner] = useState(null);
  const [copied, setCopied] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        window.location.href = createPageUrl('Login');
        return;
      }
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      const partners = await base44.entities.Partner.filter({ email: currentUser.email });
      if (partners.length > 0) {
        setPartner(partners[0]);
      } else {
        window.location.href = createPageUrl('PartnerPortal');
      }
    } catch (error) {
      window.location.href = createPageUrl('Login');
    }
  };

  const { data: referrals = [] } = useQuery({
    queryKey: ['partner-referrals', partner?.id],
    queryFn: async () => {
      return await base44.entities.PartnerReferral.filter(
        { referrer_partner_id: partner.id },
        '-created_date'
      );
    },
    enabled: !!partner
  });

  const { data: referredPartners = [] } = useQuery({
    queryKey: ['referred-partners', referrals],
    queryFn: async () => {
      const partnerIds = referrals
        .filter(r => r.referred_partner_id)
        .map(r => r.referred_partner_id);
      
      if (partnerIds.length === 0) return [];
      
      const allPartners = await base44.entities.Partner.list();
      return allPartners.filter(p => partnerIds.includes(p.id));
    },
    enabled: referrals.length > 0
  });

  const generateReferralCode = useMutation({
    mutationFn: async () => {
      const code = `${partner.company_name.substring(0, 3).toUpperCase()}${Date.now().toString(36)}`;
      await base44.entities.Partner.update(partner.id, { referral_code: code });
      return code;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partner-profile'] });
      loadUser();
    }
  });

  const copyReferralLink = () => {
    const referralLink = `${window.location.origin}${createPageUrl('PartnerRegistration')}?ref=${partner.referral_code}`;
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!user || !partner) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#FF771D' }}></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  const primaryColor = partner.white_label_primary_color || '#FF771D';
  const activeReferrals = referrals.filter(r => r.status === 'active' || r.status === 'completed');
  const pendingReferrals = referrals.filter(r => r.status === 'pending');
  const totalBonus = referrals.reduce((sum, r) => sum + (r.bonus_amount || 0), 0);

  const tierBenefits = {
    bronze: { bonus: 500, commissionBoost: 0, color: '#CD7F32', icon: Award },
    silver: { bonus: 1000, commissionBoost: 1, color: '#C0C0C0', icon: Star },
    gold: { bonus: 2000, commissionBoost: 2, color: '#FFD700', icon: Trophy },
    platinum: { bonus: 5000, commissionBoost: 5, color: '#E5E4E2', icon: Gift }
  };

  const currentTier = partner.referral_bonus_tier || 'bronze';
  const tierInfo = tierBenefits[currentTier];
  const TierIcon = tierInfo.icon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" 
           style={{ background: `linear-gradient(135deg, ${primaryColor} 0%, #E52C2D 100%)` }}>
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              {partner.white_label_logo ? (
                <img src={partner.white_label_logo} alt={partner.company_name} className="h-12" />
              ) : (
                <BrandLogo variant="icon" size="md" />
              )}
              <div>
                <h1 className="text-2xl font-bold">Partner Referral Program</h1>
                <p className="text-sm opacity-90">Earn rewards by referring new partners</p>
              </div>
            </div>
            <Button
              onClick={() => window.location.href = createPageUrl('PartnerPortal')}
              variant="outline"
              className="text-white border-white/30 hover:bg-white/20"
            >
              Back to Portal
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Tabs for Partner and Customer Referrals */}
        <Tabs defaultValue="customers" className="w-full mb-6">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2">
            <TabsTrigger value="customers">Customer Referrals</TabsTrigger>
            <TabsTrigger value="partners">Partner Referrals</TabsTrigger>
          </TabsList>

          {/* Customer Referrals Tab */}
          <TabsContent value="customers">
            <CustomerReferralManager 
              partnerId={partner.id} 
              partnerCode={partner.referral_code || 'GENERATE'}
              primaryColor={primaryColor}
            />
          </TabsContent>

          {/* Partner Referrals Tab */}
          <TabsContent value="partners">
        {/* Tier Badge */}
        <Card className="mb-6 border-2" style={{ borderColor: tierInfo.color }}>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ backgroundColor: tierInfo.color + '20' }}>
                  <TierIcon className="w-8 h-8" style={{ color: tierInfo.color }} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold capitalize">{currentTier} Tier</h3>
                  <p className="text-gray-600">
                    ${tierInfo.bonus} bonus per referral • +{tierInfo.commissionBoost}% commission boost
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">Partners Referred</p>
                <p className="text-4xl font-bold" style={{ color: primaryColor }}>
                  {partner.partner_referrals_count || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Referrals</p>
                  <p className="text-3xl font-bold mt-1">{referrals.length}</p>
                </div>
                <Users className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Partners</p>
                  <p className="text-3xl font-bold mt-1" style={{ color: '#3D692B' }}>
                    {activeReferrals.length}
                  </p>
                </div>
                <CheckCircle className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending</p>
                  <p className="text-3xl font-bold mt-1">{pendingReferrals.length}</p>
                </div>
                <TrendingUp className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Bonus Earned</p>
                  <p className="text-3xl font-bold mt-1" style={{ color: '#3D692B' }}>
                    ${totalBonus.toFixed(0)}
                  </p>
                </div>
                <DollarSign className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Referral Link */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Share2 className="w-5 h-5" style={{ color: primaryColor }} />
              Your Referral Link
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!partner.referral_code ? (
              <div className="text-center py-6">
                <p className="text-gray-600 mb-4">Generate your unique referral link to start inviting partners</p>
                <Button
                  onClick={() => generateReferralCode.mutate()}
                  disabled={generateReferralCode.isLoading}
                  className="text-white"
                  style={{ backgroundColor: primaryColor }}
                >
                  {generateReferralCode.isLoading ? 'Generating...' : 'Generate Referral Link'}
                </Button>
              </div>
            ) : (
              <div>
                <p className="text-sm text-gray-600 mb-3">
                  Share this link with potential partners to earn rewards when they join
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    readOnly
                    value={`${window.location.origin}${createPageUrl('PartnerRegistration')}?ref=${partner.referral_code}`}
                    className="flex-1 px-4 py-3 border rounded-lg bg-gray-50 text-sm"
                  />
                  <Button
                    onClick={copyReferralLink}
                    className="text-white"
                    style={{ backgroundColor: copied ? '#3D692B' : primaryColor }}
                  >
                    {copied ? (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-2" />
                        Copy
                      </>
                    )}
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tier Progression */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Tier Benefits & Progression</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {Object.entries(tierBenefits).map(([tier, info]) => {
                const Icon = info.icon;
                const isCurrentTier = tier === currentTier;
                return (
                  <div
                    key={tier}
                    className={`p-4 rounded-lg border-2 ${isCurrentTier ? 'border-opacity-100' : 'border-opacity-20'}`}
                    style={{ borderColor: info.color, backgroundColor: isCurrentTier ? info.color + '10' : 'transparent' }}
                  >
                    <div className="flex items-center gap-2 mb-3">
                      <Icon className="w-5 h-5" style={{ color: info.color }} />
                      <span className="font-bold capitalize">{tier}</span>
                      {isCurrentTier && <Badge className="ml-auto">Current</Badge>}
                    </div>
                    <div className="space-y-1 text-sm">
                      <p className="font-semibold">${info.bonus} per referral</p>
                      <p className="text-gray-600">+{info.commissionBoost}% commission</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Referrals List */}
        <Card>
          <CardHeader>
            <CardTitle>Your Referrals ({referrals.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {referrals.length === 0 ? (
              <div className="text-center py-12">
                <Users className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-600 mb-2">No referrals yet</p>
                <p className="text-sm text-gray-500">Start sharing your referral link to earn rewards!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {referrals.map((referral) => {
                  const referredPartner = referredPartners.find(p => p.id === referral.referred_partner_id);
                  return (
                    <Card key={referral.id} className="border">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: primaryColor }}>
                              {referredPartner?.company_name?.[0]?.toUpperCase() || 'P'}
                            </div>
                            <div>
                              <p className="font-semibold">
                                {referredPartner?.company_name || 'Pending Application'}
                              </p>
                              <p className="text-sm text-gray-600">
                                Referred {format(new Date(referral.created_date), 'MMM d, yyyy')}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge className={
                              referral.status === 'completed' ? 'bg-green-100 text-green-800' :
                              referral.status === 'active' ? 'bg-blue-100 text-blue-800' :
                              referral.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-gray-100 text-gray-800'
                            }>
                              {referral.status}
                            </Badge>
                            {referral.bonus_amount > 0 && (
                              <p className="text-lg font-bold mt-1" style={{ color: '#3D692B' }}>
                                +${referral.bonus_amount}
                              </p>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}