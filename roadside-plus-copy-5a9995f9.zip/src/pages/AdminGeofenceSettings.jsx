import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { MapPin, Save, Users, Map, AlertCircle } from 'lucide-react';
import { MapContainer, TileLayer, Circle, Marker, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

function ServiceAreaPicker({ center, radius, onCenterChange }) {
  const [tempCenter, setTempCenter] = useState(center);

  const MapClickHandler = () => {
    useMapEvents({
      click: (e) => {
        const newCenter = { lat: e.latlng.lat, lng: e.latlng.lng };
        setTempCenter(newCenter);
        onCenterChange(newCenter);
      }
    });
    return null;
  };

  return (
    <MapContainer
      center={[tempCenter.lat, tempCenter.lng]}
      zoom={10}
      style={{ height: '400px', width: '100%' }}
    >
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      <MapClickHandler />
      <Marker position={[tempCenter.lat, tempCenter.lng]} />
      <Circle
        center={[tempCenter.lat, tempCenter.lng]}
        radius={radius * 1609.34}
        pathOptions={{ color: '#FF771D', fillColor: '#FF771D', fillOpacity: 0.2 }}
      />
    </MapContainer>
  );
}

export default function AdminGeofenceSettings() {
  const [selectedTechId, setSelectedTechId] = useState(null);
  const [centerLat, setCenterLat] = useState(37.7749);
  const [centerLng, setCenterLng] = useState(-122.4194);
  const [radius, setRadius] = useState(25);
  const [autoEnabled, setAutoEnabled] = useState(false);
  const queryClient = useQueryClient();

  const { data: technicians = [] } = useQuery({
    queryKey: ['all-tech-profiles'],
    queryFn: () => base44.entities.TechnicianProfile.list('-created_date', 100)
  });

  const { data: users = [] } = useQuery({
    queryKey: ['tech-users'],
    queryFn: () => base44.entities.User.list()
  });

  const selectedTech = technicians.find(t => t.id === selectedTechId);

  useEffect(() => {
    if (selectedTech) {
      setCenterLat(selectedTech.service_area_center_lat || 37.7749);
      setCenterLng(selectedTech.service_area_center_lng || -122.4194);
      setRadius(selectedTech.service_area_radius_miles || 25);
      setAutoEnabled(selectedTech.auto_geofence_enabled || false);
    }
  }, [selectedTech]);

  const updateGeofence = useMutation({
    mutationFn: async () => {
      return base44.entities.TechnicianProfile.update(selectedTechId, {
        service_area_center_lat: centerLat,
        service_area_center_lng: centerLng,
        service_area_radius_miles: radius,
        auto_geofence_enabled: autoEnabled
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-tech-profiles'] });
      alert('Geofence settings updated successfully!');
    }
  });

  const getUserName = (userId) => {
    const user = users.find(u => u.id === userId);
    return user?.full_name || 'Unknown';
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <Map className="w-8 h-8" style={{ color: '#FF771D' }} />
            Geofence Settings
          </h1>
          <p className="text-gray-600 mt-2">Define service areas and enable automatic availability control for technicians</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Technician List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Technicians
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {technicians.map(tech => (
                  <div
                    key={tech.id}
                    onClick={() => setSelectedTechId(tech.id)}
                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                      selectedTechId === tech.id
                        ? 'border-orange-500 bg-orange-50'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <p className="font-semibold">{getUserName(tech.user_id)}</p>
                    <div className="flex items-center gap-2 mt-1">
                      {tech.auto_geofence_enabled ? (
                        <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded">
                          Auto-enabled
                        </span>
                      ) : (
                        <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">
                          Manual
                        </span>
                      )}
                      {tech.is_within_service_area !== undefined && (
                        <span className={`text-xs px-2 py-0.5 rounded ${
                          tech.is_within_service_area
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {tech.is_within_service_area ? 'In Area' : 'Out of Area'}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Configuration */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>
                {selectedTech ? `Configure ${getUserName(selectedTech.user_id)}` : 'Select a Technician'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!selectedTech ? (
                <div className="text-center py-12 text-gray-500">
                  <MapPin className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p>Select a technician to configure their service area</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Auto Geofence Toggle */}
                  <Card className="border-2 border-orange-200 bg-orange-50">
                    <CardContent className="pt-6">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <Label className="font-semibold text-orange-900">
                              Automatic Geofence Control
                            </Label>
                            <Switch
                              checked={autoEnabled}
                              onCheckedChange={setAutoEnabled}
                            />
                          </div>
                          <p className="text-sm text-orange-700">
                            When enabled, the technician will automatically become available when inside their service area 
                            and offline when outside. Location is checked every 30 seconds.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Service Area Configuration */}
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Center Latitude</Label>
                        <Input
                          type="number"
                          step="0.0001"
                          value={centerLat}
                          onChange={(e) => setCenterLat(parseFloat(e.target.value))}
                        />
                      </div>
                      <div>
                        <Label>Center Longitude</Label>
                        <Input
                          type="number"
                          step="0.0001"
                          value={centerLng}
                          onChange={(e) => setCenterLng(parseFloat(e.target.value))}
                        />
                      </div>
                    </div>

                    <div>
                      <Label>Service Radius (miles)</Label>
                      <Input
                        type="number"
                        min="1"
                        max="100"
                        value={radius}
                        onChange={(e) => setRadius(parseInt(e.target.value))}
                      />
                    </div>

                    {/* Map */}
                    <div>
                      <Label className="mb-2 block">Click on map to set service area center</Label>
                      <div className="border rounded-lg overflow-hidden">
                        <ServiceAreaPicker
                          center={{ lat: centerLat, lng: centerLng }}
                          radius={radius}
                          onCenterChange={(newCenter) => {
                            setCenterLat(newCenter.lat);
                            setCenterLng(newCenter.lng);
                          }}
                        />
                      </div>
                    </div>

                    <Button
                      onClick={() => updateGeofence.mutate()}
                      className="w-full text-white"
                      style={{ backgroundColor: '#FF771D' }}
                      disabled={updateGeofence.isLoading}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      {updateGeofence.isLoading ? 'Saving...' : 'Save Geofence Settings'}
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}