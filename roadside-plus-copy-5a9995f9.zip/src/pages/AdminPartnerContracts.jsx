import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  FileText, Search, Download, CheckCircle, XCircle, 
  Clock, AlertCircle, Eye, Edit
} from 'lucide-react';
import { format, differenceInDays } from 'date-fns';
import { createPageUrl } from '@/utils';
import BrandLogo from '../components/branding/BrandLogo';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function AdminPartnerContracts() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedContract, setSelectedContract] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [editData, setEditData] = useState({});
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        window.location.href = createPageUrl('Login');
        return;
      }
      const currentUser = await base44.auth.me();
      if (currentUser.role !== 'admin') {
        window.location.href = createPageUrl('CustomerDashboard');
        return;
      }
      setUser(currentUser);
    } catch (error) {
      window.location.href = createPageUrl('Login');
    }
  };

  const { data: contracts = [] } = useQuery({
    queryKey: ['all-contracts'],
    queryFn: async () => {
      return await base44.entities.PartnerContract.list('-created_date');
    },
    enabled: !!user
  });

  const { data: partners = [] } = useQuery({
    queryKey: ['all-partners'],
    queryFn: async () => {
      return await base44.entities.Partner.list();
    },
    enabled: !!user
  });

  const updateContract = useMutation({
    mutationFn: async ({ contractId, updates }) => {
      await base44.entities.PartnerContract.update(contractId, updates);
      
      const contract = contracts.find(c => c.id === contractId);
      const partner = partners.find(p => p.id === contract.partner_id);
      
      if (partner && updates.status) {
        await base44.integrations.Core.SendEmail({
          to: partner.email,
          subject: '📄 Contract Status Update',
          body: `Your contract "${contract.contract_title}" status has been updated to: ${updates.status}`
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-contracts'] });
      setSelectedContract(null);
      setEditMode(false);
    }
  });

  const signContract = useMutation({
    mutationFn: async (contractId) => {
      await base44.entities.PartnerContract.update(contractId, {
        signed_by_admin: true,
        admin_signature_date: new Date().toISOString(),
        admin_signer_name: user.full_name,
        status: 'active'
      });

      const contract = contracts.find(c => c.id === contractId);
      const partner = partners.find(p => p.id === contract.partner_id);
      
      if (partner) {
        await base44.integrations.Core.SendEmail({
          to: partner.email,
          subject: '✅ Contract Approved and Activated',
          body: `Your contract "${contract.contract_title}" has been reviewed, signed, and is now active.`
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-contracts'] });
      setSelectedContract(null);
    }
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2" style={{ borderColor: '#FF771D' }}></div>
      </div>
    );
  }

  const filteredContracts = contracts.filter(c => {
    const partner = partners.find(p => p.id === c.partner_id);
    const matchesSearch = !searchTerm || 
      c.contract_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      partner?.company_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const pendingReview = contracts.filter(c => c.status === 'pending_review').length;
  const activeContracts = contracts.filter(c => c.status === 'active').length;
  const expiringContracts = contracts.filter(c => {
    if (c.status !== 'active' || !c.end_date) return false;
    const days = differenceInDays(new Date(c.end_date), new Date());
    return days > 0 && days <= 30;
  }).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <BrandLogo variant="icon" size="md" />
            <div>
              <h1 className="text-2xl font-bold">Partner Contracts</h1>
              <p className="text-sm text-gray-600">Manage all partner contracts and agreements</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Contracts</p>
                  <p className="text-3xl font-bold mt-1">{contracts.length}</p>
                </div>
                <FileText className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Review</p>
                  <p className="text-3xl font-bold mt-1">{pendingReview}</p>
                </div>
                <Clock className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active</p>
                  <p className="text-3xl font-bold mt-1" style={{ color: '#3D692B' }}>
                    {activeContracts}
                  </p>
                </div>
                <CheckCircle className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Expiring Soon</p>
                  <p className="text-3xl font-bold mt-1">{expiringContracts}</p>
                </div>
                <AlertCircle className="w-10 h-10 opacity-20" style={{ color: '#FF9F40' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-wrap gap-4">
              <div className="flex-1 min-w-[200px]">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Search contracts or partners..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                {['all', 'pending_review', 'active', 'expired', 'terminated'].map(status => (
                  <Button
                    key={status}
                    variant={statusFilter === status ? 'default' : 'outline'}
                    onClick={() => setStatusFilter(status)}
                    size="sm"
                    style={statusFilter === status ? { backgroundColor: '#FF771D', color: 'white' } : {}}
                  >
                    {status === 'all' ? 'All' : status.replace(/_/g, ' ')}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contracts List */}
        <Card>
          <CardHeader>
            <CardTitle>Contracts ({filteredContracts.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredContracts.map(contract => {
                const partner = partners.find(p => p.id === contract.partner_id);
                const daysUntilExpiry = contract.end_date ? 
                  differenceInDays(new Date(contract.end_date), new Date()) : null;

                return (
                  <Card key={contract.id} className="border hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-bold">{contract.contract_title}</h3>
                            <Badge className={
                              contract.status === 'active' ? 'bg-green-100 text-green-800' :
                              contract.status === 'pending_review' ? 'bg-blue-100 text-blue-800' :
                              contract.status === 'expired' ? 'bg-red-100 text-red-800' :
                              'bg-gray-100 text-gray-800'
                            }>
                              {contract.status.replace(/_/g, ' ')}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">{partner?.company_name || 'Unknown Partner'}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3 text-sm">
                        <div>
                          <p className="text-gray-600">Type</p>
                          <p className="font-semibold capitalize">{contract.contract_type.replace(/_/g, ' ')}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Start Date</p>
                          <p className="font-semibold">
                            {contract.start_date ? format(new Date(contract.start_date), 'MMM d, yyyy') : 'Not set'}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-600">End Date</p>
                          <p className="font-semibold">
                            {contract.end_date ? format(new Date(contract.end_date), 'MMM d, yyyy') : 'Open-ended'}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-600">Signatures</p>
                          <p className="font-semibold">
                            {contract.signed_by_partner && contract.signed_by_admin ? 'Complete' :
                             contract.signed_by_partner ? 'Partner only' : 'None'}
                          </p>
                        </div>
                      </div>

                      {daysUntilExpiry !== null && daysUntilExpiry > 0 && daysUntilExpiry <= 30 && (
                        <div className="bg-yellow-50 border border-yellow-200 rounded p-2 mb-3 text-sm text-yellow-800">
                          ⚠️ Expires in {daysUntilExpiry} day{daysUntilExpiry !== 1 ? 's' : ''}
                        </div>
                      )}

                      <div className="flex gap-2">
                        {contract.contract_document_url && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => window.open(contract.contract_document_url, '_blank')}
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedContract(contract);
                            setEditData(contract);
                          }}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Manage
                        </Button>
                        {contract.status === 'pending_review' && !contract.signed_by_admin && (
                          <Button
                            size="sm"
                            onClick={() => signContract.mutate(contract.id)}
                            disabled={signContract.isLoading}
                            className="text-white"
                            style={{ backgroundColor: '#3D692B' }}
                          >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Approve & Sign
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}

              {filteredContracts.length === 0 && (
                <div className="text-center py-12">
                  <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <p className="text-gray-600">No contracts found</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Contract Management Dialog */}
      <Dialog open={!!selectedContract} onOpenChange={() => {
        setSelectedContract(null);
        setEditMode(false);
      }}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle>{selectedContract?.contract_title}</DialogTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setEditMode(!editMode)}
              >
                <Edit className="w-4 h-4 mr-2" />
                {editMode ? 'Cancel Edit' : 'Edit'}
              </Button>
            </div>
          </DialogHeader>
          {selectedContract && (
            <div className="space-y-4">
              {editMode ? (
                <>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Status</label>
                    <Select
                      value={editData.status}
                      onValueChange={(value) => setEditData({...editData, status: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="pending_review">Pending Review</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="expired">Expired</SelectItem>
                        <SelectItem value="terminated">Terminated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Start Date</label>
                      <Input
                        type="date"
                        value={editData.start_date || ''}
                        onChange={(e) => setEditData({...editData, start_date: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">End Date</label>
                      <Input
                        type="date"
                        value={editData.end_date || ''}
                        onChange={(e) => setEditData({...editData, end_date: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Notes</label>
                    <Textarea
                      value={editData.notes || ''}
                      onChange={(e) => setEditData({...editData, notes: e.target.value})}
                      rows={3}
                    />
                  </div>

                  <Button
                    onClick={() => updateContract.mutate({ 
                      contractId: selectedContract.id, 
                      updates: editData 
                    })}
                    disabled={updateContract.isLoading}
                    className="w-full text-white"
                    style={{ backgroundColor: '#FF771D' }}
                  >
                    {updateContract.isLoading ? 'Saving...' : 'Save Changes'}
                  </Button>
                </>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Partner</p>
                      <p className="font-semibold">
                        {partners.find(p => p.id === selectedContract.partner_id)?.company_name}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">Type</p>
                      <p className="font-semibold capitalize">
                        {selectedContract.contract_type.replace(/_/g, ' ')}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">Start Date</p>
                      <p className="font-semibold">
                        {selectedContract.start_date ? 
                          format(new Date(selectedContract.start_date), 'MMMM d, yyyy') : 'Not set'}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">End Date</p>
                      <p className="font-semibold">
                        {selectedContract.end_date ? 
                          format(new Date(selectedContract.end_date), 'MMMM d, yyyy') : 'Open-ended'}
                      </p>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <h4 className="font-semibold mb-3">Signature Status</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center justify-between">
                        <span>Partner Signature</span>
                        {selectedContract.signed_by_partner ? (
                          <div className="flex items-center gap-2 text-green-600">
                            <CheckCircle className="w-4 h-4" />
                            <span>{format(new Date(selectedContract.partner_signature_date), 'MMM d, yyyy')}</span>
                          </div>
                        ) : (
                          <XCircle className="w-4 h-4 text-gray-400" />
                        )}
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Admin Signature</span>
                        {selectedContract.signed_by_admin ? (
                          <div className="flex items-center gap-2 text-green-600">
                            <CheckCircle className="w-4 h-4" />
                            <span>{format(new Date(selectedContract.admin_signature_date), 'MMM d, yyyy')}</span>
                          </div>
                        ) : (
                          <XCircle className="w-4 h-4 text-gray-400" />
                        )}
                      </div>
                    </div>
                  </div>

                  {selectedContract.notes && (
                    <div className="border-t pt-4">
                      <h4 className="font-semibold mb-2">Notes</h4>
                      <p className="text-sm text-gray-600">{selectedContract.notes}</p>
                    </div>
                  )}

                  {!selectedContract.signed_by_admin && (
                    <Button
                      onClick={() => signContract.mutate(selectedContract.id)}
                      disabled={signContract.isLoading}
                      className="w-full text-white"
                      style={{ backgroundColor: '#3D692B' }}
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      {signContract.isLoading ? 'Signing...' : 'Approve & Sign Contract'}
                    </Button>
                  )}
                </>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}