import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { 
  Gift, Plus, Edit, Trash2, DollarSign, Users, 
  TrendingUp, CheckCircle, Clock, Loader2 
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function AdminReferralManagement() {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingReward, setEditingReward] = useState(null);
  const queryClient = useQueryClient();

  const [rewardForm, setRewardForm] = useState({
    name: '',
    reward_type: 'credit',
    referrer_reward_value: 10,
    referred_reward_value: 10,
    minimum_purchase: 0,
    description: '',
    terms: '',
    expires_days: null,
    is_active: true
  });

  const { data: rewards = [], isLoading: rewardsLoading } = useQuery({
    queryKey: ['referral-rewards'],
    queryFn: async () => {
      return await base44.entities.ReferralReward.list();
    }
  });

  const { data: referrals = [] } = useQuery({
    queryKey: ['all-referrals'],
    queryFn: async () => {
      return await base44.entities.CustomerReferral.filter({}, '-created_date', 100);
    }
  });

  const createReward = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.ReferralReward.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['referral-rewards']);
      setShowCreateDialog(false);
      resetForm();
    }
  });

  const updateReward = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.ReferralReward.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['referral-rewards']);
      setEditingReward(null);
      resetForm();
    }
  });

  const deleteReward = useMutation({
    mutationFn: async (id) => {
      return await base44.entities.ReferralReward.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['referral-rewards']);
    }
  });

  const issueReward = useMutation({
    mutationFn: async (referralId) => {
      const referral = referrals.find(r => r.id === referralId);
      const activeReward = rewards.find(r => r.is_active);
      
      if (!activeReward) {
        throw new Error('No active reward found');
      }

      await base44.entities.CustomerReferral.update(referralId, {
        reward_issued: true,
        reward_amount: activeReward.referrer_reward_value,
        status: 'rewarded'
      });

      // Create notification for referrer
      await base44.entities.Notification.create({
        user_id: referral.referrer_id,
        type: 'job_completed',
        title: '🎉 Referral Reward Issued!',
        message: `You've earned $${activeReward.referrer_reward_value} credit from your referral!`,
        related_id: referralId
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['all-referrals']);
    }
  });

  const resetForm = () => {
    setRewardForm({
      name: '',
      reward_type: 'credit',
      referrer_reward_value: 10,
      referred_reward_value: 10,
      minimum_purchase: 0,
      description: '',
      terms: '',
      expires_days: null,
      is_active: true
    });
  };

  const handleEditReward = (reward) => {
    setEditingReward(reward);
    setRewardForm({
      name: reward.name,
      reward_type: reward.reward_type,
      referrer_reward_value: reward.referrer_reward_value,
      referred_reward_value: reward.referred_reward_value,
      minimum_purchase: reward.minimum_purchase || 0,
      description: reward.description || '',
      terms: reward.terms || '',
      expires_days: reward.expires_days || null,
      is_active: reward.is_active
    });
  };

  const handleSubmit = () => {
    if (editingReward) {
      updateReward.mutate({ id: editingReward.id, data: rewardForm });
    } else {
      createReward.mutate(rewardForm);
    }
  };

  const stats = {
    totalReferrals: referrals.length,
    completedReferrals: referrals.filter(r => r.status === 'completed' || r.status === 'rewarded').length,
    pendingRewards: referrals.filter(r => r.status === 'completed' && !r.reward_issued).length,
    totalRewardsIssued: referrals
      .filter(r => r.reward_issued)
      .reduce((sum, r) => sum + (r.reward_amount || 0), 0)
  };

  if (rewardsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF771D' }} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Referral Program Management</h1>
          <p className="text-gray-600">Manage referral rewards and track program performance</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Total Referrals</p>
                  <p className="text-2xl font-bold mt-1">{stats.totalReferrals}</p>
                </div>
                <Users className="w-8 h-8" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Completed</p>
                  <p className="text-2xl font-bold mt-1">{stats.completedReferrals}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Pending Rewards</p>
                  <p className="text-2xl font-bold mt-1">{stats.pendingRewards}</p>
                </div>
                <Clock className="w-8 h-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Rewards Issued</p>
                  <p className="text-2xl font-bold mt-1">${stats.totalRewardsIssued.toFixed(2)}</p>
                </div>
                <DollarSign className="w-8 h-8" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Rewards Management */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Gift className="w-6 h-6" style={{ color: '#FF771D' }} />
                Referral Rewards
              </CardTitle>
              <Dialog open={showCreateDialog || !!editingReward} onOpenChange={(open) => {
                if (!open) {
                  setShowCreateDialog(false);
                  setEditingReward(null);
                  resetForm();
                }
              }}>
                <DialogTrigger asChild>
                  <Button
                    onClick={() => setShowCreateDialog(true)}
                    style={{ backgroundColor: '#FF771D' }}
                    className="text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Reward
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>
                      {editingReward ? 'Edit Reward' : 'Create New Reward'}
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div>
                      <Label>Reward Name *</Label>
                      <Input
                        value={rewardForm.name}
                        onChange={(e) => setRewardForm({...rewardForm, name: e.target.value})}
                        placeholder="e.g., Standard Referral Reward"
                      />
                    </div>

                    <div>
                      <Label>Reward Type *</Label>
                      <Select
                        value={rewardForm.reward_type}
                        onValueChange={(value) => setRewardForm({...rewardForm, reward_type: value})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="credit">Account Credit</SelectItem>
                          <SelectItem value="discount_fixed">Fixed Discount</SelectItem>
                          <SelectItem value="discount_percentage">Percentage Discount</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Referrer Reward ($) *</Label>
                        <Input
                          type="number"
                          value={rewardForm.referrer_reward_value}
                          onChange={(e) => setRewardForm({...rewardForm, referrer_reward_value: parseFloat(e.target.value)})}
                        />
                      </div>
                      <div>
                        <Label>Referred User Reward ($) *</Label>
                        <Input
                          type="number"
                          value={rewardForm.referred_reward_value}
                          onChange={(e) => setRewardForm({...rewardForm, referred_reward_value: parseFloat(e.target.value)})}
                        />
                      </div>
                    </div>

                    <div>
                      <Label>Minimum Purchase ($)</Label>
                      <Input
                        type="number"
                        value={rewardForm.minimum_purchase}
                        onChange={(e) => setRewardForm({...rewardForm, minimum_purchase: parseFloat(e.target.value)})}
                      />
                    </div>

                    <div>
                      <Label>Expires After (Days)</Label>
                      <Input
                        type="number"
                        value={rewardForm.expires_days || ''}
                        onChange={(e) => setRewardForm({...rewardForm, expires_days: e.target.value ? parseInt(e.target.value) : null})}
                        placeholder="Leave empty for no expiration"
                      />
                    </div>

                    <div>
                      <Label>Description</Label>
                      <Textarea
                        value={rewardForm.description}
                        onChange={(e) => setRewardForm({...rewardForm, description: e.target.value})}
                        placeholder="Short description of the reward..."
                      />
                    </div>

                    <div>
                      <Label>Terms & Conditions</Label>
                      <Textarea
                        value={rewardForm.terms}
                        onChange={(e) => setRewardForm({...rewardForm, terms: e.target.value})}
                        placeholder="Terms and conditions..."
                        className="h-24"
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <Label>Active</Label>
                        <p className="text-sm text-gray-500">Make this the active referral reward</p>
                      </div>
                      <Switch
                        checked={rewardForm.is_active}
                        onCheckedChange={(checked) => setRewardForm({...rewardForm, is_active: checked})}
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-4">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setShowCreateDialog(false);
                          setEditingReward(null);
                          resetForm();
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={handleSubmit}
                        disabled={createReward.isLoading || updateReward.isLoading || !rewardForm.name}
                        style={{ backgroundColor: '#FF771D' }}
                        className="text-white"
                      >
                        {createReward.isLoading || updateReward.isLoading ? 'Saving...' : 'Save Reward'}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            {rewards.length === 0 ? (
              <div className="text-center py-12">
                <Gift className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-500">No rewards created yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {rewards.map((reward) => (
                  <Card key={reward.id} className={reward.is_active ? 'border-2 border-green-500' : ''}>
                    <CardContent className="pt-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-bold text-lg">{reward.name}</h3>
                            {reward.is_active && (
                              <Badge className="bg-green-600">Active</Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 mb-3">{reward.description}</p>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                            <div>
                              <p className="text-xs text-gray-500">Referrer Gets</p>
                              <p className="font-bold" style={{ color: '#3D692B' }}>
                                ${reward.referrer_reward_value}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Referred Gets</p>
                              <p className="font-bold" style={{ color: '#FF771D' }}>
                                ${reward.referred_reward_value}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Type</p>
                              <p className="font-semibold text-sm">
                                {reward.reward_type.replace(/_/g, ' ')}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Min. Purchase</p>
                              <p className="font-semibold text-sm">
                                ${reward.minimum_purchase || 0}
                              </p>
                            </div>
                          </div>

                          {reward.terms && (
                            <p className="text-xs text-gray-500 italic">{reward.terms}</p>
                          )}
                        </div>

                        <div className="flex gap-2 ml-4">
                          <Button
                            size="icon"
                            variant="outline"
                            onClick={() => handleEditReward(reward)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                size="icon"
                                variant="outline"
                                className="text-red-500 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Reward?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Are you sure you want to delete this reward? This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => deleteReward.mutate(reward.id)}
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Referral Tracking */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-6 h-6" style={{ color: '#FF771D' }} />
              Referral Tracking
            </CardTitle>
          </CardHeader>
          <CardContent>
            {referrals.length === 0 ? (
              <div className="text-center py-12">
                <Users className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-500">No referrals yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {referrals.map((referral) => (
                  <div key={referral.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold">Code: {referral.referral_code}</p>
                        <Badge variant={referral.status === 'completed' || referral.status === 'rewarded' ? 'default' : 'secondary'}>
                          {referral.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">
                        Referrer: {referral.referrer_id.substring(0, 12)}...
                      </p>
                      <p className="text-sm text-gray-600">
                        Referred: {referral.referred_id.substring(0, 12)}...
                      </p>
                      <p className="text-xs text-gray-500">
                        {new Date(referral.created_date).toLocaleDateString()}
                      </p>
                    </div>

                    <div className="text-right">
                      {referral.reward_issued ? (
                        <div>
                          <CheckCircle className="w-6 h-6 text-green-600 mb-1" />
                          <p className="text-sm font-bold" style={{ color: '#3D692B' }}>
                            ${referral.reward_amount?.toFixed(2)}
                          </p>
                        </div>
                      ) : referral.status === 'completed' ? (
                        <Button
                          size="sm"
                          onClick={() => issueReward.mutate(referral.id)}
                          disabled={issueReward.isLoading}
                          style={{ backgroundColor: '#3D692B' }}
                          className="text-white"
                        >
                          Issue Reward
                        </Button>
                      ) : (
                        <Clock className="w-6 h-6 text-gray-400" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}