import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { getCachedUser } from '@/components/utils/userCache';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useQueryWithTimeout } from '../components/common/useQueryWithTimeout';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ErrorState from '../components/common/ErrorState';
import { useNetworkStatus } from '../components/offline/NetworkMonitor';
import { offlineJobManager } from '../components/offline/OfflineJobManager';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Send, Navigation as NavIcon, Wrench, CheckCircle, Loader2, Phone, Upload, Image, FileText, Download, X } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { createPageUrl } from '@/utils';
import ServiceMap from '../components/map/ServiceMap';
import StatusBadge from '../components/common/StatusBadge';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import RouteOptimizer from '../components/technician/RouteOptimizer';
import SmartRouteOptimizer from '../components/technician/SmartRouteOptimizer';
import AIJobAssistant from '../components/technician/AIJobAssistant';
import ChatInterface from '../components/chat/ChatInterface';
import ArchivedChatHistory from '../components/chat/ArchivedChatHistory';
import SignatureCapture from '../components/technician/SignatureCapture';
import PaymentSummary from '../components/technician/PaymentSummary';
import TechnicianRatingModal from '../components/technician/TechnicianRatingModal';
import { format } from 'date-fns';
import { cacheServiceRequests } from '../components/offline/cacheServiceRequests';
import { cacheCustomers } from '../components/offline/cacheCustomers';
import { syncManager } from '../components/offline/SyncManager';
import LiveStatusUpdates from '../components/job/LiveStatusUpdates';
import PaymentStatusBadge from '../components/payments/PaymentStatusBadge';

export default function JobDetails() {
  const [user, setUser] = useState(null);
  const [requestId, setRequestId] = useState(null);
  const [message, setMessage] = useState('');
  const [showPriceInput, setShowPriceInput] = useState(false);
  const [price, setPrice] = useState('');
  const [aiDiagnostics, setAiDiagnostics] = useState(null);
  const [loadingDiagnostics, setLoadingDiagnostics] = useState(false);
  const [troubleshootingSteps, setTroubleshootingSteps] = useState(null);
  const [loadingTroubleshooting, setLoadingTroubleshooting] = useState(false);
  const [generatingSummary, setGeneratingSummary] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [selectedFileType, setSelectedFileType] = useState('photo_before');
  const [showSignatureCapture, setShowSignatureCapture] = useState(false);
  const [uploadingSignature, setUploadingSignature] = useState(false);
  const [previousStatus, setPreviousStatus] = useState(null);
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [submittingRating, setSubmittingRating] = useState(false);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isOnline } = useNetworkStatus();

  useEffect(() => {
    loadUser();
    const params = new URLSearchParams(window.location.search);
    setRequestId(params.get('id'));
  }, []);

  const loadUser = async () => {
    const currentUser = await getCachedUser();
    setUser(currentUser);
  };

  const { data: request, isLoading, isError: requestError, error: requestErrorMsg, refetch: refetchRequest } = useQueryWithTimeout({
    queryKey: ['service-request', requestId],
    queryFn: async () => {
      // Try cache first if offline
      if (!isOnline) {
        const cached = await cacheServiceRequests.getRequest(requestId);
        if (cached) return cached;
      }
      
      const requests = await base44.entities.ServiceRequest.filter({ id: requestId });
      const freshRequest = requests[0];
      
      // Cache for offline use
      if (freshRequest) {
        await cacheServiceRequests.saveRequest(freshRequest);
      }
      
      return freshRequest;
    },
    enabled: !!requestId,
    refetchInterval: (data) => {
      if (!isOnline || !data) return false;
      const activeStatuses = ['assigned', 'en_route', 'in_progress'];
      // Increase polling interval to 60s to reduce load
      return activeStatuses.includes(data.status) ? 60000 : false;
    },
    retry: isOnline ? 1 : 0,
    retryDelay: 3000,
    staleTime: 30000, // Increase stale time
    onSuccess: (data) => {
      if (data && previousStatus !== data.status) {
        setPreviousStatus(data.status);
      }
    }
  }, 12000);

  const { data: messages = [] } = useQueryWithTimeout({
    queryKey: ['messages', requestId],
    queryFn: async () => {
      return await base44.entities.Message.filter(
        { service_request_id: requestId },
        'created_date'
      );
    },
    enabled: !!requestId,
    refetchInterval: 120000, // Poll less frequently
    retry: 1,
    staleTime: 60000
  }, 15000);

  const { data: customerData } = useQueryWithTimeout({
    queryKey: ['customer', request?.customer_id],
    queryFn: async () => {
      if (!isOnline) {
        const cached = await cacheCustomers.getCustomer(request.customer_id);
        if (cached) return cached;
      }

      const users = await base44.entities.User.filter({ id: request.customer_id });
      const customer = users[0];

      if (customer) {
        await cacheCustomers.saveCustomer(customer);
      }

      return customer;
    },
    enabled: !!request?.customer_id,
    staleTime: 600000, // Increase stale time for customer data (rarely changes)
    retry: 1
  }, 15000);

  const { data: techProfile } = useQueryWithTimeout({
    queryKey: ['tech-profile', user?.id],
    queryFn: async () => {
      const profiles = await base44.entities.TechnicianProfile.filter({ user_id: user.id });
      return profiles[0];
    },
    enabled: !!user?.id,
    staleTime: 300000,
    retry: 1
  }, 15000);

  const { data: attachments = [] } = useQueryWithTimeout({
    queryKey: ['attachments', requestId],
    queryFn: async () => {
      return await base44.entities.ServiceAttachment.filter(
        { service_request_id: requestId },
        'created_date'
      );
    },
    enabled: !!requestId,
    staleTime: 60000,
    retry: 1
  }, 15000);

  const updateStatus = useMutation({
    mutationFn: async (status) => {
      const updates = { status };
      if (status === 'completed') {
        updates.completed_at = new Date().toISOString();
        updates.payment_status = 'pending';
        updates.payment_amount = request.price || 50;
        updates.status = 'awaiting_review'; // Technician must rate before truly complete
      }
      if (status === 'assigned' && user?.id) {
        updates.technician_id = user.id;
        updates.current_offered_technician_id = null;
        updates.offer_expires_at = null;
      }
      if (status === 'cancelled') {
        // Unlock technician and reset to dispatch state
        updates.status = 'pending_dispatch';
        updates.technician_id = null;
        updates.current_offered_technician_id = null;
        updates.offer_expires_at = null;
      }

      // Update cache immediately
      await cacheServiceRequests.updateRequestStatus(requestId, status);

      // If offline, queue the update
      if (!isOnline) {
        await syncManager.queueAction('update_status', { requestId, status });
        return { ...request, ...updates };
      }

      return await base44.entities.ServiceRequest.update(requestId, updates);
    },
    onSuccess: async (updatedRequest) => {
      queryClient.invalidateQueries(['service-request', requestId]);

      // Log status change event
      await base44.entities.Event.create({
        type: 'STATUS_CHANGED',
        request_id: requestId,
        customer_id: updatedRequest.customer_id,
        technician_id: updatedRequest.technician_id,
        payload: {
          from_status: request.status,
          to_status: updatedRequest.status,
          changed_by: 'technician'
        }
      });

      // Create notification for customer with immediate push
      if (updatedRequest.customer_id) {
        const notificationMessages = {
          'en_route': { 
            title: '🚗 Technician Started Journey', 
            message: 'Your technician is on the way to your location!',
            emoji: '🚗'
          },
          'in_progress': { 
            title: '🔧 Job Started', 
            message: 'Your technician has started working on your vehicle.',
            emoji: '🔧'
          },
          'completed': { 
            title: '✅ Job Completed', 
            message: 'Your service has been completed. Please rate your experience.',
            emoji: '✅'
          },
          'cancelled': { 
            title: '❌ Request Cancelled', 
            message: 'The technician has cancelled this request.',
            emoji: '❌'
          }
        };

        const notification = notificationMessages[updatedRequest.status];
        if (notification) {
          await base44.entities.Notification.create({
            user_id: updatedRequest.customer_id,
            type: updatedRequest.status === 'en_route' ? 'technician_en_route' : 
                  updatedRequest.status === 'in_progress' ? 'technician_arrived' : 
                  updatedRequest.status === 'cancelled' ? 'job_completed' : 'job_completed',
            title: notification.title,
            message: notification.message,
            related_id: updatedRequest.id
          });

          // Immediate push notification for critical status updates
          if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
            try {
              new Notification(notification.title, {
                body: notification.message,
                icon: '/icon-192.png',
                tag: `status-${updatedRequest.id}`,
                requireInteraction: ['completed', 'cancelled'].includes(updatedRequest.status),
                vibrate: [200, 100, 200]
              });
            } catch (e) {
              console.warn('Notification constructor failed (Despia Runtime):', e);
            }
          }
        }
      }

      // Show rating modal when job moves to awaiting_review
      if (updatedRequest.status === 'awaiting_review') {
        setShowRatingModal(true);
      }

      // If cancelled, trigger immediate dispatch and redirect
      if (updatedRequest.status === 'pending_dispatch') {
        // Trigger dispatch to find next technician immediately
        try {
          await base44.functions.invoke('dispatchServiceRequest', {
            requestId: updatedRequest.id
          });
        } catch (error) {
          console.error('Dispatch failed:', error);
        }

        setTimeout(() => {
          navigate(createPageUrl('TechnicianDashboard'));
        }, 1500);
      }
    }
  });

  const updatePrice = useMutation({
    mutationFn: async () => {
      const priceValue = parseFloat(price);
      
      // Update cache immediately
      const cached = await cacheServiceRequests.getRequest(requestId);
      if (cached) {
        cached.price = priceValue;
        await cacheServiceRequests.saveRequest(cached);
      }
      
      // If offline, queue the update
      if (!isOnline) {
        await syncManager.queueAction('set_price', { requestId, price: priceValue });
        return { ...request, price: priceValue };
      }
      
      return await base44.entities.ServiceRequest.update(requestId, {
        price: priceValue
      });
    },
    onSuccess: () => {
      setShowPriceInput(false);
      setPrice('');
      queryClient.invalidateQueries(['service-request', requestId]);
    }
  });

  const rejectJob = useMutation({
    mutationFn: async () => {
      // Log technician activity
      await base44.entities.TechnicianJobActivity.create({
        service_request_id: requestId,
        technician_id: user.id,
        activity_type: 'offer_rejected',
        reason: 'Rejected from job details page'
      });
      
      const updates = {
        current_offered_technician_id: null,
        offer_expires_at: null,
        status: 'pending_dispatch'
      };
      
      if (!isOnline) {
        await syncManager.queueAction('update_status', { requestId, status: 'pending_dispatch' });
        return { ...request, ...updates };
      }
      
      return await base44.entities.ServiceRequest.update(requestId, updates);
    },
    onSuccess: () => {
      navigate(createPageUrl('TechnicianDashboard'));
    }
  });

  const sendMessage = useMutation({
    mutationFn: async () => {
      return await base44.entities.Message.create({
        service_request_id: requestId,
        sender_id: user.id,
        sender_role: user.user_type,
        message: message
      });
    },
    onSuccess: async (newMessage) => {
      setMessage('');
      queryClient.invalidateQueries(['messages', requestId]);
      
      // Notify customer of new message
      if (request?.customer_id) {
        await base44.entities.Notification.create({
          user_id: request.customer_id,
          type: 'new_message',
          title: 'New Message',
          message: 'Your technician sent you a message.',
          related_id: requestId
        });
      }
    }
  });

  const openNavigation = () => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${request.location_lat},${request.location_lng}`;
    window.open(url, '_blank');
  };

  const getDiagnostics = async () => {
    setLoadingDiagnostics(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert automotive technician providing diagnostic assistance for a roadside service call.

Service Request Details:
- Service Type: ${request.service_type.replace(/_/g, ' ')}
- Customer Description: ${request.description || 'No description provided'}
- Vehicle: ${request.vehicle_year || ''} ${request.vehicle_make || ''} ${request.vehicle_model || ''}

Provide a comprehensive diagnostic analysis including:
1. Most likely causes of the issue
2. Things to check or inspect
3. Required tools or parts
4. Safety considerations
5. Estimated repair difficulty (Easy/Medium/Hard)

Be practical and specific for roadside assistance scenarios.`,
        response_json_schema: {
          type: 'object',
          properties: {
            likely_causes: {
              type: 'array',
              items: { type: 'string' },
              description: 'List of most likely causes'
            },
            inspection_checklist: {
              type: 'array',
              items: { type: 'string' },
              description: 'Things to check or inspect'
            },
            required_items: {
              type: 'array',
              items: { type: 'string' },
              description: 'Required tools or parts'
            },
            safety_notes: {
              type: 'array',
              items: { type: 'string' },
              description: 'Safety considerations'
            },
            difficulty: {
              type: 'string',
              enum: ['Easy', 'Medium', 'Hard'],
              description: 'Repair difficulty level'
            }
          }
        }
      });
      setAiDiagnostics(response);
    } catch (error) {
      console.error('Error getting diagnostics:', error);
      alert('Failed to get AI diagnostics. Please try again.');
    } finally {
      setLoadingDiagnostics(false);
    }
  };

  const getTroubleshootingSteps = async () => {
    setLoadingTroubleshooting(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert automotive technician. Provide step-by-step troubleshooting instructions for this roadside service call.

Service Type: ${request.service_type.replace(/_/g, ' ')}
Vehicle: ${request.vehicle_year || ''} ${request.vehicle_make || ''} ${request.vehicle_model || ''}
Issue: ${request.description || 'Standard ' + request.service_type.replace(/_/g, ' ')}

Provide clear, numbered step-by-step instructions that a technician can follow on-site. Include:
- Initial assessment steps
- Main repair/service steps
- Verification/testing steps
- What to tell the customer

Keep it practical for roadside scenarios.`,
        response_json_schema: {
          type: 'object',
          properties: {
            steps: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  step_number: { type: 'number' },
                  title: { type: 'string' },
                  description: { type: 'string' }
                }
              },
              description: 'Step by step instructions'
            },
            estimated_time: {
              type: 'string',
              description: 'Estimated completion time'
            }
          }
        }
      });
      setTroubleshootingSteps(response);
    } catch (error) {
      console.error('Error getting troubleshooting steps:', error);
      alert('Failed to get troubleshooting steps. Please try again.');
    } finally {
      setLoadingTroubleshooting(false);
    }
  };

  const generateRepairSummary = async () => {
    setGeneratingSummary(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a professional repair summary for a customer based on this service call.

Service Type: ${request.service_type.replace(/_/g, ' ')}
Vehicle: ${request.vehicle_year || ''} ${request.vehicle_make || ''} ${request.vehicle_model || ''}
Issue Description: ${request.description || 'Standard service'}
Service Price: $${request.price || 'TBD'}

Create a friendly, professional summary that includes:
- What was done
- Any findings or issues addressed
- Recommendations (if any)
- Next steps or follow-up advice

Keep it concise but informative for the customer.`,
        response_json_schema: {
          type: 'object',
          properties: {
            summary: {
              type: 'string',
              description: 'The repair summary message'
            }
          }
        }
      });

      setMessage(response.summary);
    } catch (error) {
      console.error('Error generating summary:', error);
      alert('Failed to generate summary. Please try again.');
    } finally {
      setGeneratingSummary(false);
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setUploadingFile(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      await base44.entities.ServiceAttachment.create({
        service_request_id: requestId,
        file_url,
        file_type: selectedFileType,
        file_name: file.name,
        uploaded_by: user.id
      });

      queryClient.invalidateQueries(['attachments', requestId]);
      
      // Notify customer
      if (request?.customer_id) {
        await base44.entities.Notification.create({
          user_id: request.customer_id,
          type: 'new_message',
          title: 'New Attachment',
          message: 'Your technician uploaded a file to your service request.',
          related_id: requestId
        });
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload file. Please try again.');
    } finally {
      setUploadingFile(false);
      event.target.value = '';
    }
  };

  const handleSignatureSave = async (signatureFile) => {
    setUploadingSignature(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: signatureFile });

      await base44.entities.ServiceAttachment.create({
        service_request_id: requestId,
        file_url,
        file_type: 'other',
        file_name: 'customer-signature.png',
        description: 'Customer signature for job completion',
        uploaded_by: user.id
      });

      queryClient.invalidateQueries(['attachments', requestId]);
      setShowSignatureCapture(false);

      // Notify customer
      if (request?.customer_id) {
        await base44.entities.Notification.create({
          user_id: request.customer_id,
          type: 'job_completed',
          title: 'Job Completed',
          message: 'Your service has been completed and signature captured.',
          related_id: requestId
        });
      }
    } catch (error) {
      console.error('Signature upload error:', error);
      alert('Failed to save signature. Please try again.');
    } finally {
      setUploadingSignature(false);
    }
  };

  const handleRatingSubmit = async ({ rating, comment }) => {
    setSubmittingRating(true);
    try {
      // Create rating for customer
      await base44.entities.Rating.create({
        service_request_id: requestId,
        technician_id: user.id,
        customer_id: request.customer_id,
        rating,
        comment
      });

      // Update job to completed (awaiting customer rating)
      await base44.entities.ServiceRequest.update(requestId, {
        status: 'completed',
        completed_at: new Date().toISOString()
      });

      // Log completion event with technician rating
      await base44.entities.Event.create({
        type: 'RATING_SUBMITTED',
        request_id: requestId,
        customer_id: request.customer_id,
        technician_id: user.id,
        payload: {
          rating_by: 'technician',
          rating: rating,
          has_comment: !!comment
        }
      });

      // Unlock technician - set available for next job
      const techProfiles = await base44.entities.TechnicianProfile.filter({ user_id: user.id });
      if (techProfiles[0]) {
        await base44.entities.TechnicianProfile.update(techProfiles[0].id, {
          availability_status: 'available',
          is_available: true
        });
      }

      // Notify customer to rate
      await base44.entities.Notification.create({
        user_id: request.customer_id,
        type: 'job_completed',
        title: '✅ Service Completed',
        message: 'Your technician has completed the service. Please rate your experience.',
        related_id: requestId
      });

      // Process referral rewards if applicable
      try {
        await base44.functions.invoke('processReferralReward', {
          serviceRequestId: requestId
        });
      } catch (refError) {
        console.error('Referral reward processing failed:', refError);
      }

      // Redirect to dashboard
      navigate(createPageUrl('TechnicianDashboard'));
      } catch (error) {
      console.error('Rating submission error:', error);
      alert('Failed to submit rating. Please try again.');
      setSubmittingRating(false);
      }
      };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner message="Loading job details..." size="lg" />
      </div>
    );
  }

  if (requestError || !request) {
    return (
      <ErrorState 
        message="We couldn't find this job. It might have been completed, cancelled, or there's a temporary glitch. Please try again or head back to your dashboard."
        onRetry={() => navigate(createPageUrl('TechnicianDashboard'))}
        buttonText="Return to Dashboard"
      />
    );
  }

  const canUpdateStatus = {
    assigned: ['en_route', 'cancelled'],
    en_route: ['arrived'],
    arrived: ['in_progress'],
    in_progress: ['completed']
  };

  const statusButtons = {
    assigned: { label: 'Start Journey', icon: NavIcon, color: '#FF771D', nextStatus: 'en_route' },
    en_route: { label: 'Arrived On Site', icon: MapPin, color: '#FF771D', nextStatus: 'arrived' },
    arrived: { label: 'Start Work', icon: Wrench, color: '#FF771D', nextStatus: 'in_progress' },
    in_progress: { label: 'Complete Job', icon: CheckCircle, color: '#3D692B', nextStatus: 'completed' }
  };

  // Full-screen navigation mode when en_route - keep map active
  if (['en_route', 'arrived', 'in_progress'].includes(request.status)) {
    return (
      <div className="fixed inset-0 z-50 bg-black flex flex-col">
        {/* Top Safe Area Spacer */}
        <div style={{ height: 'var(--safe-area-top)', background: 'linear-gradient(135deg, #E52C2D 0%, #FF771D 100%)' }} />
        {/* Top Bar */}
        <div className="text-white p-4 shadow-lg" style={{ background: 'linear-gradient(135deg, #E52C2D 0%, #FF771D 100%)' }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button 
                variant="ghost" 
                size="icon"
                className="text-white hover:bg-white/20"
                onClick={() => navigate(createPageUrl('TechnicianDashboard'))}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h2 className="font-bold">
                  {request.status === 'en_route' ? 'En Route to Customer' : 
                   request.status === 'arrived' ? 'On Site' : 
                   'Working on Vehicle'}
                </h2>
                <p className="text-xs opacity-90">{request.location_address}</p>
              </div>
            </div>
            <div className="flex gap-2">
              {customerData?.phone && (
                <Button
                  size="icon"
                  className="text-white"
                  style={{ backgroundColor: '#3D692B' }}
                  onClick={() => window.location.href = `tel:${customerData.phone}`}
                >
                  <Phone className="w-5 h-5" />
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Customer Info Banner */}
        <div className="bg-white p-4 shadow-md border-b-4" style={{ borderColor: '#FF771D' }}>
          <div className="max-w-4xl mx-auto">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <h3 className="text-lg font-bold mb-2">Customer Information</h3>
                <div className="grid md:grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-gray-500 text-xs">Name</p>
                    <p className="font-semibold">{customerData?.full_name || 'Customer'}</p>
                  </div>
                  {customerData?.email && (
                    <div>
                      <p className="text-gray-500 text-xs">Email</p>
                      <p className="font-medium">{customerData.email}</p>
                    </div>
                  )}
                  {customerData?.phone && (
                    <div>
                      <p className="text-gray-500 text-xs">Phone</p>
                      <a href={`tel:${customerData.phone}`} className="font-medium" style={{ color: '#FF771D' }}>
                        {customerData.phone}
                      </a>
                    </div>
                  )}
                  {request.vehicle_make && (
                    <div>
                      <p className="text-gray-500 text-xs">Vehicle</p>
                      <p className="font-medium">
                        {request.vehicle_year} {request.vehicle_make} {request.vehicle_model}
                        {request.vehicle_color && ` • ${request.vehicle_color}`}
                      </p>
                    </div>
                  )}
                </div>
              </div>
              {request.status === 'en_route' && (
                <Button
                  className="text-white"
                  style={{ backgroundColor: '#FF771D' }}
                  onClick={() => updateStatus.mutate('arrived')}
                >
                  <MapPin className="w-4 h-4 mr-2" />
                  Arrived On Site
                </Button>
              )}
              
              {request.status === 'arrived' && (
                <Button
                  className="text-white"
                  style={{ backgroundColor: '#FF771D' }}
                  onClick={() => updateStatus.mutate('in_progress')}
                >
                  <Wrench className="w-4 h-4 mr-2" />
                  Start Work
                </Button>
              )}

              {request.status === 'in_progress' && (
                <Button
                  className="text-white"
                  style={{ backgroundColor: '#3D692B' }}
                  onClick={() => updateStatus.mutate('completed')}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Complete Job
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Full Screen Map */}
        <div className="flex-1 relative">
          <ServiceMap
            customerLocation={request.location_lat && request.location_lng ? [request.location_lat, request.location_lng] : null}
            technicianLocation={techProfile?.current_lat ? [techProfile.current_lat, techProfile.current_lng] : null}
            height="100%"
            zoom={14}
          />
          <Button
            className="absolute bottom-6 left-1/2 transform -translate-x-1/2 text-white px-8 py-6 text-lg shadow-2xl"
            style={{ backgroundColor: '#3D692B' }}
            onClick={openNavigation}
          >
            <NavIcon className="w-6 h-6 mr-3" />
            Open in Maps App
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50 overflow-hidden">
      {/* Top Safe Area Spacer */}
      <div style={{ height: 'var(--safe-area-top)', flexShrink: 0, background: 'linear-gradient(135deg, #E52C2D 0%, #FF771D 100%)' }} />
      
      {/* Live Status Updates */}
      <LiveStatusUpdates currentStatus={request?.status} previousStatus={previousStatus} />
      
      {/* Header */}
      <div className="relative text-white p-4 md:p-6 shadow-lg flex-shrink-0" 
           style={{ 
             background: 'linear-gradient(135deg, #E52C2D 0%, #FF771D 100%)'
           }}>
        <div className="max-w-6xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20"
            onClick={() => navigate(createPageUrl('TechnicianDashboard'))}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl md:text-2xl font-bold">Job Details</h1>
            <p className="text-xs md:text-sm opacity-90">
              {request.created_date ? format(new Date(request.created_date), 'MMMM d, yyyy h:mm a') : 'Date not available'}
            </p>
          </div>
        </div>
      </div>

      {/* App Container (Scrollable) */}
      <div className="flex-1 overflow-y-auto scrollbar-hide">
      <div className="max-w-6xl mx-auto p-4 md:p-6"
           style={{ 
             paddingLeft: 'max(1rem, env(safe-area-inset-left))',
             paddingRight: 'max(1rem, env(safe-area-inset-right))'
           }}>
        <div className="flex flex-col lg:grid lg:grid-cols-2 gap-4 md:gap-6">
          {/* Left Column - Details & Actions */}
          <div className="space-y-6">
            {/* Service Info */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-3">
                    <ServiceTypeIcon type={request.service_type} />
                    <span>
                      {(request.service_type || 'service').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </span>
                  </CardTitle>
                  <StatusBadge status={request.status} />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Customer Info */}
                <div className="bg-gradient-to-r from-orange-50 to-red-50 rounded-lg p-3 md:p-4 border-2" style={{ borderColor: '#FF771D' }}>
                  <h4 className="font-bold mb-2 md:mb-3 text-base md:text-lg flex items-center gap-2">
                    👤 Customer Information
                  </h4>
                  <div className="space-y-2">
                    <div>
                      <p className="text-xs text-gray-600 mb-1">Full Name</p>
                      <p className="font-bold text-base md:text-lg break-words">{customerData?.full_name || 'Customer'}</p>
                    </div>
                    {customerData?.email && (
                      <div>
                        <p className="text-xs text-gray-600 mb-1">Email</p>
                        <a 
                          href={`mailto:${customerData.email}`}
                          className="font-semibold hover:underline text-sm md:text-base break-all"
                          style={{ color: '#FF771D' }}
                        >
                          {customerData.email}
                        </a>
                      </div>
                    )}
                    {customerData?.phone && (
                      <div>
                        <p className="text-xs text-gray-600 mb-1">Phone Number</p>
                        <a 
                          href={`tel:${customerData.phone}`}
                          className="flex items-center gap-2 font-bold text-base md:text-lg hover:underline"
                          style={{ color: '#E52C2D' }}
                        >
                          <Phone className="w-4 h-4 md:w-5 md:h-5" />
                          {customerData.phone}
                        </a>
                      </div>
                    )}
                  </div>
                </div>

                {request.description && (
                  <div>
                    <h4 className="font-semibold mb-1">Description</h4>
                    <p className="text-gray-600 text-sm">{request.description}</p>
                  </div>
                )}
                
                {request.location_address && (
                  <div>
                    <h4 className="font-semibold mb-1">Location</h4>
                    <p className="text-gray-600 text-sm">{request.location_address}</p>
                  </div>
                )}

                {request.vehicle_make && (
                  <div className="bg-blue-50 rounded-lg p-3 md:p-4 border border-blue-200">
                    <h4 className="font-semibold mb-2 flex items-center gap-2 text-sm md:text-base">
                      🚗 Vehicle Information
                    </h4>
                    <div className="space-y-1 text-xs md:text-sm">
                      <p className="break-words">
                        <span className="font-medium">Model:</span> {request.vehicle_year} {request.vehicle_make} {request.vehicle_model}
                      </p>
                      {request.vehicle_color && (
                        <p><span className="font-medium">Color:</span> {request.vehicle_color}</p>
                      )}
                      {request.vehicle_license_plate && (
                        <p><span className="font-medium">Plate:</span> {request.vehicle_license_plate}</p>
                      )}
                      {request.vehicle_vin && (
                        <p className="text-xs break-all"><span className="font-medium">VIN:</span> {request.vehicle_vin}</p>
                      )}
                    </div>
                  </div>
                )}

                {/* Payment Status */}
                {request.payment_status && (
                  <div className="bg-blue-50 rounded-lg p-3 md:p-4 border border-blue-200">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                      <div>
                        <p className="text-xs md:text-sm text-gray-600 mb-1">Payment Status</p>
                        <PaymentStatusBadge status={request.payment_status} />
                      </div>
                      {request.payment_status === 'paid' && request.payment_amount && (
                        <div className="text-left sm:text-right">
                          <p className="text-lg md:text-xl font-bold" style={{ color: '#3D692B' }}>
                            ${request.payment_amount.toFixed(2)}
                          </p>
                          {request.paid_at && (
                            <p className="text-xs text-gray-500">
                              {format(new Date(request.paid_at), 'MMM d, h:mm a')}
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Price */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold">Service Price</h4>
                    {!request.price && request.status !== 'completed' && (
                      <Button
                        variant="link"
                        className="p-0 h-auto"
                        style={{ color: '#E52C2D' }}
                        onClick={() => setShowPriceInput(true)}
                      >
                        Set Price
                      </Button>
                    )}
                  </div>
                  {showPriceInput ? (
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="Enter price"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                      />
                      <Button
                        onClick={() => updatePrice.mutate()}
                        disabled={!price || updatePrice.isLoading}
                        style={{ backgroundColor: '#E52C2D' }}
                        className="text-white"
                      >
                        Save
                      </Button>
                    </div>
                  ) : request.price ? (
                    <p className="text-2xl font-bold" style={{ color: '#E52C2D' }}>
                      ${request.price.toFixed(2)}
                    </p>
                  ) : (
                    <p className="text-gray-500 text-sm">Not set</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Accept/Reject Job Buttons - visible only when job is offered to this technician */}
            {request.status === 'pending_dispatch' && request.current_offered_technician_id === user?.id && (
              <Card>
                <CardContent className="p-6 space-y-3">
                  <Button
                    className="w-full text-white text-lg py-6 hover:opacity-90"
                    style={{ backgroundColor: '#3D692B' }}
                    onClick={() => updateStatus.mutate('assigned')}
                    disabled={updateStatus.isLoading || rejectJob.isLoading}
                  >
                    {updateStatus.isLoading ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Accepting Job...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-5 h-5 mr-2" />
                        Accept Job
                      </>
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full text-lg py-6 border-2"
                    style={{ borderColor: '#E52C2D', color: '#E52C2D' }}
                    onClick={() => rejectJob.mutate()}
                    disabled={updateStatus.isLoading || rejectJob.isLoading}
                  >
                    {rejectJob.isLoading ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Rejecting...
                      </>
                    ) : (
                      <>
                        ✕ Reject Job
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Action Buttons */}
            {canUpdateStatus[request.status] && (
              <Card>
                <CardContent className="p-6 space-y-3">
                  {/* Main Action Button */}
                  {statusButtons[request.status] && (
                    <Button
                      className="w-full text-white text-lg py-6 hover:opacity-90"
                      style={{ backgroundColor: statusButtons[request.status].color }}
                      onClick={() => updateStatus.mutate(statusButtons[request.status].nextStatus)}
                      disabled={updateStatus.isLoading}
                    >
                      {updateStatus.isLoading ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Updating...
                        </>
                      ) : (
                        <>
                          {React.createElement(statusButtons[request.status].icon, { className: "w-5 h-5 mr-2" })}
                          {statusButtons[request.status].label}
                        </>
                      )}
                    </Button>
                  )}

                  {/* Cancel Request - Only for assigned status */}
                  {request.status === 'assigned' && (
                    <Button
                      variant="outline"
                      className="w-full py-6 border-2 border-red-500 text-red-600 hover:bg-red-50"
                      onClick={() => {
                        if (confirm('Cancel this job? The system will immediately search for another technician for the customer.')) {
                          updateStatus.mutate('cancelled');
                        }
                      }}
                      disabled={updateStatus.isLoading}
                    >
                      <X className="w-5 h-5 mr-2" />
                      Cancel Request
                    </Button>
                  )}

                  {/* Start Job - Only after arrived */}
                  {request.status === 'arrived' && (
                    <Button
                      variant="outline"
                      className="w-full py-6 border-2"
                      style={{ borderColor: '#3D692B', color: '#3D692B' }}
                      onClick={() => updateStatus.mutate('in_progress')}
                      disabled={updateStatus.isLoading}
                    >
                      <Wrench className="w-5 h-5 mr-2" />
                      Start Work
                    </Button>
                  )}

                  {/* Get Signature before completing */}
                  {request.status === 'in_progress' && !attachments.find(a => a.description?.includes('Customer signature')) && (
                    <Button
                      variant="outline"
                      className="w-full py-6 border-2"
                      style={{ borderColor: '#FF771D', color: '#FF771D' }}
                      onClick={() => setShowSignatureCapture(true)}
                      disabled={uploadingSignature}
                    >
                      {uploadingSignature ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Saving Signature...
                        </>
                      ) : (
                        <>
                          ✍️ Get Customer Signature
                        </>
                      )}
                    </Button>
                  )}

                  {/* Open in Maps */}
                  {(request.status === 'assigned' || request.status === 'en_route') && (
                    <Button
                      variant="outline"
                      className="w-full py-6 border-2"
                      style={{ borderColor: '#FF771D', color: '#FF771D' }}
                      onClick={openNavigation}
                    >
                      <NavIcon className="w-5 h-5 mr-2" />
                      Open in Maps
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}

            {/* File Upload */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="w-5 h-5" style={{ color: '#E52C2D' }} />
                  Upload Files
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="file_type" className="mb-2 block">File Type</Label>
                  <Select value={selectedFileType} onValueChange={setSelectedFileType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="photo_before">Before Photo</SelectItem>
                      <SelectItem value="photo_after">After Photo</SelectItem>
                      <SelectItem value="diagnostic_report">Diagnostic Report</SelectItem>
                      <SelectItem value="receipt">Receipt</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <input
                    type="file"
                    id="file-upload"
                    className="hidden"
                    accept="image/*,.pdf,.doc,.docx"
                    onChange={handleFileUpload}
                    disabled={uploadingFile}
                  />
                  <Button
                    variant="outline"
                    className="w-full"
                    style={{ borderColor: '#E52C2D', color: '#E52C2D' }}
                    onClick={() => document.getElementById('file-upload').click()}
                    disabled={uploadingFile}
                  >
                    {uploadingFile ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Choose File
                      </>
                    )}
                  </Button>
                </div>

                {attachments.length > 0 && (
                  <div className="space-y-2 pt-2 border-t">
                    <h4 className="text-sm font-semibold">Uploaded Files ({attachments.length})</h4>
                    {attachments.map((att) => (
                      <div key={att.id} className="flex items-center justify-between p-2 bg-gray-50 rounded border">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          {att.file_type.includes('photo') ? (
                            <Image className="w-4 h-4 text-blue-600 flex-shrink-0" />
                          ) : (
                            <FileText className="w-4 h-4 text-gray-600 flex-shrink-0" />
                          )}
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-medium truncate">{att.file_name}</p>
                            <p className="text-xs text-gray-500">
                              {att.file_type.replace(/_/g, ' ')}
                            </p>
                          </div>
                        </div>
                        <a
                          href={att.file_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800"
                        >
                          <Download className="w-4 h-4" />
                        </a>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* AI Job Assistant - Replaces old AI Assistant */}
            <AIJobAssistant 
              serviceRequest={request}
              onSummaryGenerated={(summary) => {
                // Auto-populate message field with customer message
                setMessage(summary.customer_message);
              }}
            />

            {/* Legacy AI Buttons - Hidden but keeping for backwards compatibility */}
            <Card className="hidden">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  ✨ AI Assistant
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={getDiagnostics}
                  disabled={loadingDiagnostics}
                  style={{ borderColor: '#FF771D', color: '#FF771D' }}
                >
                  {loadingDiagnostics ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    '🔍 Get Diagnostics'
                  )}
                </Button>
                
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={getTroubleshootingSteps}
                  disabled={loadingTroubleshooting}
                  style={{ borderColor: '#FF771D', color: '#FF771D' }}
                >
                  {loadingTroubleshooting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Loading...
                    </>
                  ) : (
                    '📋 Get Troubleshooting Steps'
                  )}
                </Button>

                {aiDiagnostics && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200 space-y-3">
                    <div>
                      <h5 className="font-semibold text-sm mb-1">Likely Causes:</h5>
                      <ul className="text-xs space-y-1">
                        {aiDiagnostics.likely_causes?.map((cause, i) => (
                          <li key={i}>• {cause}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h5 className="font-semibold text-sm mb-1">Inspection Checklist:</h5>
                      <ul className="text-xs space-y-1">
                        {aiDiagnostics.inspection_checklist?.map((item, i) => (
                          <li key={i}>• {item}</li>
                        ))}
                      </ul>
                    </div>
                    {aiDiagnostics.required_items?.length > 0 && (
                      <div>
                        <h5 className="font-semibold text-sm mb-1">Required Items:</h5>
                        <ul className="text-xs space-y-1">
                          {aiDiagnostics.required_items.map((item, i) => (
                            <li key={i}>• {item}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {aiDiagnostics.safety_notes?.length > 0 && (
                      <div>
                        <h5 className="font-semibold text-sm mb-1 text-red-600">⚠️ Safety:</h5>
                        <ul className="text-xs space-y-1">
                          {aiDiagnostics.safety_notes.map((note, i) => (
                            <li key={i}>• {note}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    <div className="pt-2 border-t">
                      <span className="text-xs font-semibold">Difficulty: </span>
                      <span className={`text-xs px-2 py-1 rounded ${
                        aiDiagnostics.difficulty === 'Easy' ? 'bg-green-100 text-green-800' :
                        aiDiagnostics.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {aiDiagnostics.difficulty}
                      </span>
                    </div>
                  </div>
                )}

                {troubleshootingSteps && (
                  <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200 space-y-3">
                    <h5 className="font-semibold text-sm mb-2">Troubleshooting Steps:</h5>
                    {troubleshootingSteps.steps?.map((step, i) => (
                      <div key={i} className="border-l-2 border-green-400 pl-3">
                        <p className="text-xs font-semibold text-green-800">
                          Step {step.step_number}: {step.title}
                        </p>
                        <p className="text-xs text-gray-600 mt-1">{step.description}</p>
                      </div>
                    ))}
                    {troubleshootingSteps.estimated_time && (
                      <p className="text-xs text-gray-500 pt-2 border-t">
                        ⏱️ Estimated time: {troubleshootingSteps.estimated_time}
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Payment Summary */}
            {request.status === 'completed' && (
              <PaymentSummary request={request} />
            )}

            {/* Smart Route Optimizer with Traffic */}
            {techProfile?.current_lat && (
              <SmartRouteOptimizer 
                technicianId={user?.id}
                currentLocation={{ lat: techProfile.current_lat, lng: techProfile.current_lng }}
                activeJobs={[request]}
              />
            )}

            {/* Map */}
            <Card>
              <CardHeader>
                <CardTitle>Location</CardTitle>
              </CardHeader>
              <CardContent>
                <ServiceMap
                  customerLocation={request.location_lat && request.location_lng ? [request.location_lat, request.location_lng] : null}
                  height="300px"
                  zoom={14}
                />
                <Button
                  variant="outline"
                  className="w-full mt-4"
                  onClick={openNavigation}
                >
                  <NavIcon className="w-4 h-4 mr-2" />
                  Navigate
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Chat or Archived History */}
          <div className="w-full lg:sticky lg:top-6">
            <div className={request.status === 'completed' || request.status === 'cancelled' ? '' : 'lg:h-[calc(100vh-200px)]'}>
              {request.status === 'completed' || request.status === 'cancelled' ? (
                <ArchivedChatHistory
                  serviceRequestId={requestId}
                  currentUserId={user?.id}
                  currentUserRole="technician"
                />
              ) : (
                <ChatInterface
                  serviceRequestId={requestId}
                  currentUserId={user?.id}
                  currentUserRole="technician"
                  otherUserId={request.customer_id}
                  otherUserName={customerData?.full_name}
                />
              )}
            </div>
          </div>
        </div>

        {/* Signature Capture Modal */}
        {showSignatureCapture && (
          <SignatureCapture
            onSave={handleSignatureSave}
            onCancel={() => setShowSignatureCapture(false)}
            customerName={customerData?.full_name}
          />
        )}

        {/* Technician Rating Modal - Required after completion */}
        {showRatingModal && (
          <TechnicianRatingModal
            serviceRequest={request}
            customerName={customerData?.full_name || 'Customer'}
            onSubmit={handleRatingSubmit}
            isSubmitting={submittingRating}
          />
        )}
        </div>
        </div>
        
        {/* Bottom Spacer */}
        <div style={{ height: 'var(--safe-area-bottom)', flexShrink: 0 }} />
        </div>
        );
        }