import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { createPageUrl } from '@/utils';
import { 
  Users, Search, Filter, Edit2, CheckSquare, 
  Square, MoreVertical, Shield, UserCog, Mail,
  CheckCircle, AlertCircle, Loader2
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function AdminUserManagement() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [activeTab, setActiveTab] = useState('users');
  const [showBulkRoleDialog, setShowBulkRoleDialog] = useState(false);
  const [targetRole, setTargetRole] = useState('');
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('customer');
  const [inviteLoading, setInviteLoading] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  // Fetch all users
  const { data: users = [], isLoading } = useQuery({
    queryKey: ['all-users-management'],
    queryFn: async () => {
      return await base44.entities.User.list('-created_date', 1000);
    },
    enabled: !!user && user.role === 'admin'
  });

  // Fetch invitations
  const { data: invitations = [], isLoading: loadingInvitations } = useQuery({
    queryKey: ['all-invitations'],
    queryFn: async () => {
      return await base44.entities.Invitation.list('-created_date', 100);
    },
    enabled: !!user && user.role === 'admin'
  });

  // Update User Role Mutation
  const updateUserRole = useMutation({
    mutationFn: async ({ userId, newRole }) => {
      // Using entity update since admin has privileges
      return await base44.entities.User.update(userId, { role: newRole });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['all-users-management']);
    }
  });

  // Bulk Update Mutation
  const bulkUpdateRoles = useMutation({
    mutationFn: async ({ userIds, newRole }) => {
      const promises = userIds.map(id => 
        base44.entities.User.update(id, { role: newRole })
      );
      return await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['all-users-management']);
      setShowBulkRoleDialog(false);
      setSelectedUsers([]);
      setTargetRole('');
    }
  });

  // Send Invite Mutation
  const sendInvite = useMutation({
    mutationFn: async ({ email, role }) => {
      // Use backend function to send secure invitation with token via SendGrid
      const response = await base44.functions.invoke('sendInvitation', { 
        email, 
        role,
        baseUrl: window.location.origin 
      });
      
      if (response.data.error) {
        throw new Error(response.data.error);
      }
      return response.data;
    },
    onSuccess: () => {
      setShowInviteDialog(false);
      setInviteEmail('');
      setInviteRole('customer');
      queryClient.invalidateQueries(['all-invitations']);
      alert("Invitation sent successfully!");
    },
    onError: (error) => {
      console.error("Invite error:", error);
      // Extract the actual error message from the server response if available
      const serverError = error.response?.data?.error || error.response?.data?.message;
      const errorMessage = serverError || error.message || 'Unknown error';
      alert(`Failed to send invitation. Please ensure Resend secrets are set. Error: ${errorMessage}`);
    }
  });

  const deleteInvitation = useMutation({
    mutationFn: async (id) => {
      return await base44.entities.Invitation.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['all-invitations']);
    }
  });

  if (!user || user.role !== 'admin') {
    return <div className="p-8 text-center">Access Denied</div>;
  }

  const filteredUsers = users.filter(u => {
    const matchesSearch = 
      u.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const toggleSelectUser = (userId) => {
    if (selectedUsers.includes(userId)) {
      setSelectedUsers(selectedUsers.filter(id => id !== userId));
    } else {
      setSelectedUsers([...selectedUsers, userId]);
    }
  };

  const toggleSelectAll = () => {
    if (selectedUsers.length === filteredUsers.length) {
      setSelectedUsers([]);
    } else {
      setSelectedUsers(filteredUsers.map(u => u.id));
    }
  };

  const handleBulkRoleUpdate = () => {
    if (!targetRole) return;
    bulkUpdateRoles.mutate({ userIds: selectedUsers, newRole: targetRole });
  };

  const handleInvite = async () => {
    setInviteLoading(true);
    try {
      await sendInvite.mutateAsync({ email: inviteEmail, role: inviteRole });
      // Ideally create a User placeholder or invitation record here if the backend supported it
      // For now just sending email
    } finally {
      setInviteLoading(false);
    }
  };

  const roles = ['admin', 'customer', 'technician', 'partner', 'security_company'];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">User Management</h1>
            <p className="text-gray-600">Manage roles, permissions, and user accounts</p>
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={() => setShowInviteDialog(true)}
              style={{ backgroundColor: '#FF771D' }}
              className="text-white hover:opacity-90"
            >
              <Mail className="w-4 h-4 mr-2" />
              Invite User
            </Button>
          </div>
        </div>

        <Tabs defaultValue="users" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="grid w-full max-w-md grid-cols-2 mb-4">
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="invitations">Invitations</TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            {/* Filters and Actions */}
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                  <div className="flex gap-4 flex-1 w-full md:w-auto">
                    <div className="relative flex-1 md:max-w-sm">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input 
                        placeholder="Search users..." 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <Select value={roleFilter} onValueChange={setRoleFilter}>
                      <SelectTrigger className="w-[180px]">
                        <div className="flex items-center gap-2">
                          <Filter className="w-4 h-4" />
                          <SelectValue placeholder="Filter by Role" />
                        </div>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Roles</SelectItem>
                        {roles.map(r => (
                          <SelectItem key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedUsers.length > 0 && (
                    <div className="flex items-center gap-2 bg-blue-50 p-2 rounded-lg border border-blue-100 w-full md:w-auto justify-between md:justify-start">
                      <span className="text-sm font-medium text-blue-700 px-2">
                        {selectedUsers.length} selected
                      </span>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => setShowBulkRoleDialog(true)}
                        className="bg-white"
                      >
                        <UserCog className="w-4 h-4 mr-2" />
                        Change Role
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Users Table */}
            <Card>
              <CardContent className="p-0 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="p-4 w-10">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="p-0 h-4 w-4"
                            onClick={toggleSelectAll}
                          >
                            {selectedUsers.length === filteredUsers.length && filteredUsers.length > 0 ? (
                              <CheckSquare className="w-4 h-4 text-blue-600" />
                            ) : (
                              <Square className="w-4 h-4 text-gray-400" />
                            )}
                          </Button>
                        </th>
                        <th className="p-4 font-semibold text-gray-600">User</th>
                        <th className="p-4 font-semibold text-gray-600">Role</th>
                        <th className="p-4 font-semibold text-gray-600">Phone</th>
                        <th className="p-4 font-semibold text-gray-600">Status</th>
                        <th className="p-4 font-semibold text-gray-600">Joined</th>
                        <th className="p-4 w-10"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {isLoading ? (
                        <tr>
                          <td colSpan={7} className="p-8 text-center text-gray-500">Loading users...</td>
                        </tr>
                      ) : filteredUsers.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="p-8 text-center text-gray-500">No users found</td>
                        </tr>
                      ) : (
                        filteredUsers.map(u => (
                          <tr key={u.id} className="hover:bg-gray-50 transition-colors group">
                            <td className="p-4">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="p-0 h-4 w-4"
                                onClick={() => toggleSelectUser(u.id)}
                              >
                                {selectedUsers.includes(u.id) ? (
                                  <CheckSquare className="w-4 h-4 text-blue-600" />
                                ) : (
                                  <Square className="w-4 h-4 text-gray-400 group-hover:text-gray-600" />
                                )}
                              </Button>
                            </td>
                            <td className="p-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-xs font-bold text-gray-600">
                                  {u.full_name?.[0] || u.email?.[0] || '?'}
                                </div>
                                <div>
                                  <p className="font-medium text-gray-900">{u.full_name || 'Unnamed'}</p>
                                  <p className="text-xs text-gray-500">{u.email}</p>
                                </div>
                              </div>
                            </td>
                            <td className="p-4">
                              <Select 
                                defaultValue={u.role} 
                                onValueChange={(val) => updateUserRole.mutate({ userId: u.id, newRole: val })}
                              >
                                <SelectTrigger className="h-8 w-[140px] bg-white">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {roles.map(r => (
                                    <SelectItem key={r} value={r} className="capitalize">
                                      {r.replace(/_/g, ' ')}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </td>
                            <td className="p-4 text-gray-600">
                              {u.phone || '-'}
                            </td>
                            <td className="p-4">
                              {u.profile_completed ? (
                                <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Completed</Badge>
                              ) : (
                                <Badge variant="outline" className="text-gray-500">Pending</Badge>
                              )}
                            </td>
                            <td className="p-4 text-gray-600">
                              {format(new Date(u.created_date), 'MMM d, yyyy')}
                            </td>
                            <td className="p-4 text-right">
                              {/* Additional row actions could go here */}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="invitations">
            <Card>
              <CardContent className="p-0 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="p-4 font-semibold text-gray-600">Email</th>
                        <th className="p-4 font-semibold text-gray-600">Role</th>
                        <th className="p-4 font-semibold text-gray-600">Status</th>
                        <th className="p-4 font-semibold text-gray-600">Sent Date</th>
                        <th className="p-4 font-semibold text-gray-600">Expires</th>
                        <th className="p-4 w-20"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {loadingInvitations ? (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-gray-500">Loading invitations...</td>
                        </tr>
                      ) : invitations.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-gray-500">No invitations found</td>
                        </tr>
                      ) : (
                        invitations.map(invite => (
                          <tr key={invite.id} className="hover:bg-gray-50 transition-colors">
                            <td className="p-4 font-medium text-gray-900">{invite.email}</td>
                            <td className="p-4 capitalize">{invite.role.replace(/_/g, ' ')}</td>
                            <td className="p-4">
                              <Badge variant={
                                invite.status === 'accepted' ? 'success' : 
                                invite.status === 'expired' ? 'destructive' : 
                                'outline'
                              } className={
                                invite.status === 'accepted' ? 'bg-green-100 text-green-800' : 
                                invite.status === 'expired' ? 'bg-red-100 text-red-800' : 
                                'text-blue-600 bg-blue-50 border-blue-200'
                              }>
                                {invite.status}
                              </Badge>
                            </td>
                            <td className="p-4 text-gray-600">{format(new Date(invite.created_date), 'MMM d, yyyy')}</td>
                            <td className="p-4 text-gray-600">{format(new Date(invite.expires_at), 'MMM d, yyyy')}</td>
                            <td className="p-4 text-right">
                              {invite.status === 'pending' && (
                                <div className="flex justify-end gap-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                                    onClick={() => {
                                        if(confirm(`Resend invitation to ${invite.email}?`)) {
                                            sendInvite.mutate({ email: invite.email, role: invite.role });
                                        }
                                    }}
                                    disabled={sendInvite.isLoading}
                                  >
                                    Resend
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="text-red-600 hover:text-red-800 hover:bg-red-50"
                                    onClick={() => {
                                        if(confirm('Are you sure you want to revoke this invitation?')) {
                                            deleteInvitation.mutate(invite.id);
                                        }
                                    }}
                                  >
                                    Revoke
                                  </Button>
                                </div>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Bulk Role Update Dialog */}
        <AlertDialog open={showBulkRoleDialog} onOpenChange={setShowBulkRoleDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Bulk Change Role</AlertDialogTitle>
              <AlertDialogDescription>
                You are about to change the role for {selectedUsers.length} selected users.
                This will affect their access permissions and dashboard view.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <div className="py-4">
              <label className="text-sm font-medium text-gray-700 mb-2 block">Select New Role</label>
              <Select value={targetRole} onValueChange={setTargetRole}>
                <SelectTrigger>
                  <SelectValue placeholder="Select role..." />
                </SelectTrigger>
                <SelectContent>
                  {roles.map(r => (
                    <SelectItem key={r} value={r} className="capitalize">
                      {r.replace(/_/g, ' ')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction 
                onClick={handleBulkRoleUpdate}
                disabled={!targetRole || bulkUpdateRoles.isLoading}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {bulkUpdateRoles.isLoading ? 'Updating...' : 'Update Roles'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Invite User Dialog */}
        <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Invite User</DialogTitle>
              <DialogDescription>
                Send an email invitation with a registration link for a specific role.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Email Address</label>
                <Input 
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="user@example.com"
                  type="email"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">Assign Role</label>
                <Select value={inviteRole} onValueChange={setInviteRole}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map(r => (
                      <SelectItem key={r} value={r} className="capitalize">
                        {r.replace(/_/g, ' ')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowInviteDialog(false)}>Cancel</Button>
              <Button 
                onClick={handleInvite}
                disabled={!inviteEmail || inviteLoading}
                style={{ backgroundColor: '#FF771D' }}
                className="text-white hover:opacity-90"
              >
                {inviteLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  'Send Invitation'
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}