import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, TrendingUp, Trophy, Award, BarChart3 } from 'lucide-react';
import { createPageUrl } from '@/utils';
import PerformanceMetrics from '../components/technician/PerformanceMetrics';
import Leaderboard from '../components/technician/Leaderboard';
import AchievementsBadges from '../components/technician/AchievementsBadges';
import PerformanceReports from '../components/technician/PerformanceReports';

export default function TechnicianPerformance() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
    
    const profiles = await base44.entities.TechnicianProfile.filter({ user_id: currentUser.id });
    if (profiles.length > 0) {
      setProfile(profiles[0]);
    }
  };

  if (!user || !profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2" style={{ borderColor: '#FF771D' }} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              variant="ghost" 
              className="text-white hover:bg-white/20"
              onClick={() => window.location.href = createPageUrl('TechnicianDashboard')}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Performance Analytics</h1>
              <p className="text-sm opacity-90">Track your progress and compete with others</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Key Metrics */}
        <div className="mb-6">
          <PerformanceMetrics technicianId={user.id} profile={profile} />
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="reports" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Reports
            </TabsTrigger>
            <TabsTrigger value="leaderboard" className="flex items-center gap-2">
              <Trophy className="w-4 h-4" />
              Leaderboard
            </TabsTrigger>
            <TabsTrigger value="achievements" className="flex items-center gap-2">
              <Award className="w-4 h-4" />
              Achievements
            </TabsTrigger>
          </TabsList>

          <TabsContent value="reports">
            <PerformanceReports technicianId={user.id} />
          </TabsContent>

          <TabsContent value="leaderboard">
            <Leaderboard currentTechnicianId={user.id} />
          </TabsContent>

          <TabsContent value="achievements">
            <AchievementsBadges technicianId={user.id} profile={profile} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}