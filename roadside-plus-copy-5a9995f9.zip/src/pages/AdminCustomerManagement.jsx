import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Users, AlertCircle, Search, Eye, Ban, CheckCircle, 
  Mail, Phone, Calendar, DollarSign, FileText, UserX,
  UserCheck, Key, XCircle, Clock, Trash2
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import StatusBadge from '../components/common/StatusBadge';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import { createPageUrl } from '@/utils';

export default function AdminCustomerManagement() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [showCustomerDetails, setShowCustomerDetails] = useState(false);
  const [actionType, setActionType] = useState(null);
  const [showActionDialog, setShowActionDialog] = useState(false);
  const [customerToDelete, setCustomerToDelete] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  // Fetch all customers
  const { data: customers = [] } = useQuery({
    queryKey: ['all-customers'],
    queryFn: async () => {
      const allUsers = await base44.entities.User.list('-created_date');
      // Filter for customers only (not technicians or admins primarily)
      return allUsers.filter(u => u.role !== 'admin');
    },
    enabled: !!user,
    refetchInterval: 10000
  });

  // Fetch all service requests
  const { data: allRequests = [] } = useQuery({
    queryKey: ['all-customer-requests'],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.list('-created_date', 1000);
    },
    enabled: !!user
  });

  // Fetch all payments
  const { data: allPayments = [] } = useQuery({
    queryKey: ['all-customer-payments'],
    queryFn: async () => {
      return await base44.entities.Payment.list('-created_date', 1000);
    },
    enabled: !!user
  });

  // Fetch customer's requests
  const { data: customerRequests = [] } = useQuery({
    queryKey: ['customer-requests', selectedCustomer?.id],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter(
        { customer_id: selectedCustomer.id },
        '-created_date'
      );
    },
    enabled: !!selectedCustomer
  });

  // Fetch customer's payments
  const { data: customerPayments = [] } = useQuery({
    queryKey: ['customer-payments', selectedCustomer?.id],
    queryFn: async () => {
      const requests = await base44.entities.ServiceRequest.filter({ customer_id: selectedCustomer.id });
      const requestIds = requests.map(r => r.id);
      const payments = await base44.entities.Payment.list('-created_date');
      return payments.filter(p => requestIds.includes(p.request_id));
    },
    enabled: !!selectedCustomer
  });

  // Fetch customer's vehicles
  const { data: customerVehicles = [] } = useQuery({
    queryKey: ['customer-vehicles', selectedCustomer?.id],
    queryFn: async () => {
      return await base44.entities.Vehicle.filter({ customer_id: selectedCustomer.id });
    },
    enabled: !!selectedCustomer
  });

  // Account management mutations
  const updateCustomerStatus = useMutation({
    mutationFn: async ({ customerId, updates }) => {
      return await base44.auth.updateMe(updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['all-customers']);
      queryClient.invalidateQueries(['customer-requests', selectedCustomer?.id]);
      setShowActionDialog(false);
      setSelectedCustomer(null);
      setShowCustomerDetails(false);
    }
  });

  const sendPasswordReset = useMutation({
    mutationFn: async (email) => {
      // Send password reset email
      await base44.integrations.Core.SendEmail({
        to: email,
        subject: 'Password Reset Request',
        body: `A password reset has been requested for your ROADSIDEPLUS account. Please contact support or click the link to reset your password.`
      });
    },
    onSuccess: () => {
      setShowActionDialog(false);
    }
  });

  const deleteCustomer = useMutation({
    mutationFn: async (customerId) => {
      // Cascading delete: vehicles, service requests, payments, ratings, messages, notifications
      const vehicles = await base44.entities.Vehicle.filter({ customer_id: customerId });
      const requests = await base44.entities.ServiceRequest.filter({ customer_id: customerId });
      const payments = await base44.entities.Payment.list();
      const ratings = await base44.entities.Rating.filter({ customer_id: customerId });
      const messages = await base44.entities.Message.filter({ sender_id: customerId });
      const notifications = await base44.entities.Notification.filter({ user_id: customerId });
      const paymentMethods = await base44.entities.PaymentMethod.filter({ user_id: customerId });
      const supportConvos = await base44.entities.SupportConversation.filter({ customer_id: customerId });

      // Delete vehicles
      for (const vehicle of vehicles) {
        await base44.entities.Vehicle.delete({ id: vehicle.id });
      }

      // Delete payments related to customer's requests
      const requestIds = requests.map(r => r.id);
      for (const payment of payments) {
        if (requestIds.includes(payment.request_id)) {
          await base44.entities.Payment.delete({ id: payment.id });
        }
      }

      // Delete service requests
      for (const request of requests) {
        await base44.entities.ServiceRequest.delete({ id: request.id });
      }

      // Delete ratings
      for (const rating of ratings) {
        await base44.entities.Rating.delete({ id: rating.id });
      }

      // Delete messages
      for (const message of messages) {
        await base44.entities.Message.delete({ id: message.id });
      }

      // Delete notifications
      for (const notification of notifications) {
        await base44.entities.Notification.delete({ id: notification.id });
      }

      // Delete payment methods
      for (const method of paymentMethods) {
        await base44.entities.PaymentMethod.delete({ id: method.id });
      }

      // Delete support conversations
      for (const convo of supportConvos) {
        const convoMessages = await base44.entities.SupportMessage.filter({ conversation_id: convo.id });
        for (const msg of convoMessages) {
          await base44.entities.SupportMessage.delete({ id: msg.id });
        }
        await base44.entities.SupportConversation.delete({ id: convo.id });
      }

      // Note: Cannot delete User entity directly, would need backend implementation
      // For now, mark as deleted or implement backend endpoint
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['all-customers']);
      setShowDeleteDialog(false);
      setCustomerToDelete(null);
      setSelectedCustomer(null);
      setShowCustomerDetails(false);
    }
  });

  // Check admin access
  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8">
          <AlertCircle className="w-12 h-12 mx-auto mb-4" style={{ color: '#E52C2D' }} />
          <h2 className="text-xl font-bold text-center">Access Denied</h2>
          <p className="text-gray-600 text-center mt-2">
            This page is only accessible to administrators.
          </p>
        </Card>
      </div>
    );
  }

  // Filter customers
  const filteredCustomers = customers.filter(customer => {
    const searchLower = searchTerm.toLowerCase();
    return (
      customer.email?.toLowerCase().includes(searchLower) ||
      customer.full_name?.toLowerCase().includes(searchLower) ||
      customer.id?.toLowerCase().includes(searchLower)
    );
  });

  // Calculate stats
  const getCustomerStats = (customerId) => {
    const requests = allRequests.filter(r => r.customer_id === customerId);
    const payments = allPayments.filter(p => 
      requests.some(r => r.id === p.request_id)
    );
    const totalSpent = payments
      .filter(p => p.status === 'paid')
      .reduce((sum, p) => sum + (p.amount || 0) + (p.tip_amount || 0), 0);
    
    return {
      totalRequests: requests.length,
      completedRequests: requests.filter(r => r.status === 'completed').length,
      totalSpent: totalSpent
    };
  };

  const stats = {
    total: customers.length,
    active: customers.filter(c => {
      const requests = allRequests.filter(r => r.customer_id === c.id);
      return requests.some(r => ['pending_dispatch', 'dispatched', 'assigned', 'en_route', 'in_progress'].includes(r.status));
    }).length,
    blocked: 0, // Would need a user status field
  };

  const viewCustomerDetails = (customer) => {
    setSelectedCustomer(customer);
    setShowCustomerDetails(true);
  };

  const handleAccountAction = (type) => {
    setActionType(type);
    setShowActionDialog(true);
  };

  const confirmAccountAction = async () => {
    if (actionType === 'reset_password') {
      await sendPasswordReset.mutate(selectedCustomer.email);
    } else if (actionType === 'suspend' || actionType === 'block') {
      // Note: Would need to add status field to User entity
      alert('Account suspension/blocking requires additional User entity fields. Contact support.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Customer Management</h1>
          <p className="text-gray-600 mt-1">View and manage customer accounts and activity</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Customers</p>
                  <p className="text-3xl font-bold mt-1">{stats.total}</p>
                </div>
                <Users className="w-10 h-10" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Customers</p>
                  <p className="text-3xl font-bold mt-1">{stats.active}</p>
                  <p className="text-xs text-gray-500 mt-1">With ongoing jobs</p>
                </div>
                <CheckCircle className="w-10 h-10" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Blocked Accounts</p>
                  <p className="text-3xl font-bold mt-1">{stats.blocked}</p>
                </div>
                <Ban className="w-10 h-10 text-red-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search by name, email, or customer ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Customer List */}
        <Card>
          <CardHeader>
            <CardTitle>All Customers ({filteredCustomers.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {filteredCustomers.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-gray-500">No customers found</p>
                </div>
              ) : (
                filteredCustomers.map(customer => {
                  const customerStats = getCustomerStats(customer.id);
                  return (
                    <Card key={customer.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 flex-1">
                            <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg"
                                 style={{ backgroundColor: '#FF771D' }}>
                              {customer.full_name?.[0]?.toUpperCase() || 'C'}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <h3 className="font-bold text-lg">{customer.full_name || 'Unnamed Customer'}</h3>
                                <Badge variant="outline" className="text-xs">
                                  ID: {customer.id.substring(0, 8)}
                                </Badge>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
                                <div className="flex items-center gap-1 text-gray-600">
                                  <Mail className="w-4 h-4" />
                                  <span className="truncate">{customer.email}</span>
                                </div>
                                <div className="flex items-center gap-1 text-gray-600">
                                  <FileText className="w-4 h-4" />
                                  <span>{customerStats.totalRequests} requests</span>
                                </div>
                                <div className="flex items-center gap-1 text-gray-600">
                                  <DollarSign className="w-4 h-4" />
                                  <span>${customerStats.totalSpent.toFixed(2)} spent</span>
                                </div>
                              </div>
                              <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
                                <Calendar className="w-3 h-3" />
                                Joined {format(new Date(customer.created_date), 'MMM d, yyyy')}
                              </div>
                            </div>
                          </div>
                          <Button
                            onClick={() => viewCustomerDetails(customer)}
                            variant="outline"
                            className="ml-4"
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View Details
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Customer Details Modal */}
      <Dialog open={showCustomerDetails} onOpenChange={setShowCustomerDetails}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          {selectedCustomer && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg"
                       style={{ backgroundColor: '#FF771D' }}>
                    {selectedCustomer.full_name?.[0]?.toUpperCase() || 'C'}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span>{selectedCustomer.full_name || 'Unnamed Customer'}</span>
                      <Badge variant="outline" className="text-xs">
                        {selectedCustomer.role || 'customer'}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-500 font-normal">{selectedCustomer.email}</p>
                  </div>
                </DialogTitle>
              </DialogHeader>

              {/* Account Actions */}
              <div className="grid grid-cols-4 gap-3 my-4">
                <Button
                  variant="outline"
                  onClick={() => handleAccountAction('reset_password')}
                  className="flex items-center gap-2"
                >
                  <Key className="w-4 h-4" />
                  Reset Password
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleAccountAction('suspend')}
                  className="flex items-center gap-2 text-yellow-600 border-yellow-300 hover:bg-yellow-50"
                >
                  <Clock className="w-4 h-4" />
                  Suspend Account
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleAccountAction('block')}
                  className="flex items-center gap-2 text-yellow-600 border-yellow-300 hover:bg-yellow-50"
                >
                  <Ban className="w-4 h-4" />
                  Block Account
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setCustomerToDelete(selectedCustomer);
                    setShowDeleteDialog(true);
                  }}
                  className="flex items-center gap-2 text-red-600 border-red-300 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete Customer
                </Button>
              </div>

              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="requests">Service History</TabsTrigger>
                  <TabsTrigger value="payments">Payments</TabsTrigger>
                  <TabsTrigger value="vehicles">Vehicles</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Account Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600 mb-1">Full Name</p>
                          <p className="font-semibold">{selectedCustomer.full_name || 'Not set'}</p>
                        </div>
                        <div>
                          <p className="text-gray-600 mb-1">Email</p>
                          <p className="font-semibold">{selectedCustomer.email}</p>
                        </div>
                        <div>
                          <p className="text-gray-600 mb-1">Customer ID</p>
                          <p className="font-mono text-xs">{selectedCustomer.id}</p>
                        </div>
                        <div>
                          <p className="text-gray-600 mb-1">Member Since</p>
                          <p className="font-semibold">
                            {format(new Date(selectedCustomer.created_date), 'MMMM d, yyyy')}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Activity Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-center p-4 bg-gray-50 rounded-lg">
                          <p className="text-2xl font-bold" style={{ color: '#FF771D' }}>
                            {customerRequests.length}
                          </p>
                          <p className="text-sm text-gray-600 mt-1">Total Requests</p>
                        </div>
                        <div className="text-center p-4 bg-green-50 rounded-lg">
                          <p className="text-2xl font-bold" style={{ color: '#3D692B' }}>
                            {customerRequests.filter(r => r.status === 'completed').length}
                          </p>
                          <p className="text-sm text-gray-600 mt-1">Completed</p>
                        </div>
                        <div className="text-center p-4 bg-blue-50 rounded-lg">
                          <p className="text-2xl font-bold text-blue-600">
                            ${customerPayments
                              .filter(p => p.status === 'paid')
                              .reduce((sum, p) => sum + (p.amount || 0) + (p.tip_amount || 0), 0)
                              .toFixed(2)}
                          </p>
                          <p className="text-sm text-gray-600 mt-1">Total Spent</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="requests" className="space-y-3">
                  {customerRequests.length === 0 ? (
                    <div className="text-center py-12">
                      <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p className="text-gray-500">No service requests yet</p>
                    </div>
                  ) : (
                    customerRequests.map(request => (
                      <Card key={request.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <ServiceTypeIcon type={request.service_type} />
                                <span className="font-semibold">
                                  {request.service_type.replace(/_/g, ' ').toUpperCase()}
                                </span>
                                <StatusBadge status={request.status} />
                              </div>
                              <div className="text-sm text-gray-600 space-y-1">
                                <p className="flex items-center gap-2">
                                  <Calendar className="w-4 h-4" />
                                  {format(new Date(request.created_date), 'MMM d, yyyy h:mm a')}
                                </p>
                                {request.location_address && (
                                  <p className="line-clamp-1">{request.location_address}</p>
                                )}
                                {request.price && (
                                  <p className="font-semibold" style={{ color: '#3D692B' }}>
                                    ${request.price.toFixed(2)}
                                  </p>
                                )}
                              </div>
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => window.open(createPageUrl(`ServiceDetails?id=${request.id}`), '_blank')}
                            >
                              <Eye className="w-4 h-4 mr-1" />
                              View
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </TabsContent>

                <TabsContent value="payments" className="space-y-3">
                  {customerPayments.length === 0 ? (
                    <div className="text-center py-12">
                      <DollarSign className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p className="text-gray-500">No payment history</p>
                    </div>
                  ) : (
                    customerPayments.map(payment => (
                      <Card key={payment.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-semibold text-lg">
                                  ${((payment.amount || 0) + (payment.tip_amount || 0)).toFixed(2)}
                                </span>
                                <Badge className={
                                  payment.status === 'paid' ? 'bg-green-100 text-green-800' :
                                  payment.status === 'failed' ? 'bg-red-100 text-red-800' :
                                  'bg-yellow-100 text-yellow-800'
                                }>
                                  {payment.status}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600">
                                {payment.payment_method} {payment.last_four && `•••• ${payment.last_four}`}
                              </p>
                              <p className="text-xs text-gray-500 mt-1">
                                {format(new Date(payment.created_date), 'MMM d, yyyy h:mm a')}
                              </p>
                              {payment.tip_amount > 0 && (
                                <p className="text-xs text-green-600 mt-1">
                                  Includes ${payment.tip_amount.toFixed(2)} tip
                                </p>
                              )}
                            </div>
                            {payment.transaction_id && (
                              <div className="text-right">
                                <p className="text-xs text-gray-500">Transaction ID</p>
                                <p className="text-xs font-mono">{payment.transaction_id}</p>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </TabsContent>

                <TabsContent value="vehicles" className="space-y-3">
                  {customerVehicles.length === 0 ? (
                    <div className="text-center py-12">
                      <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p className="text-gray-500">No vehicles registered</p>
                    </div>
                  ) : (
                    customerVehicles.map(vehicle => (
                      <Card key={vehicle.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <h4 className="font-semibold text-lg">
                                  {vehicle.year} {vehicle.make} {vehicle.model}
                                </h4>
                                {vehicle.is_default && (
                                  <Badge className="bg-green-100 text-green-800">Default</Badge>
                                )}
                              </div>
                              <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
                                {vehicle.nickname && (
                                  <p>Nickname: {vehicle.nickname}</p>
                                )}
                                {vehicle.color && (
                                  <p>Color: {vehicle.color}</p>
                                )}
                                {vehicle.license_plate && (
                                  <p>Plate: {vehicle.license_plate}</p>
                                )}
                                {vehicle.vin && (
                                  <p className="font-mono text-xs">VIN: {vehicle.vin}</p>
                                )}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </TabsContent>
              </Tabs>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Customer Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-600">
              <Trash2 className="w-5 h-5" />
              Delete Customer Account?
            </AlertDialogTitle>
            <AlertDialogDescription>
              <div className="space-y-3">
                <p className="font-semibold">
                  This will permanently delete {customerToDelete?.full_name || 'this customer'} and ALL associated data:
                </p>
                <ul className="list-disc list-inside text-sm space-y-1 text-gray-700">
                  <li>All service requests and history</li>
                  <li>All payment records</li>
                  <li>All vehicles</li>
                  <li>All ratings and reviews</li>
                  <li>All messages and notifications</li>
                  <li>All support conversations</li>
                </ul>
                <p className="font-bold text-red-600 mt-3">
                  This action cannot be undone!
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteCustomer.mutate(customerToDelete.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteCustomer.isLoading ? 'Deleting...' : 'Delete Permanently'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Action Confirmation Dialog */}
      <AlertDialog open={showActionDialog} onOpenChange={setShowActionDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {actionType === 'reset_password' && 'Reset Customer Password?'}
              {actionType === 'suspend' && 'Suspend Customer Account?'}
              {actionType === 'block' && 'Block Customer Account?'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {actionType === 'reset_password' && 
                `Send a password reset email to ${selectedCustomer?.email}?`}
              {actionType === 'suspend' && 
                'This will temporarily suspend the customer account. They will not be able to request services until reactivated.'}
              {actionType === 'block' && 
                'This will permanently block the customer account. This action should only be used for policy violations.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmAccountAction}
              className={actionType === 'block' ? 'bg-red-600 hover:bg-red-700' : ''}
            >
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}