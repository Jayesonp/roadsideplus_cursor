import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Search, Filter, MapPin, Calendar, DollarSign, User,
  AlertCircle, CheckCircle, Clock, Truck, XCircle,
  Eye, Wrench, Phone, Mail, Navigation, RefreshCw
} from 'lucide-react';
import { format } from 'date-fns';
import StatusBadge from '../components/common/StatusBadge';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import { createPageUrl } from '@/utils';

export default function AdminServiceRequestMonitor() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [serviceTypeFilter, setServiceTypeFilter] = useState('all');
  const [selectedRequest, setSelectedRequest] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const { data: requests = [], refetch } = useQuery({
    queryKey: ['admin-all-requests'],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.list('-created_date', 500);
    },
    enabled: !!user && user.role === 'admin',
    refetchInterval: 5000
  });

  const { data: technicians = [] } = useQuery({
    queryKey: ['all-techs-map'],
    queryFn: async () => {
      return await base44.entities.TechnicianProfile.list();
    },
    enabled: !!user && user.role === 'admin'
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['all-customers-map'],
    queryFn: async () => {
      return await base44.entities.User.list();
    },
    enabled: !!user && user.role === 'admin'
  });

  const cancelRequest = useMutation({
    mutationFn: async (requestId) => {
      return await base44.entities.ServiceRequest.update(requestId, {
        status: 'cancelled'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-all-requests']);
      alert('Service request cancelled');
    }
  });

  const reassignTechnician = useMutation({
    mutationFn: async ({ requestId, newTechId }) => {
      return await base44.entities.ServiceRequest.update(requestId, {
        technician_id: newTechId,
        status: 'assigned'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-all-requests']);
      alert('Technician reassigned');
    }
  });

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <AlertCircle className="w-12 h-12 mx-auto mb-4" style={{ color: '#E52C2D' }} />
          <h2 className="text-xl font-bold">Access Denied</h2>
          <p className="text-gray-600 mt-2">This page is only accessible to administrators.</p>
        </Card>
      </div>
    );
  }

  const filteredRequests = requests.filter(req => {
    const searchLower = searchTerm.toLowerCase();
    const searchMatch = (
      req.id?.toLowerCase().includes(searchLower) ||
      req.customer_id?.toLowerCase().includes(searchLower) ||
      req.location_address?.toLowerCase().includes(searchLower) ||
      req.vehicle_make?.toLowerCase().includes(searchLower)
    );
    const statusMatch = statusFilter === 'all' || req.status === statusFilter;
    const typeMatch = serviceTypeFilter === 'all' || req.service_type === serviceTypeFilter;
    return searchMatch && statusMatch && typeMatch;
  });

  const getTechName = (techId) => {
    const tech = technicians.find(t => t.user_id === techId);
    return tech ? `Tech ${tech.user_id.substring(0, 8)}` : 'Unassigned';
  };

  const getCustomerName = (customerId) => {
    const customer = customers.find(c => c.id === customerId);
    return customer ? customer.full_name : 'Unknown';
  };

  const stats = {
    total: requests.length,
    pending: requests.filter(r => r.status === 'pending_dispatch' || r.status === 'pending_payment').length,
    active: requests.filter(r => ['assigned', 'en_route', 'in_progress', 'arrived'].includes(r.status)).length,
    completed: requests.filter(r => r.status === 'completed').length,
    cancelled: requests.filter(r => r.status === 'cancelled').length
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">Service Request Monitor</h1>
            <p className="text-sm opacity-90">Real-time monitoring of all service requests</p>
          </div>
          <Button
            onClick={() => refetch()}
            variant="outline"
            className="bg-white/10 border-white/30 text-white hover:bg-white/20"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <Card className="border-l-4" style={{ borderLeftColor: '#FF771D' }}>
            <CardContent className="pt-4 pb-4">
              <p className="text-sm text-gray-600 mb-1">Total</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-yellow-500">
            <CardContent className="pt-4 pb-4">
              <p className="text-sm text-gray-600 mb-1">Pending</p>
              <p className="text-2xl font-bold">{stats.pending}</p>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-blue-500">
            <CardContent className="pt-4 pb-4">
              <p className="text-sm text-gray-600 mb-1">Active</p>
              <p className="text-2xl font-bold">{stats.active}</p>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-green-500">
            <CardContent className="pt-4 pb-4">
              <p className="text-sm text-gray-600 mb-1">Completed</p>
              <p className="text-2xl font-bold">{stats.completed}</p>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-gray-500">
            <CardContent className="pt-4 pb-4">
              <p className="text-sm text-gray-600 mb-1">Cancelled</p>
              <p className="text-2xl font-bold">{stats.cancelled}</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search by ID, location, vehicle..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="pending_payment">Pending Payment</SelectItem>
                  <SelectItem value="pending_dispatch">Pending Dispatch</SelectItem>
                  <SelectItem value="assigned">Assigned</SelectItem>
                  <SelectItem value="en_route">En Route</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
              <Select value={serviceTypeFilter} onValueChange={setServiceTypeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by service type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Service Types</SelectItem>
                  <SelectItem value="tire_change">Tire Change</SelectItem>
                  <SelectItem value="battery_jump">Battery Jump</SelectItem>
                  <SelectItem value="fuel_delivery">Fuel Delivery</SelectItem>
                  <SelectItem value="lockout">Lockout</SelectItem>
                  <SelectItem value="towing">Towing</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Request List */}
        <div className="space-y-3">
          {filteredRequests.map(request => {
            const customer = customers.find(c => c.id === request.customer_id);
            const tech = technicians.find(t => t.user_id === request.technician_id);

            return (
              <Card key={request.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      <ServiceTypeIcon type={request.service_type} size="lg" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-bold text-lg">
                              {request.service_type.replace(/_/g, ' ').toUpperCase()}
                            </h3>
                            <StatusBadge status={request.status} />
                            {request.priority && request.priority !== 'normal' && (
                              <Badge className={
                                request.priority === 'critical' ? 'bg-red-600 text-white' :
                                request.priority === 'high' ? 'bg-orange-600 text-white' :
                                'bg-blue-600 text-white'
                              }>
                                {request.priority.toUpperCase()}
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-gray-500 font-mono">ID: {request.id.substring(0, 16)}</p>
                        </div>
                        {request.price && (
                          <div className="text-right">
                            <p className="text-2xl font-bold" style={{ color: '#3D692B' }}>
                              ${request.price.toFixed(2)}
                            </p>
                          </div>
                        )}
                      </div>

                      <div className="grid md:grid-cols-2 gap-3 mb-3">
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2 text-gray-700">
                            <User className="w-4 h-4 text-gray-400" />
                            <span className="font-medium">Customer:</span>
                            <span>{customer?.full_name || 'Unknown'}</span>
                          </div>
                          {request.technician_id && (
                            <div className="flex items-center gap-2 text-gray-700">
                              <Wrench className="w-4 h-4 text-gray-400" />
                              <span className="font-medium">Technician:</span>
                              <span>{getTechName(request.technician_id)}</span>
                            </div>
                          )}
                          <div className="flex items-center gap-2 text-gray-700">
                            <Calendar className="w-4 h-4 text-gray-400" />
                            <span>{format(new Date(request.created_date), 'MMM d, yyyy h:mm a')}</span>
                          </div>
                        </div>

                        <div className="space-y-2 text-sm">
                          {request.location_address && (
                            <div className="flex items-start gap-2 text-gray-700">
                              <MapPin className="w-4 h-4 text-gray-400 mt-0.5" />
                              <span className="line-clamp-2">{request.location_address}</span>
                            </div>
                          )}
                          {request.vehicle_make && (
                            <div className="flex items-center gap-2 text-gray-700">
                              <Truck className="w-4 h-4 text-gray-400" />
                              <span>
                                {request.vehicle_year} {request.vehicle_make} {request.vehicle_model}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(createPageUrl(`ServiceDetails?id=${request.id}`), '_blank')}
                        >
                          <Eye className="w-3 h-3 mr-1" />
                          View Details
                        </Button>
                        {request.technician_id && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedRequest(request)}
                          >
                            <RefreshCw className="w-3 h-3 mr-1" />
                            Reassign
                          </Button>
                        )}
                        {!['completed', 'cancelled'].includes(request.status) && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              if (confirm('Cancel this service request?')) {
                                cancelRequest.mutate(request.id);
                              }
                            }}
                            className="text-red-600 border-red-300 hover:bg-red-50"
                          >
                            <XCircle className="w-3 h-3 mr-1" />
                            Cancel
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}

          {filteredRequests.length === 0 && (
            <div className="text-center py-16">
              <Search className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-gray-500">No service requests found</p>
            </div>
          )}
        </div>
      </div>

      {/* Reassignment Dialog */}
      {selectedRequest && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Reassign Technician</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 mb-2">Current Technician:</p>
                <p className="font-semibold">{getTechName(selectedRequest.technician_id)}</p>
              </div>

              <div>
                <p className="text-sm text-gray-600 mb-2">Select New Technician:</p>
                <Select
                  onValueChange={(techId) => {
                    if (confirm('Reassign this job to the selected technician?')) {
                      reassignTechnician.mutate({
                        requestId: selectedRequest.id,
                        newTechId: techId
                      });
                      setSelectedRequest(null);
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose technician..." />
                  </SelectTrigger>
                  <SelectContent>
                    {technicians
                      .filter(t => t.availability_status === 'available')
                      .map(tech => (
                        <SelectItem key={tech.user_id} value={tech.user_id}>
                          Tech {tech.user_id.substring(0, 12)} - {tech.phone}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setSelectedRequest(null)}
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}