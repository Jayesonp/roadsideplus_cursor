
import '@/components/despia/runtimeSafety'; // 🛡️ Apply Despia runtime patches FIRST
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { getCachedUser } from '@/components/utils/userCache';
import { createPageUrl } from '@/utils';
import { 
  Home, Wrench, MapPin, MessageSquare, History, Settings, 
  Menu, X, LogOut, User, Users, ClipboardList, Camera, Map, Crown
} from 'lucide-react';
import PushNotificationManager from '../components/pwa/PushNotificationManager';
import BackgroundLocationTracker from '../components/location/BackgroundLocationTracker';
import InstallPrompt from '../components/pwa/InstallPrompt';
import DispatchMonitor from '../components/dispatch/DispatchMonitor';
import SOSButton from '../components/common/SOSButton';
import { NetworkMonitor } from '../components/offline/NetworkMonitor';
import ThemeProvider from '../components/theme/ThemeProvider';

// 🔥 Force-remove ALL existing service workers & caches
if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then(regs => {
    regs.forEach(reg => reg.unregister());
  });

  if (window.caches) {
    caches.keys().then(keys => {
      keys.forEach(key => caches.delete(key));
    });
  }
}
import ThemeToggle from '../components/theme/ThemeToggle';
import OfflineIndicator from '../components/offline/OfflineIndicator';
import { syncManager } from '../components/offline/SyncManager';
import BrandLogo from '../components/branding/BrandLogo';
import RealTimeNotificationSystem from '../components/notifications/RealTimeNotificationSystem';
import AISupportWidget from '../components/support/AISupportWidget';
import JobReassignmentMonitor from '../components/dispatch/JobReassignmentMonitor';
import UberStyleDispatcher from '../components/dispatch/UberStyleDispatcher';
import ContinuousDispatchMonitor from '../components/dispatch/ContinuousDispatchMonitor';

export default function Layout({ children, currentPageName }) {
  // Pages that don't need layout - check BEFORE any hooks
  const noLayoutPages = ['Login', 'Register', 'ForgotPassword', 'RoleSelection', 'Payment', 'TermsAcceptance', 'SecurityLogin', 'SecurityOfficerMobile', 'RegisterCustomer', 'RegisterTechnician', 'RegisterPartner', 'RegisterSecurityCompany', 'RegisterSelection', 'OTPVerification'];
  if (noLayoutPages.includes(currentPageName)) {
    return <>{children}</>;
  }

  const [user, setUser] = useState(null);
  const [isTechnician, setIsTechnician] = useState(false);
  const [techProfile, setTechProfile] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUser();
    
    // Double-check cleanup on mount
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.getRegistrations().then(regs => regs.forEach(r => r.unregister()));
    }

    // Despia Native SDK is injected by runtime, no need to load script
    console.log('✅ Layout mounted - Despia Safe Areas active');
    
    // Set up sync on network reconnection
    window.addEventListener('online', () => {
      syncManager.syncAll();
    });

    // Suppress WebSocket errors from React dev server and Base44 SDK
    const originalError = console.error;
    console.error = (...args) => {
      const message = typeof args[0] === 'string' ? args[0] : args[0]?.message || '';
      if (
        message.includes('WebSocket') || 
        message.includes('websocket') ||
        args[0] instanceof Error && args[0].message.includes('WebSocket')
      ) {
        return;
      }
      originalError.apply(console, args);
    };

    // Global Despia RevenueCat Purchase Handler
    window.onRevenueCatPurchase = (data) => {
      console.log('💰 RevenueCat Purchase Completed:', data);
      // Trigger sync or refresh user data
      syncManager.syncAll();
      // Optionally show a success message or modal here
      if (window.location.pathname.includes('PremiumUpgrade')) {
        alert('Purchase Successful! refreshing your profile...');
        window.location.reload();
      }
    };

    return () => {
      console.error = originalError;
      delete window.onRevenueCatPurchase;
    };
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        setLoading(false);
        return;
      }

      const currentUser = await getCachedUser();
      setUser(currentUser);
      setLoading(false);

      // Check if technician
      const profiles = await base44.entities.TechnicianProfile.filter({ user_id: currentUser.id });
      setIsTechnician(profiles.length > 0);
      if (profiles.length > 0) {
        setTechProfile(profiles[0]);
      }
    } catch (error) {
      console.error('Error loading user:', error);
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  // Customer navigation
  const customerNav = [
    { name: 'Home', icon: Home, page: 'CustomerDashboard' },
    { name: 'Request Service', icon: Wrench, page: 'ServiceOptions' },
    { name: 'Upgrade', icon: Crown, page: 'PremiumUpgrade' },
    { name: 'History', icon: History, page: 'CustomerDashboard' },
    { name: 'AI Support', icon: MessageSquare, page: 'AISupportChat' },
    { name: 'Profile', icon: User, page: 'Profile' },
    { name: 'Settings', icon: Settings, page: 'Settings' },
  ];

  // Admin navigation additions
  const adminNav = user?.role === 'admin' ? [
    { name: 'Admin', icon: Settings, page: 'AdminDashboard' },
    { name: 'Customers', icon: User, page: 'AdminCustomerManagement' },
    { name: 'Technicians', icon: User, page: 'AdminTechnicianManagement' },
    { name: 'Verifications', icon: ClipboardList, page: 'AdminDocumentVerification' },
    { name: 'Service Requests', icon: ClipboardList, page: 'AdminServiceRequestMonitor' },
    { name: 'Tech Payouts', icon: Settings, page: 'AdminTechnicianPayouts' },
    { name: 'Partners', icon: User, page: 'AdminPartnerManagement' },
    { name: 'Partner Payouts', icon: Settings, page: 'AdminPartnerPayouts' },
    { name: 'Analytics', icon: Settings, page: 'AdminAnalyticsDashboard' },
    { name: 'Support', icon: MessageSquare, page: 'AdminSupportDashboard' },
    { name: 'Manual Dispatch', icon: Wrench, page: 'AdminManualDispatch' },
    { name: 'Reviews', icon: MessageSquare, page: 'AdminReviewManagement' },
    { name: 'Geofence', icon: MapPin, page: 'AdminGeofenceSettings' },
    { name: 'User Management', icon: Users, page: 'AdminUserManagement' },
  ] : [];

  // Technician navigation
  const technicianNav = [
    { name: 'Dashboard', icon: Home, page: 'TechnicianDashboard' },
    { name: 'Jobs', icon: ClipboardList, page: 'TechnicianDashboard' },
    { name: 'Performance', icon: Settings, page: 'TechnicianPerformance' },
    { name: 'Analytics', icon: Settings, page: 'FeedbackAnalytics' },
    { name: 'AI Support', icon: MessageSquare, page: 'AISupportChat' },
    { name: 'Profile', icon: User, page: 'TechnicianProfile' },
    { name: 'Settings', icon: Settings, page: 'Settings' },
  ];

  // Admin role takes priority over technician role
  const navigation = user?.role === 'admin'
    ? [...customerNav, ...adminNav]
    : (isTechnician ? technicianNav : customerNav);

  // Route Guard: Prevent unauthorized access to role-specific dashboards
  useEffect(() => {
    if (!loading && user) {
      const role = user.role;
      const page = currentPageName;
      
      // Admin can access everything
      if (role === 'admin') return;

      // Define restricted pages
      const restrictions = {
        'TechnicianDashboard': ['technician'],
        'TechnicianPerformance': ['technician'],
        'PartnerDashboard': ['partner'],
        'SecurityCommandCenter': ['security_company'],
        'CustomerDashboard': ['customer'],
      };

      const allowedRoles = restrictions[page];
      if (allowedRoles && !allowedRoles.includes(role)) {
        console.warn(`Access denied for role ${role} to page ${page}`);
        // Redirect to their own dashboard
        const correctDashboard = {
          'customer': 'CustomerDashboard',
          'technician': 'TechnicianDashboard',
          'partner': 'PartnerDashboard',
          'security_company': 'SecurityCommandCenter'
        }[role] || 'CustomerDashboard';
        
        window.location.href = createPageUrl(correctDashboard);
      }
    }
  }, [loading, user, currentPageName]);

  if (loading) {
    return <div className="h-screen w-screen flex items-center justify-center bg-background">Loading...</div>;
  }

  if (!user) {
    return <>{children}</>;
  }

  return (
    <ThemeProvider>
      <NetworkMonitor>
        {/* Despia Native Layout Structure - Fixed Height Container */}
        <div className="h-[100dvh] w-full flex flex-col overflow-hidden bg-gray-50 dark:bg-gray-900">

          {/* Top Safe Area */}
          <div className="shrink-0" style={{ height: 'var(--safe-area-top)', backgroundColor: 'var(--primary, #FF771D)' }} />
        <PushNotificationManager userId={user?.id} userRole={isTechnician ? 'technician' : 'customer'} />
        <RealTimeNotificationSystem userId={user?.id} userRole={isTechnician ? 'technician' : 'customer'} />
        
        {/* Only Admins should run global dispatch monitors to prevent API rate limits */}
        {user?.role === 'admin' && (
          <>
            <JobReassignmentMonitor />
            <UberStyleDispatcher />
            <ContinuousDispatchMonitor />
            <DispatchMonitor />
          </>
        )}

        {isTechnician && techProfile && (
          <BackgroundLocationTracker 
            technicianId={user.id}
            isAvailable={techProfile.is_available}
            hasActiveJob={false}
          />
        )}
        <InstallPrompt />
        <SOSButton userId={user?.id} />
        <OfflineIndicator />
      {/* Mobile Header - Relative Flow */}
      <div className="md:hidden w-full shrink-0 z-40 text-white shadow-lg"
       style={{ 
         background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)',
         minHeight: '64px'
       }}>
       <div className="flex items-center justify-between px-4 py-4">
         <BrandLogo variant="full" size="sm" className="text-white" />
         <div className="flex items-center gap-2">
           <ThemeToggle className="text-white hover:bg-white/20" />
           <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
             {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
           </button>
         </div>
       </div>
       </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 bg-black/50 z-30" onClick={() => setMobileMenuOpen(false)}>
          <div className="bg-white dark:bg-gray-800 w-64 h-full shadow-xl flex flex-col overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex-shrink-0 p-6"
                 style={{
                   paddingTop: 'calc(var(--safe-area-top, env(safe-area-inset-top)) + 1.5rem)'
                 }}>
              <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <p className="text-sm text-gray-500 dark:text-gray-400">Logged in as</p>
                <p className="font-semibold dark:text-white truncate">{user.full_name}</p>
                <p className="text-xs text-gray-400 truncate">{user.email}</p>
              </div>
            </div>

            <nav className="flex-1 overflow-y-auto px-6 py-2 space-y-2">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = currentPageName === item.page;
                return (
                  <a
                    key={item.name}
                    href={createPageUrl(item.page)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-orange-100 dark:bg-orange-900 text-orange-900 dark:text-orange-100 font-semibold' 
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    <Icon className="w-5 h-5 flex-shrink-0" />
                    <span className="truncate">{item.name}</span>
                  </a>
                );
              })}
            </nav>

            <div className="flex-shrink-0 p-6 border-t dark:border-gray-700"
                 style={{
                   paddingBottom: 'calc(var(--safe-area-bottom, env(safe-area-inset-bottom)) + 1.5rem)'
                 }}>
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg w-full"
              >
                <LogOut className="w-5 h-5 flex-shrink-0" />
                <span className="truncate">Logout</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Desktop Sidebar - Fixed */}
      <div className="hidden md:block fixed left-0 top-0 bottom-0 w-64 bg-white dark:bg-gray-800 border-r dark:border-gray-700 shadow-sm z-50"
           style={{
             paddingLeft: 'var(--safe-area-left, env(safe-area-inset-left, 0px))'
           }}>
        <div className="flex flex-col h-full pt-[calc(var(--safe-area-top)+1rem)]">
          <div className="flex-shrink-0 p-6">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <BrandLogo variant="full" size="md" />
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  {user?.role === 'admin' ? 'Admin' : isTechnician ? 'Technician' : 'Customer'} Portal
                </p>
              </div>
              <ThemeToggle />
            </div>

            <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Logged in as</p>
              <p className="font-semibold text-sm dark:text-white truncate">{user.full_name}</p>
              <p className="text-xs text-gray-400 truncate">{user.email}</p>
            </div>
          </div>

          <nav className="flex-1 overflow-y-auto px-6 py-2 space-y-1">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = currentPageName === item.page;
              return (
                <a
                  key={item.name}
                  href={createPageUrl(item.page)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    isActive 
                      ? 'text-white font-semibold' 
                      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  }`}
                  style={isActive ? { backgroundColor: '#FF771D' } : {}}
                >
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  <span className="truncate">{item.name}</span>
                </a>
              );
            })}
          </nav>

          <div className="flex-shrink-0 p-6 border-t dark:border-gray-700 pb-[calc(var(--safe-area-bottom)+1.5rem)]">
            <button
              onClick={handleLogout}
              className="flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg w-full"
            >
              <LogOut className="w-5 h-5 flex-shrink-0" />
              <span className="truncate">Logout</span>
            </button>
          </div>
        </div>
      </div>

      {/* App Container - Scrollable Area */}
      <div className="flex-1 overflow-y-auto scrollbar-hide md:ml-64 relative bg-gray-50 dark:bg-gray-900 w-full">

        {/* Content Wrapper with Padding - removed pt-16 since header is relative */}
        <div className="pb-24 md:pb-10 pt-4 md:pt-6 px-4 min-h-full">
          {children}
        </div>

        {/* AI Support Widget */}
        <AISupportWidget userId={user?.id} userRole={isTechnician ? 'technician' : 'customer'} />
      </div>

      {/* Mobile Bottom Navigation - Absolute at bottom of main container */}
      <div className="md:hidden relative shrink-0 bg-white dark:bg-gray-800 border-t dark:border-gray-700 shadow-lg z-40">
        <div className="grid grid-cols-4 gap-1 p-2">
          {(isTechnician ? technicianNav : customerNav).slice(0, 4).map((item) => {
            const Icon = item.icon;
            const isActive = currentPageName === item.page;
            return (
              <a
                key={item.name}
                href={createPageUrl(item.page)}
                className={`flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-colors ${
                  isActive ? 'font-semibold' : 'text-gray-600 dark:text-gray-400'
                }`}
                style={isActive ? { color: '#FF771D' } : {}}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs">{item.name}</span>
              </a>
            );
          })}
        </div>
        {/* Bottom Safe Area Spacer inside the bar */}
        <div style={{ height: 'var(--safe-area-bottom)' }} />
      </div>

      </div>
      </NetworkMonitor>
      </ThemeProvider>
      );
      }
