import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, Activity, DollarSign, TrendingUp, 
  AlertCircle, CheckCircle, MapPin, Clock, Gift
} from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import StatusBadge from '../components/common/StatusBadge';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import PartnerOnboardingAssistant from '../components/partner/PartnerOnboardingAssistant';

export default function PartnerDashboard() {
  const [user, setUser] = useState(null);
  const [partner, setPartner] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        window.location.href = createPageUrl('Login');
        return;
      }
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Get partner profile
      const partners = await base44.entities.Partner.filter({ email: currentUser.email });
      if (partners.length > 0) {
        setPartner(partners[0]);
      } else {
        window.location.href = createPageUrl('PartnerPortal');
      }
    } catch (error) {
      window.location.href = createPageUrl('Login');
    }
  };

  // Fetch partner's customers
  const { data: customers = [] } = useQuery({
    queryKey: ['partner-customers', partner?.id],
    queryFn: async () => {
      const allUsers = await base44.entities.User.list('-created_date');
      // In production, filter by partner_id relationship
      return allUsers.filter(u => u.role !== 'admin');
    },
    enabled: !!partner && partner.has_client_database_access
  });

  // Fetch partner's service requests
  const { data: serviceRequests = [] } = useQuery({
    queryKey: ['partner-requests', partner?.id],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter(
        { partner_id: partner.id },
        '-created_date'
      );
    },
    enabled: !!partner,
    refetchInterval: 10000
  });

  // Fetch all technicians (shared resource)
  const { data: technicians = [] } = useQuery({
    queryKey: ['all-technicians'],
    queryFn: async () => {
      return await base44.entities.TechnicianProfile.list('-updated_date');
    },
    enabled: !!partner
  });

  if (!user || !partner) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: partner?.white_label_primary_color || '#FF771D' }}></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!partner.has_client_database_access) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md">
          <CardContent className="pt-8 text-center">
            <AlertCircle className="w-16 h-16 mx-auto mb-4" style={{ color: '#E52C2D' }} />
            <h2 className="text-xl font-bold mb-2">Access Restricted</h2>
            <p className="text-gray-600 mb-6">
              Your partner account doesn't have client database access. Please contact support to upgrade your account.
            </p>
            <Button
              onClick={() => window.location.href = createPageUrl('PartnerPortal')}
              style={{ backgroundColor: partner.white_label_primary_color || '#FF771D' }}
              className="text-white"
            >
              Back to Portal
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const primaryColor = partner.white_label_primary_color || '#FF771D';
  const secondaryColor = partner.white_label_secondary_color || '#E52C2D';

  const activeRequests = serviceRequests.filter(r => 
    ['pending_dispatch', 'dispatched', 'assigned', 'en_route', 'in_progress'].includes(r.status)
  );
  const completedRequests = serviceRequests.filter(r => r.status === 'completed');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <PartnerOnboardingAssistant partner={partner} onboardingStage="active" />
      {/* Header */}
      <div className="text-white p-6 shadow-lg" 
           style={{ background: `linear-gradient(135deg, ${primaryColor} 0%, ${secondaryColor} 100%)` }}>
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              {partner.white_label_logo ? (
                <img src={partner.white_label_logo} alt={partner.company_name} className="h-12" />
              ) : (
                <h1 className="text-2xl font-bold">{partner.company_name}</h1>
              )}
            </div>
            <Badge className="bg-white/20 text-white border-white/30">
              White-Label Partner
            </Badge>
          </div>
          <p className="text-sm opacity-90">Partner Dashboard - Client Database Access</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Clients</p>
                  <p className="text-3xl font-bold mt-1">{customers.length}</p>
                </div>
                <Users className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Jobs</p>
                  <p className="text-3xl font-bold mt-1">{activeRequests.length}</p>
                </div>
                <Activity className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Services</p>
                  <p className="text-3xl font-bold mt-1">{serviceRequests.length}</p>
                </div>
                <TrendingUp className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Available Techs</p>
                  <p className="text-3xl font-bold mt-1">
                    {technicians.filter(t => t.availability_status === 'available').length}
                  </p>
                </div>
                <CheckCircle className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = createPageUrl('PartnerClientManagement')}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: primaryColor + '20' }}>
                  <Users className="w-6 h-6" style={{ color: primaryColor }} />
                </div>
                <div>
                  <p className="font-semibold">Clients</p>
                  <p className="text-sm text-gray-600">Manage clients</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = createPageUrl('PartnerAnalytics')}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: primaryColor + '20' }}>
                  <TrendingUp className="w-6 h-6" style={{ color: primaryColor }} />
                </div>
                <div>
                  <p className="font-semibold">Analytics</p>
                  <p className="text-sm text-gray-600">View reports</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = createPageUrl('PartnerReferralDashboard')}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full flex items-center justify-center bg-purple-100">
                  <Gift className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="font-semibold">Referrals</p>
                  <p className="text-sm text-gray-600">Earn rewards</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = createPageUrl('PartnerPayoutHistory')}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full flex items-center justify-center bg-green-100">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="font-semibold">Payouts</p>
                  <p className="text-sm text-gray-600">Commission</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => window.location.href = createPageUrl('PartnerSettings')}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full flex items-center justify-center bg-blue-100">
                  <CheckCircle className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="font-semibold">Settings</p>
                  <p className="text-sm text-gray-600">Branding</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="clients" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="clients">Clients</TabsTrigger>
            <TabsTrigger value="jobs">Service Jobs</TabsTrigger>
            <TabsTrigger value="technicians">Technicians</TabsTrigger>
          </TabsList>

          <TabsContent value="clients">
            <Card>
              <CardHeader>
                <CardTitle>Client Database ({customers.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {customers.length === 0 ? (
                    <div className="text-center py-12">
                      <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p className="text-gray-500">No clients yet</p>
                    </div>
                  ) : (
                    customers.map(customer => {
                      const customerRequests = serviceRequests.filter(r => r.customer_id === customer.id);
                      return (
                        <Card key={customer.id} className="border hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: primaryColor }}>
                                  {customer.full_name?.[0]?.toUpperCase() || 'C'}
                                </div>
                                <div>
                                  <p className="font-semibold">{customer.full_name || 'Unnamed'}</p>
                                  <p className="text-sm text-gray-600">{customer.email}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="text-sm text-gray-600">Total Services</p>
                                <p className="text-2xl font-bold" style={{ color: primaryColor }}>
                                  {customerRequests.length}
                                </p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="jobs">
            <Card>
              <CardHeader>
                <CardTitle>Service Requests ({serviceRequests.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {serviceRequests.length === 0 ? (
                    <div className="text-center py-12">
                      <Activity className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p className="text-gray-500">No service requests yet</p>
                    </div>
                  ) : (
                    serviceRequests.map(request => (
                      <Card key={request.id} className="border hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <ServiceTypeIcon type={request.service_type} />
                              <span className="font-semibold">
                                {request.service_type.replace(/_/g, ' ').toUpperCase()}
                              </span>
                            </div>
                            <StatusBadge status={request.status} />
                          </div>
                          <div className="space-y-2 text-sm">
                            <div className="flex items-center gap-2 text-gray-600">
                              <Clock className="w-4 h-4" />
                              {format(new Date(request.created_date), 'MMM d, h:mm a')}
                            </div>
                            {request.location_address && (
                              <div className="flex items-start gap-2 text-gray-600">
                                <MapPin className="w-4 h-4 mt-0.5" />
                                <span className="line-clamp-1">{request.location_address}</span>
                              </div>
                            )}
                            {request.price && (
                              <div className="text-lg font-bold" style={{ color: '#3D692B' }}>
                                ${request.price.toFixed(2)}
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="technicians">
            <Card>
              <CardHeader>
                <CardTitle>Available Technicians ({technicians.length})</CardTitle>
                <p className="text-sm text-gray-600 mt-1">
                  Shared technician pool across all partners
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {technicians.map(tech => (
                    <Card key={tech.id} className="border">
                      <CardContent className="pt-6">
                        <div className="flex items-center gap-3 mb-3">
                          {tech.profile_picture ? (
                            <img src={tech.profile_picture} alt="Tech" className="w-12 h-12 rounded-full" />
                          ) : (
                            <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: primaryColor }}>
                              T
                            </div>
                          )}
                          <div>
                            <p className="font-semibold text-sm">Tech {tech.user_id.substring(0, 8)}</p>
                            <Badge className={
                              tech.availability_status === 'available' ? 'bg-green-100 text-green-800' :
                              tech.availability_status === 'on_job' ? 'bg-blue-100 text-blue-800' :
                              'bg-gray-100 text-gray-800'
                            }>
                              {tech.availability_status?.replace(/_/g, ' ')}
                            </Badge>
                          </div>
                        </div>
                        <div className="text-sm space-y-1">
                          <p className="text-gray-600">Rating: <span className="font-bold">{tech.rating || 5.0}</span></p>
                          <p className="text-gray-600">Jobs: <span className="font-bold">{tech.total_jobs || 0}</span></p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}