import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MessageCircle, Send, User, Clock, ExternalLink } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { formatDistanceToNow } from 'date-fns';

export default function AdminSupportDashboard() {
  const [user, setUser] = useState(null);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const messagesEndRef = useRef(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  // Fetch all conversations
  const { data: allConversations = [] } = useQuery({
    queryKey: ['admin-support-conversations'],
    queryFn: async () => {
      return await base44.entities.SupportConversation.list('-last_message_at');
    },
    enabled: !!user,
    refetchInterval: 3000
  });

  // Fetch messages
  const { data: messages = [] } = useQuery({
    queryKey: ['admin-support-messages', selectedConversation?.id],
    queryFn: async () => {
      return await base44.entities.SupportMessage.filter(
        { conversation_id: selectedConversation.id },
        'created_date'
      );
    },
    enabled: !!selectedConversation,
    refetchInterval: 2000
  });

  // Fetch customer info
  const { data: customer } = useQuery({
    queryKey: ['customer-info', selectedConversation?.customer_id],
    queryFn: async () => {
      const users = await base44.entities.User.filter({ id: selectedConversation.customer_id });
      return users[0];
    },
    enabled: !!selectedConversation?.customer_id
  });

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Mark messages as read and assign agent
  useEffect(() => {
    if (selectedConversation && messages.length > 0 && user) {
      const unreadMessages = messages.filter(
        msg => msg.sender_role === 'customer' && !msg.is_read
      );
      
      unreadMessages.forEach(async (msg) => {
        await base44.entities.SupportMessage.update(msg.id, { is_read: true });
      });

      if (unreadMessages.length > 0) {
        base44.entities.SupportConversation.update(selectedConversation.id, {
          agent_unread_count: 0,
          assigned_agent_id: user.id,
          status: selectedConversation.status === 'open' ? 'in_progress' : selectedConversation.status
        });
        queryClient.invalidateQueries(['admin-support-conversations']);
      }
    }
  }, [messages, selectedConversation, user]);

  // Send message
  const sendMessage = useMutation({
    mutationFn: async () => {
      const msg = await base44.entities.SupportMessage.create({
        conversation_id: selectedConversation.id,
        sender_id: user.id,
        sender_role: 'agent',
        message: newMessage
      });

      await base44.entities.SupportConversation.update(selectedConversation.id, {
        last_message_at: new Date().toISOString(),
        customer_unread_count: (selectedConversation.customer_unread_count || 0) + 1
      });

      // Notify customer
      await base44.entities.Notification.create({
        user_id: selectedConversation.customer_id,
        type: 'new_message',
        title: 'Support Reply',
        message: `Support replied to your inquiry`,
        related_id: selectedConversation.id
      });

      return msg;
    },
    onSuccess: () => {
      setNewMessage('');
      queryClient.invalidateQueries(['admin-support-messages']);
      queryClient.invalidateQueries(['admin-support-conversations']);
    }
  });

  // Update status
  const updateStatus = useMutation({
    mutationFn: async (newStatus) => {
      return await base44.entities.SupportConversation.update(
        selectedConversation.id,
        { status: newStatus }
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-support-conversations']);
    }
  });

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <h2 className="text-xl font-bold mb-2">Access Denied</h2>
          <p className="text-gray-600">This page is only accessible to administrators.</p>
        </Card>
      </div>
    );
  }

  const filteredConversations = statusFilter === 'all'
    ? allConversations
    : allConversations.filter(conv => conv.status === statusFilter);

  const statusConfig = {
    open: { label: 'Open', color: 'bg-blue-100 text-blue-800' },
    in_progress: { label: 'In Progress', color: 'bg-yellow-100 text-yellow-800' },
    resolved: { label: 'Resolved', color: 'bg-green-100 text-green-800' },
    closed: { label: 'Closed', color: 'bg-gray-100 text-gray-800' }
  };

  const totalUnread = allConversations.reduce((sum, conv) => sum + (conv.agent_unread_count || 0), 0);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold mb-2">Support Dashboard</h1>
          <div className="flex items-center gap-4 text-sm">
            <span>{allConversations.length} Total Conversations</span>
            {totalUnread > 0 && (
              <Badge className="bg-red-500 text-white">{totalUnread} Unread</Badge>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid md:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
          {/* Conversations List */}
          <div className="flex flex-col">
            <Card className="flex-1 flex flex-col">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Conversations</CardTitle>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-32 h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto space-y-2 p-3">
                {filteredConversations.map(conv => (
                  <Card
                    key={conv.id}
                    className={`cursor-pointer hover:bg-gray-50 transition-colors ${
                      selectedConversation?.id === conv.id ? 'border-orange-500' : ''
                    }`}
                    onClick={() => setSelectedConversation(conv)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-start justify-between mb-1">
                        <h4 className="font-semibold text-sm line-clamp-1">{conv.subject}</h4>
                        {conv.agent_unread_count > 0 && (
                          <div className="w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center flex-shrink-0 ml-2">
                            {conv.agent_unread_count}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center justify-between">
                        <Badge className={`text-xs ${statusConfig[conv.status].color}`}>
                          {statusConfig[conv.status].label}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          {formatDistanceToNow(new Date(conv.last_message_at || conv.created_date), { addSuffix: true })}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Chat Area */}
          <div className="md:col-span-2">
            {selectedConversation ? (
              <Card className="h-full flex flex-col">
                <CardHeader className="pb-3 border-b">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold mb-2">{selectedConversation.subject}</h3>
                      {customer && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <User className="w-4 h-4" />
                          <span>{customer.full_name} ({customer.email})</span>
                        </div>
                      )}
                      {selectedConversation.service_request_id && (
                        <a
                          href={createPageUrl(`ServiceDetails?id=${selectedConversation.service_request_id}`)}
                          className="text-xs text-blue-600 hover:underline flex items-center gap-1 mt-1"
                        >
                          <ExternalLink className="w-3 h-3" />
                          View Related Service Request
                        </a>
                      )}
                    </div>
                    <Select
                      value={selectedConversation.status}
                      onValueChange={(val) => updateStatus.mutate(val)}
                    >
                      <SelectTrigger className="w-32 h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Open</SelectItem>
                        <SelectItem value="in_progress">In Progress</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                        <SelectItem value="closed">Closed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>

                <CardContent className="flex-1 overflow-y-auto p-4 space-y-3">
                  {messages.map(msg => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.sender_role === 'agent' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[70%] rounded-lg px-4 py-2 ${
                          msg.sender_role === 'agent'
                            ? 'text-white'
                            : 'bg-gray-100 text-gray-900'
                        }`}
                        style={msg.sender_role === 'agent' ? { backgroundColor: '#FF771D' } : {}}
                      >
                        <p className="text-sm">{msg.message}</p>
                        <div className="flex items-center gap-1 mt-1 text-xs opacity-70">
                          <Clock className="w-3 h-3" />
                          {formatDistanceToNow(new Date(msg.created_date), { addSuffix: true })}
                        </div>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </CardContent>

                <div className="p-4 border-t">
                  <div className="flex gap-2">
                    <Textarea
                      placeholder="Type your response..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          if (newMessage.trim()) sendMessage.mutate();
                        }
                      }}
                      className="flex-1 min-h-[80px]"
                    />
                    <Button
                      onClick={() => sendMessage.mutate()}
                      disabled={!newMessage.trim() || sendMessage.isLoading}
                      className="text-white"
                      style={{ backgroundColor: '#FF771D' }}
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ) : (
              <Card className="h-full flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Select a conversation to view messages</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}