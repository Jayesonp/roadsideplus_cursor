import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { createPageUrl } from '@/utils';
import { Loader2, CheckCircle } from 'lucide-react';

export default function PartnerRegistration() {
  const [formData, setFormData] = useState({
    company_name: '',
    contact_name: '',
    email: '',
    phone: ''
  });
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: value
    }));
  };

  const registerPartnerMutation = useMutation({
    mutationFn: async (partnerData) => {
      return await base44.entities.Partner.create(partnerData);
    },
    onSuccess: () => {
      setSuccess(true);
      setFormData({
        company_name: '',
        contact_name: '',
        email: '',
        phone: ''
      });
    },
    onError: (error) => {
      console.error('Partner registration failed:', error);
      alert('Failed to register partner. Please try again.');
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    registerPartnerMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">Partner Registration</CardTitle>
          <p className="text-center text-gray-500">Join our network of trusted partners</p>
        </CardHeader>
        <CardContent>
          {success ? (
            <div className="text-center py-10">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Application Submitted!</h3>
              <p className="text-gray-600">
                Thank you for your interest. We will review your application and get in touch soon.
              </p>
              <Button onClick={() => window.location.href = createPageUrl('AdminDashboard')} className="mt-6">
                Go to Dashboard
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="company_name">Company Name</Label>
                <Input
                  id="company_name"
                  type="text"
                  placeholder="Your Company Name"
                  value={formData.company_name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div>
                <Label htmlFor="contact_name">Contact Person Name</Label>
                <Input
                  id="contact_name"
                  type="text"
                  placeholder="Contact Person's Full Name"
                  value={formData.contact_name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="company@example.com"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+1 (555) 123-4567"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                />
              </div>
              <Button
                type="submit"
                className="w-full"
                disabled={registerPartnerMutation.isLoading}
              >
                {registerPartnerMutation.isLoading ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  'Submit Application'
                )}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}