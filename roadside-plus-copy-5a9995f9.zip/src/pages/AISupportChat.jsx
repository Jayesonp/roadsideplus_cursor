import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Bot, MessageSquare } from 'lucide-react';
import AISupportAssistant from '../components/support/AISupportAssistant';
import { createPageUrl } from '@/utils';

export default function AISupportChat() {
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState('customer');

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        window.location.href = createPageUrl('Login');
        return;
      }

      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Check if partner
      const partners = await base44.entities.Partner.filter({ email: currentUser.email });
      if (partners.length > 0) {
        setUserRole('partner');
      } else {
        // Check if technician
        const techProfiles = await base44.entities.TechnicianProfile.filter({ user_id: currentUser.id });
        if (techProfiles.length > 0) {
          setUserRole('technician');
        }
      }
    } catch (error) {
      window.location.href = createPageUrl('Login');
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2" style={{ borderColor: '#FF771D' }}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        <Card className="shadow-lg">
          <CardHeader className="border-b" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
            <CardTitle className="flex items-center gap-3 text-white">
              <Bot className="w-6 h-6" />
              AI Support Assistant
            </CardTitle>
            <p className="text-white text-sm opacity-90 mt-1">
              Get instant help with your questions and issues
            </p>
          </CardHeader>
          <div className="h-[600px]">
            <AISupportAssistant userId={user.id} userRole={userRole} />
          </div>
        </Card>

        <div className="mt-4 text-center text-sm text-gray-600">
          <p>Need to speak with a human? Visit our <a href={createPageUrl('SupportCenter')} className="text-blue-600 hover:underline">Support Center</a></p>
        </div>
      </div>
    </div>
  );
}