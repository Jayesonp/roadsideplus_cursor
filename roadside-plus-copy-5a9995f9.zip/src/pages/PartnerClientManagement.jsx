import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  Users, Search, Plus, Upload, Download, Eye, 
  Activity, DollarSign, AlertCircle, FileText 
} from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function PartnerClientManagement() {
  const [user, setUser] = useState(null);
  const [partner, setPartner] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  const [newClient, setNewClient] = useState({ full_name: '', email: '', phone: '' });
  const [importFile, setImportFile] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
    const partners = await base44.entities.Partner.filter({ email: currentUser.email });
    if (partners[0]) setPartner(partners[0]);
  };

  const { data: clients = [] } = useQuery({
    queryKey: ['partner-clients', partner?.id],
    queryFn: async () => {
      const requests = await base44.entities.ServiceRequest.filter({ partner_id: partner.id });
      const customerIds = [...new Set(requests.map(r => r.customer_id).filter(Boolean))];
      const allUsers = await base44.entities.User.list();
      return allUsers.filter(u => customerIds.includes(u.id));
    },
    enabled: !!partner
  });

  const { data: requests = [] } = useQuery({
    queryKey: ['partner-requests', partner?.id],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter({ partner_id: partner.id });
    },
    enabled: !!partner
  });

  const addClient = useMutation({
    mutationFn: async (clientData) => {
      // Create user account
      const user = await base44.entities.User.create({
        ...clientData,
        role: 'user'
      });
      return user;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['partner-clients']);
      setShowAddDialog(false);
      setNewClient({ full_name: '', email: '', phone: '' });
    }
  });

  const importClients = useMutation({
    mutationFn: async (file) => {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      const result = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url,
        json_schema: {
          type: "object",
          properties: {
            clients: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  full_name: { type: "string" },
                  email: { type: "string" },
                  phone: { type: "string" }
                }
              }
            }
          }
        }
      });

      if (result.status === 'success' && result.output?.clients) {
        const createdClients = [];
        for (const client of result.output.clients) {
          const user = await base44.entities.User.create({
            ...client,
            role: 'user'
          });
          createdClients.push(user);
        }
        return createdClients;
      }
      throw new Error('Import failed');
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['partner-clients']);
      setShowImportDialog(false);
      setImportFile(null);
    }
  });

  const filteredClients = clients.filter(c => 
    c.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getClientStats = (clientId) => {
    const clientRequests = requests.filter(r => r.customer_id === clientId);
    const completed = clientRequests.filter(r => r.status === 'completed');
    const revenue = completed.reduce((sum, r) => sum + (r.price || 0), 0);
    return {
      totalJobs: clientRequests.length,
      completedJobs: completed.length,
      revenue,
      lastService: clientRequests[0]?.created_date
    };
  };

  const exportClients = () => {
    const data = filteredClients.map(c => {
      const stats = getClientStats(c.id);
      return {
        name: c.full_name,
        email: c.email,
        totalJobs: stats.totalJobs,
        completedJobs: stats.completedJobs,
        revenue: stats.revenue,
        lastService: stats.lastService
      };
    });
    const csv = [
      ['Name', 'Email', 'Total Jobs', 'Completed Jobs', 'Revenue', 'Last Service'],
      ...data.map(d => [d.name, d.email, d.totalJobs, d.completedJobs, d.revenue, d.lastService])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `clients-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
  };

  if (!partner) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  const primaryColor = partner.white_label_primary_color || '#FF771D';

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold">Client Management</h1>
            <p className="text-gray-600 mt-1">Manage your client database and track referrals</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={exportClients}>
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
            <Button variant="outline" onClick={() => setShowImportDialog(true)}>
              <Upload className="w-4 h-4 mr-2" />
              Import
            </Button>
            <Button onClick={() => setShowAddDialog(true)} className="text-white" style={{ backgroundColor: primaryColor }}>
              <Plus className="w-4 h-4 mr-2" />
              Add Client
            </Button>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Clients</p>
                  <p className="text-3xl font-bold mt-1">{clients.length}</p>
                </div>
                <Users className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Clients</p>
                  <p className="text-3xl font-bold mt-1">
                    {clients.filter(c => getClientStats(c.id).totalJobs > 0).length}
                  </p>
                </div>
                <Activity className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Jobs</p>
                  <p className="text-3xl font-bold mt-1">{requests.length}</p>
                </div>
                <FileText className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Revenue</p>
                  <p className="text-3xl font-bold mt-1">
                    ${requests.filter(r => r.status === 'completed').reduce((sum, r) => sum + (r.price || 0), 0).toFixed(0)}
                  </p>
                </div>
                <DollarSign className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                placeholder="Search clients by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Clients List */}
        <Card>
          <CardHeader>
            <CardTitle>Clients ({filteredClients.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredClients.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-gray-500">No clients found</p>
                </div>
              ) : (
                filteredClients.map(client => {
                  const stats = getClientStats(client.id);
                  return (
                    <Card key={client.id} className="border hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-bold">{client.full_name}</h3>
                              {stats.totalJobs === 0 && (
                                <Badge variant="outline" className="text-xs">New</Badge>
                              )}
                            </div>
                            <p className="text-sm text-gray-600 mb-3">{client.email}</p>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                              <div>
                                <p className="text-gray-600">Total Jobs</p>
                                <p className="font-semibold">{stats.totalJobs}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Completed</p>
                                <p className="font-semibold">{stats.completedJobs}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Revenue</p>
                                <p className="font-semibold text-green-600">${stats.revenue.toFixed(2)}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Last Service</p>
                                <p className="font-semibold">
                                  {stats.lastService ? format(new Date(stats.lastService), 'MMM d, yyyy') : 'Never'}
                                </p>
                              </div>
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedClient(client)}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View Details
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Add Client Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Client</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Full Name</label>
              <Input
                value={newClient.full_name}
                onChange={(e) => setNewClient({...newClient, full_name: e.target.value})}
                placeholder="John Doe"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Email</label>
              <Input
                type="email"
                value={newClient.email}
                onChange={(e) => setNewClient({...newClient, email: e.target.value})}
                placeholder="john@example.com"
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Phone</label>
              <Input
                value={newClient.phone}
                onChange={(e) => setNewClient({...newClient, phone: e.target.value})}
                placeholder="+1234567890"
              />
            </div>
            <Button
              onClick={() => addClient.mutate(newClient)}
              disabled={!newClient.email || addClient.isLoading}
              className="w-full text-white"
              style={{ backgroundColor: primaryColor }}
            >
              {addClient.isLoading ? 'Adding...' : 'Add Client'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Import Clients</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              Upload a CSV or Excel file with columns: full_name, email, phone
            </p>
            <Input
              type="file"
              accept=".csv,.xlsx"
              onChange={(e) => setImportFile(e.target.files[0])}
            />
            <Button
              onClick={() => importFile && importClients.mutate(importFile)}
              disabled={!importFile || importClients.isLoading}
              className="w-full text-white"
              style={{ backgroundColor: primaryColor }}
            >
              {importClients.isLoading ? 'Importing...' : 'Import Clients'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Client Details Dialog */}
      <Dialog open={!!selectedClient} onOpenChange={() => setSelectedClient(null)}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedClient?.full_name}</DialogTitle>
          </DialogHeader>
          {selectedClient && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Email</p>
                  <p className="font-semibold">{selectedClient.email}</p>
                </div>
                <div>
                  <p className="text-gray-600">Member Since</p>
                  <p className="font-semibold">{format(new Date(selectedClient.created_date), 'MMM d, yyyy')}</p>
                </div>
              </div>

              <div>
                <h3 className="font-bold mb-3">Service History</h3>
                <div className="space-y-2">
                  {requests.filter(r => r.customer_id === selectedClient.id).map(request => (
                    <Card key={request.id} className="border">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold">
                              {request.service_type.replace(/_/g, ' ').toUpperCase()}
                            </p>
                            <p className="text-xs text-gray-500">
                              {format(new Date(request.created_date), 'MMM d, yyyy h:mm a')}
                            </p>
                          </div>
                          <div className="text-right">
                            <Badge>{request.status}</Badge>
                            {request.price && (
                              <p className="text-sm font-semibold mt-1">${request.price}</p>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}