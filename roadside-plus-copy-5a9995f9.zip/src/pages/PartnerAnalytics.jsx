import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Users, DollarSign, Activity, CheckCircle, Clock, Download, Calendar, UserPlus } from 'lucide-react';
import { format, startOfMonth, endOfMonth, subMonths, isWithinInterval, parseISO } from 'date-fns';

export default function PartnerAnalytics() {
  const [user, setUser] = useState(null);
  const [partner, setPartner] = useState(null);
  const [dateRange, setDateRange] = useState({
    start: format(subMonths(new Date(), 6), 'yyyy-MM-dd'),
    end: format(new Date(), 'yyyy-MM-dd')
  });

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
    const partners = await base44.entities.Partner.filter({ email: currentUser.email });
    if (partners[0]) setPartner(partners[0]);
  };

  const { data: requests = [] } = useQuery({
    queryKey: ['partner-requests-analytics', partner?.id],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter({ partner_id: partner.id });
    },
    enabled: !!partner
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['partner-customers-count', partner?.id],
    queryFn: async () => {
      const allUsers = await base44.entities.User.list();
      return allUsers.filter(u => u.role !== 'admin');
    },
    enabled: !!partner && partner.has_client_database_access
  });

  const { data: payouts = [] } = useQuery({
    queryKey: ['partner-payouts', partner?.id],
    queryFn: async () => {
      return await base44.entities.PartnerPayout.filter({ partner_id: partner.id });
    },
    enabled: !!partner
  });

  if (!partner) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  // Filter data by date range
  const filteredRequests = requests.filter(r => {
    const date = new Date(r.created_date);
    return isWithinInterval(date, {
      start: parseISO(dateRange.start),
      end: parseISO(dateRange.end)
    });
  });

  const primaryColor = partner.white_label_primary_color || '#FF771D';
  const completedRequests = filteredRequests.filter(r => r.status === 'completed');
  const activeJobs = filteredRequests.filter(r => ['assigned', 'en_route', 'in_progress'].includes(r.status)).length;
  const totalRevenue = completedRequests.reduce((sum, r) => sum + (r.price || 0), 0);
  const avgJobValue = completedRequests.length > 0 ? totalRevenue / completedRequests.length : 0;
  const completionRate = filteredRequests.length > 0 ? (completedRequests.length / filteredRequests.length) * 100 : 0;
  
  // Calculate CAC (Customer Acquisition Cost)
  const totalPaidCommission = payouts.filter(p => p.status === 'paid').reduce((sum, p) => sum + p.commission_amount, 0);
  const cac = customers.length > 0 ? totalPaidCommission / customers.length : 0;
  
  // Customer growth trend
  const customersByMonth = customers.reduce((acc, customer) => {
    const month = format(new Date(customer.created_date), 'yyyy-MM');
    acc[month] = (acc[month] || 0) + 1;
    return acc;
  }, {});
  
  // Referral trends
  const monthsInRange = [];
  let currentMonth = startOfMonth(parseISO(dateRange.start));
  const endDate = endOfMonth(parseISO(dateRange.end));
  while (currentMonth <= endDate) {
    monthsInRange.push(currentMonth);
    currentMonth = startOfMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
  }
  
  const referralTrendData = monthsInRange.map(date => {
    const monthKey = format(date, 'yyyy-MM');
    const monthStart = startOfMonth(date);
    const monthEnd = endOfMonth(date);
    const monthRequests = requests.filter(r => {
      const created = new Date(r.created_date);
      return created >= monthStart && created <= monthEnd;
    });
    return {
      month: format(date, 'MMM yyyy'),
      newCustomers: customersByMonth[monthKey] || 0,
      jobs: monthRequests.length,
      revenue: monthRequests.filter(r => r.status === 'completed').reduce((sum, r) => sum + (r.price || 0), 0)
    };
  });

  // Performance over time
  const performanceData = monthsInRange.map(date => {
    const monthStart = startOfMonth(date);
    const monthEnd = endOfMonth(date);
    const monthRequests = requests.filter(r => {
      const created = new Date(r.created_date);
      return created >= monthStart && created <= monthEnd;
    });
    const completed = monthRequests.filter(r => r.status === 'completed');
    return {
      month: format(date, 'MMM yy'),
      jobs: monthRequests.length,
      completed: completed.length,
      revenue: completed.reduce((sum, r) => sum + (r.price || 0), 0)
    };
  });

  // Service type distribution
  const serviceTypes = filteredRequests.reduce((acc, r) => {
    acc[r.service_type] = (acc[r.service_type] || 0) + 1;
    return acc;
  }, {});
  const serviceData = Object.entries(serviceTypes).map(([name, value]) => ({
    name: name.replace(/_/g, ' '),
    value
  }));

  const COLORS = [primaryColor, '#3D692B', '#E52C2D', '#FF9F40', '#4BC0C0', '#9966FF'];

  // Generate downloadable report
  const generateReport = () => {
    const reportData = {
      partner: partner.company_name,
      period: `${dateRange.start} to ${dateRange.end}`,
      metrics: {
        totalClients: customers.length,
        totalJobs: filteredRequests.length,
        activeJobs,
        completedJobs: completedRequests.length,
        totalRevenue: totalRevenue.toFixed(2),
        avgJobValue: avgJobValue.toFixed(2),
        completionRate: completionRate.toFixed(1) + '%',
        cac: cac.toFixed(2)
      },
      performanceData,
      referralTrendData,
      serviceDistribution: serviceData
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `partner-report-${partner.company_name}-${format(new Date(), 'yyyy-MM-dd')}.json`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold">Analytics & Reports</h1>
          <Button onClick={generateReport} className="text-white" style={{ backgroundColor: primaryColor }}>
            <Download className="w-4 h-4 mr-2" />
            Download Report
          </Button>
        </div>

        {/* Date Range Filter */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <Calendar className="w-5 h-5 text-gray-600" />
              <div className="flex items-center gap-2 flex-1">
                <Input
                  type="date"
                  value={dateRange.start}
                  onChange={(e) => setDateRange({...dateRange, start: e.target.value})}
                  max={dateRange.end}
                />
                <span className="text-gray-600">to</span>
                <Input
                  type="date"
                  value={dateRange.end}
                  onChange={(e) => setDateRange({...dateRange, end: e.target.value})}
                  min={dateRange.start}
                  max={format(new Date(), 'yyyy-MM-dd')}
                />
              </div>
              <Button 
                variant="outline" 
                onClick={() => setDateRange({
                  start: format(subMonths(new Date(), 6), 'yyyy-MM-dd'),
                  end: format(new Date(), 'yyyy-MM-dd')
                })}
              >
                Last 6 Months
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Real-time Performance Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Jobs</p>
                  <p className="text-3xl font-bold mt-1">{activeJobs}</p>
                </div>
                <Clock className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Clients</p>
                  <p className="text-3xl font-bold mt-1">{customers.length}</p>
                </div>
                <Users className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Completed Jobs</p>
                  <p className="text-3xl font-bold mt-1">{completedRequests.length}</p>
                </div>
                <CheckCircle className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Revenue Earned</p>
                  <p className="text-3xl font-bold mt-1">${totalRevenue.toFixed(0)}</p>
                </div>
                <DollarSign className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Clients</p>
                  <p className="text-3xl font-bold mt-1">{customers.length}</p>
                </div>
                <Users className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">CAC</p>
                  <p className="text-2xl font-bold mt-1">${cac.toFixed(2)}</p>
                  <p className="text-xs text-gray-500">per customer</p>
                </div>
                <UserPlus className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Referral Trends */}
          <Card>
            <CardHeader>
              <CardTitle>Referral Trends Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={referralTrendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="newCustomers" stroke={primaryColor} strokeWidth={2} name="New Customers" />
                  <Line type="monotone" dataKey="jobs" stroke="#3D692B" strokeWidth={2} name="Jobs" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Revenue Trend */}
          <Card>
            <CardHeader>
              <CardTitle>Revenue Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="revenue" fill={primaryColor} name="Revenue ($)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Service Type Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Service Type Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie data={serviceData} cx="50%" cy="50%" labelLine={false} label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`} outerRadius={80} fill="#8884d8" dataKey="value">
                    {serviceData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Performance Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Key Performance Metrics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Average Job Value</span>
                <span className="text-2xl font-bold" style={{ color: '#3D692B' }}>${avgJobValue.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Success Rate</span>
                <span className="text-2xl font-bold">{completionRate.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Customer Acquisition Cost</span>
                <span className="text-2xl font-bold" style={{ color: primaryColor }}>${cac.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Revenue per Customer</span>
                <span className="text-2xl font-bold" style={{ color: '#3D692B' }}>
                  ${customers.length > 0 ? (totalRevenue / customers.length).toFixed(2) : '0.00'}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}