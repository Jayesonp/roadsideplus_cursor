import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, RefreshCw, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { createPageUrl } from '@/utils';
import ProviderTrackingMap from '../components/tracking/ProviderTrackingMap';

export default function TrackProvider() {
  const [requestId, setRequestId] = useState(null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUser();
    const params = new URLSearchParams(window.location.search);
    const id = params.get('requestId');
    if (id) {
      setRequestId(id);
    }
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  // Fetch service request
  const { data: serviceRequest, isLoading: loadingRequest } = useQuery({
    queryKey: ['serviceRequest', requestId],
    queryFn: async () => {
      if (!requestId) return null;
      const requests = await base44.entities.ServiceRequest.filter({ id: requestId });
      return requests[0] || null;
    },
    enabled: !!requestId,
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  // Fetch technician profile
  const { data: technicianProfile } = useQuery({
    queryKey: ['technicianProfile', serviceRequest?.assigned_technician_id],
    queryFn: async () => {
      if (!serviceRequest?.assigned_technician_id) return null;
      const profiles = await base44.entities.TechnicianProfile.filter({ 
        user_id: serviceRequest.assigned_technician_id 
      });
      return profiles[0] || null;
    },
    enabled: !!serviceRequest?.assigned_technician_id,
  });

  // Fetch latest technician location
  const { data: technicianLocation, refetch: refetchLocation } = useQuery({
    queryKey: ['technicianLocation', serviceRequest?.assigned_technician_id],
    queryFn: async () => {
      if (!serviceRequest?.assigned_technician_id) return null;
      const locations = await base44.entities.TechnicianLocation.filter(
        { technician_id: serviceRequest.assigned_technician_id },
        '-timestamp',
        1
      );
      return locations[0] || null;
    },
    enabled: !!serviceRequest?.assigned_technician_id,
    refetchInterval: 10000, // Refresh every 10 seconds for real-time tracking
  });

  const handleCallTechnician = () => {
    if (technicianProfile?.phone) {
      window.location.href = `tel:${technicianProfile.phone}`;
    }
  };

  const handleRefresh = () => {
    refetchLocation();
  };

  if (!requestId) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">No Request ID</h2>
            <p className="text-gray-600 mb-4">
              Please access this page from your service request.
            </p>
            <Button 
              onClick={() => window.location.href = createPageUrl('CustomerDashboard')}
              className="bg-gradient-to-r from-orange-500 to-red-500"
            >
              Go to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loadingRequest) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin text-orange-500 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Loading tracking information...</p>
        </div>
      </div>
    );
  }

  if (!serviceRequest) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Request Not Found</h2>
            <p className="text-gray-600 mb-4">
              Unable to find the service request.
            </p>
            <Button 
              onClick={() => window.location.href = createPageUrl('CustomerDashboard')}
              className="bg-gradient-to-r from-orange-500 to-red-500"
            >
              Go to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!serviceRequest.assigned_technician_id) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">No Provider Assigned Yet</h2>
            <p className="text-gray-600 mb-4">
              We're finding the best service provider for you. You'll be able to track them once they're assigned.
            </p>
            <Button 
              onClick={() => window.location.href = createPageUrl('CustomerDashboard')}
              className="bg-gradient-to-r from-orange-500 to-red-500"
            >
              Go to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={() => window.location.href = createPageUrl('CustomerDashboard')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Button>
          <Button
            variant="outline"
            onClick={handleRefresh}
            className="flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh
          </Button>
        </div>

        {/* Page Title */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent mb-2">
            Track Your Provider
          </h1>
          <p className="text-gray-600 dark:text-gray-400 text-lg">
            Real-time location and estimated arrival time
          </p>
        </div>

        {/* Service Request Info */}
        <Card className="mb-6 shadow-lg">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Service Type</p>
                <p className="font-semibold text-gray-900 dark:text-white capitalize">
                  {serviceRequest.service_type?.replace(/_/g, ' ') || 'N/A'}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Status</p>
                <p className="font-semibold text-gray-900 dark:text-white capitalize">
                  {serviceRequest.status?.replace(/_/g, ' ') || 'N/A'}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Location</p>
                <p className="font-semibold text-gray-900 dark:text-white text-sm">
                  {serviceRequest.location_address || 'N/A'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tracking Map */}
        <ProviderTrackingMap
          serviceRequest={serviceRequest}
          technicianLocation={technicianLocation}
          technicianProfile={technicianProfile}
          onCallTechnician={handleCallTechnician}
        />

        {/* Auto-refresh notice */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            📍 Location updates automatically every 10 seconds
          </p>
        </div>
      </div>
    </div>
  );
}