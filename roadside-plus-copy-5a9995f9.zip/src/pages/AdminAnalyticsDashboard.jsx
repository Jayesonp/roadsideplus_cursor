import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Clock, Users, CheckCircle, AlertCircle, MessageSquare } from 'lucide-react';
import { format, subDays, differenceInMinutes, differenceInHours } from 'date-fns';

export default function AdminAnalyticsDashboard() {
  const [user, setUser] = useState(null);
  const [dateRange, setDateRange] = useState('7');

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const startDate = subDays(new Date(), parseInt(dateRange)).toISOString();

  // Fetch service requests
  const { data: requests = [] } = useQuery({
    queryKey: ['analytics-requests', dateRange],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.list('-created_date', 500);
    },
    enabled: !!user
  });

  // Fetch technicians
  const { data: technicians = [] } = useQuery({
    queryKey: ['analytics-technicians'],
    queryFn: async () => {
      return await base44.entities.TechnicianProfile.list();
    },
    enabled: !!user
  });

  // Fetch ratings
  const { data: ratings = [] } = useQuery({
    queryKey: ['analytics-ratings', dateRange],
    queryFn: async () => {
      return await base44.entities.Rating.list('-created_date', 500);
    },
    enabled: !!user
  });

  // Fetch support conversations
  const { data: supportChats = [] } = useQuery({
    queryKey: ['analytics-support', dateRange],
    queryFn: async () => {
      return await base44.entities.SupportConversation.list('-created_date', 500);
    },
    enabled: !!user
  });

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <h2 className="text-xl font-bold mb-2">Access Denied</h2>
          <p className="text-gray-600">This page is only accessible to administrators.</p>
        </Card>
      </div>
    );
  }

  const filteredRequests = requests.filter(r => new Date(r.created_date) >= new Date(startDate));
  const filteredRatings = ratings.filter(r => new Date(r.created_date) >= new Date(startDate));
  const filteredChats = supportChats.filter(c => new Date(c.created_date) >= new Date(startDate));

  // Calculate metrics
  const completedRequests = filteredRequests.filter(r => r.status === 'completed');
  
  // Average response time (from created to assigned)
  const responseTimes = filteredRequests
    .filter(r => r.technician_id && r.created_date)
    .map(r => {
      const events = [];
      // Simplified: use estimated_arrival as proxy for assignment time
      return differenceInMinutes(
        new Date(r.estimated_arrival || r.updated_date),
        new Date(r.created_date)
      );
    })
    .filter(t => t > 0 && t < 180); // Filter outliers

  const avgResponseTime = responseTimes.length > 0
    ? Math.round(responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length)
    : 0;

  // Technician utilization
  const techWithJobs = technicians.map(tech => {
    const techJobs = completedRequests.filter(r => r.technician_id === tech.user_id);
    return {
      ...tech,
      jobCount: techJobs.length
    };
  }).filter(t => t.onboarding_completed);

  const utilizationRate = techWithJobs.length > 0
    ? Math.round((techWithJobs.filter(t => t.jobCount > 0).length / techWithJobs.length) * 100)
    : 0;

  // Completion times by service type
  const serviceTypeStats = {};
  completedRequests.forEach(req => {
    if (req.completed_at && req.created_date) {
      const duration = differenceInHours(new Date(req.completed_at), new Date(req.created_date));
      if (!serviceTypeStats[req.service_type]) {
        serviceTypeStats[req.service_type] = [];
      }
      if (duration > 0 && duration < 24) {
        serviceTypeStats[req.service_type].push(duration);
      }
    }
  });

  const completionTimeData = Object.keys(serviceTypeStats).map(type => ({
    service: type.replace(/_/g, ' ').toUpperCase(),
    avgHours: serviceTypeStats[type].length > 0
      ? (serviceTypeStats[type].reduce((a, b) => a + b, 0) / serviceTypeStats[type].length).toFixed(1)
      : 0
  }));

  // Customer satisfaction
  const avgRating = filteredRatings.length > 0
    ? (filteredRatings.reduce((sum, r) => sum + r.rating, 0) / filteredRatings.length).toFixed(1)
    : 5.0;

  const ratingDistribution = [
    { rating: '5 Stars', count: filteredRatings.filter(r => r.rating === 5).length },
    { rating: '4 Stars', count: filteredRatings.filter(r => r.rating === 4).length },
    { rating: '3 Stars', count: filteredRatings.filter(r => r.rating === 3).length },
    { rating: '2 Stars', count: filteredRatings.filter(r => r.rating === 2).length },
    { rating: '1 Star', count: filteredRatings.filter(r => r.rating === 1).length }
  ];

  // Support chat issues
  const commonIssues = {};
  filteredChats.forEach(chat => {
    const subject = chat.subject.toLowerCase();
    let category = 'Other';
    if (subject.includes('payment') || subject.includes('charge')) category = 'Payment';
    else if (subject.includes('technician') || subject.includes('late')) category = 'Technician';
    else if (subject.includes('cancel')) category = 'Cancellation';
    else if (subject.includes('quality') || subject.includes('service')) category = 'Service Quality';
    else if (subject.includes('app') || subject.includes('bug')) category = 'Technical';

    commonIssues[category] = (commonIssues[category] || 0) + 1;
  });

  const issuesData = Object.keys(commonIssues).map(category => ({
    category,
    count: commonIssues[category]
  })).sort((a, b) => b.count - a.count);

  // Daily trends
  const dailyData = {};
  filteredRequests.forEach(req => {
    const day = format(new Date(req.created_date), 'MMM dd');
    if (!dailyData[day]) {
      dailyData[day] = { date: day, requests: 0, completed: 0 };
    }
    dailyData[day].requests++;
    if (req.status === 'completed') dailyData[day].completed++;
  });

  const trendData = Object.values(dailyData).slice(-7);

  const COLORS = ['#FF771D', '#E52C2D', '#3D692B', '#FFA500', '#4CAF50', '#2196F3'];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">Analytics Dashboard</h1>
            <p className="text-sm opacity-90">Business insights and performance metrics</p>
          </div>
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-40 bg-white/10 border-white/30 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 Days</SelectItem>
              <SelectItem value="30">Last 30 Days</SelectItem>
              <SelectItem value="90">Last 90 Days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Key Metrics */}
        <div className="grid md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Avg Response Time</p>
                  <p className="text-2xl font-bold">{avgResponseTime}m</p>
                </div>
                <Clock className="w-8 h-8" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Utilization Rate</p>
                  <p className="text-2xl font-bold">{utilizationRate}%</p>
                </div>
                <Users className="w-8 h-8" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Avg Rating</p>
                  <p className="text-2xl font-bold">{avgRating} ⭐</p>
                </div>
                <CheckCircle className="w-8 h-8" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Support Tickets</p>
                  <p className="text-2xl font-bold">{filteredChats.length}</p>
                </div>
                <MessageSquare className="w-8 h-8" style={{ color: '#E52C2D' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <Tabs defaultValue="trends" className="space-y-6">
          <TabsList className="grid w-full max-w-2xl grid-cols-4">
            <TabsTrigger value="trends">Trends</TabsTrigger>
            <TabsTrigger value="service">Service Times</TabsTrigger>
            <TabsTrigger value="satisfaction">Satisfaction</TabsTrigger>
            <TabsTrigger value="support">Support</TabsTrigger>
          </TabsList>

          <TabsContent value="trends">
            <Card>
              <CardHeader>
                <CardTitle>Daily Request Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="requests" stroke="#FF771D" strokeWidth={2} name="Total Requests" />
                    <Line type="monotone" dataKey="completed" stroke="#3D692B" strokeWidth={2} name="Completed" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="service">
            <Card>
              <CardHeader>
                <CardTitle>Average Completion Time by Service Type</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={completionTimeData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="service" />
                    <YAxis label={{ value: 'Hours', angle: -90, position: 'insideLeft' }} />
                    <Tooltip />
                    <Bar dataKey="avgHours" fill="#FF771D" name="Avg Hours" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="satisfaction">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Rating Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={ratingDistribution}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="rating" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count" fill="#3D692B" name="Count" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Technician Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {techWithJobs
                      .sort((a, b) => b.rating - a.rating)
                      .slice(0, 5)
                      .map((tech, idx) => (
                        <div key={tech.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: '#FF771D' }}>
                              {idx + 1}
                            </div>
                            <div>
                              <p className="font-semibold text-sm">Technician #{tech.user_id.slice(0, 8)}</p>
                              <p className="text-xs text-gray-500">{tech.jobCount} jobs</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold" style={{ color: '#3D692B' }}>{tech.rating.toFixed(1)} ⭐</p>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="support">
            <Card>
              <CardHeader>
                <CardTitle>Common Support Issues</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={issuesData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ category, percent }) => `${category} (${(percent * 100).toFixed(0)}%)`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="count"
                      >
                        {issuesData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>

                  <div className="space-y-2">
                    <h4 className="font-semibold mb-3">Issue Breakdown</h4>
                    {issuesData.map((issue, idx) => (
                      <div key={issue.category} className="flex items-center justify-between p-2 border-b">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                          <span className="text-sm">{issue.category}</span>
                        </div>
                        <span className="font-semibold">{issue.count}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}