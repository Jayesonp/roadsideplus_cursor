import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Calendar, DollarSign, Star, MapPin, Clock } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { format } from 'date-fns';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';

export default function JobHistory() {
  const [user, setUser] = useState(null);

  React.useEffect(() => {
    base44.auth.me().then(setUser);
  }, []);

  const { data: jobs = [], isLoading } = useQuery({
    queryKey: ['technician-history', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const completed = await base44.entities.ServiceRequest.filter({
        technician_id: user.id,
        status: 'completed'
      }, '-created_date', 50);
      
      const cancelled = await base44.entities.ServiceRequest.filter({
        technician_id: user.id,
        status: 'cancelled'
      }, '-created_date', 20);

      return [...completed, ...cancelled].sort((a, b) => 
        new Date(b.created_date) - new Date(a.created_date)
      );
    },
    enabled: !!user
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner message="Loading history..." />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Safe Area Top */}
      <div style={{ height: 'var(--safe-area-top)', background: 'linear-gradient(135deg, #E52C2D 0%, #FF771D 100%)' }} />
      
      <div className="text-white p-4 shadow-lg sticky top-0 z-10" style={{ background: 'linear-gradient(135deg, #E52C2D 0%, #FF771D 100%)' }}>
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20"
            onClick={() => window.location.href = createPageUrl('TechnicianDashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold">Job History</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-4">
        {jobs.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No completed jobs yet.</p>
          </div>
        ) : (
          jobs.map(job => (
            <Card key={job.id} className="hover:shadow-md transition-shadow" onClick={() => window.location.href = createPageUrl(`JobDetails?id=${job.id}`)}>
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-3">
                    <ServiceTypeIcon type={job.service_type} />
                    <div>
                      <h3 className="font-bold text-gray-900">
                        {(job.service_type || 'Service').replace(/_/g, ' ')}
                      </h3>
                      <p className="text-xs text-gray-500">
                        {format(new Date(job.created_date), 'MMM d, yyyy • h:mm a')}
                      </p>
                    </div>
                  </div>
                  <Badge variant={job.status === 'completed' ? 'default' : 'destructive'} 
                         className={job.status === 'completed' ? 'bg-green-600' : 'bg-red-600'}>
                    {job.status}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2 text-gray-600">
                    <MapPin className="w-4 h-4" />
                    <span className="truncate">{job.location_address || 'Location not recorded'}</span>
                  </div>
                  {job.payment_amount && (
                    <div className="flex items-center gap-2 font-semibold text-green-700 justify-end">
                      <DollarSign className="w-4 h-4" />
                      ${job.payment_amount.toFixed(2)}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
      
      {/* Safe Area Bottom */}
      <div style={{ height: 'var(--safe-area-bottom)' }} />
    </div>
  );
}