import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Loader2 } from 'lucide-react';

export default function RoleSelection() {
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    checkUserRole();
  }, []);

  const checkUserRole = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      
      if (!isAuth) {
        base44.auth.redirectToLogin();
        return;
      }

      const user = await base44.auth.me();
      
      // Check if terms have been accepted
      if (!user.terms_accepted || !user.privacy_accepted) {
        window.location.href = createPageUrl('TermsAcceptance');
        return;
      }

      // Check for technician profile
      const techProfiles = await base44.entities.TechnicianProfile.filter({ user_id: user.id });
      const isTechnician = techProfiles.length > 0;
      
      // Route based on user type and onboarding status
      if (user.role === 'admin') {
        // Admin can access both dashboards
        if (isTechnician) {
          window.location.href = createPageUrl('TechnicianDashboard');
        } else {
          window.location.href = createPageUrl('CustomerDashboard');
        }
      } else if (user.user_type === 'technician' || isTechnician) {
        // Technician onboarding flow
        if (!user.onboarding_completed || !techProfiles[0]?.onboarding_completed) {
          window.location.href = createPageUrl('TechnicianOnboardingChecklist');
        } else {
          window.location.href = createPageUrl('TechnicianDashboard');
        }
      } else if (user.user_type === 'partner') {
        // Partner routing
        window.location.href = createPageUrl('PartnerDashboard');
      } else if (user.user_type === 'security_company') {
        // Security company routing
        window.location.href = createPageUrl('SecurityCommandCenter');
      } else {
        // Customer onboarding flow
        if (!user.onboarding_completed) {
          // Will show onboarding wizard in CustomerDashboard
          window.location.href = createPageUrl('CustomerDashboard');
        } else {
          // Check payment method for existing customers
          const paymentMethods = await base44.entities.PaymentMethod.filter({ user_id: user.id });
          if (paymentMethods.length === 0) {
            window.location.href = createPageUrl('AddPaymentCard');
          } else {
            window.location.href = createPageUrl('CustomerDashboard');
          }
        }
      }
    } catch (error) {
      console.error('Error checking role:', error);
      base44.auth.redirectToLogin();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center" 
      style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
      <div className="text-center text-white">
        <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4" />
        <p className="text-lg">Loading your dashboard...</p>
      </div>
    </div>
  );
}