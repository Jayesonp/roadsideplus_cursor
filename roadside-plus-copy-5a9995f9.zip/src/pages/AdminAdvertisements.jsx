import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, Eye, TrendingUp, MousePointer, BarChart3,
  Edit, Trash2, Play, Pause, Upload
} from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import BrandLogo from '../components/branding/BrandLogo';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function AdminAdvertisements() {
  const [user, setUser] = useState(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedAd, setSelectedAd] = useState(null);
  const [uploadFile, setUploadFile] = useState(null);
  const [newAd, setNewAd] = useState({
    title: '',
    subtitle: '',
    image_url: '',
    cta_text: 'Learn More',
    link_url: '',
    ad_type: 'dashboard_card',
    placement: 'both',
    status: 'paused',
    priority: 1,
    rotation_duration: 15,
    category: 'general',
    target_audience: 'all',
    use_ai_selection: false,
    revenue_model: 'cpm',
    revenue_value: 0,
    max_impressions_per_user: 3
  });
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        window.location.href = createPageUrl('Login');
        return;
      }
      const currentUser = await base44.auth.me();
      if (currentUser.role !== 'admin') {
        window.location.href = createPageUrl('CustomerDashboard');
        return;
      }
      setUser(currentUser);
    } catch (error) {
      window.location.href = createPageUrl('Login');
    }
  };

  const { data: ads = [] } = useQuery({
    queryKey: ['all-ads'],
    queryFn: async () => {
      return await base44.entities.Advertisement.list('-created_date');
    },
    enabled: !!user
  });

  const createAd = useMutation({
    mutationFn: async () => {
      let imageUrl = newAd.image_url;
      
      if (uploadFile) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: uploadFile });
        imageUrl = file_url;
      }
      
      await base44.entities.Advertisement.create({
        ...newAd,
        image_url: imageUrl
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-ads'] });
      setShowCreateDialog(false);
      setUploadFile(null);
      setNewAd({
        title: '',
        subtitle: '',
        image_url: '',
        cta_text: 'Learn More',
        link_url: '',
        ad_type: 'dashboard_card',
        placement: 'both',
        status: 'paused',
        priority: 1,
        rotation_duration: 15,
        category: 'general',
        target_audience: 'all',
        use_ai_selection: false,
        revenue_model: 'cpm',
        revenue_value: 0,
        max_impressions_per_user: 3
      });
    }
  });

  const updateAdStatus = useMutation({
    mutationFn: async ({ adId, status }) => {
      await base44.entities.Advertisement.update(adId, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-ads'] });
    }
  });

  const deleteAd = useMutation({
    mutationFn: async (adId) => {
      await base44.entities.Advertisement.delete(adId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-ads'] });
    }
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2" style={{ borderColor: '#FF771D' }}></div>
      </div>
    );
  }

  const activeAds = ads.filter(a => a.status === 'active').length;
  const totalImpressions = ads.reduce((sum, a) => sum + (a.total_impressions || 0), 0);
  const totalClicks = ads.reduce((sum, a) => sum + (a.total_clicks || 0), 0);
  const avgCTR = totalImpressions > 0 ? ((totalClicks / totalImpressions) * 100).toFixed(2) : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <BrandLogo variant="icon" size="md" />
            <div>
              <h1 className="text-2xl font-bold">Advertisement Management</h1>
              <p className="text-sm text-gray-600">Manage in-app advertising campaigns</p>
            </div>
          </div>
          <Button
            onClick={() => setShowCreateDialog(true)}
            className="text-white"
            style={{ backgroundColor: '#FF771D' }}
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Ad
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Ads</p>
                  <p className="text-3xl font-bold mt-1">{ads.length}</p>
                </div>
                <BarChart3 className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active</p>
                  <p className="text-3xl font-bold mt-1" style={{ color: '#3D692B' }}>
                    {activeAds}
                  </p>
                </div>
                <Play className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Impressions</p>
                  <p className="text-3xl font-bold mt-1">{totalImpressions.toLocaleString()}</p>
                </div>
                <Eye className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg CTR</p>
                  <p className="text-3xl font-bold mt-1">{avgCTR}%</p>
                </div>
                <TrendingUp className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Ads List */}
        <Card>
          <CardHeader>
            <CardTitle>All Advertisements</CardTitle>
          </CardHeader>
          <CardContent>
            {ads.length === 0 ? (
              <div className="text-center py-12">
                <BarChart3 className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-600">No advertisements yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {ads.map(ad => (
                  <Card key={ad.id} className="border hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        {ad.image_url && (
                          <img 
                            src={ad.image_url} 
                            alt={ad.title}
                            className="w-24 h-24 object-cover rounded-lg"
                          />
                        )}
                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h3 className="font-bold">{ad.title}</h3>
                              <p className="text-sm text-gray-600">{ad.subtitle}</p>
                            </div>
                            <Badge className={
                              ad.status === 'active' ? 'bg-green-100 text-green-800' :
                              ad.status === 'paused' ? 'bg-gray-100 text-gray-800' :
                              'bg-yellow-100 text-yellow-800'
                            }>
                              {ad.status}
                            </Badge>
                          </div>
                          
                          <div className="grid grid-cols-4 gap-4 mb-3 text-sm">
                            <div>
                              <p className="text-gray-600">Type</p>
                              <p className="font-semibold capitalize">{ad.ad_type}</p>
                            </div>
                            <div>
                              <p className="text-gray-600">Impressions</p>
                              <p className="font-semibold">{ad.total_impressions || 0}</p>
                            </div>
                            <div>
                              <p className="text-gray-600">Clicks</p>
                              <p className="font-semibold">{ad.total_clicks || 0}</p>
                            </div>
                            <div>
                              <p className="text-gray-600">CTR</p>
                              <p className="font-semibold">
                                {ad.total_impressions > 0 ? 
                                  ((ad.total_clicks / ad.total_impressions) * 100).toFixed(2) : 0}%
                              </p>
                            </div>
                          </div>

                          <div className="flex gap-2">
                            {ad.status === 'active' ? (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => updateAdStatus.mutate({ adId: ad.id, status: 'paused' })}
                              >
                                <Pause className="w-4 h-4 mr-2" />
                                Pause
                              </Button>
                            ) : (
                              <Button
                                size="sm"
                                onClick={() => updateAdStatus.mutate({ adId: ad.id, status: 'active' })}
                                className="text-white"
                                style={{ backgroundColor: '#3D692B' }}
                              >
                                <Play className="w-4 h-4 mr-2" />
                                Activate
                              </Button>
                            )}
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setSelectedAd(ad)}
                            >
                              <Eye className="w-4 h-4 mr-2" />
                              Details
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                if (confirm('Delete this ad?')) {
                                  deleteAd.mutate(ad.id);
                                }
                              }}
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Create Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Advertisement</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Ad Title</label>
              <Input
                value={newAd.title}
                onChange={(e) => setNewAd({...newAd, title: e.target.value})}
                placeholder="Summer Sale - 20% Off!"
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Subtitle</label>
              <Textarea
                value={newAd.subtitle}
                onChange={(e) => setNewAd({...newAd, subtitle: e.target.value})}
                placeholder="Limited time offer on all services"
                rows={2}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Ad Image</label>
              <Input
                type="file"
                accept="image/*"
                onChange={(e) => setUploadFile(e.target.files[0])}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">CTA Text</label>
                <Input
                  value={newAd.cta_text}
                  onChange={(e) => setNewAd({...newAd, cta_text: e.target.value})}
                  placeholder="Learn More"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Destination URL</label>
                <Input
                  value={newAd.link_url}
                  onChange={(e) => setNewAd({...newAd, link_url: e.target.value})}
                  placeholder="https://example.com"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Ad Type</label>
                <Select
                  value={newAd.ad_type}
                  onValueChange={(value) => setNewAd({...newAd, ad_type: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dashboard_card">Dashboard Card (Premium)</SelectItem>
                    <SelectItem value="expandable">Expandable Banner</SelectItem>
                    <SelectItem value="screen_open">Fullscreen Idle</SelectItem>
                    <SelectItem value="banner">Mini Banner</SelectItem>
                    <SelectItem value="carousel">Carousel</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Placement</label>
                <Select
                  value={newAd.placement}
                  onValueChange={(value) => setNewAd({...newAd, placement: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="customer_dashboard">Customer Dashboard</SelectItem>
                    <SelectItem value="technician_dashboard">Technician Dashboard</SelectItem>
                    <SelectItem value="both">Both</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Priority</label>
                <Input
                  type="number"
                  min="1"
                  max="10"
                  value={newAd.priority}
                  onChange={(e) => setNewAd({...newAd, priority: parseInt(e.target.value)})}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Start Date</label>
                <Input
                  type="datetime-local"
                  value={newAd.start_date || ''}
                  onChange={(e) => setNewAd({...newAd, start_date: e.target.value})}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">End Date</label>
                <Input
                  type="datetime-local"
                  value={newAd.end_date || ''}
                  onChange={(e) => setNewAd({...newAd, end_date: e.target.value})}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Category</label>
                <Select
                  value={newAd.category || 'general'}
                  onValueChange={(value) => setNewAd({...newAd, category: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General</SelectItem>
                    <SelectItem value="vehicle_service">Vehicle Service</SelectItem>
                    <SelectItem value="insurance">Insurance</SelectItem>
                    <SelectItem value="fuel">Fuel</SelectItem>
                    <SelectItem value="auto_parts">Auto Parts</SelectItem>
                    <SelectItem value="food">Food & Coffee</SelectItem>
                    <SelectItem value="emergency">Emergency Products</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Target Audience</label>
                <Select
                  value={newAd.target_audience || 'all'}
                  onValueChange={(value) => setNewAd({...newAd, target_audience: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Users</SelectItem>
                    <SelectItem value="new_users">New Users</SelectItem>
                    <SelectItem value="returning_users">Returning Users</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Revenue Model</label>
                <Select
                  value={newAd.revenue_model || 'cpm'}
                  onValueChange={(value) => setNewAd({...newAd, revenue_model: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cpm">CPM (Cost per 1000 impressions)</SelectItem>
                    <SelectItem value="cpc">CPC (Cost per click)</SelectItem>
                    <SelectItem value="cpa">CPA (Cost per action)</SelectItem>
                    <SelectItem value="flat">Flat Rate</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Revenue Value ($)</label>
                <Input
                  type="number"
                  step="0.01"
                  value={newAd.revenue_value || 0}
                  onChange={(e) => setNewAd({...newAd, revenue_value: parseFloat(e.target.value)})}
                />
              </div>
            </div>

            <div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newAd.use_ai_selection || false}
                  onChange={(e) => setNewAd({...newAd, use_ai_selection: e.target.checked})}
                  className="rounded"
                />
                <span className="text-sm font-medium">Use AI for optimal ad selection</span>
              </label>
            </div>

            <Button
              onClick={() => createAd.mutate()}
              disabled={!newAd.title || !newAd.link_url || (!uploadFile && !newAd.image_url) || createAd.isLoading}
              className="w-full text-white"
              style={{ backgroundColor: '#FF771D' }}
            >
              {createAd.isLoading ? 'Creating...' : 'Create Advertisement'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Details Dialog */}
      <Dialog open={!!selectedAd} onOpenChange={() => setSelectedAd(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedAd?.title}</DialogTitle>
          </DialogHeader>
          {selectedAd && (
            <div className="space-y-4">
              {selectedAd.image_url && (
                <img 
                  src={selectedAd.image_url} 
                  alt={selectedAd.title}
                  className="w-full h-48 object-cover rounded-lg"
                />
              )}
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Type</p>
                  <p className="font-semibold capitalize">{selectedAd.ad_type}</p>
                </div>
                <div>
                  <p className="text-gray-600">Placement</p>
                  <p className="font-semibold capitalize">{selectedAd.placement}</p>
                </div>
                <div>
                  <p className="text-gray-600">Total Impressions</p>
                  <p className="font-semibold">{selectedAd.total_impressions || 0}</p>
                </div>
                <div>
                  <p className="text-gray-600">Total Clicks</p>
                  <p className="font-semibold">{selectedAd.total_clicks || 0}</p>
                </div>
              </div>
              {selectedAd.link_url && (
                <Button
                  onClick={() => window.open(selectedAd.link_url, '_blank')}
                  className="w-full text-white"
                  style={{ backgroundColor: '#FF771D' }}
                >
                  View Destination
                </Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}