import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { getCachedUser } from '@/components/utils/userCache';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Send, Star, Loader2, Image, FileText, Download, CheckCircle, XCircle, Receipt } from 'lucide-react';
import { useQueryWithTimeout } from '../components/common/useQueryWithTimeout';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ErrorState from '../components/common/ErrorState';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { createPageUrl } from '@/utils';
import StatusBadge from '../components/common/StatusBadge';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';

// Lazy load heavy components
const ServiceMap = React.lazy(() => import('../components/map/ServiceMap'));
const RealTimeTrackingMap = React.lazy(() => import('../components/map/RealTimeTrackingMap'));
const ChatInterface = React.lazy(() => import('../components/chat/ChatInterface'));
const ArchivedChatHistory = React.lazy(() => import('../components/chat/ArchivedChatHistory'));
import { format } from 'date-fns';
// Lazy load payment components
const InvoiceGenerator = React.lazy(() => import('../components/payments/InvoiceGenerator'));
const InvoiceViewer = React.lazy(() => import('../components/payments/InvoiceViewer'));
const RatingPrompt = React.lazy(() => import('../components/reviews/RatingPrompt'));
import LiveStatusUpdates from '../components/job/LiveStatusUpdates';
import PaymentStatusBadge from '../components/payments/PaymentStatusBadge';
import CriticalJobNotifications from '../components/notifications/CriticalJobNotifications';
import ETADisplay from '../components/service/ETADisplay';

export default function ServiceDetails() {
  const [user, setUser] = useState(null);
  const [requestId, setRequestId] = useState(null);
  const [message, setMessage] = useState('');
  const [rating, setRating] = useState(0);
  const [ratingComment, setRatingComment] = useState('');
  const [previousStatus, setPreviousStatus] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    setRequestId(id);
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await getCachedUser();
      setUser(currentUser);
    } catch (e) {
      console.error('Failed to load user', e);
    }
  };

  const { data: request, isLoading, isError, error, refetch } = useQueryWithTimeout({
    queryKey: ['service-request', requestId],
    queryFn: async () => {
      if (!requestId) throw new Error('No request ID');
      const requests = await base44.entities.ServiceRequest.filter({ id: requestId });
      if (!requests || requests.length === 0) throw new Error('Request not found');
      return requests[0];
    },
    enabled: !!requestId,
    refetchInterval: (data) => {
      if (!data) return 10000; 
      // Increase polling interval to reduce server load
      const activeStatuses = ['assigned', 'en_route', 'arrived', 'in_progress'];
      return activeStatuses.includes(data.status) ? 20000 : false;
    },
    retry: 1,
    staleTime: 10000,
    refetchOnWindowFocus: true,
    onSuccess: (data) => {
      if (data && previousStatus !== data.status) {
        setPreviousStatus(data.status);
      }
    }
  }, 10000);

  const { data: messages = [] } = useQueryWithTimeout({
    queryKey: ['messages', requestId],
    queryFn: async () => {
      return await base44.entities.Message.filter(
        { service_request_id: requestId },
        'created_date'
      );
    },
    enabled: !!requestId,
    refetchInterval: 120000, // Increased to 2m
    retry: 1,
    staleTime: 60000,
    refetchOnWindowFocus: false
  }, 10000);

  const { data: existingRating } = useQueryWithTimeout({
    queryKey: ['rating', requestId],
    queryFn: async () => {
      const ratings = await base44.entities.Rating.filter({
        service_request_id: requestId,
        customer_id: user.id
      });
      return ratings[0];
    },
    enabled: !!requestId && !!user && request?.status === 'completed',
    retry: 1
  }, 8000);

  const { data: attachments = [] } = useQueryWithTimeout({
    queryKey: ['attachments', requestId],
    queryFn: async () => {
      return await base44.entities.ServiceAttachment.filter(
        { service_request_id: requestId },
        'created_date'
      );
    },
    enabled: !!requestId && !!request,
    retry: 1,
    staleTime: 60000
  }, 15000);

  const sendMessage = useMutation({
    mutationFn: async () => {
      return await base44.entities.Message.create({
        service_request_id: requestId,
        sender_id: user.id,
        sender_role: user.user_type,
        message: message
      });
    },
    onSuccess: async (newMessage) => {
      setMessage('');
      queryClient.invalidateQueries(['messages', requestId]);
      
      // Notify technician of new message
      if (request?.technician_id) {
        await base44.entities.Notification.create({
          user_id: request.technician_id,
          type: 'new_message',
          title: 'New Message',
          message: 'A customer sent you a message.',
          related_id: requestId
        });
      }
    }
  });

  const submitRating = useMutation({
    mutationFn: async () => {
      const newRating = await base44.entities.Rating.create({
        service_request_id: requestId,
        technician_id: request.technician_id,
        customer_id: user.id,
        rating: rating,
        comment: ratingComment
      });
      
      // Update technician's average rating
      const allRatings = await base44.entities.Rating.filter({ technician_id: request.technician_id });
      const avgRating = allRatings.reduce((sum, r) => sum + r.rating, 0) / allRatings.length;
      
      const techProfiles = await base44.entities.TechnicianProfile.filter({ user_id: request.technician_id });
      if (techProfiles[0]) {
        await base44.entities.TechnicianProfile.update(techProfiles[0].id, {
          rating: avgRating,
          total_jobs: (techProfiles[0].total_jobs || 0) + 1
        });
      }
      
      return newRating;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['rating', requestId]);
      setRating(0);
      setRatingComment('');
    }
  });

  const cancelRequest = useMutation({
    mutationFn: async () => {
      await base44.entities.ServiceRequest.update(requestId, {
        status: 'cancelled'
      });

      // Log event
      await base44.entities.Event.create({
        type: 'JOB_CANCELED',
        request_id: requestId,
        customer_id: request.customer_id,
        technician_id: request.technician_id,
        payload: { cancelled_by: 'customer', reason: 'customer_request' }
      });

      // Notify technician if assigned
      if (request.technician_id) {
        await base44.entities.Notification.create({
          user_id: request.technician_id,
          type: 'job_cancelled',
          title: 'Job Cancelled',
          message: 'The customer has cancelled this service request.',
          related_id: requestId
        });

        // Update technician availability
        const techProfiles = await base44.entities.TechnicianProfile.filter({ user_id: request.technician_id });
        if (techProfiles[0]) {
          await base44.entities.TechnicianProfile.update(techProfiles[0].id, {
            availability_status: 'available'
          });
        }
      }

      // Handle refund if payment was made
      if (request.payment_status === 'paid') {
        await base44.entities.ServiceRequest.update(requestId, {
          payment_status: 'refunded'
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['service-request', requestId]);
      window.location.href = createPageUrl('CustomerDashboard');
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-6">
        <LoadingSpinner message="Loading your service request..." size="lg" />
        <p className="text-gray-600 mt-4 text-center max-w-md">
          We're getting your request details ready. This should only take a moment...
        </p>
      </div>
    );
  }

  if (!requestId) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
          <div className="max-w-6xl mx-auto flex items-center gap-4">
            <Button 
              variant="ghost" 
              className="text-white hover:bg-white/20"
              onClick={() => window.location.href = createPageUrl('CustomerDashboard')}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Service Request Not Found</h1>
            </div>
          </div>
        </div>
        <div className="max-w-6xl mx-auto p-6">
          <Card className="p-8 text-center">
            <div className="mb-4">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-100 flex items-center justify-center">
                <XCircle className="w-8 h-8 text-red-600" />
              </div>
              <h2 className="text-xl font-bold mb-2">Oops!</h2>
              <p className="text-gray-600 mb-4">No request ID provided</p>
            </div>
            <Button
              onClick={() => window.location.href = createPageUrl('CustomerDashboard')}
              style={{ backgroundColor: '#FF771D' }}
              className="text-white"
            >
              Go to Dashboard
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  if (isError || !request) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
          <div className="max-w-6xl mx-auto flex items-center gap-4">
            <Button 
              variant="ghost" 
              className="text-white hover:bg-white/20"
              onClick={() => window.location.href = createPageUrl('CustomerDashboard')}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Service Request Not Found</h1>
            </div>
          </div>
        </div>
        <div className="max-w-6xl mx-auto p-6">
          <ErrorState 
            message={error?.message || "Unable to load service request. It may have been deleted or doesn't exist."}
            onRetry={refetch}
          />
        </div>
      </div>
    );
  }

  const isCustomer = user?.user_type === 'customer';

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Critical Job Notifications */}
      <CriticalJobNotifications 
        serviceRequestId={requestId}
        userId={user?.id}
        currentStatus={request?.status}
      />
      
      {/* Live Status Updates */}
      <LiveStatusUpdates currentStatus={request?.status} previousStatus={previousStatus} />

      {/* ETA Display */}
      {isCustomer && request && (
        <div className="fixed top-20 right-4 z-50 w-80 md:w-96">
          <ETADisplay serviceRequest={request} />
        </div>
      )}
      
      {/* Header */}
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-6xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20"
            onClick={() => window.location.href = createPageUrl(isCustomer ? 'CustomerDashboard' : 'TechnicianDashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Service Request</h1>
            <p className="text-sm opacity-90">
              {format(new Date(request.created_date), 'MMMM d, yyyy h:mm a')}
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        {/* Cancellation Banner */}
        {isCustomer && ['pending_payment', 'pending_dispatch', 'dispatched', 'assigned'].includes(request.status) && (
          <Card className="mb-6 border-yellow-300 bg-yellow-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-700">Need to cancel this request?</p>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" className="border-red-300 text-red-600 hover:bg-red-50">
                      <XCircle className="w-4 h-4 mr-2" />
                      Cancel Request
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Cancel Service Request?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to cancel this service request? 
                        {request.payment_status === 'paid' && ' Your payment will be refunded.'}
                        {request.technician_id && ' The assigned technician will be notified.'}
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Keep Request</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => cancelRequest.mutate()}
                        className="bg-red-600 hover:bg-red-700"
                        disabled={cancelRequest.isLoading}
                      >
                        {cancelRequest.isLoading ? 'Cancelling...' : 'Yes, Cancel'}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Payment Status */}
        {isCustomer && request.payment_status && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Payment Status</p>
                  <div className="mt-1">
                    <PaymentStatusBadge status={request.payment_status} />
                  </div>
                </div>
                {request.payment_status === 'paid' && request.payment_amount && (
                  <div className="text-right">
                    <p className="text-2xl font-bold" style={{ color: '#3D692B' }}>
                      ${request.payment_amount.toFixed(2)}
                    </p>
                    <p className="text-xs text-gray-500">
                      {request.paid_at && format(new Date(request.paid_at), 'MMM d, yyyy')}
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Payment Banner */}
        {isCustomer && request.status === 'completed' && request.payment_status === 'pending' && (
          <Card className="mb-6 border-2" style={{ borderColor: '#FF771D' }}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold mb-1">Outstanding Payment</h3>
                  <p className="text-gray-600">Please complete payment for your service</p>
                </div>
                <Button
                  onClick={() => window.location.href = createPageUrl(`CustomerPayment?requestId=${request.id}`)}
                  className="text-white hover:opacity-90 text-lg px-6 py-6"
                  style={{ backgroundColor: '#3D692B' }}
                >
                  Pay ${(request.payment_amount || request.price || 0).toFixed(2)}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Payment Success Banner */}
        {isCustomer && request.payment_status === 'paid' && (
          <Card className="mb-6 border-2 border-green-500 bg-green-50">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-green-900">Payment Complete</h3>
                  <p className="text-green-700">Thank you! Your payment has been received.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Real-Time Tracking Section - Full Width for Active Jobs */}
        {isCustomer && request.technician_id && ['assigned', 'en_route', 'arrived', 'in_progress'].includes(request.status) && (
          <div className="mb-6">
            <React.Suspense fallback={<div className="h-[400px] bg-gray-100 animate-pulse rounded-lg" />}>
              <RealTimeTrackingMap request={request} />
            </React.Suspense>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          {/* Left Column - Details */}
          <div className="space-y-6">
            {/* Service Info */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-3">
                    <ServiceTypeIcon type={request.service_type} />
                    <span>
                      {request.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </span>
                  </CardTitle>
                  <StatusBadge status={request.status} />
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {request.description && (
                  <div>
                    <h4 className="font-semibold mb-1">Description</h4>
                    <p className="text-gray-600 text-sm">{request.description}</p>
                  </div>
                )}
                
                {request.location_address && (
                  <div>
                    <h4 className="font-semibold mb-1">Location</h4>
                    <p className="text-gray-600 text-sm">{request.location_address}</p>
                  </div>
                )}

                {request.vehicle_make && (
                  <div>
                    <h4 className="font-semibold mb-1">Vehicle</h4>
                    <p className="text-gray-600 text-sm">
                      {request.vehicle_year} {request.vehicle_make} {request.vehicle_model}
                      {request.vehicle_color && ` - ${request.vehicle_color}`}
                    </p>
                  </div>
                )}

                {request.estimated_arrival && request.status !== 'completed' && (
                  <div>
                    <h4 className="font-semibold mb-1">Estimated Arrival</h4>
                    <p className="text-gray-600 text-sm">
                      {format(new Date(request.estimated_arrival), 'h:mm a')}
                    </p>
                  </div>
                )}

                {request.price && (
                  <div>
                    <h4 className="font-semibold mb-1">Price</h4>
                    <p className="text-2xl font-bold" style={{ color: '#FF771D' }}>
                      ${request.price.toFixed(2)}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Static Map for Completed/Cancelled Jobs */}
            {(!request.technician_id || !['assigned', 'en_route', 'arrived', 'in_progress'].includes(request.status)) && (
              <Card>
                <CardHeader>
                  <CardTitle>Location</CardTitle>
                </CardHeader>
                <CardContent>
                  <React.Suspense fallback={<div className="h-[300px] bg-gray-100 animate-pulse rounded-lg" />}>
                    <ServiceMap
                      customerLocation={[request.location_lat, request.location_lng]}
                      height="300px"
                      zoom={14}
                    />
                  </React.Suspense>
                </CardContent>
              </Card>
            )}

            {/* Attachments */}
            {attachments.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Service Documentation</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-3">
                    {attachments.map((att) => {
                      const isSignature = att.description?.includes('Customer signature');
                      return (
                        <a
                          key={att.id}
                          href={att.file_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`border rounded-lg p-3 hover:shadow-md transition-shadow ${
                            isSignature ? 'col-span-2 border-green-300 bg-green-50' : ''
                          }`}
                        >
                          <div className="flex items-start gap-2 mb-2">
                            {isSignature ? (
                              <div className="text-green-600 font-semibold text-sm flex items-center gap-1">
                                ✍️ Customer Signature
                              </div>
                            ) : att.file_type.includes('photo') ? (
                              <Image className="w-5 h-5 text-blue-600" />
                            ) : (
                              <FileText className="w-5 h-5 text-gray-600" />
                            )}
                            {!isSignature && (
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-semibold truncate">{att.file_name}</p>
                                <p className="text-xs text-gray-500 capitalize">
                                  {att.file_type.replace(/_/g, ' ')}
                                </p>
                              </div>
                            )}
                            <Download className="w-4 h-4 text-gray-400 flex-shrink-0 ml-auto" />
                          </div>
                          {(att.file_type.includes('photo') || isSignature) && (
                            <img 
                              src={att.file_url} 
                              alt={att.file_name}
                              className={`w-full ${isSignature ? 'h-32' : 'h-24'} object-contain bg-white rounded border`}
                            />
                          )}
                        </a>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Rating Prompt (Customer only, after completion) */}
            {isCustomer && (request.status === 'completed' || request.status === 'awaiting_review') && !existingRating && (
              <React.Suspense fallback={<div className="h-32 bg-gray-100 animate-pulse rounded-lg" />}>
                <RatingPrompt 
                  serviceRequest={request}
                  onComplete={() => queryClient.invalidateQueries(['service-request', requestId])}
                />
              </React.Suspense>
            )}

            {existingRating && (
              <Card>
                <CardHeader>
                  <CardTitle>Your Rating</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-1 mb-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-5 h-5 ${star <= existingRating.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                      />
                    ))}
                  </div>
                  {existingRating.comment && (
                    <p className="text-gray-600 text-sm">{existingRating.comment}</p>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Invoice Section */}
            {isCustomer && request.status === 'completed' && request.payment_status === 'paid' && (
              <>
                <React.Suspense fallback={<div className="h-20 bg-gray-100 animate-pulse rounded-lg" />}>
                  <InvoiceViewer serviceRequestId={requestId} />
                </React.Suspense>
                <Card>
                  <CardContent className="pt-6">
                    <React.Suspense fallback={<div className="h-20 bg-gray-100 animate-pulse rounded-lg" />}>
                      <InvoiceGenerator 
                        serviceRequest={request}
                        onInvoiceCreated={() => queryClient.invalidateQueries({ queryKey: ['invoice', requestId] })}
                      />
                    </React.Suspense>
                  </CardContent>
                </Card>
              </>
            )}
          </div>

          {/* Right Column - Chat or Archived History */}
          <div className={request.status === 'completed' || request.status === 'cancelled' ? '' : 'h-[calc(100vh-200px)]'}>
            <React.Suspense fallback={<div className="h-full bg-gray-100 animate-pulse rounded-lg" />}>
              {request.status === 'completed' || request.status === 'cancelled' ? (
                <ArchivedChatHistory
                  serviceRequestId={requestId}
                  currentUserId={user?.id}
                  currentUserRole={isCustomer ? 'customer' : 'technician'}
                />
              ) : (
                <ChatInterface
                  serviceRequestId={requestId}
                  currentUserId={user?.id}
                  currentUserRole={isCustomer ? 'customer' : 'technician'}
                  otherUserId={isCustomer ? request.technician_id : request.customer_id}
                  otherUserName={isCustomer ? 'Technician' : 'Customer'}
                />
              )}
            </React.Suspense>
          </div>
        </div>
      </div>
    </div>
  );
}