import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Clock, Star, DollarSign, CheckCircle, AlertCircle, Filter } from 'lucide-react';
import { format, differenceInMinutes, parseISO, startOfMonth, endOfMonth, eachMonthOfInterval } from 'date-fns';

export default function AdminPerformanceDashboard() {
  const [user, setUser] = useState(null);
  const [selectedTechnician, setSelectedTechnician] = useState('all');
  const [selectedServiceType, setSelectedServiceType] = useState('all');
  const [startDate, setStartDate] = useState(format(new Date(new Date().setMonth(new Date().getMonth() - 6)), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState(format(new Date(), 'yyyy-MM-dd'));

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  // Fetch all technicians
  const { data: technicians = [] } = useQuery({
    queryKey: ['technicians'],
    queryFn: async () => {
      return await base44.entities.TechnicianProfile.list();
    }
  });

  // Fetch service requests with filters
  const { data: serviceRequests = [] } = useQuery({
    queryKey: ['service-requests', selectedTechnician, selectedServiceType, startDate, endDate],
    queryFn: async () => {
      let filters = {
        status: 'completed'
      };
      
      if (selectedTechnician !== 'all') {
        filters.technician_id = selectedTechnician;
      }
      
      if (selectedServiceType !== 'all') {
        filters.service_type = selectedServiceType;
      }

      const requests = await base44.entities.ServiceRequest.filter(filters, '-completed_at');
      
      // Filter by date range
      return requests.filter(req => {
        if (!req.completed_at) return false;
        const completedDate = new Date(req.completed_at);
        return completedDate >= new Date(startDate) && completedDate <= new Date(endDate);
      });
    },
    enabled: !!startDate && !!endDate
  });

  // Fetch ratings
  const { data: ratings = [] } = useQuery({
    queryKey: ['ratings', selectedTechnician, startDate, endDate],
    queryFn: async () => {
      let filters = {};
      
      if (selectedTechnician !== 'all') {
        filters.technician_id = selectedTechnician;
      }

      const allRatings = await base44.entities.Rating.filter(filters);
      
      // Filter by date range using service request completion dates
      return allRatings.filter(rating => {
        const matchingRequest = serviceRequests.find(req => req.id === rating.service_request_id);
        return matchingRequest !== undefined;
      });
    },
    enabled: serviceRequests.length > 0
  });

  // Calculate metrics
  const calculateMetrics = () => {
    if (serviceRequests.length === 0) {
      return {
        avgCompletionTime: 0,
        avgRating: 0,
        totalJobs: 0,
        etaAdherence: 0,
        totalEarnings: 0
      };
    }

    // Average completion time (in minutes)
    const completionTimes = serviceRequests
      .filter(req => req.created_date && req.completed_at)
      .map(req => differenceInMinutes(new Date(req.completed_at), new Date(req.created_date)));
    
    const avgCompletionTime = completionTimes.length > 0 
      ? completionTimes.reduce((sum, time) => sum + time, 0) / completionTimes.length 
      : 0;

    // Average rating
    const avgRating = ratings.length > 0
      ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length
      : 0;

    // Total jobs
    const totalJobs = serviceRequests.length;

    // ETA adherence (percentage of jobs where tech arrived within 10 min of ETA)
    const jobsWithETA = serviceRequests.filter(req => req.estimated_arrival);
    const onTimeJobs = jobsWithETA.filter(req => {
      if (!req.estimated_arrival) return false;
      // Assuming actual arrival is when status changed to 'in_progress'
      const estimatedTime = new Date(req.estimated_arrival);
      const actualTime = new Date(req.updated_date); // Approximation
      const diff = Math.abs(differenceInMinutes(actualTime, estimatedTime));
      return diff <= 10;
    });
    const etaAdherence = jobsWithETA.length > 0 
      ? (onTimeJobs.length / jobsWithETA.length) * 100 
      : 0;

    // Total earnings
    const totalEarnings = serviceRequests
      .filter(req => req.price)
      .reduce((sum, req) => sum + req.price, 0);

    return {
      avgCompletionTime: Math.round(avgCompletionTime),
      avgRating: avgRating.toFixed(1),
      totalJobs,
      etaAdherence: Math.round(etaAdherence),
      totalEarnings: totalEarnings.toFixed(2)
    };
  };

  // Calculate trends by month
  const calculateMonthlyTrends = () => {
    if (serviceRequests.length === 0) return [];

    const months = eachMonthOfInterval({
      start: new Date(startDate),
      end: new Date(endDate)
    });

    return months.map(month => {
      const monthStart = startOfMonth(month);
      const monthEnd = endOfMonth(month);
      
      const monthRequests = serviceRequests.filter(req => {
        const completedDate = new Date(req.completed_at);
        return completedDate >= monthStart && completedDate <= monthEnd;
      });

      const monthRatings = ratings.filter(rating => {
        const matchingRequest = monthRequests.find(req => req.id === rating.service_request_id);
        return matchingRequest !== undefined;
      });

      const avgRating = monthRatings.length > 0
        ? monthRatings.reduce((sum, r) => sum + r.rating, 0) / monthRatings.length
        : 0;

      const earnings = monthRequests
        .filter(req => req.price)
        .reduce((sum, req) => sum + req.price, 0);

      return {
        month: format(month, 'MMM yyyy'),
        jobs: monthRequests.length,
        avgRating: parseFloat(avgRating.toFixed(1)),
        earnings: parseFloat(earnings.toFixed(2))
      };
    });
  };

  // Calculate service type breakdown
  const calculateServiceTypeBreakdown = () => {
    const breakdown = {};
    
    serviceRequests.forEach(req => {
      if (!breakdown[req.service_type]) {
        breakdown[req.service_type] = {
          count: 0,
          earnings: 0
        };
      }
      breakdown[req.service_type].count++;
      breakdown[req.service_type].earnings += req.price || 0;
    });

    return Object.entries(breakdown).map(([type, data]) => ({
      type: type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      count: data.count,
      earnings: parseFloat(data.earnings.toFixed(2))
    }));
  };

  // Check if user is admin
  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8">
          <AlertCircle className="w-12 h-12 mx-auto mb-4" style={{ color: '#E52C2D' }} />
          <h2 className="text-xl font-bold text-center">Access Denied</h2>
          <p className="text-gray-600 text-center mt-2">
            This dashboard is only accessible to administrators.
          </p>
        </Card>
      </div>
    );
  }

  const metrics = calculateMetrics();
  const monthlyTrends = calculateMonthlyTrends();
  const serviceTypeBreakdown = calculateServiceTypeBreakdown();

  const serviceTypes = [
    { value: 'tire_change', label: 'Tire Change' },
    { value: 'battery_jump', label: 'Battery Jump' },
    { value: 'fuel_delivery', label: 'Fuel Delivery' },
    { value: 'lockout', label: 'Lockout' },
    { value: 'towing', label: 'Towing' },
    { value: 'other', label: 'Other' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Performance Analytics</h1>
          <p className="text-gray-600 mt-2">Monitor and analyze technician performance metrics</p>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" style={{ color: '#FF771D' }} />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Technician</label>
                <Select value={selectedTechnician} onValueChange={setSelectedTechnician}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Technicians</SelectItem>
                    {technicians.map(tech => (
                      <SelectItem key={tech.id} value={tech.user_id}>
                        Technician {tech.user_id.substring(0, 8)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Service Type</label>
                <Select value={selectedServiceType} onValueChange={setSelectedServiceType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Services</SelectItem>
                    {serviceTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Start Date</label>
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">End Date</label>
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg Completion Time</p>
                  <p className="text-2xl font-bold mt-1">{metrics.avgCompletionTime} min</p>
                </div>
                <Clock className="w-8 h-8" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg Rating</p>
                  <p className="text-2xl font-bold mt-1">{metrics.avgRating}</p>
                </div>
                <Star className="w-8 h-8 fill-yellow-400 text-yellow-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Jobs</p>
                  <p className="text-2xl font-bold mt-1">{metrics.totalJobs}</p>
                </div>
                <CheckCircle className="w-8 h-8" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">ETA Adherence</p>
                  <p className="text-2xl font-bold mt-1">{metrics.etaAdherence}%</p>
                </div>
                <TrendingUp className="w-8 h-8" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Earnings</p>
                  <p className="text-2xl font-bold mt-1">${metrics.totalEarnings}</p>
                </div>
                <DollarSign className="w-8 h-8" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Jobs and Ratings Trend */}
          <Card>
            <CardHeader>
              <CardTitle>Jobs & Ratings Trend</CardTitle>
            </CardHeader>
            <CardContent>
              {monthlyTrends.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={monthlyTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" domain={[0, 5]} />
                    <Tooltip />
                    <Legend />
                    <Line 
                      yAxisId="left"
                      type="monotone" 
                      dataKey="jobs" 
                      stroke="#FF771D" 
                      strokeWidth={2}
                      name="Jobs Completed"
                    />
                    <Line 
                      yAxisId="right"
                      type="monotone" 
                      dataKey="avgRating" 
                      stroke="#3D692B" 
                      strokeWidth={2}
                      name="Avg Rating"
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-gray-500">
                  No data available for selected filters
                </div>
              )}
            </CardContent>
          </Card>

          {/* Earnings Trend */}
          <Card>
            <CardHeader>
              <CardTitle>Earnings Trend</CardTitle>
            </CardHeader>
            <CardContent>
              {monthlyTrends.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={monthlyTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar 
                      dataKey="earnings" 
                      fill="#FF771D" 
                      name="Earnings ($)"
                    />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-gray-500">
                  No data available for selected filters
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Service Type Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>Service Type Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            {serviceTypeBreakdown.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={serviceTypeBreakdown}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="type" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    yAxisId="left"
                    dataKey="count" 
                    fill="#3D692B" 
                    name="Job Count"
                  />
                  <Bar 
                    yAxisId="right"
                    dataKey="earnings" 
                    fill="#FF771D" 
                    name="Earnings ($)"
                  />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-gray-500">
                No data available for selected filters
              </div>
            )}
          </CardContent>
        </Card>

        {/* Insights */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Performance Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {metrics.avgRating < 4.0 && (
                <div className="flex items-start gap-3 p-3 bg-red-50 rounded-lg border border-red-200">
                  <AlertCircle className="w-5 h-5 mt-0.5" style={{ color: '#E52C2D' }} />
                  <div>
                    <p className="font-semibold" style={{ color: '#E52C2D' }}>Low Average Rating</p>
                    <p className="text-sm text-gray-700">
                      Current rating ({metrics.avgRating}) is below 4.0. Consider providing additional training
                      on customer service and communication skills.
                    </p>
                  </div>
                </div>
              )}

              {metrics.etaAdherence < 70 && (
                <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                  <AlertCircle className="w-5 h-5 mt-0.5 text-yellow-600" />
                  <div>
                    <p className="font-semibold text-yellow-800">ETA Adherence Needs Improvement</p>
                    <p className="text-sm text-gray-700">
                      Only {metrics.etaAdherence}% of jobs are meeting ETA expectations. Review routing 
                      and time estimation processes.
                    </p>
                  </div>
                </div>
              )}

              {metrics.avgCompletionTime > 120 && (
                <div className="flex items-start gap-3 p-3 bg-orange-50 rounded-lg border border-orange-200">
                  <Clock className="w-5 h-5 mt-0.5 text-orange-600" />
                  <div>
                    <p className="font-semibold text-orange-800">High Average Completion Time</p>
                    <p className="text-sm text-gray-700">
                      Jobs are taking an average of {metrics.avgCompletionTime} minutes. Consider 
                      efficiency training or reviewing job complexity assignments.
                    </p>
                  </div>
                </div>
              )}

              {metrics.avgRating >= 4.5 && metrics.etaAdherence >= 80 && (
                <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                  <CheckCircle className="w-5 h-5 mt-0.5" style={{ color: '#3D692B' }} />
                  <div>
                    <p className="font-semibold" style={{ color: '#3D692B' }}>Excellent Performance</p>
                    <p className="text-sm text-gray-700">
                      Performance metrics are strong across the board. Keep up the great work!
                    </p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}