import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, MapPin, Users, AlertTriangle, Clock, Radio, LogOut, FileText } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { format } from 'date-fns';
import SecurityIncidentQueue from '../components/security/SecurityIncidentQueue';
import SecurityOfficerStatus from '../components/security/SecurityOfficerStatus';
import AdvancedSecurityMap from '../components/security/AdvancedSecurityMap';
import BroadcastMessaging from '../components/security/BroadcastMessaging';
import SecurityChatPanel from '../components/security/SecurityChatPanel';
import CriticalSOSAlert from '../components/security/CriticalSOSAlert';

export default function SecurityCommandCenter() {
  const [companyId, setCompanyId] = useState(null);
  const [officerId, setOfficerId] = useState(null);
  const [role, setRole] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const storedCompanyId = localStorage.getItem('security_company_id');
    const storedOfficerId = localStorage.getItem('security_officer_id');
    const storedRole = localStorage.getItem('security_role');

    if (!storedCompanyId || !storedOfficerId) {
      window.location.href = createPageUrl('SecurityLogin');
      return;
    }

    setCompanyId(storedCompanyId);
    setOfficerId(storedOfficerId);
    setRole(storedRole);
  }, []);

  const { data: incidents = [] } = useQuery({
    queryKey: ['security-incidents', companyId],
    queryFn: () => base44.entities.SOSIncident.filter({ company_id: companyId }, '-created_date', 100),
    enabled: !!companyId,
    refetchInterval: 3000
  });

  const { data: officers = [] } = useQuery({
    queryKey: ['security-officers', companyId],
    queryFn: () => base44.entities.SecurityOfficer.filter({ company_id: companyId }),
    enabled: !!companyId,
    refetchInterval: 5000
  });

  const { data: company } = useQuery({
    queryKey: ['security-company', companyId],
    queryFn: async () => {
      const companies = await base44.entities.SecurityCompany.list();
      return companies.find(c => c.id === companyId);
    },
    enabled: !!companyId
  });

  const activeIncidents = incidents.filter(i => !['completed', 'cancelled', 'fraudulent'].includes(i.status));
  const availableOfficers = officers.filter(o => o.status === 'available');
  const busyOfficers = officers.filter(o => o.status === 'busy');
  const criticalIncidents = activeIncidents.filter(i => i.severity === 'critical');

  const handleLogout = () => {
    localStorage.removeItem('security_company_id');
    localStorage.removeItem('security_officer_id');
    localStorage.removeItem('security_role');
    window.location.href = createPageUrl('SecurityLogin');
  };

  if (!companyId) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Critical SOS Alert */}
      <CriticalSOSAlert userId={officerId} userRole="security" />
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: '#FF771D' }}>
              <Shield className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Security Command Center</h1>
              <p className="text-sm text-gray-400">{company?.company_name}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              className="text-white border-gray-600 hover:bg-gray-700"
              onClick={() => window.location.href = createPageUrl('SecurityAnalytics')}
            >
              <FileText className="w-4 h-4 mr-2" />
              Reports
            </Button>
            <Button
              variant="outline"
              className="text-white border-gray-600 hover:bg-gray-700"
              onClick={handleLogout}
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Active SOS</p>
                  <p className="text-3xl font-bold text-white">{activeIncidents.length}</p>
                </div>
                <AlertTriangle className="w-10 h-10 opacity-20" style={{ color: '#E52C2D' }} />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Critical</p>
                  <p className="text-3xl font-bold" style={{ color: '#E52C2D' }}>{criticalIncidents.length}</p>
                </div>
                <Radio className="w-10 h-10 opacity-20" style={{ color: '#E52C2D' }} />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Available</p>
                  <p className="text-3xl font-bold" style={{ color: '#3D692B' }}>{availableOfficers.length}</p>
                </div>
                <Users className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">On Duty</p>
                  <p className="text-3xl font-bold text-white">{busyOfficers.length}</p>
                </div>
                <Shield className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Incident Queue */}
          <div className="lg:col-span-2 space-y-6">
            <SecurityIncidentQueue 
              incidents={activeIncidents}
              companyId={companyId}
            />
            
            {/* Broadcast Messaging */}
            <BroadcastMessaging 
              companyId={companyId}
              senderId={officerId}
            />
          </div>

          {/* Right: Officers Status & Chat */}
          <div className="space-y-6">
            <SecurityOfficerStatus officers={officers} />
            
            {/* Dispatcher Chat */}
            <SecurityChatPanel
              companyId={companyId}
              userId={officerId}
              userRole={role}
              chatType="officer_dispatcher"
            />
          </div>
        </div>

        {/* Advanced Live Map */}
        <div className="mt-6">
          <AdvancedSecurityMap
            incidents={activeIncidents}
            officers={officers}
            companyId={companyId}
            height="600px"
          />
        </div>
      </div>
    </div>
  );
}