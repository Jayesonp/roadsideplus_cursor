import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Clock, MapPin, Loader2, ArrowRight } from 'lucide-react';
import { createPageUrl } from '@/utils';
import StatusBadge from '../components/common/StatusBadge';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import { format } from 'date-fns';

export default function ServiceConfirmation() {
  const [requestId, setRequestId] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id') || sessionStorage.getItem('lastRequestId');
    
    console.log('CONFIRMATION PAGE LOADED, requestId:', id);
    console.log('CURRENT URL:', window.location.href);
    
    if (id) {
      setRequestId(id);
    }
    // NO REDIRECTS - only fetch data
  }, []);

  const { data: request, isLoading, error } = useQuery({
    queryKey: ['service-request-confirmation', requestId],
    queryFn: async () => {
      console.log('[CONFIRMATION] Fetching request data for ID:', requestId);
      const requests = await base44.entities.ServiceRequest.filter({ id: requestId });
      
      if (!requests || requests.length === 0) {
        throw new Error('Request not found');
      }
      
      console.log('[CONFIRMATION] Request data loaded:', requests[0]);
      return requests[0];
    },
    enabled: !!requestId,
    retry: 3,
    retryDelay: 1000,
    refetchInterval: 3000, // Poll every 3 seconds for updates
  });

  // Trigger dispatch if pending and not yet offered
  useEffect(() => {
    if (request && request.status === 'pending_dispatch' && !request.current_offered_technician_id) {
      console.log('Triggering initial dispatch for request:', request.id);
      base44.functions.invoke('dispatchServiceRequest', {
        requestId: request.id
      }).then(res => {
        console.log('Dispatch result:', res.data);
      }).catch(err => {
        console.error('Dispatch trigger failed:', err);
      });
    }
  }, [request?.id, request?.status, request?.current_offered_technician_id]);

  if (!requestId) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <p className="text-gray-600 mb-4">No request found.</p>
            <Button onClick={() => navigate(createPageUrl('ServiceOptions'))}>
              Submit a New Request
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading || !request) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4" style={{ color: '#FF771D' }} />
          <p className="text-gray-600">Loading your request details...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <p className="text-red-600 mb-4">Failed to load request details</p>
            <Button onClick={() => navigate(createPageUrl('CustomerDashboard'))}>
              Go to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <div className="max-w-2xl mx-auto p-6 pt-12">
        {/* Success Animation */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-500 rounded-full mb-4 animate-bounce">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Request Submitted Successfully!</h1>
          <p className="text-gray-600">We're finding the best technician for you</p>
        </div>

        {/* Request Details Card */}
        <Card className="mb-6 border-2 border-green-300">
          <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50">
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <ServiceTypeIcon type={request.service_type} />
                {request.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </span>
              <StatusBadge status={request.status} />
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            {/* Request Number */}
            <div className="bg-gray-50 rounded-lg p-4 border-2 border-dashed border-gray-300">
              <p className="text-sm text-gray-600 mb-1">Your Request Number</p>
              <p className="text-2xl font-bold" style={{ color: '#FF771D' }}>
                #{request.id.slice(0, 8).toUpperCase()}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                Created {format(new Date(request.created_date), 'MMM d, yyyy h:mm a')}
              </p>
            </div>

            {/* Location */}
            {request.location_address && (
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 mt-1 flex-shrink-0" style={{ color: '#FF771D' }} />
                <div>
                  <p className="font-semibold text-sm text-gray-600">Service Location</p>
                  <p className="text-gray-900">{request.location_address}</p>
                </div>
              </div>
            )}

            {/* Estimated Arrival */}
            {request.estimated_arrival && (
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 mt-1 flex-shrink-0" style={{ color: '#FF771D' }} />
                <div>
                  <p className="font-semibold text-sm text-gray-600">Estimated Arrival</p>
                  <p className="text-gray-900">
                    {format(new Date(request.estimated_arrival), 'h:mm a')}
                  </p>
                </div>
              </div>
            )}

            {/* Price */}
            {request.price && (
              <div className="bg-orange-50 rounded-lg p-4 border border-orange-200">
                <p className="text-sm text-gray-600 mb-1">Service Price</p>
                <p className="text-3xl font-bold" style={{ color: '#FF771D' }}>
                  ${request.price.toFixed(2)}
                </p>
              </div>
            )}

            {/* Vehicle Info */}
            {request.vehicle_make && (
              <div className="text-sm text-gray-600">
                <span className="font-semibold">Vehicle: </span>
                {request.vehicle_year} {request.vehicle_make} {request.vehicle_model}
                {request.vehicle_color && ` - ${request.vehicle_color}`}
              </div>
            )}
          </CardContent>
        </Card>

        {/* What's Next Card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">What Happens Next?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">
                1
              </div>
              <div>
                <p className="font-semibold">Finding a Technician</p>
                <p className="text-sm text-gray-600">We're matching you with nearby available technicians</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">
                2
              </div>
              <div>
                <p className="font-semibold">Technician Assigned</p>
                <p className="text-sm text-gray-600">You'll be notified when a technician accepts your request</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">
                3
              </div>
              <div>
                <p className="font-semibold">Track in Real-Time</p>
                <p className="text-sm text-gray-600">Watch your technician's location as they travel to you</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button
            onClick={() => navigate(createPageUrl(`ServiceDetails?id=${request.id}`))}
            className="w-full text-white py-6 text-lg font-semibold hover:opacity-90"
            style={{ backgroundColor: '#FF771D' }}
          >
            Track Request Status
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          
          <Button
            variant="outline"
            onClick={() => navigate(createPageUrl('CustomerDashboard'))}
            className="w-full py-6 text-lg"
          >
            Back to Dashboard
          </Button>
        </div>

        {/* Help Text */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Need help? Contact support or check your notifications for updates
          </p>
        </div>
      </div>
    </div>
  );
}