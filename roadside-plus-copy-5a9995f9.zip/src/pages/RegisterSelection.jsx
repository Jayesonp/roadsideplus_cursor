import React from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { createPageUrl } from '@/utils';
import { Users, Wrench, Briefcase, Shield, ArrowRight } from 'lucide-react';
import BrandLogo from '../components/branding/BrandLogo';

export default function RegisterSelection() {
  const roles = [
    {
      id: 'customer',
      title: 'Customer',
      description: 'Get emergency roadside assistance when you need it',
      icon: Users,
      color: 'blue',
      page: 'Register?role=customer'
    },
    {
      id: 'technician',
      title: 'Technician',
      description: 'Join our team and provide roadside assistance',
      icon: Wrench,
      color: 'orange',
      page: 'Register?role=technician'
    },
    {
      id: 'partner',
      title: 'Partner',
      description: 'Partner with us to grow your business',
      icon: Briefcase,
      color: 'purple',
      page: 'Register?role=partner'
    },
    {
      id: 'security',
      title: 'Security Company',
      description: 'Provide emergency security services',
      icon: Shield,
      color: 'green',
      page: 'Register?role=security_company'
    }
  ];

  const colorClasses = {
    blue: {
      bg: 'bg-blue-50 hover:bg-blue-100',
      border: 'border-blue-200 hover:border-blue-300',
      icon: 'bg-blue-100 text-blue-600',
      text: 'text-blue-600'
    },
    orange: {
      bg: 'bg-orange-50 hover:bg-orange-100',
      border: 'border-orange-200 hover:border-orange-300',
      icon: 'bg-orange-100 text-orange-600',
      text: 'text-orange-600'
    },
    purple: {
      bg: 'bg-purple-50 hover:bg-purple-100',
      border: 'border-purple-200 hover:border-purple-300',
      icon: 'bg-purple-100 text-purple-600',
      text: 'text-purple-600'
    },
    green: {
      bg: 'bg-green-50 hover:bg-green-100',
      border: 'border-green-200 hover:border-green-300',
      icon: 'bg-green-100 text-green-600',
      text: 'text-green-600'
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative" 
      style={{ 
        background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)',
        paddingTop: 'calc(var(--safe-area-top) + 1rem)',
        paddingBottom: 'calc(var(--safe-area-bottom) + 1rem)',
        paddingLeft: '1rem',
        paddingRight: '1rem'
      }}>
      <div className="w-full max-w-4xl flex-1 flex flex-col justify-center">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <BrandLogo variant="full" size="xl" className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Choose Your Account Type</h1>
          <p className="text-white/90">Select the option that best describes you</p>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {roles.map((role) => {
            const Icon = role.icon;
            const colors = colorClasses[role.color];
            
            return (
              <a
                key={role.id}
                href={createPageUrl(role.page)}
                className="block"
              >
                <Card className={`cursor-pointer transition-all hover:shadow-xl ${colors.bg} border-2 ${colors.border}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className={`p-3 rounded-lg ${colors.icon}`}>
                        <Icon className="w-8 h-8" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-gray-900 mb-1">{role.title}</h3>
                        <p className="text-sm text-gray-600 mb-4">{role.description}</p>
                        <div className={`flex items-center gap-2 text-sm font-semibold ${colors.text}`}>
                          <span>Sign up as {role.title}</span>
                          <ArrowRight className="w-4 h-4" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </a>
            );
          })}
        </div>

        <div className="text-center mt-6" style={{ paddingBottom: 'calc(var(--safe-area-bottom) + 1rem)' }}>
          <p className="text-white/90 text-sm">
            Already have an account?{' '}
            <button
              onClick={() => base44.auth.redirectToLogin(createPageUrl('CustomerDashboard'))}
              className="font-semibold underline hover:opacity-80 p-2"
            >
              Sign in here
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}