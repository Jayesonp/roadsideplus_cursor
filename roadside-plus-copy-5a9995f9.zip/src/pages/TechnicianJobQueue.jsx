import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, MapPin, Clock, Eye } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { formatDistanceToNow } from 'date-fns';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import JobDetailsModal from '../components/technician/JobDetailsModal';

// Haversine distance calculation
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

export default function TechnicianJobQueue() {
  const [user, setUser] = useState(null);
  const [techLocation, setTechLocation] = useState(null);
  const [selectedJob, setSelectedJob] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);

    // Get technician location
    const locations = await base44.entities.TechnicianLocation.filter({
      technician_id: currentUser.id
    });
    if (locations.length > 0) {
      const latest = locations.sort((a, b) => 
        new Date(b.created_date) - new Date(a.created_date)
      )[0];
      setTechLocation({ lat: latest.latitude, lng: latest.longitude });
    }
  };

  // Fetch pending jobs
  const { data: pendingJobs = [] } = useQuery({
    queryKey: ['pending-jobs'],
    queryFn: async () => {
      const jobs = await base44.entities.ServiceRequest.filter({
        status: 'pending_dispatch'
      }, 'created_date');
      
      // Calculate distances
      return jobs.map(job => ({
        ...job,
        distance: techLocation 
          ? calculateDistance(
              techLocation.lat, 
              techLocation.lng, 
              job.location_lat, 
              job.location_lng
            )
          : null
      }));
    },
    enabled: !!user && !!techLocation,
    refetchInterval: 5000 // Auto-refresh every 5 seconds
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20"
            onClick={() => window.location.href = createPageUrl('TechnicianDashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Available Jobs</h1>
            <p className="text-sm opacity-90">{pendingJobs.length} jobs waiting</p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6">
        {pendingJobs.length === 0 ? (
          <Card className="p-12 text-center">
            <div className="text-gray-400 mb-4">
              <MapPin className="w-16 h-16 mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              No Jobs Available
            </h3>
            <p className="text-gray-500">
              Check back soon for new service requests
            </p>
          </Card>
        ) : (
          <div className="space-y-4">
            {pendingJobs.map(job => (
              <Card key={job.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <ServiceTypeIcon type={job.service_type} className="w-6 h-6" />
                      <div>
                        <h3 className="font-semibold text-lg">
                          {job.service_type.replace(/_/g, ' ').toUpperCase()}
                        </h3>
                        <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                          <Clock className="w-4 h-4" />
                          {formatDistanceToNow(new Date(job.created_date), { addSuffix: true })}
                        </div>
                      </div>
                    </div>
                    
                    {job.distance && (
                      <Badge 
                        className="text-white"
                        style={{ backgroundColor: '#3D692B' }}
                      >
                        {job.distance.toFixed(1)} km away
                      </Badge>
                    )}
                  </div>

                  {job.location_address && (
                    <div className="flex items-start gap-2 text-sm text-gray-600 mb-3">
                      <MapPin className="w-4 h-4 mt-0.5" />
                      <span className="line-clamp-2">{job.location_address}</span>
                    </div>
                  )}

                  {job.description && (
                    <p className="text-sm text-gray-700 mb-4 line-clamp-2">
                      {job.description}
                    </p>
                  )}

                  {job.price && (
                    <div className="text-xl font-bold mb-3" style={{ color: '#3D692B' }}>
                      ${job.price.toFixed(2)}
                    </div>
                  )}

                  <Button
                    onClick={() => setSelectedJob(job)}
                    className="w-full flex items-center justify-center gap-2"
                    style={{ backgroundColor: '#FF771D' }}
                  >
                    <Eye className="w-4 h-4" />
                    View Details
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Job Details Modal */}
      {selectedJob && (
        <JobDetailsModal
          job={selectedJob}
          technicianId={user?.id}
          onClose={() => setSelectedJob(null)}
          onAccepted={() => {
            setSelectedJob(null);
            window.location.href = createPageUrl('TechnicianDashboard');
          }}
        />
      )}
    </div>
  );
}