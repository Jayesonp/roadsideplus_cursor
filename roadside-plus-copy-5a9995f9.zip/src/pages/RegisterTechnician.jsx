import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { createPageUrl } from '@/utils';
import { User, Mail, Phone, Lock, Loader2, Wrench } from 'lucide-react';
import BrandLogo from '../components/branding/BrandLogo';

export default function RegisterTechnician() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  });
  const [invitationToken, setInvitationToken] = useState(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token');
    const emailParam = params.get('email');
    
    if (emailParam) {
        setFormData(prev => ({ ...prev, email: emailParam }));
    }

    if (token) {
        setInvitationToken(token);
        // Verify token
        base44.functions.invoke('verifyInvitation', { token })
            .then(({ data }) => {
                if (data.valid) {
                    setFormData(prev => ({ ...prev, email: data.email }));
                } else {
                    alert(`Invalid or expired invitation: ${data.error}`);
                }
            })
            .catch(err => console.error("Token verification failed", err));
    }
  }, []);

  // Role options for selector
  const roles = [
    { id: 'customer', label: 'Customer', page: 'RegisterCustomer' },
    { id: 'technician', label: 'Technician', page: 'RegisterTechnician' },
    { id: 'partner', label: 'Partner', page: 'RegisterPartner' },
    { id: 'security_company', label: 'Security Company', page: 'RegisterSecurityCompany' }
  ];

  const handleRoleChange = (e) => {
    const selectedRole = roles.find(r => r.id === e.target.value);
    if (selectedRole && selectedRole.page !== 'RegisterTechnician') {
      navigate(createPageUrl(selectedRole.page));
    }
  };
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);

    try {
      // Register the user
      await base44.auth.register({
        email: formData.email,
        password: formData.password,
        full_name: formData.fullName,
        phone: formData.phone,
        role: 'technician'
      });

      // Accept invitation if token exists
      if (invitationToken) {
        try {
            await base44.functions.invoke('acceptInvitation', { token: invitationToken });
        } catch (err) {
            console.error("Failed to accept invitation", err);
        }
      }

      // Redirect to OTP verification page
      navigate(createPageUrl('OTPVerification') + 
        `?email=${encodeURIComponent(formData.email)}&redirect_to=${encodeURIComponent(createPageUrl('TechnicianDashboard'))}`);
    } catch (err) {
      console.error('Registration error:', err);
      setError(err.message || 'Registration failed. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" 
      style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
      <Card className="w-full max-w-md">
        <CardHeader className="text-center pb-4">
          <div className="flex justify-center mb-4">
            <BrandLogo variant="icon" size="xl" />
          </div>
          <div className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-orange-100 text-orange-800 rounded-full mb-4">
            <Wrench className="w-5 h-5" />
            <span className="font-semibold">Technician Sign Up</span>
          </div>
          <CardTitle className="text-2xl font-bold">Create Technician Account</CardTitle>
          <p className="text-sm text-gray-500">Join our team and provide roadside assistance</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleRegister} className="space-y-4">
            {/* Role Selection */}
            <div>
              <Label htmlFor="role">I am signing up as a:</Label>
              <div className="relative mt-1">
                <select
                  id="role"
                  value="technician"
                  onChange={handleRoleChange}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {roles.map(role => (
                    <option key={role.id} value={role.id}>
                      {role.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <Label htmlFor="fullName">Full Name</Label>
              <div className="relative mt-1">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="fullName"
                  name="fullName"
                  type="text"
                  placeholder="John Doe"
                  value={formData.fullName}
                  onChange={handleChange}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="email">Email</Label>
              <div className="relative mt-1">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={handleChange}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <div className="relative mt-1">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  value={formData.phone}
                  onChange={handleChange}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="password">Password</Label>
              <div className="relative mt-1">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={handleChange}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <div className="relative mt-1">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
                {error}
              </div>
            )}

            <Button
              type="submit"
              className="w-full text-white hover:opacity-90"
              style={{ backgroundColor: '#FF771D' }}
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating account...
                </>
              ) : (
                'Create Technician Account'
              )}
            </Button>

            <div className="text-center text-sm">
              <span className="text-gray-600">Already have an account? </span>
              <button
                type="button"
                onClick={() => base44.auth.redirectToLogin()}
                className="font-semibold hover:underline"
                style={{ color: '#FF771D' }}
              >
                Sign in
              </button>
            </div>

            <div className="text-center text-sm pt-2 border-t">
              <span className="text-gray-600">Need a different account type? </span>
              <a
                href={createPageUrl('RegisterSelection')}
                className="font-semibold hover:underline"
                style={{ color: '#FF771D' }}
              >
                Choose role
              </a>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}