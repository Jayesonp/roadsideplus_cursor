import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { useSmartAdManager } from '../components/ads/SmartAdManager';
import DashboardCardAd from '../components/ads/DashboardCardAd';
import ExpandableBanner from '../components/ads/ExpandableBanner';
import FullscreenIdleAd from '../components/ads/FullscreenIdleAd';
import RealTimeTechniciansMap from '../components/map/RealTimeTechniciansMap';
import ETADisplay from '../components/service/ETADisplay';
import CriticalJobNotifications from '../components/notifications/CriticalJobNotifications';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, MapPin, MessageSquare, Star, User, LogOut, History, Map as MapIcon, XCircle } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { createPageUrl } from '@/utils';
import StatusBadge from '../components/common/StatusBadge';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import AvailableTechniciansMap from '../components/customer/AvailableTechniciansMap';
import TrackJobCard from '../components/customer/TrackJobCard';
import SupportChatbot from '../components/customer/SupportChatbot';
import ProactiveAssistant from '../components/customer/ProactiveAssistant';
import NotificationBell from '../components/notifications/NotificationBell';
import ServiceHistory from '../components/customer/ServiceHistory';
import CustomerSupportChat from '../components/customer/CustomerSupportChat';
import VehicleManager from '../components/customer/VehicleManager';
import JobHistoryCard from '../components/customer/JobHistoryCard';
import PreferredTechniciansList from '../components/customer/PreferredTechniciansList';
import ReferralProgram from '../components/customer/ReferralProgram';
import { OfflineStorage } from '../components/pwa/OfflineStorage';
import { format } from 'date-fns';
import { useNetworkStatus } from '../components/offline/NetworkMonitor';
import { cacheServiceRequests } from '../components/offline/cacheServiceRequests';
import BrandLogo from '../components/branding/BrandLogo';
import OnboardingWizard from '../components/customer/OnboardingWizard';
import GuidedTour from '../components/customer/GuidedTour';
import CustomerOnboardingFlow from '../components/onboarding/CustomerOnboardingFlow';
import CustomerRatingModal from '../components/customer/CustomerRatingModal';

export default function CustomerDashboard() {
  const [user, setUser] = useState(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showTour, setShowTour] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [submittingRating, setSubmittingRating] = useState(false);
  const { isOnline } = useNetworkStatus();
  const queryClient = useQueryClient();
  
  // Always call hooks at top level - pass null if user not loaded yet
  const { adsEnabled, ads, recordImpression, recordClick, isIdle } = useSmartAdManager('customer_dashboard', user?.id || null, 'customer');

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      setAuthLoading(false);
      
      // Check if user needs onboarding
      if (!currentUser.onboarding_completed) {
        setShowOnboarding(true);
      } else {
        // Check if tour should be shown
        const tourCompleted = localStorage.getItem('tour_completed');
        if (!tourCompleted) {
          setTimeout(() => setShowTour(true), 1000);
        }
      }
    } catch (error) {
      console.error('Auth error:', error);
      // Don't redirect immediately on error to prevent loops due to temporary failures
      setAuthLoading(false);
    }
  };

  const { data: requests = [], isLoading, isError } = useQuery({
    queryKey: ['customer-requests', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      if (!isOnline) {
        const cached = await cacheServiceRequests.getMyCustomerRequests(user.id);
        return cached || [];
      }
      
      const freshRequests = await base44.entities.ServiceRequest.filter(
        { customer_id: user.id },
        '-created_date',
        10
      );
      
      await cacheServiceRequests.saveMultipleRequests(freshRequests);
      
      return freshRequests;
    },
    enabled: !!user,
    refetchInterval: 120000,
    retry: 1,
    retryDelay: 3000,
    staleTime: 115000,
    cacheTime: 600000
  });

  const activeRequest = requests.find(r => ['pending_payment', 'pending_dispatch', 'dispatched', 'assigned', 'en_route', 'in_progress', 'awaiting_review'].includes(r.status));
  const isSearchingAfterCancel = activeRequest?.status === 'pending_dispatch' && activeRequest?.technician_id === null;
  const needsCustomerRating = activeRequest?.status === 'awaiting_review';

  const { data: ratings = [] } = useQuery({
    queryKey: ['customer-ratings', user?.id],
    queryFn: async () => {
      if (!user) return [];
      return await base44.entities.Rating.filter(
        { customer_id: user.id },
        '-created_date',
        20
      );
    },
    enabled: false,
    staleTime: 300000
  });

  const { data: technicianData } = useQuery({
    queryKey: ['technician-data', activeRequest?.technician_id],
    queryFn: async () => {
      if (!activeRequest?.technician_id) return null;
      const users = await base44.entities.User.filter({ id: activeRequest.technician_id });
      return users[0];
    },
    enabled: !!activeRequest?.technician_id && needsCustomerRating,
    staleTime: 300000
  });

  useEffect(() => {
    if (needsCustomerRating && !showRatingModal) {
      setShowRatingModal(true);
    }
  }, [needsCustomerRating]);

  const { data: allAttachments = [] } = useQuery({
    queryKey: ['all-attachments'],
    queryFn: async () => {
      if (!requests.length) return [];
      const recentRequests = requests.slice(0, 5);
      const serviceIds = recentRequests.map(r => r.id);
      const attachments = await Promise.all(
        serviceIds.map(id => base44.entities.ServiceAttachment.filter({ service_request_id: id }))
      );
      return attachments.flat();
    },
    enabled: false,
    staleTime: 300000
  });
  const completedRequests = requests.filter(r => r.status === 'completed');

  const getJobAttachments = (jobId) => {
    return allAttachments.filter(att => att.service_request_id === jobId);
  };

  const getJobRating = (jobId) => {
    return ratings.find(r => r.service_request_id === jobId);
  };

  useEffect(() => {
    if (requests.length > 0 && user) {
      OfflineStorage.saveCache('last_jobs', requests);
      OfflineStorage.saveCache('user_data', user);
    }
  }, [requests, user]);

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  const cancelRequest = useMutation({
    mutationFn: async (request) => {
      await base44.entities.ServiceRequest.update(request.id, {
        status: 'cancelled'
      });

      await base44.entities.Event.create({
        type: 'JOB_CANCELED',
        request_id: request.id,
        customer_id: request.customer_id,
        technician_id: request.technician_id,
        payload: { cancelled_by: 'customer' }
      });

      if (request.technician_id) {
        await base44.entities.Notification.create({
          user_id: request.technician_id,
          type: 'job_completed',
          title: 'Job Cancelled',
          message: 'The customer has cancelled this service request.',
          related_id: request.id
        });

        const techProfiles = await base44.entities.TechnicianProfile.filter({ user_id: request.technician_id });
        if (techProfiles[0]) {
          await base44.entities.TechnicianProfile.update(techProfiles[0].id, {
            availability_status: 'available'
          });
        }
      }

      if (request.payment_status === 'paid') {
        await base44.entities.ServiceRequest.update(request.id, {
          payment_status: 'refunded'
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['customer-requests']);
    }
  });

  const handleRatingSubmit = async ({ rating, comment, tipAmount }) => {
    setSubmittingRating(true);
    try {
      // Create rating for technician
      await base44.entities.Rating.create({
        service_request_id: activeRequest.id,
        technician_id: activeRequest.technician_id,
        customer_id: user.id,
        rating,
        comment
      });

      // Final job closure - add tip and mark fully completed
      const currentPayment = activeRequest.payment_amount || 0;
      await base44.entities.ServiceRequest.update(activeRequest.id, {
        payment_amount: currentPayment + (tipAmount || 0),
        status: 'completed'
      });

      // Log completion event with customer rating and tip
      await base44.entities.Event.create({
        type: 'RATING_SUBMITTED',
        request_id: activeRequest.id,
        customer_id: user.id,
        technician_id: activeRequest.technician_id,
        payload: {
          rating_by: 'customer',
          rating: rating,
          has_comment: !!comment,
          tip_amount: tipAmount || 0
        }
      });

      // Final job completed event
      await base44.entities.Event.create({
        type: 'JOB_COMPLETED',
        request_id: activeRequest.id,
        customer_id: user.id,
        technician_id: activeRequest.technician_id,
        payload: {
          both_ratings_complete: true,
          total_payment: currentPayment + (tipAmount || 0)
        }
      });

      // Notify technician of rating and tip
      await base44.entities.Notification.create({
        user_id: activeRequest.technician_id,
        type: 'job_completed',
        title: '✅ Customer Rated Service',
        message: `You received a ${rating}-star rating${tipAmount > 0 ? ` and a $${tipAmount.toFixed(2)} tip` : ''}!`,
        related_id: activeRequest.id
      });

      // Refresh and close - customer now unlocked
      queryClient.invalidateQueries(['customer-requests']);
      setShowRatingModal(false);
      window.location.reload();
    } catch (error) {
      console.error('Rating submission error:', error);
      alert('Failed to submit rating. Please try again.');
      setSubmittingRating(false);
    }
  };

  if (authLoading || !user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-orange-200 border-t-orange-600 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="text-white p-6 shadow-lg" 
             style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
          <div className="max-w-6xl mx-auto">
            <div className="h-20 bg-white/10 rounded animate-pulse" />
          </div>
        </div>
        <div className="max-w-6xl mx-auto p-6">
          <div className="space-y-4">
            <div className="h-48 bg-gray-200 rounded-lg animate-pulse" />
            <div className="h-32 bg-gray-200 rounded-lg animate-pulse" />
            <div className="h-32 bg-gray-200 rounded-lg animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center p-6">
          <p className="text-red-600 mb-4">Failed to load your data</p>
          <Button onClick={() => window.location.reload()}>
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50 overflow-hidden">
      {/* Top Safe Area Spacer - Removed as Layout handles it */}

      {/* Onboarding Wizard */}
      {showOnboarding && (
        <OnboardingWizard
          user={user}
          onComplete={() => {
            setShowOnboarding(false);
            setShowTour(true);
            loadUser();
          }}
        />
      )}

      {/* Guided Tour */}
      {showTour && !showOnboarding && (
        <GuidedTour onComplete={() => setShowTour(false)} />
      )}

      {/* Header */}
      <div className="relative text-white p-6 shadow-lg flex-shrink-0" 
           style={{ 
             background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)',
           }}>
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <BrandLogo variant="icon" size="lg" />
            <div>
              <h1 className="text-3xl font-bold">Welcome</h1>
              <p className="opacity-90">{user?.full_name || 'Customer'}</p>
            </div>
          </div>
          <div className="flex gap-3">
            <NotificationBell userId={user?.id} />
            <Button 
              variant="outline" 
              className="bg-white/10 border-white/30 text-white hover:bg-white/20"
              onClick={() => window.location.href = createPageUrl('Profile')}
            >
              <User className="w-4 h-4 mr-2" />
              Profile
            </Button>
            <Button 
              variant="outline" 
              className="bg-white/10 border-white/30 text-white hover:bg-white/20"
              onClick={handleLogout}
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* App Container (Scrollable) */}
      <div className="flex-1 overflow-y-auto scrollbar-hide">
      <div className="max-w-6xl mx-auto p-6">


        {/* Critical Job Notifications */}
        {activeRequest && (
          <CriticalJobNotifications 
            serviceRequestId={activeRequest.id}
            userId={user?.id}
            currentStatus={activeRequest.status}
          />
        )}



        {/* ETA Display for Active Jobs */}
        {activeRequest && ['assigned', 'en_route', 'arrived'].includes(activeRequest.status) && (
          <ETADisplay serviceRequest={activeRequest} className="mb-6" />
        )}

        {/* Track Active Job */}
        {activeRequest && activeRequest.status !== 'pending' && (
          <div className="mb-6 track-job-card">
            <TrackJobCard request={activeRequest} />
          </div>
        )}

        {/* Searching for Technician Alert */}
        {isSearchingAfterCancel && (
          <Card className="mb-6 border-2 animate-pulse" style={{ borderColor: '#FF771D' }}>
            <CardContent className="p-6 text-center">
              <div className="flex flex-col items-center gap-4">
                <div className="relative">
                  <div className="w-16 h-16 rounded-full border-4 border-orange-200 border-t-orange-600 animate-spin" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Searching for Technician...</h3>
                  <p className="text-gray-600 mb-1">Finding the nearest available technician</p>
                  <p className="text-sm text-gray-500">This may take a moment</p>
                </div>
                <StatusBadge status={activeRequest.status} />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Pending Request Alert */}
        {activeRequest && !isSearchingAfterCancel && (
          <Card className="mb-6 border-2" style={{ borderColor: '#FF771D' }}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <ServiceTypeIcon type={activeRequest.service_type} />
                    <h3 className="text-xl font-bold">Active Request</h3>
                  </div>
                  <StatusBadge status={activeRequest.status} />
                </div>
                <div className="flex gap-2">
                  <Button 
                    style={{ backgroundColor: '#FF771D' }}
                    className="text-white hover:opacity-90"
                    onClick={() => window.location.href = createPageUrl(`ServiceDetails?id=${activeRequest.id}`)}
                  >
                    View Details
                  </Button>
                  {['pending_payment', 'pending_dispatch', 'dispatched', 'assigned'].includes(activeRequest.status) && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" className="border-red-300 text-red-600 hover:bg-red-50">
                          <XCircle className="w-4 h-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Cancel Request?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to cancel this service request?
                            {activeRequest.payment_status === 'paid' && ' Your payment will be refunded.'}
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Keep Request</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => cancelRequest.mutate(activeRequest)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Yes, Cancel
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2 text-gray-600">
                  <MapPin className="w-4 h-4" />
                  {activeRequest.location_address || 'Location set'}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Request Service Button - Only show if no active job */}
        {!activeRequest && (
          <Card className="mb-6 border-2 hover:shadow-lg transition-shadow cursor-pointer request-service-btn" 
                style={{ 
                  borderColor: '#FF771D',
                  marginBottom: 'calc(env(safe-area-inset-bottom) + 1.5rem)'
                }}
            onClick={() => window.location.href = createPageUrl('RequestService')}
          >
            <CardContent className="p-6 sm:p-8 text-center">
              <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ backgroundColor: '#FF771D' }}>
                <Plus className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl font-bold mb-2">Need Roadside Assistance?</h3>
              <p className="text-sm sm:text-base text-gray-600 mb-4">Get help from nearby technicians</p>
              <Button 
                size="lg"
                style={{ backgroundColor: '#FF771D' }}
                className="text-white hover:opacity-90 px-6 sm:px-8 w-full sm:w-auto"
              >
                Request Service Now
              </Button>
            </CardContent>
          </Card>
        )}
        
        {/* Job Lock Notice */}
        {activeRequest && (
          <Card className="mb-6 border-2 border-gray-300 bg-gray-50">
            <CardContent className="p-6 text-center">
              <h3 className="text-lg font-semibold mb-2 text-gray-700">
                {isSearchingAfterCancel ? 'Finding Your Technician' : 'Service In Progress'}
              </h3>
              <p className="text-sm text-gray-600 mb-3">
                {isSearchingAfterCancel 
                  ? 'Please wait while we find the nearest available technician for you.'
                  : 'Complete your current service and rate your technician to request a new service.'}
              </p>
            </CardContent>
          </Card>
        )}

        {/* Tabs Section */}
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full max-w-3xl mx-auto grid-cols-3 md:grid-cols-6 mb-6 gap-1">
            <TabsTrigger value="overview" className="text-xs md:text-sm">Overview</TabsTrigger>
            <TabsTrigger value="vehicles" className="text-xs md:text-sm">Vehicles</TabsTrigger>
            <TabsTrigger value="preferred" className="text-xs md:text-sm">Preferred</TabsTrigger>
            <TabsTrigger value="referrals" className="text-xs md:text-sm">Referrals</TabsTrigger>
            <TabsTrigger value="history" className="history-tab text-xs md:text-sm">
              <History className="w-4 h-4 mr-1 md:mr-2" />
              History
            </TabsTrigger>
            <TabsTrigger value="map" className="text-xs md:text-sm">
              <MapIcon className="w-4 h-4 mr-1 md:mr-2" />
              Map
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                {requests.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">No service requests yet</div>
                ) : (
                  <div className="grid md:grid-cols-2 gap-4">
                    {requests.slice(0, 4).map((request) => (
                      <JobHistoryCard
                        key={request.id}
                        job={request}
                        attachments={getJobAttachments(request.id)}
                        rating={getJobRating(request.id)}
                      />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="vehicles">
            <VehicleManager userId={user?.id} />
          </TabsContent>

          <TabsContent value="preferred">
            <PreferredTechniciansList customerId={user?.id} />
          </TabsContent>

          <TabsContent value="referrals">
            <ReferralProgram userId={user?.id} />
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Complete Service History</CardTitle>
              </CardHeader>
              <CardContent>
                {completedRequests.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <History className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <p className="text-lg font-semibold mb-2">No Completed Services</p>
                    <p className="text-sm">Your completed services with photos and documents will appear here</p>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {completedRequests.map((job) => (
                      <JobHistoryCard
                        key={job.id}
                        job={job}
                        attachments={getJobAttachments(job.id)}
                        rating={getJobRating(job.id)}
                      />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="map">
            <React.Suspense fallback={<div className="h-96 bg-gray-100 animate-pulse rounded-lg" />}>
              <RealTimeTechniciansMap 
                customerLocation={null}
                showCustomer={false}
                highlightClosest={false}
              />
            </React.Suspense>
          </TabsContent>
        </Tabs>
      </div>

      {/* AI Chatbot */}
      <div className="support-chat">
        <SupportChatbot userId={user?.id} />
      </div>
      
      {/* Support Chat */}
      <CustomerSupportChat userId={user?.id} />

      {/* Expandable Banner */}
      {adsEnabled && ads.filter(a => a.ad_type === 'expandable').length > 0 && (
        <ExpandableBanner 
          ads={ads.filter(a => a.ad_type === 'expandable')} 
          onImpression={recordImpression}
          onClick={recordClick}
        />
      )}

      </div>

      {/* Bottom Spacer */}
      <div style={{ height: 'var(--safe-area-bottom)', flexShrink: 0 }} />

      {/* Customer Rating Modal - Required after job completion */}
      {showRatingModal && needsCustomerRating && (
        <CustomerRatingModal
          serviceRequest={activeRequest}
          technicianName={technicianData?.full_name || 'Technician'}
          onSubmit={handleRatingSubmit}
          isSubmitting={submittingRating}
        />
      )}
    </div>
  );
}