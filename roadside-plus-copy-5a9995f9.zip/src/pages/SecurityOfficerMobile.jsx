import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Camera, Radio, AlertTriangle, CheckCircle, Clock, Navigation } from 'lucide-react';
import { createPageUrl } from '@/utils';
import SecurityChatPanel from '../components/security/SecurityChatPanel';
import OfficerEvidenceUpload from '../components/security/OfficerEvidenceUpload';
import OfficerLocationTracker from '../components/security/OfficerLocationTracker';
import { format } from 'date-fns';

export default function SecurityOfficerMobile() {
  const [officer, setOfficer] = useState(null);
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadOfficer();
  }, []);

  const loadOfficer = async () => {
    const officerId = localStorage.getItem('security_officer_id');
    const companyId = localStorage.getItem('security_company_id');
    
    if (!officerId) {
      window.location.href = createPageUrl('SecurityLogin');
      return;
    }

    const officerData = await base44.entities.SecurityOfficer.filter({ id: officerId });
    if (officerData.length > 0) {
      setOfficer(officerData[0]);
      const userData = await base44.entities.User.filter({ id: officerData[0].user_id });
      setUser(userData[0]);
    }
  };

  const { data: currentIncident } = useQuery({
    queryKey: ['current-incident', officer?.current_incident_id],
    queryFn: () => base44.entities.SOSIncident.filter({ id: officer.current_incident_id }),
    enabled: !!officer?.current_incident_id,
    refetchInterval: 3000
  });

  const incident = currentIncident?.[0];

  const updateStatus = useMutation({
    mutationFn: async (newStatus) => {
      const updates = { status: newStatus };
      
      if (newStatus === 'arrived') {
        updates.time_arrived = new Date().toISOString();
      } else if (newStatus === 'resolved') {
        updates.time_resolved = new Date().toISOString();
      }

      await base44.entities.SOSIncident.update(incident.id, updates);
      
      await base44.entities.SecurityEvent.create({
        incident_id: incident.id,
        company_id: officer.company_id,
        officer_id: officer.id,
        event_type: 'status_changed',
        event_data: { new_status: newStatus },
        location_lat: officer.current_lat,
        location_lng: officer.current_lng
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['current-incident'] });
    }
  });

  const updateOfficerStatus = useMutation({
    mutationFn: (status) => base44.entities.SecurityOfficer.update(officer.id, { status }),
    onSuccess: (updated) => {
      setOfficer(updated);
    }
  });

  const statusOptions = [
    { value: 'assigned', label: 'Assigned', icon: Clock, color: '#3B82F6' },
    { value: 'en_route', label: 'En Route', icon: Navigation, color: '#F59E0B' },
    { value: 'arrived', label: 'Arrived', icon: MapPin, color: '#10B981' },
    { value: 'securing_area', label: 'Securing Area', icon: AlertTriangle, color: '#EF4444' },
    { value: 'resolved', label: 'Resolved', icon: CheckCircle, color: '#3D692B' }
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white pb-20"
         style={{ 
           paddingTop: 'env(safe-area-inset-top)',
           paddingLeft: 'env(safe-area-inset-left)',
           paddingRight: 'env(safe-area-inset-right)',
           paddingBottom: 'calc(env(safe-area-inset-bottom) + 5rem)'
         }}>
      
      {/* Location Tracker */}
      {officer && (
        <OfficerLocationTracker 
          officerId={officer.id}
          companyId={officer.company_id}
          incidentId={incident?.id}
        />
      )}

      {/* Header */}
      <div className="p-4 border-b border-gray-700" style={{ backgroundColor: '#1F2937' }}>
        <div className="flex items-center justify-between mb-2">
          <div>
            <p className="text-sm text-gray-400">Officer</p>
            <h1 className="text-xl font-bold">{user?.full_name}</h1>
          </div>
          <Badge className={officer?.status === 'available' ? 'bg-green-600' : 'bg-gray-600'}>
            {officer?.status}
          </Badge>
        </div>

        {/* Status Toggle */}
        <div className="flex gap-2 mt-3">
          <Button
            size="sm"
            variant={officer?.status === 'available' ? 'default' : 'outline'}
            onClick={() => updateOfficerStatus.mutate('available')}
            className={officer?.status === 'available' ? 'bg-green-600' : 'border-gray-600 text-white'}
          >
            <Radio className="w-3 h-3 mr-1" />
            Available
          </Button>
          <Button
            size="sm"
            variant={officer?.status === 'busy' ? 'default' : 'outline'}
            onClick={() => updateOfficerStatus.mutate('busy')}
            className={officer?.status === 'busy' ? 'bg-orange-600' : 'border-gray-600 text-white'}
          >
            Busy
          </Button>
          <Button
            size="sm"
            variant={officer?.status === 'offline' ? 'default' : 'outline'}
            onClick={() => updateOfficerStatus.mutate('offline')}
            className={officer?.status === 'offline' ? 'bg-gray-600' : 'border-gray-600 text-white'}
          >
            Offline
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Current Incident */}
        {incident ? (
          <>
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" style={{ color: '#E52C2D' }} />
                  Active Incident
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-gray-400">Status</p>
                  <Badge style={{ backgroundColor: '#FF771D' }}>{incident.status}</Badge>
                </div>

                <div>
                  <p className="text-sm text-gray-400 mb-1">Severity</p>
                  <Badge className={
                    incident.severity === 'critical' ? 'bg-red-600' :
                    incident.severity === 'high' ? 'bg-orange-600' :
                    incident.severity === 'medium' ? 'bg-yellow-600' : 'bg-blue-600'
                  }>
                    {incident.severity}
                  </Badge>
                </div>

                <div>
                  <p className="text-sm text-gray-400">Location</p>
                  <p className="text-white text-sm">{incident.location_address || 'Address unavailable'}</p>
                </div>

                {incident.description && (
                  <div>
                    <p className="text-sm text-gray-400">Description</p>
                    <p className="text-white text-sm">{incident.description}</p>
                  </div>
                )}

                {/* Quick Status Updates */}
                <div>
                  <p className="text-sm text-gray-400 mb-2">Update Status</p>
                  <div className="grid grid-cols-2 gap-2">
                    {statusOptions.map(option => {
                      const Icon = option.icon;
                      return (
                        <Button
                          key={option.value}
                          size="sm"
                          variant={incident.status === option.value ? 'default' : 'outline'}
                          onClick={() => updateStatus.mutate(option.value)}
                          className={incident.status === option.value ? 'text-white' : 'border-gray-600 text-white'}
                          style={incident.status === option.value ? { backgroundColor: option.color } : {}}
                        >
                          <Icon className="w-4 h-4 mr-1" />
                          {option.label}
                        </Button>
                      );
                    })}
                  </div>
                </div>

                <Button
                  className="w-full text-white"
                  style={{ backgroundColor: '#FF771D' }}
                  onClick={() => window.location.href = createPageUrl(`SecurityIncidentDetail?id=${incident.id}`)}
                >
                  View Full Details
                </Button>
              </CardContent>
            </Card>

            {/* Evidence Upload */}
            <OfficerEvidenceUpload 
              incidentId={incident.id}
              officerId={officer.id}
              companyId={officer.company_id}
            />

            {/* Customer Chat */}
            <SecurityChatPanel
              companyId={officer.company_id}
              userId={officer.id}
              userRole="officer"
              incidentId={incident.id}
              chatType="officer_customer"
              recipientId={incident.customer_id}
            />
          </>
        ) : (
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="py-12 text-center">
              <CheckCircle className="w-12 h-12 mx-auto mb-3 text-gray-600" />
              <p className="text-gray-400">No active incidents</p>
              <p className="text-sm text-gray-500 mt-2">
                You'll be notified when assigned to a new incident
              </p>
            </CardContent>
          </Card>
        )}

        {/* Dispatcher Chat */}
        <SecurityChatPanel
          companyId={officer?.company_id}
          userId={officer?.id}
          userRole="officer"
          chatType="officer_dispatcher"
        />
      </div>
    </div>
  );
}