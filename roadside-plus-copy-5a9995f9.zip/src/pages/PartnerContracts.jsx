import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  FileText, Upload, Download, CheckCircle, AlertCircle, 
  Clock, XCircle, Calendar, Plus, Eye
} from 'lucide-react';
import { format, isPast, isFuture, differenceInDays } from 'date-fns';
import { createPageUrl } from '@/utils';
import BrandLogo from '../components/branding/BrandLogo';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function PartnerContracts() {
  const [user, setUser] = useState(null);
  const [partner, setPartner] = useState(null);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [selectedContract, setSelectedContract] = useState(null);
  const [uploadFile, setUploadFile] = useState(null);
  const [newContract, setNewContract] = useState({
    contract_title: '',
    contract_type: 'partnership_agreement',
    start_date: '',
    end_date: '',
    auto_renew: false,
    notes: ''
  });
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        window.location.href = createPageUrl('Login');
        return;
      }
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      const partners = await base44.entities.Partner.filter({ email: currentUser.email });
      if (partners.length > 0) {
        setPartner(partners[0]);
      } else {
        window.location.href = createPageUrl('PartnerPortal');
      }
    } catch (error) {
      window.location.href = createPageUrl('Login');
    }
  };

  const { data: contracts = [] } = useQuery({
    queryKey: ['partner-contracts', partner?.id],
    queryFn: async () => {
      return await base44.entities.PartnerContract.filter(
        { partner_id: partner.id },
        '-created_date'
      );
    },
    enabled: !!partner
  });

  const uploadContract = useMutation({
    mutationFn: async () => {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: uploadFile });
      
      await base44.entities.PartnerContract.create({
        ...newContract,
        partner_id: partner.id,
        contract_document_url: file_url,
        status: 'pending_review',
        signed_by_partner: true,
        partner_signature_date: new Date().toISOString()
      });

      // Notify admin
      await base44.integrations.Core.SendEmail({
        to: 'admin@roadsideplus.com',
        subject: '📄 New Contract Uploaded',
        body: `${partner.company_name} has uploaded a new ${newContract.contract_type.replace(/_/g, ' ')} contract for review.`
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partner-contracts'] });
      setShowUploadDialog(false);
      setUploadFile(null);
      setNewContract({
        contract_title: '',
        contract_type: 'partnership_agreement',
        start_date: '',
        end_date: '',
        auto_renew: false,
        notes: ''
      });
    }
  });

  if (!user || !partner) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2" style={{ borderColor: '#FF771D' }}></div>
      </div>
    );
  }

  const primaryColor = partner.white_label_primary_color || '#FF771D';
  const activeContracts = contracts.filter(c => c.status === 'active');
  const pendingContracts = contracts.filter(c => c.status === 'pending_review');
  const expiringContracts = activeContracts.filter(c => {
    if (!c.end_date) return false;
    const daysUntilExpiry = differenceInDays(new Date(c.end_date), new Date());
    return daysUntilExpiry > 0 && daysUntilExpiry <= 30;
  });

  const getContractStatus = (contract) => {
    if (contract.status === 'expired' || (contract.end_date && isPast(new Date(contract.end_date)))) {
      return { label: 'Expired', color: 'bg-red-100 text-red-800', icon: XCircle };
    }
    if (contract.status === 'active') {
      const daysUntilExpiry = contract.end_date ? differenceInDays(new Date(contract.end_date), new Date()) : null;
      if (daysUntilExpiry !== null && daysUntilExpiry <= 30 && daysUntilExpiry > 0) {
        return { label: 'Expiring Soon', color: 'bg-yellow-100 text-yellow-800', icon: AlertCircle };
      }
      return { label: 'Active', color: 'bg-green-100 text-green-800', icon: CheckCircle };
    }
    if (contract.status === 'pending_review') {
      return { label: 'Pending Review', color: 'bg-blue-100 text-blue-800', icon: Clock };
    }
    return { label: contract.status, color: 'bg-gray-100 text-gray-800', icon: FileText };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" 
           style={{ background: `linear-gradient(135deg, ${primaryColor} 0%, #E52C2D 100%)` }}>
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              {partner.white_label_logo ? (
                <img src={partner.white_label_logo} alt={partner.company_name} className="h-12" />
              ) : (
                <BrandLogo variant="icon" size="md" />
              )}
              <div>
                <h1 className="text-2xl font-bold">Contract Management</h1>
                <p className="text-sm opacity-90">{partner.company_name}</p>
              </div>
            </div>
            <Button
              onClick={() => window.location.href = createPageUrl('PartnerPortal')}
              variant="outline"
              className="text-white border-white/30 hover:bg-white/20"
            >
              Back to Portal
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Alert for expiring contracts */}
        {expiringContracts.length > 0 && (
          <Card className="mb-6 border-l-4 border-orange-500">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-6 h-6 text-orange-600 mt-0.5" />
                <div>
                  <h3 className="font-semibold mb-1">Contracts Expiring Soon</h3>
                  <p className="text-sm text-gray-600">
                    You have {expiringContracts.length} contract(s) expiring within the next 30 days. 
                    Please review and renew as needed.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Contracts</p>
                  <p className="text-3xl font-bold mt-1">{contracts.length}</p>
                </div>
                <FileText className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active</p>
                  <p className="text-3xl font-bold mt-1" style={{ color: '#3D692B' }}>
                    {activeContracts.length}
                  </p>
                </div>
                <CheckCircle className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Review</p>
                  <p className="text-3xl font-bold mt-1">{pendingContracts.length}</p>
                </div>
                <Clock className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Expiring Soon</p>
                  <p className="text-3xl font-bold mt-1">{expiringContracts.length}</p>
                </div>
                <AlertCircle className="w-10 h-10 opacity-20" style={{ color: '#FF9F40' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Upload Button */}
        <div className="mb-6">
          <Button
            onClick={() => setShowUploadDialog(true)}
            className="text-white"
            style={{ backgroundColor: primaryColor }}
          >
            <Upload className="w-4 h-4 mr-2" />
            Upload New Contract
          </Button>
        </div>

        {/* Contracts List */}
        <Card>
          <CardHeader>
            <CardTitle>Your Contracts</CardTitle>
          </CardHeader>
          <CardContent>
            {contracts.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-600 mb-2">No contracts yet</p>
                <p className="text-sm text-gray-500">Upload your partnership agreement to get started</p>
              </div>
            ) : (
              <div className="space-y-3">
                {contracts.map(contract => {
                  const status = getContractStatus(contract);
                  const StatusIcon = status.icon;
                  const daysUntilExpiry = contract.end_date ? differenceInDays(new Date(contract.end_date), new Date()) : null;

                  return (
                    <Card key={contract.id} className="border hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-lg flex items-center justify-center bg-gray-100">
                              <FileText className="w-6 h-6" style={{ color: primaryColor }} />
                            </div>
                            <div>
                              <h3 className="font-bold">{contract.contract_title}</h3>
                              <p className="text-sm text-gray-600 capitalize">
                                {contract.contract_type.replace(/_/g, ' ')}
                              </p>
                            </div>
                          </div>
                          <Badge className={status.color}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {status.label}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3 text-sm">
                          <div>
                            <p className="text-gray-600">Start Date</p>
                            <p className="font-semibold">
                              {contract.start_date ? format(new Date(contract.start_date), 'MMM d, yyyy') : 'Not set'}
                            </p>
                          </div>
                          <div>
                            <p className="text-gray-600">End Date</p>
                            <p className="font-semibold">
                              {contract.end_date ? format(new Date(contract.end_date), 'MMM d, yyyy') : 'Open-ended'}
                            </p>
                          </div>
                          <div>
                            <p className="text-gray-600">Auto-Renew</p>
                            <p className="font-semibold">{contract.auto_renew ? 'Yes' : 'No'}</p>
                          </div>
                          <div>
                            <p className="text-gray-600">Signed</p>
                            <p className="font-semibold">
                              {contract.signed_by_partner && contract.signed_by_admin ? 'Both parties' :
                               contract.signed_by_partner ? 'By you' : 
                               contract.signed_by_admin ? 'By admin' : 'Pending'}
                            </p>
                          </div>
                        </div>

                        {daysUntilExpiry !== null && daysUntilExpiry > 0 && daysUntilExpiry <= 30 && (
                          <div className="bg-yellow-50 border border-yellow-200 rounded p-3 mb-3 text-sm">
                            <p className="text-yellow-800">
                              ⚠️ Expires in {daysUntilExpiry} day{daysUntilExpiry !== 1 ? 's' : ''}
                            </p>
                          </div>
                        )}

                        <div className="flex gap-2">
                          {contract.contract_document_url && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => window.open(contract.contract_document_url, '_blank')}
                            >
                              <Download className="w-4 h-4 mr-2" />
                              Download
                            </Button>
                          )}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedContract(contract)}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            View Details
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Upload Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Upload New Contract</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Contract Title</label>
              <Input
                value={newContract.contract_title}
                onChange={(e) => setNewContract({...newContract, contract_title: e.target.value})}
                placeholder="Partnership Agreement 2025"
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Contract Type</label>
              <Select
                value={newContract.contract_type}
                onValueChange={(value) => setNewContract({...newContract, contract_type: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="partnership_agreement">Partnership Agreement</SelectItem>
                  <SelectItem value="service_agreement">Service Agreement</SelectItem>
                  <SelectItem value="nda">Non-Disclosure Agreement</SelectItem>
                  <SelectItem value="amendment">Amendment</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Start Date</label>
                <Input
                  type="date"
                  value={newContract.start_date}
                  onChange={(e) => setNewContract({...newContract, start_date: e.target.value})}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">End Date</label>
                <Input
                  type="date"
                  value={newContract.end_date}
                  onChange={(e) => setNewContract({...newContract, end_date: e.target.value})}
                  min={newContract.start_date}
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="auto_renew"
                checked={newContract.auto_renew}
                onChange={(e) => setNewContract({...newContract, auto_renew: e.target.checked})}
                className="w-4 h-4"
              />
              <label htmlFor="auto_renew" className="text-sm">Auto-renew contract</label>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Notes (Optional)</label>
              <Textarea
                value={newContract.notes}
                onChange={(e) => setNewContract({...newContract, notes: e.target.value})}
                placeholder="Additional information about this contract..."
                rows={3}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Contract Document</label>
              <Input
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={(e) => setUploadFile(e.target.files[0])}
              />
              <p className="text-xs text-gray-500 mt-1">PDF, DOC, or DOCX files only</p>
            </div>

            <Button
              onClick={() => uploadContract.mutate()}
              disabled={!uploadFile || !newContract.contract_title || uploadContract.isLoading}
              className="w-full text-white"
              style={{ backgroundColor: primaryColor }}
            >
              {uploadContract.isLoading ? 'Uploading...' : 'Upload Contract'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Contract Details Dialog */}
      <Dialog open={!!selectedContract} onOpenChange={() => setSelectedContract(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{selectedContract?.contract_title}</DialogTitle>
          </DialogHeader>
          {selectedContract && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Contract Type</p>
                  <p className="font-semibold capitalize">{selectedContract.contract_type.replace(/_/g, ' ')}</p>
                </div>
                <div>
                  <p className="text-gray-600">Status</p>
                  <Badge className={getContractStatus(selectedContract).color}>
                    {getContractStatus(selectedContract).label}
                  </Badge>
                </div>
                <div>
                  <p className="text-gray-600">Start Date</p>
                  <p className="font-semibold">
                    {selectedContract.start_date ? format(new Date(selectedContract.start_date), 'MMMM d, yyyy') : 'Not set'}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">End Date</p>
                  <p className="font-semibold">
                    {selectedContract.end_date ? format(new Date(selectedContract.end_date), 'MMMM d, yyyy') : 'Open-ended'}
                  </p>
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="font-semibold mb-3">Signature Status</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span>Partner Signature</span>
                    {selectedContract.signed_by_partner ? (
                      <div className="flex items-center gap-2 text-green-600">
                        <CheckCircle className="w-4 h-4" />
                        <span>Signed on {format(new Date(selectedContract.partner_signature_date), 'MMM d, yyyy')}</span>
                      </div>
                    ) : (
                      <span className="text-gray-500">Not signed</span>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Admin Signature</span>
                    {selectedContract.signed_by_admin ? (
                      <div className="flex items-center gap-2 text-green-600">
                        <CheckCircle className="w-4 h-4" />
                        <span>Signed on {format(new Date(selectedContract.admin_signature_date), 'MMM d, yyyy')}</span>
                      </div>
                    ) : (
                      <span className="text-gray-500">Pending</span>
                    )}
                  </div>
                </div>
              </div>

              {selectedContract.notes && (
                <div className="border-t pt-4">
                  <h4 className="font-semibold mb-2">Notes</h4>
                  <p className="text-sm text-gray-600">{selectedContract.notes}</p>
                </div>
              )}

              {selectedContract.contract_document_url && (
                <Button
                  onClick={() => window.open(selectedContract.contract_document_url, '_blank')}
                  className="w-full text-white"
                  style={{ backgroundColor: primaryColor }}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Contract Document
                </Button>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}