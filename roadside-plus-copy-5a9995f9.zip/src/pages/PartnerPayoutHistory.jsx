import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  DollarSign, Calendar, TrendingUp, CheckCircle, 
  Clock, AlertCircle, Download, FileText
} from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import BrandLogo from '../components/branding/BrandLogo';

export default function PartnerPayoutHistory() {
  const [user, setUser] = useState(null);
  const [partner, setPartner] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        window.location.href = createPageUrl('Login');
        return;
      }
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      const partners = await base44.entities.Partner.filter({ email: currentUser.email });
      if (partners.length > 0) {
        setPartner(partners[0]);
      }
    } catch (error) {
      window.location.href = createPageUrl('Login');
    }
  };

  const { data: payouts = [] } = useQuery({
    queryKey: ['partner-payouts', partner?.id],
    queryFn: async () => {
      return await base44.entities.PartnerPayout.filter(
        { partner_id: partner.id },
        '-created_date'
      );
    },
    enabled: !!partner
  });

  if (!user || !partner) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2" style={{ borderColor: '#FF771D' }}></div>
      </div>
    );
  }

  const primaryColor = partner.white_label_primary_color || '#FF771D';
  const pendingPayouts = payouts.filter(p => p.status === 'pending');
  const paidPayouts = payouts.filter(p => p.status === 'paid');
  const totalEarned = paidPayouts.reduce((sum, p) => sum + p.commission_amount, 0);
  const totalPending = pendingPayouts.reduce((sum, p) => sum + p.commission_amount, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="text-white p-6 shadow-lg" 
           style={{ background: `linear-gradient(135deg, ${primaryColor} 0%, ${partner.white_label_secondary_color || '#E52C2D'} 100%)` }}>
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <BrandLogo variant="icon" size="md" />
            <div>
              <h1 className="text-2xl font-bold">Commission History</h1>
              <p className="text-sm opacity-90">{partner.company_name}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Stripe Connect Alert */}
        {!partner.stripe_onboarding_complete && (
          <Card className="mb-6 border-l-4 border-orange-500">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-6 h-6 text-orange-600 mt-0.5" />
                <div className="flex-1">
                  <h3 className="font-semibold mb-1">Setup Required</h3>
                  <p className="text-gray-600 text-sm mb-3">
                    Connect your bank account to receive automatic payouts
                  </p>
                  <Button
                    onClick={() => window.location.href = createPageUrl('PartnerStripeConnect')}
                    style={{ backgroundColor: primaryColor }}
                    className="text-white"
                  >
                    Connect Bank Account
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Earned</p>
                  <p className="text-3xl font-bold mt-1" style={{ color: '#3D692B' }}>
                    ${totalEarned.toFixed(2)}
                  </p>
                </div>
                <DollarSign className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending</p>
                  <p className="text-3xl font-bold mt-1" style={{ color: primaryColor }}>
                    ${totalPending.toFixed(2)}
                  </p>
                </div>
                <Clock className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Payouts</p>
                  <p className="text-3xl font-bold mt-1">{payouts.length}</p>
                </div>
                <TrendingUp className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payout History */}
        <Card>
          <CardHeader>
            <CardTitle>Payout History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {payouts.length === 0 ? (
                <div className="text-center py-12">
                  <DollarSign className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-gray-500">No payouts yet</p>
                  <p className="text-sm text-gray-400 mt-1">
                    Payouts are generated monthly for completed jobs
                  </p>
                </div>
              ) : (
                payouts.map(payout => {
                  const statusConfig = {
                    pending: { color: 'bg-yellow-100 text-yellow-800', icon: Clock, label: 'Processing' },
                    processing: { color: 'bg-blue-100 text-blue-800', icon: TrendingUp, label: 'Processing' },
                    paid: { color: 'bg-green-100 text-green-800', icon: CheckCircle, label: 'Paid' },
                    failed: { color: 'bg-red-100 text-red-800', icon: AlertCircle, label: 'Failed' }
                  };
                  const status = statusConfig[payout.status];
                  const StatusIcon = status.icon;

                  return (
                    <Card key={payout.id} className="border hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-5 h-5" style={{ color: primaryColor }} />
                            <h3 className="font-bold">
                              {format(new Date(payout.period_start), 'MMMM yyyy')}
                            </h3>
                          </div>
                          <Badge className={status.color}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {status.label}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                          <div>
                            <p className="text-sm text-gray-600">Jobs Completed</p>
                            <p className="text-xl font-bold">{payout.total_jobs}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Total Revenue</p>
                            <p className="text-xl font-bold">${payout.total_revenue.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Rate</p>
                            <p className="text-xl font-bold">{payout.commission_rate}%</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Your Commission</p>
                            <p className="text-2xl font-bold" style={{ color: '#3D692B' }}>
                              ${payout.commission_amount.toFixed(2)}
                            </p>
                          </div>
                        </div>

                        {payout.paid_at && (
                          <div className="text-sm text-gray-600 border-t pt-3">
                            <p>Paid on {format(new Date(payout.paid_at), 'MMMM d, yyyy')}</p>
                            {payout.stripe_transfer_id && (
                              <p className="text-xs font-mono mt-1">Transfer ID: {payout.stripe_transfer_id}</p>
                            )}
                          </div>
                        )}

                        {payout.status === 'pending' && (
                          <div className="text-sm text-gray-600 border-t pt-3">
                            <p className="flex items-center gap-2">
                              <Clock className="w-4 h-4" />
                              Payment will be processed within 3-5 business days
                            </p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>

        {/* Payment Info */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Payment Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <div>
                <p className="text-gray-600">Payment Schedule</p>
                <p className="font-semibold">Monthly - Processed on the 5th of each month</p>
              </div>
              <div>
                <p className="text-gray-600">Payment Method</p>
                <p className="font-semibold">Stripe Connect - Direct Bank Transfer</p>
              </div>
              <div>
                <p className="text-gray-600">Commission Rate</p>
                <p className="font-semibold">{partner.commission_rate}% of completed job revenue</p>
              </div>
              <div>
                <p className="text-gray-600">Payment Terms</p>
                <p className="font-semibold">{partner.payment_terms || 'Standard terms'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}