import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { AlertCircle, Settings, Save, Bot, Zap } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function AdminDispatchSettings() {
  const [user, setUser] = useState(null);
  const [saved, setSaved] = useState(false);
  const [settings, setSettings] = useState({
    aiEnabled: true,
    autoAssign: true,
    maxDistance: 50,
    offerTimeout: 60,
    preferSpecialists: true,
    balanceWorkload: true,
    minRating: 4.0,
    maxDailyJobs: 10,
    prioritizeNewTechs: false
  });

  useEffect(() => {
    loadUser();
    loadSettings();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const loadSettings = async () => {
    try {
      const stored = localStorage.getItem('dispatch_settings');
      if (stored) {
        setSettings(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  const saveSettings = () => {
    localStorage.setItem('dispatch_settings', JSON.stringify(settings));
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="p-8 text-center">
          <AlertCircle className="w-16 h-16 mx-auto mb-4" style={{ color: '#E52C2D' }} />
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-gray-600">Admin access required</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold mb-2">AI Dispatch Settings</h1>
          <p className="text-sm opacity-90">Configure intelligent dispatch rules and preferences</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6 space-y-6">
        {saved && (
          <Alert className="border-green-500 bg-green-50">
            <AlertDescription className="text-green-800">
              Settings saved successfully!
            </AlertDescription>
          </Alert>
        )}

        {/* AI Features */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bot className="w-5 h-5" style={{ color: '#FF771D' }} />
              AI-Powered Dispatch
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-base font-semibold">Enable AI Dispatch</Label>
                <p className="text-sm text-gray-600">
                  Use AI to intelligently select the best technician for each job
                </p>
              </div>
              <Switch
                checked={settings.aiEnabled}
                onCheckedChange={(checked) => setSettings({...settings, aiEnabled: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label className="text-base font-semibold">Auto-Assign Jobs</Label>
                <p className="text-sm text-gray-600">
                  Automatically assign jobs without technician confirmation
                </p>
              </div>
              <Switch
                checked={settings.autoAssign}
                onCheckedChange={(checked) => setSettings({...settings, autoAssign: checked})}
              />
            </div>
          </CardContent>
        </Card>

        {/* Distance & Timing */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5" style={{ color: '#FF771D' }} />
              Distance & Timing Rules
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-base font-semibold">Maximum Distance</Label>
                <span className="text-lg font-bold" style={{ color: '#FF771D' }}>
                  {settings.maxDistance} km
                </span>
              </div>
              <Slider
                value={[settings.maxDistance]}
                onValueChange={([value]) => setSettings({...settings, maxDistance: value})}
                min={10}
                max={100}
                step={5}
                className="w-full"
              />
              <p className="text-xs text-gray-600 mt-2">
                Maximum distance technicians can be from the service location
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-base font-semibold">Offer Timeout</Label>
                <span className="text-lg font-bold" style={{ color: '#FF771D' }}>
                  {settings.offerTimeout}s
                </span>
              </div>
              <Slider
                value={[settings.offerTimeout]}
                onValueChange={([value]) => setSettings({...settings, offerTimeout: value})}
                min={30}
                max={300}
                step={15}
                className="w-full"
              />
              <p className="text-xs text-gray-600 mt-2">
                Time technicians have to accept or reject job offers
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Selection Preferences */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" style={{ color: '#FF771D' }} />
              Selection Preferences
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-base font-semibold">Prefer Specialists</Label>
                <p className="text-sm text-gray-600">
                  Prioritize technicians with matching service specialties
                </p>
              </div>
              <Switch
                checked={settings.preferSpecialists}
                onCheckedChange={(checked) => setSettings({...settings, preferSpecialists: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label className="text-base font-semibold">Balance Workload</Label>
                <p className="text-sm text-gray-600">
                  Distribute jobs fairly among all available technicians
                </p>
              </div>
              <Switch
                checked={settings.balanceWorkload}
                onCheckedChange={(checked) => setSettings({...settings, balanceWorkload: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label className="text-base font-semibold">Prioritize New Technicians</Label>
                <p className="text-sm text-gray-600">
                  Help new technicians build their reputation with more jobs
                </p>
              </div>
              <Switch
                checked={settings.prioritizeNewTechs}
                onCheckedChange={(checked) => setSettings({...settings, prioritizeNewTechs: checked})}
              />
            </div>

            <div>
              <Label htmlFor="minRating" className="text-base font-semibold">
                Minimum Rating Threshold
              </Label>
              <div className="flex items-center gap-4 mt-2">
                <Input
                  id="minRating"
                  type="number"
                  min="0"
                  max="5"
                  step="0.1"
                  value={settings.minRating}
                  onChange={(e) => setSettings({...settings, minRating: parseFloat(e.target.value)})}
                  className="w-24"
                />
                <span className="text-sm text-gray-600">out of 5.0</span>
              </div>
              <p className="text-xs text-gray-600 mt-2">
                Only consider technicians with ratings above this threshold
              </p>
            </div>

            <div>
              <Label htmlFor="maxJobs" className="text-base font-semibold">
                Max Daily Jobs Per Technician
              </Label>
              <div className="flex items-center gap-4 mt-2">
                <Input
                  id="maxJobs"
                  type="number"
                  min="1"
                  max="50"
                  value={settings.maxDailyJobs}
                  onChange={(e) => setSettings({...settings, maxDailyJobs: parseInt(e.target.value)})}
                  className="w-24"
                />
                <span className="text-sm text-gray-600">jobs per day</span>
              </div>
              <p className="text-xs text-gray-600 mt-2">
                Prevent technician burnout by limiting daily assignments
              </p>
            </div>
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">How AI Dispatch Works</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-blue-800 space-y-2">
            <p>
              <strong>1. Analysis:</strong> AI analyzes all available technicians, considering location, skills, ratings, and current workload.
            </p>
            <p>
              <strong>2. Scoring:</strong> Each technician receives a score based on service specialty match (30%), proximity (25%), performance metrics (25%), and workload balance (20%).
            </p>
            <p>
              <strong>3. Selection:</strong> The optimal technician is selected and automatically notified.
            </p>
            <p>
              <strong>4. Fallback:</strong> If AI selection fails, rule-based logic ensures a technician is still assigned.
            </p>
          </CardContent>
        </Card>

        <Button
          onClick={saveSettings}
          className="w-full text-white py-6 text-lg font-semibold"
          style={{ backgroundColor: '#FF771D' }}
        >
          <Save className="w-5 h-5 mr-2" />
          Save Dispatch Settings
        </Button>
      </div>
    </div>
  );
}