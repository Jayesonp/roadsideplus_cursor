import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Palette, Upload, CheckCircle, Loader2 } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function PartnerSettings() {
  const [user, setUser] = useState(null);
  const [partner, setPartner] = useState(null);
  const [branding, setBranding] = useState({
    white_label_logo: '',
    white_label_domain: '',
    white_label_primary_color: '#FF771D',
    white_label_secondary_color: '#E52C2D'
  });
  const [uploading, setUploading] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
    const partners = await base44.entities.Partner.filter({ email: currentUser.email });
    if (partners[0]) {
      setPartner(partners[0]);
      setBranding({
        white_label_logo: partners[0].white_label_logo || '',
        white_label_domain: partners[0].white_label_domain || '',
        white_label_primary_color: partners[0].white_label_primary_color || '#FF771D',
        white_label_secondary_color: partners[0].white_label_secondary_color || '#E52C2D'
      });
    }
  };

  const uploadLogo = async (file) => {
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setBranding(prev => ({ ...prev, white_label_logo: file_url }));
    } finally {
      setUploading(false);
    }
  };

  const saveBranding = useMutation({
    mutationFn: async () => {
      await base44.entities.Partner.update(partner.id, branding);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['partner-profile']);
      alert('Branding updated successfully!');
    }
  });

  if (!partner) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Partner Settings</h1>

        <Tabs defaultValue="branding">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="branding">Branding</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
          </TabsList>

          <TabsContent value="branding">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="w-5 h-5" />
                  White-Label Branding
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Company Logo</label>
                  <div className="flex items-center gap-4">
                    {branding.white_label_logo && (
                      <img src={branding.white_label_logo} alt="Logo" className="h-16 border rounded" />
                    )}
                    <label>
                      <input type="file" className="hidden" accept="image/*" onChange={(e) => uploadLogo(e.target.files[0])} />
                      <Button type="button" variant="outline" disabled={uploading} onClick={(e) => e.currentTarget.previousElementSibling.click()}>
                        {uploading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                        Upload Logo
                      </Button>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Custom Domain</label>
                  <Input value={branding.white_label_domain} onChange={(e) => setBranding({...branding, white_label_domain: e.target.value})} placeholder="partners.yourcompany.com" />
                  <p className="text-xs text-gray-500 mt-1">Contact support to configure DNS</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Primary Color</label>
                    <div className="flex gap-2">
                      <Input type="color" value={branding.white_label_primary_color} onChange={(e) => setBranding({...branding, white_label_primary_color: e.target.value})} className="w-20" />
                      <Input value={branding.white_label_primary_color} onChange={(e) => setBranding({...branding, white_label_primary_color: e.target.value})} />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Secondary Color</label>
                    <div className="flex gap-2">
                      <Input type="color" value={branding.white_label_secondary_color} onChange={(e) => setBranding({...branding, white_label_secondary_color: e.target.value})} className="w-20" />
                      <Input value={branding.white_label_secondary_color} onChange={(e) => setBranding({...branding, white_label_secondary_color: e.target.value})} />
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4" style={{ background: `linear-gradient(135deg, ${branding.white_label_primary_color} 0%, ${branding.white_label_secondary_color} 100%)` }}>
                  <p className="text-white font-semibold">Preview</p>
                  <p className="text-white text-sm opacity-90">This is how your branded portal will look</p>
                </div>

                <Button onClick={() => saveBranding.mutate()} disabled={saveBranding.isLoading} className="w-full text-white" style={{ backgroundColor: branding.white_label_primary_color }}>
                  {saveBranding.isLoading ? 'Saving...' : 'Save Branding'}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="account">
            <Card>
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Company Name</label>
                  <Input value={partner.company_name} disabled />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Email</label>
                  <Input value={partner.email} disabled />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Partner Type</label>
                  <Input value={partner.partner_type?.replace(/_/g, ' ')} disabled className="capitalize" />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}