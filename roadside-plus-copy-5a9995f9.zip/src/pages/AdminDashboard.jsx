import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { createPageUrl } from '@/utils';
import { 
  TrendingUp, Users, MessageSquare, Activity, 
  MapPin, Settings, BarChart3, Clock, CheckCircle,
  AlertCircle, DollarSign, ArrowRight, FileText
} from 'lucide-react';
import { format, subDays } from 'date-fns';
import BrandLogo from '../components/branding/BrandLogo';
import CriticalSOSAlert from '../components/security/CriticalSOSAlert';

export default function AdminDashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  // Fetch overview data - hooks must always be called
  const { data: requests = [] } = useQuery({
    queryKey: ['admin-overview-requests'],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.list('-created_date', 100);
    },
    enabled: !!user && user.role === 'admin'
  });

  const { data: technicians = [] } = useQuery({
    queryKey: ['admin-overview-techs'],
    queryFn: async () => {
      return await base44.entities.TechnicianProfile.list();
    },
    enabled: !!user && user.role === 'admin'
  });

  const { data: supportChats = [] } = useQuery({
    queryKey: ['admin-overview-support'],
    queryFn: async () => {
      return await base44.entities.SupportConversation.list('-last_message_at', 50);
    },
    enabled: !!user && user.role === 'admin'
  });

  const { data: payments = [] } = useQuery({
    queryKey: ['admin-overview-payments'],
    queryFn: async () => {
      return await base44.entities.Payment.list('-created_date', 100);
    },
    enabled: !!user && user.role === 'admin'
  });

  // Early returns after all hooks
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#FF771D' }}></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="p-8 text-center max-w-md">
          <AlertCircle className="w-16 h-16 mx-auto mb-4" style={{ color: '#E52C2D' }} />
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-gray-600">This dashboard is only accessible to administrators.</p>
        </Card>
      </div>
    );
  }

  // Calculate metrics
  const today = new Date();
  const last7Days = subDays(today, 7);
  const last30Days = subDays(today, 30);

  const recentRequests = requests.filter(r => new Date(r.created_date) >= last7Days);
  const completedRequests = requests.filter(r => r.status === 'completed');
  const activeRequests = requests.filter(r => 
    ['pending_dispatch', 'dispatched', 'assigned', 'en_route', 'in_progress'].includes(r.status)
  );

  const availableTechs = technicians.filter(t => t.availability_status === 'available').length;
  const onJobTechs = technicians.filter(t => t.availability_status === 'on_job').length;

  const openSupport = supportChats.filter(c => c.status === 'open' || c.status === 'in_progress').length;
  const unreadSupport = supportChats.reduce((sum, c) => sum + (c.agent_unread_count || 0), 0);

  const totalRevenue = payments
    .filter(p => p.status === 'paid' && new Date(p.created_date) >= last30Days)
    .reduce((sum, p) => sum + (p.amount || 0) + (p.tip_amount || 0), 0);

  const avgResponseTime = recentRequests.length > 0 
    ? Math.round(recentRequests.reduce((sum, r) => sum + 15, 0) / recentRequests.length) 
    : 0;

  const completionRate = requests.length > 0
    ? Math.round((completedRequests.length / requests.length) * 100)
    : 0;

  // Quick action cards
  const quickActions = [
    {
      title: 'Service Requests',
      description: 'Monitor all service requests & statuses',
      icon: MapPin,
      color: '#FF771D',
      bgColor: 'bg-orange-50',
      page: 'AdminServiceRequestMonitor',
      metric: `${activeRequests.length} active jobs`
    },
    {
      title: 'Customer Management',
      description: 'View and manage customer profiles',
      icon: Users,
      color: '#3D692B',
      bgColor: 'bg-blue-50',
      page: 'AdminUserManagement',
      metric: `${requests.filter(r => r.customer_id).length} customers`
    },
    {
      title: 'Technician Management',
      description: 'Manage technician profiles & status',
      icon: Users,
      color: '#E52C2D',
      bgColor: 'bg-purple-50',
      page: 'AdminTechnicianManagement',
      metric: `${availableTechs} available`
    },
    {
      title: 'Technician Payouts',
      description: 'Manage earnings & payouts',
      icon: DollarSign,
      color: '#3D692B',
      bgColor: 'bg-green-50',
      page: 'AdminTechnicianPayouts',
      metric: `${completedRequests.length} completed jobs`
    },
    {
      title: 'Support Dashboard',
      description: 'Handle customer support inquiries',
      icon: MessageSquare,
      color: '#FF771D',
      bgColor: 'bg-yellow-50',
      page: 'AdminSupportDashboard',
      metric: `${openSupport} open tickets`,
      badge: unreadSupport > 0 ? unreadSupport : null
    },
    {
      title: 'Analytics Dashboard',
      description: 'Business insights & performance metrics',
      icon: BarChart3,
      color: '#E52C2D',
      bgColor: 'bg-red-50',
      page: 'AdminAnalyticsDashboard',
      metric: `${completionRate}% completion rate`
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Critical SOS Alert */}
      <CriticalSOSAlert userId={user.id} userRole="admin" />
      {/* Header */}
      <div className="text-white p-6 shadow-lg" 
           style={{ 
             background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)',
             paddingTop: 'calc(env(safe-area-inset-top) + 1.5rem)',
             paddingLeft: 'calc(env(safe-area-inset-left) + 1.5rem)',
             paddingRight: 'calc(env(safe-area-inset-right) + 1.5rem)'
           }}>
           <div className="max-w-7xl mx-auto">
           <div className="flex items-center gap-3 mb-3">
           <BrandLogo variant="icon" size="md" />
           <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
           </div>
           <p className="text-sm opacity-90">Welcome back, {user.full_name}</p>
           <p className="text-xs opacity-75 mt-1">{format(today, 'EEEE, MMMM d, yyyy')}</p>
           </div>
           </div>

      <div className="max-w-7xl mx-auto p-6"
           style={{
             paddingLeft: 'calc(env(safe-area-inset-left) + 1.5rem)',
             paddingRight: 'calc(env(safe-area-inset-right) + 1.5rem)',
             paddingBottom: 'calc(env(safe-area-inset-bottom) + 1.5rem)'
           }}>
        
        {/* Key Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="border-l-4" style={{ borderLeftColor: '#FF771D' }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Active Jobs</p>
                  <p className="text-3xl font-bold">{activeRequests.length}</p>
                  <p className="text-xs text-gray-500 mt-1">Live now</p>
                </div>
                <Activity className="w-12 h-12 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4" style={{ borderLeftColor: '#3D692B' }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Available Techs</p>
                  <p className="text-3xl font-bold">{availableTechs}</p>
                  <p className="text-xs text-gray-500 mt-1">{onJobTechs} on job</p>
                </div>
                <Users className="w-12 h-12 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-blue-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Support Tickets</p>
                  <p className="text-3xl font-bold">{openSupport}</p>
                  {unreadSupport > 0 && (
                    <p className="text-xs font-semibold mt-1" style={{ color: '#E52C2D' }}>
                      {unreadSupport} unread
                    </p>
                  )}
                </div>
                <MessageSquare className="w-12 h-12 text-blue-500 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4" style={{ borderLeftColor: '#3D692B' }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Revenue (30d)</p>
                  <p className="text-3xl font-bold">${totalRevenue.toFixed(0)}</p>
                  <p className="text-xs text-gray-500 mt-1">Last 30 days</p>
                </div>
                <DollarSign className="w-12 h-12 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Performance Overview */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: '#FF771D' }}>
                  <Clock className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Avg Response</p>
                  <p className="text-2xl font-bold">{avgResponseTime}m</p>
                </div>
              </div>
              <p className="text-xs text-gray-500">Average time to assign technician</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5" style={{ color: '#3D692B' }} />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Completion Rate</p>
                  <p className="text-2xl font-bold">{completionRate}%</p>
                </div>
              </div>
              <p className="text-xs text-gray-500">Successfully completed jobs</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Weekly Requests</p>
                  <p className="text-2xl font-bold">{recentRequests.length}</p>
                </div>
              </div>
              <p className="text-xs text-gray-500">Last 7 days</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-2xl font-bold mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <div
                  key={action.page}
                  onClick={() => window.location.href = createPageUrl(action.page)}
                  className="block group cursor-pointer"
                >
                  <Card className={`${action.bgColor} border-2 border-transparent hover:border-current transition-all hover:shadow-lg`}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: action.color }}>
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        {action.badge && (
                          <div className="w-6 h-6 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold">
                            {action.badge}
                          </div>
                        )}
                      </div>
                      <h3 className="font-bold text-lg mb-1 group-hover:underline">{action.title}</h3>
                      <p className="text-sm text-gray-600 mb-3">{action.description}</p>
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-semibold" style={{ color: action.color }}>
                          {action.metric}
                        </p>
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" style={{ color: action.color }} />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Activity */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Recent Service Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentRequests.slice(0, 5).map((req) => (
                <div key={req.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex-1">
                    <p className="font-semibold text-sm">
                      {req.service_type.replace(/_/g, ' ').toUpperCase()}
                    </p>
                    <p className="text-xs text-gray-500">
                      {format(new Date(req.created_date), 'MMM d, h:mm a')}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    {req.price && (
                      <span className="text-sm font-bold" style={{ color: '#3D692B' }}>
                        ${req.price.toFixed(2)}
                      </span>
                    )}
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      req.status === 'completed' ? 'bg-green-100 text-green-800' :
                      req.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {req.status.replace(/_/g, ' ')}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}