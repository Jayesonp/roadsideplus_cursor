import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Briefcase, AlertCircle, Search, Eye, Plus, Edit, 
  Mail, Phone, MapPin, DollarSign, FileText, TrendingUp,
  Calendar, CheckCircle, XCircle, Clock, Trash2
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { format } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import StatusBadge from '../components/common/StatusBadge';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import { createPageUrl } from '@/utils';

export default function AdminPartnerManagement() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPartner, setSelectedPartner] = useState(null);
  const [showPartnerDetails, setShowPartnerDetails] = useState(false);
  const [showAddPartner, setShowAddPartner] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [partnerToDelete, setPartnerToDelete] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [partnerForm, setPartnerForm] = useState({
    company_name: '',
    contact_name: '',
    email: '',
    phone: '',
    address: '',
    partner_type: 'other',
    commission_rate: 10,
    status: 'pending',
    contract_start_date: '',
    contract_end_date: '',
    payment_terms: '',
    notes: ''
  });
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  // Fetch all partners
  const { data: partners = [] } = useQuery({
    queryKey: ['all-partners'],
    queryFn: async () => {
      return await base44.entities.Partner.list('-created_date');
    },
    enabled: !!user,
    refetchInterval: 10000
  });

  // Fetch all service requests
  const { data: allRequests = [] } = useQuery({
    queryKey: ['all-requests'],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.list('-created_date', 1000);
    },
    enabled: !!user
  });

  // Fetch partner's referred jobs (assuming partner_id field on ServiceRequest)
  const { data: partnerJobs = [] } = useQuery({
    queryKey: ['partner-jobs', selectedPartner?.id],
    queryFn: async () => {
      // In a real implementation, you'd filter by partner_id
      // For now, returning empty array as ServiceRequest doesn't have partner_id field yet
      return [];
    },
    enabled: !!selectedPartner
  });

  // Create/Update partner
  const savePartner = useMutation({
    mutationFn: async (partnerData) => {
      if (isEditing && selectedPartner) {
        return await base44.entities.Partner.update(selectedPartner.id, partnerData);
      } else {
        return await base44.entities.Partner.create(partnerData);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['all-partners']);
      setShowAddPartner(false);
      setShowPartnerDetails(false);
      setIsEditing(false);
      resetForm();
    }
  });

  // Update commission rate
  const updateCommissionRate = useMutation({
    mutationFn: async ({ partnerId, newRate }) => {
      return await base44.entities.Partner.update(partnerId, { commission_rate: newRate });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['all-partners']);
    }
  });

  // Delete partner
  const deletePartner = useMutation({
    mutationFn: async (partnerId) => {
      // Delete the partner record
      await base44.entities.Partner.delete({ id: partnerId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['all-partners']);
      setShowDeleteDialog(false);
      setPartnerToDelete(null);
      setShowPartnerDetails(false);
    }
  });

  // Check admin access
  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8">
          <AlertCircle className="w-12 h-12 mx-auto mb-4" style={{ color: '#E52C2D' }} />
          <h2 className="text-xl font-bold text-center">Access Denied</h2>
          <p className="text-gray-600 text-center mt-2">
            This page is only accessible to administrators.
          </p>
        </Card>
      </div>
    );
  }

  const filteredPartners = partners.filter(partner => {
    const searchLower = searchTerm.toLowerCase();
    return (
      partner.company_name?.toLowerCase().includes(searchLower) ||
      partner.email?.toLowerCase().includes(searchLower) ||
      partner.contact_name?.toLowerCase().includes(searchLower)
    );
  });

  const stats = {
    total: partners.length,
    active: partners.filter(p => p.status === 'active').length,
    pending: partners.filter(p => p.status === 'pending').length,
    totalReferrals: partners.reduce((sum, p) => sum + (p.total_referrals || 0), 0),
    totalCommission: partners.reduce((sum, p) => sum + (p.total_commission_earned || 0), 0)
  };

  const statusConfig = {
    active: { label: 'Active', color: 'bg-green-100 text-green-800', icon: CheckCircle },
    inactive: { label: 'Inactive', color: 'bg-gray-100 text-gray-800', icon: XCircle },
    pending: { label: 'Pending', color: 'bg-yellow-100 text-yellow-800', icon: Clock },
    suspended: { label: 'Suspended', color: 'bg-red-100 text-red-800', icon: XCircle }
  };

  const partnerTypeLabels = {
    towing_company: 'Towing Company',
    insurance_provider: 'Insurance Provider',
    fleet_service: 'Fleet Service',
    corporate_partner: 'Corporate Partner',
    other: 'Other'
  };

  const resetForm = () => {
    setPartnerForm({
      company_name: '',
      contact_name: '',
      email: '',
      phone: '',
      address: '',
      partner_type: 'other',
      commission_rate: 10,
      status: 'pending',
      contract_start_date: '',
      contract_end_date: '',
      payment_terms: '',
      notes: ''
    });
  };

  const openAddPartner = () => {
    resetForm();
    setIsEditing(false);
    setShowAddPartner(true);
  };

  const openEditPartner = (partner) => {
    setPartnerForm({
      company_name: partner.company_name || '',
      contact_name: partner.contact_name || '',
      email: partner.email || '',
      phone: partner.phone || '',
      address: partner.address || '',
      partner_type: partner.partner_type || 'other',
      commission_rate: partner.commission_rate || 10,
      status: partner.status || 'pending',
      contract_start_date: partner.contract_start_date || '',
      contract_end_date: partner.contract_end_date || '',
      payment_terms: partner.payment_terms || '',
      notes: partner.notes || ''
    });
    setSelectedPartner(partner);
    setIsEditing(true);
    setShowAddPartner(true);
  };

  const viewPartnerDetails = (partner) => {
    setSelectedPartner(partner);
    setShowPartnerDetails(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    savePartner.mutate(partnerForm);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Partner Management</h1>
            <p className="text-gray-600 mt-1">Manage partner organizations and commission rates</p>
          </div>
          <Button
            onClick={openAddPartner}
            className="text-white"
            style={{ backgroundColor: '#FF771D' }}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Partner
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Partners</p>
                  <p className="text-3xl font-bold mt-1">{stats.total}</p>
                </div>
                <Briefcase className="w-10 h-10" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Partners</p>
                  <p className="text-3xl font-bold mt-1">{stats.active}</p>
                </div>
                <CheckCircle className="w-10 h-10" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Approval</p>
                  <p className="text-3xl font-bold mt-1">{stats.pending}</p>
                </div>
                <Clock className="w-10 h-10 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Referrals</p>
                  <p className="text-3xl font-bold mt-1">{stats.totalReferrals}</p>
                </div>
                <TrendingUp className="w-10 h-10" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Commission</p>
                  <p className="text-3xl font-bold mt-1">${stats.totalCommission.toFixed(2)}</p>
                </div>
                <DollarSign className="w-10 h-10" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search partners by company name, email, or contact..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Partner List */}
        <Card>
          <CardHeader>
            <CardTitle>All Partners ({filteredPartners.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredPartners.length === 0 ? (
                <div className="text-center py-12">
                  <Briefcase className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-gray-500">No partners found</p>
                </div>
              ) : (
                filteredPartners.map(partner => {
                  const statusCfg = statusConfig[partner.status] || statusConfig.pending;
                  const StatusIcon = statusCfg.icon;
                  
                  return (
                    <Card key={partner.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-4 flex-1">
                            <div className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-lg"
                                 style={{ backgroundColor: '#FF771D' }}>
                              {partner.company_name?.[0]?.toUpperCase() || 'P'}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <h3 className="font-bold text-lg">{partner.company_name}</h3>
                                <Badge className={statusCfg.color}>
                                  <StatusIcon className="w-3 h-3 mr-1" />
                                  {statusCfg.label}
                                </Badge>
                                <Badge variant="outline" className="text-xs">
                                  {partnerTypeLabels[partner.partner_type]}
                                </Badge>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-4 gap-2 text-sm text-gray-600">
                                <div className="flex items-center gap-1">
                                  <Mail className="w-4 h-4" />
                                  <span className="truncate">{partner.email}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Phone className="w-4 h-4" />
                                  <span>{partner.phone}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <DollarSign className="w-4 h-4" />
                                  <span className="font-semibold">{partner.commission_rate}% commission</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <TrendingUp className="w-4 h-4" />
                                  <span>{partner.total_referrals || 0} referrals</span>
                                </div>
                              </div>
                              {partner.contact_name && (
                                <p className="text-xs text-gray-500 mt-1">
                                  Contact: {partner.contact_name}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            {partner.ai_review && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  alert(`AI Review:\n\nRecommendation: ${partner.ai_review.recommendation}\nConfidence: ${(partner.ai_review.confidence_score * 100).toFixed(1)}%\n\nReasoning: ${partner.ai_review.reasoning}\n\nRisk Level: ${partner.ai_review.risk_level}`);
                                }}
                                className="text-blue-600 border-blue-300"
                              >
                                <FileText className="w-4 h-4" />
                              </Button>
                            )}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openEditPartner(partner)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => viewPartnerDetails(partner)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setPartnerToDelete(partner);
                                setShowDeleteDialog(true);
                              }}
                              className="text-red-600 border-red-300 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Delete Partner Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-600">
              <Trash2 className="w-5 h-5" />
              Delete Partner?
            </AlertDialogTitle>
            <AlertDialogDescription>
              <div className="space-y-3">
                <p className="font-semibold">
                  Are you sure you want to delete {partnerToDelete?.company_name}?
                </p>
                <ul className="list-disc list-inside text-sm space-y-1 text-gray-700">
                  <li>All partner information will be removed</li>
                  <li>Commission history: ${(partnerToDelete?.total_commission_earned || 0).toFixed(2)}</li>
                  <li>Total referrals: {partnerToDelete?.total_referrals || 0}</li>
                </ul>
                <p className="font-bold text-red-600 mt-3">
                  This action cannot be undone!
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletePartner.mutate(partnerToDelete.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              {deletePartner.isLoading ? 'Deleting...' : 'Delete Permanently'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Add/Edit Partner Dialog */}
      <Dialog open={showAddPartner} onOpenChange={setShowAddPartner}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{isEditing ? 'Edit Partner' : 'Add New Partner'}</DialogTitle>
            <DialogDescription>
              {isEditing ? 'Update partner information and commission rates' : 'Create a new partner account'}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Company Name *</label>
                <Input
                  value={partnerForm.company_name}
                  onChange={(e) => setPartnerForm({...partnerForm, company_name: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Contact Name</label>
                <Input
                  value={partnerForm.contact_name}
                  onChange={(e) => setPartnerForm({...partnerForm, contact_name: e.target.value})}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Email *</label>
                <Input
                  type="email"
                  value={partnerForm.email}
                  onChange={(e) => setPartnerForm({...partnerForm, email: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Phone *</label>
                <Input
                  value={partnerForm.phone}
                  onChange={(e) => setPartnerForm({...partnerForm, phone: e.target.value})}
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Address</label>
              <Input
                value={partnerForm.address}
                onChange={(e) => setPartnerForm({...partnerForm, address: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Partner Type</label>
                <Select value={partnerForm.partner_type} onValueChange={(val) => setPartnerForm({...partnerForm, partner_type: val})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(partnerTypeLabels).map(([value, label]) => (
                      <SelectItem key={value} value={value}>{label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Commission Rate (%)</label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={partnerForm.commission_rate}
                  onChange={(e) => setPartnerForm({...partnerForm, commission_rate: parseFloat(e.target.value)})}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Status</label>
                <Select value={partnerForm.status} onValueChange={(val) => setPartnerForm({...partnerForm, status: val})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Contract Start Date</label>
                <Input
                  type="date"
                  value={partnerForm.contract_start_date}
                  onChange={(e) => setPartnerForm({...partnerForm, contract_start_date: e.target.value})}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Contract End Date</label>
                <Input
                  type="date"
                  value={partnerForm.contract_end_date}
                  onChange={(e) => setPartnerForm({...partnerForm, contract_end_date: e.target.value})}
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Payment Terms</label>
              <Input
                placeholder="e.g., Net 30, Monthly payout"
                value={partnerForm.payment_terms}
                onChange={(e) => setPartnerForm({...partnerForm, payment_terms: e.target.value})}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Notes</label>
              <Textarea
                placeholder="Additional notes about this partner..."
                value={partnerForm.notes}
                onChange={(e) => setPartnerForm({...partnerForm, notes: e.target.value})}
                className="h-20"
              />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowAddPartner(false);
                  setIsEditing(false);
                }}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="text-white"
                style={{ backgroundColor: '#FF771D' }}
                disabled={savePartner.isLoading}
              >
                {savePartner.isLoading ? 'Saving...' : (isEditing ? 'Update Partner' : 'Add Partner')}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Partner Details Dialog */}
      <Dialog open={showPartnerDetails} onOpenChange={setShowPartnerDetails}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          {selectedPartner && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-lg"
                       style={{ backgroundColor: '#FF771D' }}>
                    {selectedPartner.company_name?.[0]?.toUpperCase() || 'P'}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span>{selectedPartner.company_name}</span>
                      <Badge className={statusConfig[selectedPartner.status].color}>
                        {statusConfig[selectedPartner.status].label}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-500 font-normal">
                      {partnerTypeLabels[selectedPartner.partner_type]}
                    </p>
                  </div>
                </DialogTitle>
              </DialogHeader>

              <Tabs defaultValue="details" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="jobs">Referred Jobs</TabsTrigger>
                  <TabsTrigger value="commission">Commission</TabsTrigger>
                </TabsList>

                <TabsContent value="details" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Contact Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600 mb-1">Contact Person</p>
                          <p className="font-semibold">{selectedPartner.contact_name || 'Not specified'}</p>
                        </div>
                        <div>
                          <p className="text-gray-600 mb-1">Email</p>
                          <p className="font-semibold">{selectedPartner.email}</p>
                        </div>
                        <div>
                          <p className="text-gray-600 mb-1">Phone</p>
                          <p className="font-semibold">{selectedPartner.phone}</p>
                        </div>
                        <div>
                          <p className="text-gray-600 mb-1">Address</p>
                          <p className="font-semibold">{selectedPartner.address || 'Not specified'}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Partnership Terms</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600 mb-1">Commission Rate</p>
                          <p className="font-semibold text-lg" style={{ color: '#3D692B' }}>
                            {selectedPartner.commission_rate}%
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-600 mb-1">Payment Terms</p>
                          <p className="font-semibold">{selectedPartner.payment_terms || 'Not specified'}</p>
                        </div>
                        {selectedPartner.contract_start_date && (
                          <div>
                            <p className="text-gray-600 mb-1">Contract Start</p>
                            <p className="font-semibold">
                              {format(new Date(selectedPartner.contract_start_date), 'MMM d, yyyy')}
                            </p>
                          </div>
                        )}
                        {selectedPartner.contract_end_date && (
                          <div>
                            <p className="text-gray-600 mb-1">Contract End</p>
                            <p className="font-semibold">
                              {format(new Date(selectedPartner.contract_end_date), 'MMM d, yyyy')}
                            </p>
                          </div>
                        )}
                      </div>
                      {selectedPartner.notes && (
                        <div className="mt-4">
                          <p className="text-gray-600 mb-1">Notes</p>
                          <p className="text-sm">{selectedPartner.notes}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="jobs" className="space-y-3">
                  <div className="text-center py-12">
                    <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p className="text-gray-500">No referred jobs yet</p>
                    <p className="text-xs text-gray-400 mt-1">
                      Jobs will appear here when customers are referred by this partner
                    </p>
                  </div>
                </TabsContent>

                <TabsContent value="commission">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Commission Overview</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-3 gap-4 mb-6">
                        <div className="text-center p-4 bg-gray-50 rounded-lg">
                          <p className="text-3xl font-bold" style={{ color: '#FF771D' }}>
                            {selectedPartner.total_referrals || 0}
                          </p>
                          <p className="text-sm text-gray-600 mt-1">Total Referrals</p>
                        </div>
                        <div className="text-center p-4 bg-green-50 rounded-lg">
                          <p className="text-3xl font-bold" style={{ color: '#3D692B' }}>
                            ${(selectedPartner.total_commission_earned || 0).toFixed(2)}
                          </p>
                          <p className="text-sm text-gray-600 mt-1">Commission Earned</p>
                        </div>
                        <div className="text-center p-4 bg-blue-50 rounded-lg">
                          <p className="text-3xl font-bold text-blue-600">
                            {selectedPartner.commission_rate}%
                          </p>
                          <p className="text-sm text-gray-600 mt-1">Commission Rate</p>
                        </div>
                      </div>

                      <div className="border-t pt-4">
                        <h4 className="font-semibold mb-3">Update Commission Rate</h4>
                        <div className="flex gap-3">
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            step="0.1"
                            defaultValue={selectedPartner.commission_rate}
                            id="new-commission-rate"
                            className="max-w-xs"
                          />
                          <Button
                            onClick={() => {
                              const newRate = parseFloat(document.getElementById('new-commission-rate').value);
                              updateCommissionRate.mutate({ partnerId: selectedPartner.id, newRate });
                            }}
                            className="text-white"
                            style={{ backgroundColor: '#FF771D' }}
                          >
                            Update Rate
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}