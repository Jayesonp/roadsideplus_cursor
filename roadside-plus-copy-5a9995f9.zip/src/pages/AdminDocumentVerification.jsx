import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, XCircle, FileText, ExternalLink, AlertTriangle, Check } from 'lucide-react';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import ErrorState from '@/components/common/ErrorState';

export default function AdminDocumentVerification() {
  const queryClient = useQueryClient();
  const [selectedProfile, setSelectedProfile] = useState(null);

  // Fetch all technician profiles
  const { data: profiles = [], isLoading, isError, error } = useQuery({
    queryKey: ['admin-technician-profiles'],
    queryFn: async () => {
      const allProfiles = await base44.entities.TechnicianProfile.list();
      // Fetch user details for these profiles to show names
      const userIds = allProfiles.map(p => p.user_id);
      const users = await Promise.all(userIds.map(id => base44.entities.User.filter({ id })));
      const userMap = {};
      users.flat().forEach(u => { if(u) userMap[u.id] = u; });
      
      return allProfiles.map(profile => ({
        ...profile,
        user: userMap[profile.user_id] || { full_name: 'Unknown', email: 'Unknown' }
      }));
    }
  });

  const approveMutation = useMutation({
    mutationFn: async (profileId) => {
      return await base44.entities.TechnicianProfile.update(profileId, {
        documents_approved_by_admin: true
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-technician-profiles']);
      setSelectedProfile(null);
    }
  });

  const revokeMutation = useMutation({
    mutationFn: async (profileId) => {
      return await base44.entities.TechnicianProfile.update(profileId, {
        documents_approved_by_admin: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-technician-profiles']);
      setSelectedProfile(null);
    }
  });

  if (isLoading) return <div className="p-8"><LoadingSpinner message="Loading technicians..." /></div>;
  if (isError) return <div className="p-8"><ErrorState message={error?.message || "Failed to load data"} /></div>;

  const pendingProfiles = profiles.filter(p => p.onboarding_completed && !p.documents_approved_by_admin);
  const approvedProfiles = profiles.filter(p => p.documents_approved_by_admin);
  const incompleteProfiles = profiles.filter(p => !p.onboarding_completed);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Document Verification</h1>
          <p className="text-gray-500 mt-1">Review and approve technician documents</p>
        </div>
      </div>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="pending">
            Pending ({pendingProfiles.length})
          </TabsTrigger>
          <TabsTrigger value="approved">
            Approved ({approvedProfiles.length})
          </TabsTrigger>
          <TabsTrigger value="incomplete">
            Incomplete ({incompleteProfiles.length})
          </TabsTrigger>
        </TabsList>

        {/* Pending Tab */}
        <TabsContent value="pending" className="space-y-4 mt-6">
          {pendingProfiles.length === 0 ? (
            <Card className="bg-gray-50 border-dashed">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <CheckCircle className="w-12 h-12 text-green-500 mb-4" />
                <h3 className="text-lg font-medium text-gray-900">All Caught Up!</h3>
                <p className="text-gray-500">No pending document approvals.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pendingProfiles.map(profile => (
                <TechnicianCard 
                  key={profile.id} 
                  profile={profile} 
                  onApprove={() => approveMutation.mutate(profile.id)}
                  status="pending"
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* Approved Tab */}
        <TabsContent value="approved" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {approvedProfiles.map(profile => (
              <TechnicianCard 
                key={profile.id} 
                profile={profile} 
                onRevoke={() => revokeMutation.mutate(profile.id)}
                status="approved"
              />
            ))}
          </div>
        </TabsContent>

        {/* Incomplete Tab */}
        <TabsContent value="incomplete" className="space-y-4 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {incompleteProfiles.map(profile => (
              <TechnicianCard 
                key={profile.id} 
                profile={profile} 
                status="incomplete"
              />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function TechnicianCard({ profile, onApprove, onRevoke, status }) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{profile.user.full_name}</CardTitle>
            <p className="text-sm text-gray-500">{profile.user.email}</p>
          </div>
          <Badge variant={status === 'approved' ? 'default' : status === 'pending' ? 'secondary' : 'outline'}>
            {status === 'approved' ? 'Verified' : status === 'pending' ? 'Review Needed' : 'Incomplete'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="col-span-2">
            <span className="text-gray-500">Vehicle:</span> <span className="font-medium">{profile.vehicle_year} {profile.vehicle_make} {profile.vehicle_model}</span>
          </div>
          <div className="col-span-2">
            <span className="text-gray-500">Plate:</span> <span className="font-medium">{profile.license_plate}</span>
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-sm font-medium text-gray-700">Documents</p>
          <div className="grid grid-cols-2 gap-2">
            {profile.drivers_license_url ? (
              <a href={profile.drivers_license_url} target="_blank" rel="noopener noreferrer" className="block group relative aspect-video bg-gray-100 rounded-md overflow-hidden border">
                <img src={profile.drivers_license_url} alt="License" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <ExternalLink className="text-white w-5 h-5" />
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-1 truncate">Driver's License</div>
              </a>
            ) : (
              <div className="aspect-video bg-gray-50 rounded-md flex items-center justify-center border border-dashed text-gray-400 text-xs text-center p-2">
                No License
              </div>
            )}

            {profile.insurance_url ? (
              <a href={profile.insurance_url} target="_blank" rel="noopener noreferrer" className="block group relative aspect-video bg-gray-100 rounded-md overflow-hidden border">
                <img src={profile.insurance_url} alt="Insurance" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <ExternalLink className="text-white w-5 h-5" />
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-1 truncate">Insurance</div>
              </a>
            ) : (
              <div className="aspect-video bg-gray-50 rounded-md flex items-center justify-center border border-dashed text-gray-400 text-xs text-center p-2">
                No Insurance
              </div>
            )}
          </div>
        </div>

        <div className="pt-2">
          {status === 'pending' && (
            <Button 
              onClick={onApprove} 
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <Check className="w-4 h-4 mr-2" />
              Approve Documents
            </Button>
          )}
          
          {status === 'approved' && (
            <Button 
              onClick={onRevoke} 
              variant="outline"
              className="w-full border-red-200 text-red-600 hover:bg-red-50"
            >
              <XCircle className="w-4 h-4 mr-2" />
              Revoke Approval
            </Button>
          )}

          {status === 'incomplete' && (
            <p className="text-xs text-center text-gray-400 italic">
              Waiting for user to complete onboarding
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}