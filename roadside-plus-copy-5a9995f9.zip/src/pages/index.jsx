import Layout from "./Layout.jsx";

import RoleSelection from "./RoleSelection";

import CustomerDashboard from "./CustomerDashboard";

import RequestService from "./RequestService";

import TechnicianDashboard from "./TechnicianDashboard";

import ServiceDetails from "./ServiceDetails";

import JobDetails from "./JobDetails";

import Profile from "./Profile";

import TechnicianProfile from "./TechnicianProfile";

import TechnicianOnboarding from "./TechnicianOnboarding";

import Register from "./Register";

import ForgotPassword from "./ForgotPassword";

import FeedbackAnalytics from "./FeedbackAnalytics";

import Payment from "./Payment";

import Settings from "./Settings";

import AdminPerformanceDashboard from "./AdminPerformanceDashboard";

import AdminJobMonitoring from "./AdminJobMonitoring";

import AdminTechnicianManagement from "./AdminTechnicianManagement";

import TechnicianJobQueue from "./TechnicianJobQueue";

import AdminSupportDashboard from "./AdminSupportDashboard";

import AdminAnalyticsDashboard from "./AdminAnalyticsDashboard";

import AdminDispatchMonitor from "./AdminDispatchMonitor";

import CustomerPayment from "./CustomerPayment";

import PaymentStatus from "./PaymentStatus";

import SupportCenter from "./SupportCenter";

import TermsAcceptance from "./TermsAcceptance";

import AdminDashboard from "./AdminDashboard";

import AdminDispatchSettings from "./AdminDispatchSettings";

import AdminCustomerManagement from "./AdminCustomerManagement";

import AdminPartnerManagement from "./AdminPartnerManagement";

import AdminManualDispatch from "./AdminManualDispatch";

import PartnerRegistration from "./PartnerRegistration";

import PartnerPortal from "./PartnerPortal";

import PartnerDashboard from "./PartnerDashboard";

import AdminPartnerPayouts from "./AdminPartnerPayouts";

import PartnerPayoutHistory from "./PartnerPayoutHistory";

import PartnerSettings from "./PartnerSettings";

import PartnerAnalytics from "./PartnerAnalytics";

import AISupportChat from "./AISupportChat";

import PartnerClientManagement from "./PartnerClientManagement";

import PartnerStaffManagement from "./PartnerStaffManagement";

import PartnerReferralDashboard from "./PartnerReferralDashboard";

import PartnerStripeConnect from "./PartnerStripeConnect";

import PartnerContracts from "./PartnerContracts";

import AdminPartnerContracts from "./AdminPartnerContracts";

import AdminAdvertisements from "./AdminAdvertisements";

import AdminGeofenceSettings from "./AdminGeofenceSettings";

import SecurityLogin from "./SecurityLogin";

import SecurityCommandCenter from "./SecurityCommandCenter";

import SecurityIncidentDetail from "./SecurityIncidentDetail";

import SecurityAnalytics from "./SecurityAnalytics";

import SecurityRouteOptimizer from "./SecurityRouteOptimizer";

import SecurityOfficerMobile from "./SecurityOfficerMobile";

import TrackProvider from "./TrackProvider";

import TechnicianOnboardingChecklist from "./TechnicianOnboardingChecklist";

import TechnicianPerformance from "./TechnicianPerformance";

import AddPaymentCard from "./AddPaymentCard";

import ServiceOptions from "./ServiceOptions";

import ServiceConfirmation from "./ServiceConfirmation";

import RegisterCustomer from "./RegisterCustomer";

import RegisterTechnician from "./RegisterTechnician";

import RegisterPartner from "./RegisterPartner";

import RegisterSecurityCompany from "./RegisterSecurityCompany";

import RegisterSelection from "./RegisterSelection";

import AdminReferralManagement from "./AdminReferralManagement";

import NotificationSettings from "./NotificationSettings";

import OTPVerification from "./OTPVerification";

import AdminServiceRequestMonitor from "./AdminServiceRequestMonitor";

import AdminTechnicianPayouts from "./AdminTechnicianPayouts";

import AdminReviewManagement from "./AdminReviewManagement";

import AdminUserManagement from "./AdminUserManagement";

import AdminDocumentVerification from "./AdminDocumentVerification";

import JobHistory from "./JobHistory";

import PremiumUpgrade from "./PremiumUpgrade";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    RoleSelection: RoleSelection,
    
    CustomerDashboard: CustomerDashboard,
    
    RequestService: RequestService,
    
    TechnicianDashboard: TechnicianDashboard,
    
    ServiceDetails: ServiceDetails,
    
    JobDetails: JobDetails,
    
    Profile: Profile,
    
    TechnicianProfile: TechnicianProfile,
    
    TechnicianOnboarding: TechnicianOnboarding,
    
    Register: Register,
    
    ForgotPassword: ForgotPassword,
    
    FeedbackAnalytics: FeedbackAnalytics,
    
    Payment: Payment,
    
    Settings: Settings,
    
    AdminPerformanceDashboard: AdminPerformanceDashboard,
    
    AdminJobMonitoring: AdminJobMonitoring,
    
    AdminTechnicianManagement: AdminTechnicianManagement,
    
    TechnicianJobQueue: TechnicianJobQueue,
    
    AdminSupportDashboard: AdminSupportDashboard,
    
    AdminAnalyticsDashboard: AdminAnalyticsDashboard,
    
    AdminDispatchMonitor: AdminDispatchMonitor,
    
    CustomerPayment: CustomerPayment,
    
    PaymentStatus: PaymentStatus,
    
    SupportCenter: SupportCenter,
    
    TermsAcceptance: TermsAcceptance,
    
    AdminDashboard: AdminDashboard,
    
    AdminDispatchSettings: AdminDispatchSettings,
    
    AdminCustomerManagement: AdminCustomerManagement,
    
    AdminPartnerManagement: AdminPartnerManagement,
    
    AdminManualDispatch: AdminManualDispatch,
    
    PartnerRegistration: PartnerRegistration,
    
    PartnerPortal: PartnerPortal,
    
    PartnerDashboard: PartnerDashboard,
    
    AdminPartnerPayouts: AdminPartnerPayouts,
    
    PartnerPayoutHistory: PartnerPayoutHistory,
    
    PartnerSettings: PartnerSettings,
    
    PartnerAnalytics: PartnerAnalytics,
    
    AISupportChat: AISupportChat,
    
    PartnerClientManagement: PartnerClientManagement,
    
    PartnerStaffManagement: PartnerStaffManagement,
    
    PartnerReferralDashboard: PartnerReferralDashboard,
    
    PartnerStripeConnect: PartnerStripeConnect,
    
    PartnerContracts: PartnerContracts,
    
    AdminPartnerContracts: AdminPartnerContracts,
    
    AdminAdvertisements: AdminAdvertisements,
    
    AdminGeofenceSettings: AdminGeofenceSettings,
    
    SecurityLogin: SecurityLogin,
    
    SecurityCommandCenter: SecurityCommandCenter,
    
    SecurityIncidentDetail: SecurityIncidentDetail,
    
    SecurityAnalytics: SecurityAnalytics,
    
    SecurityRouteOptimizer: SecurityRouteOptimizer,
    
    SecurityOfficerMobile: SecurityOfficerMobile,
    
    TrackProvider: TrackProvider,
    
    TechnicianOnboardingChecklist: TechnicianOnboardingChecklist,
    
    TechnicianPerformance: TechnicianPerformance,
    
    AddPaymentCard: AddPaymentCard,
    
    ServiceOptions: ServiceOptions,
    
    ServiceConfirmation: ServiceConfirmation,
    
    RegisterCustomer: RegisterCustomer,
    
    RegisterTechnician: RegisterTechnician,
    
    RegisterPartner: RegisterPartner,
    
    RegisterSecurityCompany: RegisterSecurityCompany,
    
    RegisterSelection: RegisterSelection,
    
    AdminReferralManagement: AdminReferralManagement,
    
    NotificationSettings: NotificationSettings,
    
    OTPVerification: OTPVerification,
    
    AdminServiceRequestMonitor: AdminServiceRequestMonitor,
    
    AdminTechnicianPayouts: AdminTechnicianPayouts,
    
    AdminReviewManagement: AdminReviewManagement,
    
    AdminUserManagement: AdminUserManagement,
    
    AdminDocumentVerification: AdminDocumentVerification,
    
    JobHistory: JobHistory,
    
    PremiumUpgrade: PremiumUpgrade,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<RoleSelection />} />
                
                
                <Route path="/RoleSelection" element={<RoleSelection />} />
                
                <Route path="/CustomerDashboard" element={<CustomerDashboard />} />
                
                <Route path="/RequestService" element={<RequestService />} />
                
                <Route path="/TechnicianDashboard" element={<TechnicianDashboard />} />
                
                <Route path="/ServiceDetails" element={<ServiceDetails />} />
                
                <Route path="/JobDetails" element={<JobDetails />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/TechnicianProfile" element={<TechnicianProfile />} />
                
                <Route path="/TechnicianOnboarding" element={<TechnicianOnboarding />} />
                
                <Route path="/Register" element={<Register />} />
                
                <Route path="/ForgotPassword" element={<ForgotPassword />} />
                
                <Route path="/FeedbackAnalytics" element={<FeedbackAnalytics />} />
                
                <Route path="/Payment" element={<Payment />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/AdminPerformanceDashboard" element={<AdminPerformanceDashboard />} />
                
                <Route path="/AdminJobMonitoring" element={<AdminJobMonitoring />} />
                
                <Route path="/AdminTechnicianManagement" element={<AdminTechnicianManagement />} />
                
                <Route path="/TechnicianJobQueue" element={<TechnicianJobQueue />} />
                
                <Route path="/AdminSupportDashboard" element={<AdminSupportDashboard />} />
                
                <Route path="/AdminAnalyticsDashboard" element={<AdminAnalyticsDashboard />} />
                
                <Route path="/AdminDispatchMonitor" element={<AdminDispatchMonitor />} />
                
                <Route path="/CustomerPayment" element={<CustomerPayment />} />
                
                <Route path="/PaymentStatus" element={<PaymentStatus />} />
                
                <Route path="/SupportCenter" element={<SupportCenter />} />
                
                <Route path="/TermsAcceptance" element={<TermsAcceptance />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/AdminDispatchSettings" element={<AdminDispatchSettings />} />
                
                <Route path="/AdminCustomerManagement" element={<AdminCustomerManagement />} />
                
                <Route path="/AdminPartnerManagement" element={<AdminPartnerManagement />} />
                
                <Route path="/AdminManualDispatch" element={<AdminManualDispatch />} />
                
                <Route path="/PartnerRegistration" element={<PartnerRegistration />} />
                
                <Route path="/PartnerPortal" element={<PartnerPortal />} />
                
                <Route path="/PartnerDashboard" element={<PartnerDashboard />} />
                
                <Route path="/AdminPartnerPayouts" element={<AdminPartnerPayouts />} />
                
                <Route path="/PartnerPayoutHistory" element={<PartnerPayoutHistory />} />
                
                <Route path="/PartnerSettings" element={<PartnerSettings />} />
                
                <Route path="/PartnerAnalytics" element={<PartnerAnalytics />} />
                
                <Route path="/AISupportChat" element={<AISupportChat />} />
                
                <Route path="/PartnerClientManagement" element={<PartnerClientManagement />} />
                
                <Route path="/PartnerStaffManagement" element={<PartnerStaffManagement />} />
                
                <Route path="/PartnerReferralDashboard" element={<PartnerReferralDashboard />} />
                
                <Route path="/PartnerStripeConnect" element={<PartnerStripeConnect />} />
                
                <Route path="/PartnerContracts" element={<PartnerContracts />} />
                
                <Route path="/AdminPartnerContracts" element={<AdminPartnerContracts />} />
                
                <Route path="/AdminAdvertisements" element={<AdminAdvertisements />} />
                
                <Route path="/AdminGeofenceSettings" element={<AdminGeofenceSettings />} />
                
                <Route path="/SecurityLogin" element={<SecurityLogin />} />
                
                <Route path="/SecurityCommandCenter" element={<SecurityCommandCenter />} />
                
                <Route path="/SecurityIncidentDetail" element={<SecurityIncidentDetail />} />
                
                <Route path="/SecurityAnalytics" element={<SecurityAnalytics />} />
                
                <Route path="/SecurityRouteOptimizer" element={<SecurityRouteOptimizer />} />
                
                <Route path="/SecurityOfficerMobile" element={<SecurityOfficerMobile />} />
                
                <Route path="/TrackProvider" element={<TrackProvider />} />
                
                <Route path="/TechnicianOnboardingChecklist" element={<TechnicianOnboardingChecklist />} />
                
                <Route path="/TechnicianPerformance" element={<TechnicianPerformance />} />
                
                <Route path="/AddPaymentCard" element={<AddPaymentCard />} />
                
                <Route path="/ServiceOptions" element={<ServiceOptions />} />
                
                <Route path="/ServiceConfirmation" element={<ServiceConfirmation />} />
                
                <Route path="/RegisterCustomer" element={<RegisterCustomer />} />
                
                <Route path="/RegisterTechnician" element={<RegisterTechnician />} />
                
                <Route path="/RegisterPartner" element={<RegisterPartner />} />
                
                <Route path="/RegisterSecurityCompany" element={<RegisterSecurityCompany />} />
                
                <Route path="/RegisterSelection" element={<RegisterSelection />} />
                
                <Route path="/AdminReferralManagement" element={<AdminReferralManagement />} />
                
                <Route path="/NotificationSettings" element={<NotificationSettings />} />
                
                <Route path="/OTPVerification" element={<OTPVerification />} />
                
                <Route path="/AdminServiceRequestMonitor" element={<AdminServiceRequestMonitor />} />
                
                <Route path="/AdminTechnicianPayouts" element={<AdminTechnicianPayouts />} />
                
                <Route path="/AdminReviewManagement" element={<AdminReviewManagement />} />
                
                <Route path="/AdminUserManagement" element={<AdminUserManagement />} />
                
                <Route path="/AdminDocumentVerification" element={<AdminDocumentVerification />} />
                
                <Route path="/JobHistory" element={<JobHistory />} />
                
                <Route path="/PremiumUpgrade" element={<PremiumUpgrade />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}