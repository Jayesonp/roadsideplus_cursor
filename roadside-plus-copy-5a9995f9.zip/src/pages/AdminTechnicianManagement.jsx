import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Users, AlertCircle, Star, Phone, Car, Award, 
  Search, MapPin, CheckCircle, Clock, Coffee, XCircle,
  Eye, MessageSquare, Trash2
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';

const availabilityConfig = {
  available: {
    label: 'Available',
    color: 'bg-green-100 text-green-800 border-green-300',
    icon: CheckCircle,
    iconColor: '#3D692B'
  },
  on_job: {
    label: 'On Job',
    color: 'bg-blue-100 text-blue-800 border-blue-300',
    icon: Clock,
    iconColor: '#FF771D'
  },
  break: {
    label: 'On Break',
    color: 'bg-yellow-100 text-yellow-800 border-yellow-300',
    icon: Coffee,
    iconColor: '#FF771D'
  },
  offline: {
    label: 'Offline',
    color: 'bg-gray-100 text-gray-800 border-gray-300',
    icon: XCircle,
    iconColor: '#999'
  }
};

export default function AdminTechnicianManagement() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedTech, setSelectedTech] = useState(null);
  const [showReviews, setShowReviews] = useState(false);
  const [showJobs, setShowJobs] = useState(false);
  const [techToDelete, setTechToDelete] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedTechs, setSelectedTechs] = useState(new Set());
  const [showBulkActions, setShowBulkActions] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  // Fetch all technicians
  const { data: technicians = [] } = useQuery({
    queryKey: ['all-technicians'],
    queryFn: async () => {
      return await base44.entities.TechnicianProfile.list('-updated_date');
    },
    refetchInterval: 10000, // Refresh every 10 seconds
    enabled: !!user && user.role === 'admin'
  });

  // Fetch active jobs for each technician
  const { data: activeJobs = [] } = useQuery({
    queryKey: ['active-technician-jobs'],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter({
        status: ['assigned', 'en_route', 'arrived', 'in_progress', 'awaiting_review']
      });
    },
    refetchInterval: 10000,
    enabled: !!user && user.role === 'admin'
  });

  // Fetch all ratings
  const { data: allRatings = [] } = useQuery({
    queryKey: ['all-technician-ratings'],
    queryFn: async () => {
      return await base44.entities.Rating.list('-created_date', 500);
    },
    enabled: !!user && user.role === 'admin'
  });

  // Fetch completed jobs for selected technician
  const { data: techJobs = [] } = useQuery({
    queryKey: ['tech-jobs', selectedTech?.user_id],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter(
        { technician_id: selectedTech.user_id, status: 'completed' },
        '-completed_at'
      );
    },
    enabled: !!selectedTech && !!user && user.role === 'admin'
  });

  // Fetch ratings for selected technician
  const { data: techRatings = [] } = useQuery({
    queryKey: ['tech-ratings', selectedTech?.user_id],
    queryFn: async () => {
      return await base44.entities.Rating.filter(
        { technician_id: selectedTech.user_id },
        '-created_date'
      );
    },
    enabled: !!selectedTech && !!user && user.role === 'admin'
  });

  const bulkUpdateStatus = useMutation({
    mutationFn: async (newStatus) => {
      const updates = [];
      for (const techId of selectedTechs) {
        const tech = technicians.find(t => t.user_id === techId);
        if (tech) {
          updates.push(
            base44.entities.TechnicianProfile.update(tech.id, {
              availability_status: newStatus,
              is_available: newStatus !== 'offline'
            })
          );
        }
      }
      await Promise.all(updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['all-technicians']);
      setSelectedTechs(new Set());
      setShowBulkActions(false);
    }
  });

  const deleteTechnician = useMutation({
    mutationFn: async (techId) => {
      // Cascading delete: service requests, ratings, messages, notifications, location history
      const requests = await base44.entities.ServiceRequest.filter({ technician_id: techId });
      const ratings = await base44.entities.Rating.filter({ technician_id: techId });
      const messages = await base44.entities.Message.filter({ sender_id: techId });
      const notifications = await base44.entities.Notification.filter({ user_id: techId });
      const locations = await base44.entities.TechnicianLocation.filter({ technician_id: techId });
      const attachments = await base44.entities.ServiceAttachment.list();

      // Delete service attachments for technician's jobs
      const requestIds = requests.map(r => r.id);
      for (const attachment of attachments) {
        if (requestIds.includes(attachment.service_request_id)) {
          await base44.entities.ServiceAttachment.delete({ id: attachment.id });
        }
      }

      // Delete service requests
      for (const request of requests) {
        await base44.entities.ServiceRequest.delete({ id: request.id });
      }

      // Delete ratings
      for (const rating of ratings) {
        await base44.entities.Rating.delete({ id: rating.id });
      }

      // Delete messages
      for (const message of messages) {
        await base44.entities.Message.delete({ id: message.id });
      }

      // Delete notifications
      for (const notification of notifications) {
        await base44.entities.Notification.delete({ id: notification.id });
      }

      // Delete location history
      for (const location of locations) {
        await base44.entities.TechnicianLocation.delete({ id: location.id });
      }

      // Delete technician profile
      const profile = await base44.entities.TechnicianProfile.filter({ user_id: techId });
      if (profile.length > 0) {
        await base44.entities.TechnicianProfile.delete({ id: profile[0].id });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['all-technicians']);
      setShowDeleteDialog(false);
      setTechToDelete(null);
    }
  });

  // Check admin access
  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8">
          <AlertCircle className="w-12 h-12 mx-auto mb-4" style={{ color: '#E52C2D' }} />
          <h2 className="text-xl font-bold text-center">Access Denied</h2>
          <p className="text-gray-600 text-center mt-2">
            This page is only accessible to administrators.
          </p>
        </Card>
      </div>
    );
  }

  const filteredTechnicians = technicians.filter(tech => {
    const searchLower = searchTerm.toLowerCase();
    const searchMatch = (
      tech.phone?.toLowerCase().includes(searchLower) ||
      tech.vehicle_type?.toLowerCase().includes(searchLower) ||
      tech.license_plate?.toLowerCase().includes(searchLower) ||
      tech.user_id?.toLowerCase().includes(searchLower)
    );
    
    const statusMatch = statusFilter === 'all' || tech.availability_status === statusFilter;
    
    return searchMatch && statusMatch;
  });

  const getTechnicianActiveJob = (techId) => {
    return activeJobs.find(job => job.technician_id === techId);
  };

  const getTechRatingCount = (techId) => {
    return allRatings.filter(r => r.technician_id === techId).length;
  };

  const viewTechnicianReviews = (tech) => {
    setSelectedTech(tech);
    setShowReviews(true);
  };

  const viewTechnicianJobs = (tech) => {
    setSelectedTech(tech);
    setShowJobs(true);
  };

  const toggleTechSelection = (techId) => {
    const newSelected = new Set(selectedTechs);
    if (newSelected.has(techId)) {
      newSelected.delete(techId);
    } else {
      newSelected.add(techId);
    }
    setSelectedTechs(newSelected);
    setShowBulkActions(newSelected.size > 0);
  };

  const selectAllTechs = () => {
    if (selectedTechs.size === filteredTechnicians.length) {
      setSelectedTechs(new Set());
      setShowBulkActions(false);
    } else {
      setSelectedTechs(new Set(filteredTechnicians.map(t => t.user_id)));
      setShowBulkActions(true);
    }
  };

  const stats = {
    total: technicians.length,
    available: technicians.filter(t => t.availability_status === 'available').length,
    onJob: technicians.filter(t => t.availability_status === 'on_job').length,
    break: technicians.filter(t => t.availability_status === 'break').length,
    offline: technicians.filter(t => t.availability_status === 'offline').length
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Technician Management</h1>
          <p className="text-gray-600 mt-1">Monitor and manage all technician profiles</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Technicians</p>
                  <p className="text-2xl font-bold mt-1">{stats.total}</p>
                </div>
                <Users className="w-8 h-8" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Available</p>
                  <p className="text-2xl font-bold mt-1">{stats.available}</p>
                </div>
                <CheckCircle className="w-8 h-8" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">On Job</p>
                  <p className="text-2xl font-bold mt-1">{stats.onJob}</p>
                </div>
                <Clock className="w-8 h-8" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">On Break</p>
                  <p className="text-2xl font-bold mt-1">{stats.break}</p>
                </div>
                <Coffee className="w-8 h-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Offline</p>
                  <p className="text-2xl font-bold mt-1">{stats.offline}</p>
                </div>
                <XCircle className="w-8 h-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search by phone, vehicle, license plate, or ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="available">Available</SelectItem>
                    <SelectItem value="on_job">On Job</SelectItem>
                    <SelectItem value="break">On Break</SelectItem>
                    <SelectItem value="offline">Offline</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Bulk Actions Bar */}
        {showBulkActions && (
          <Card className="mb-6 border-2" style={{ borderColor: '#FF771D' }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5" style={{ color: '#FF771D' }} />
                  <span className="font-semibold">{selectedTechs.size} technician(s) selected</span>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => bulkUpdateStatus.mutate('available')}
                    disabled={bulkUpdateStatus.isLoading}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    Enable Selected
                  </Button>
                  <Button
                    onClick={() => bulkUpdateStatus.mutate('offline')}
                    disabled={bulkUpdateStatus.isLoading}
                    variant="outline"
                    className="text-gray-600 border-gray-300"
                  >
                    Disable Selected
                  </Button>
                  <Button
                    onClick={() => {
                      setSelectedTechs(new Set());
                      setShowBulkActions(false);
                    }}
                    variant="ghost"
                  >
                    Clear
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Select All */}
        {filteredTechnicians.length > 0 && (
          <div className="mb-4 flex items-center gap-2">
            <input
              type="checkbox"
              checked={selectedTechs.size === filteredTechnicians.length && filteredTechnicians.length > 0}
              onChange={selectAllTechs}
              className="w-4 h-4 cursor-pointer"
            />
            <label className="text-sm font-medium cursor-pointer" onClick={selectAllTechs}>
              Select All ({filteredTechnicians.length})
            </label>
          </div>
        )}

        {/* Technician Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTechnicians.map(tech => {
            const activeJob = getTechnicianActiveJob(tech.user_id);
            const availConfig = availabilityConfig[tech.availability_status] || availabilityConfig.offline;
            const AvailIcon = availConfig.icon;

            return (
              <Card key={tech.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex items-start gap-4">
                    <input
                      type="checkbox"
                      checked={selectedTechs.has(tech.user_id)}
                      onChange={() => toggleTechSelection(tech.user_id)}
                      className="mt-2 w-4 h-4 cursor-pointer"
                      onClick={(e) => e.stopPropagation()}
                    />
                    {tech.profile_picture ? (
                      <img
                        src={tech.profile_picture}
                        alt="Profile"
                        className="w-16 h-16 rounded-full object-cover border-4"
                        style={{ borderColor: '#FF771D' }}
                      />
                    ) : (
                      <div
                        className="w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold"
                        style={{ backgroundColor: '#FF771D' }}
                      >
                        T
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-lg truncate">
                        Tech {tech.user_id.substring(0, 8)}
                      </h3>
                      <Badge className={`${availConfig.color} border flex items-center gap-1 w-fit`}>
                        <AvailIcon className="w-3 h-3" style={{ color: availConfig.iconColor }} />
                        {availConfig.label}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-3">
                  {/* Rating */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-semibold">{tech.rating?.toFixed(1) || '5.0'}</span>
                      <span className="text-gray-500 text-sm">
                        ({getTechRatingCount(tech.user_id)} reviews)
                      </span>
                    </div>
                    {getTechRatingCount(tech.user_id) > 0 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => viewTechnicianReviews(tech)}
                        className="text-xs h-7"
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        View
                      </Button>
                    )}
                  </div>

                  {/* Phone */}
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="w-4 h-4" style={{ color: '#FF771D' }} />
                    <span>{tech.phone}</span>
                  </div>

                  {/* Vehicle */}
                  {tech.vehicle_type && (
                    <div className="flex items-center gap-2 text-sm">
                      <Car className="w-4 h-4" style={{ color: '#FF771D' }} />
                      <span>{tech.vehicle_type}</span>
                      {tech.license_plate && (
                        <Badge variant="outline" className="ml-auto">
                          {tech.license_plate}
                        </Badge>
                      )}
                    </div>
                  )}

                  {/* Location */}
                  {tech.current_lat && tech.current_lng && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <span>
                        {tech.current_lat.toFixed(4)}, {tech.current_lng.toFixed(4)}
                      </span>
                    </div>
                  )}

                  {/* Skills & Certifications */}
                  {tech.skills_certifications && tech.skills_certifications.length > 0 && (
                    <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                      <div className="flex items-center gap-2 text-sm font-semibold mb-2">
                        <Award className="w-4 h-4" style={{ color: '#3D692B' }} />
                        Skills & Certifications
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {tech.skills_certifications.map((skill, index) => (
                          <Badge
                            key={index}
                            className="text-xs text-white"
                            style={{ backgroundColor: '#3D692B' }}
                          >
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Specialties */}
                  {tech.specialties && tech.specialties.length > 0 && (
                    <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                      <div className="text-sm font-semibold mb-2" style={{ color: '#FF771D' }}>
                        Service Specialties
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {tech.specialties.map((specialty, index) => (
                          <Badge 
                            key={index} 
                            variant="outline" 
                            className="text-xs border-orange-300"
                            style={{ color: '#FF771D' }}
                          >
                            {specialty}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Active Job */}
                  {activeJob && (
                    <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <p className="text-xs font-semibold text-blue-900 mb-1">
                        Currently on Job
                      </p>
                      <p className="text-xs text-blue-700">
                        {activeJob.service_type.replace(/_/g, ' ').toUpperCase()}
                      </p>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="grid grid-cols-2 gap-2 mt-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewTechnicianJobs(tech)}
                      className="flex items-center justify-center gap-1"
                    >
                      <Eye className="w-3 h-3" />
                      Jobs
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setTechToDelete(tech);
                        setShowDeleteDialog(true);
                      }}
                      className="text-red-600 border-red-300 hover:bg-red-50 flex items-center justify-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredTechnicians.length === 0 && (
          <div className="text-center py-12">
            <Users className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <p className="text-gray-500">No technicians found</p>
          </div>
        )}
      </div>

      {/* Delete Technician Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-600">
              <Trash2 className="w-5 h-5" />
              Delete Technician?
            </AlertDialogTitle>
            <AlertDialogDescription>
              <div className="space-y-3">
                <p className="font-semibold">
                  This will permanently delete Tech {techToDelete?.user_id?.substring(0, 12)} and ALL associated data:
                </p>
                <ul className="list-disc list-inside text-sm space-y-1 text-gray-700">
                  <li>Technician profile and documents</li>
                  <li>All service history and completed jobs</li>
                  <li>All ratings and reviews</li>
                  <li>All messages and notifications</li>
                  <li>All location history</li>
                </ul>
                <p className="font-bold text-red-600 mt-3">
                  This action cannot be undone!
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTechnician.mutate(techToDelete.user_id)}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteTechnician.isLoading ? 'Deleting...' : 'Delete Permanently'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Jobs Modal */}
      <Dialog open={showJobs} onOpenChange={setShowJobs}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <Eye className="w-6 h-6" style={{ color: '#FF771D' }} />
              Completed Jobs - Tech {selectedTech?.user_id?.substring(0, 12)}
            </DialogTitle>
          </DialogHeader>

          {selectedTech && (
            <div className="space-y-4">
              {/* Summary */}
              <Card className="bg-gray-50">
                <CardContent className="pt-6">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold">{techJobs.length}</p>
                      <p className="text-sm text-gray-600">Completed Jobs</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold" style={{ color: '#3D692B' }}>
                        ${techJobs.reduce((sum, job) => sum + (job.price || 0), 0).toFixed(2)}
                      </p>
                      <p className="text-sm text-gray-600">Total Revenue</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold">{selectedTech.rating?.toFixed(1) || '5.0'} ⭐</p>
                      <p className="text-sm text-gray-600">Average Rating</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Jobs List */}
              <div className="space-y-3">
                {techJobs.length === 0 ? (
                  <div className="text-center py-12 bg-gray-50 rounded-lg">
                    <Clock className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p className="text-gray-500">No completed jobs yet</p>
                  </div>
                ) : (
                  techJobs.map((job) => (
                    <Card key={job.id} className="border hover:shadow-md transition-shadow">
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-semibold">
                              {job.service_type.replace(/_/g, ' ').toUpperCase()}
                            </h4>
                            <p className="text-sm text-gray-600">
                              {format(new Date(job.completed_at), 'MMM d, yyyy h:mm a')}
                            </p>
                          </div>
                          <Badge className="bg-green-100 text-green-800">
                            Completed
                          </Badge>
                        </div>
                        
                        <div className="grid md:grid-cols-2 gap-3 text-sm">
                          {job.location_address && (
                            <div className="flex items-start gap-2">
                              <MapPin className="w-4 h-4 mt-0.5 text-gray-400" />
                              <span className="text-gray-600">{job.location_address}</span>
                            </div>
                          )}
                          {job.vehicle_make && (
                            <div className="flex items-center gap-2">
                              <Car className="w-4 h-4 text-gray-400" />
                              <span className="text-gray-600">
                                {job.vehicle_year} {job.vehicle_make} {job.vehicle_model}
                              </span>
                            </div>
                          )}
                          {job.price && (
                            <div className="font-bold text-lg" style={{ color: '#3D692B' }}>
                              ${job.price.toFixed(2)}
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reviews Modal */}
      <Dialog open={showReviews} onOpenChange={setShowReviews}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
              Technician Reviews & Ratings
            </DialogTitle>
          </DialogHeader>

          {selectedTech && (
            <div className="space-y-6">
              {/* Technician Summary */}
              <Card className="bg-gray-50">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    {selectedTech.profile_picture ? (
                      <img
                        src={selectedTech.profile_picture}
                        alt="Profile"
                        className="w-16 h-16 rounded-full object-cover border-4"
                        style={{ borderColor: '#FF771D' }}
                      />
                    ) : (
                      <div
                        className="w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold"
                        style={{ backgroundColor: '#FF771D' }}
                      >
                        T
                      </div>
                    )}
                    <div>
                      <h3 className="font-bold text-lg">
                        Tech {selectedTech.user_id.substring(0, 12)}...
                      </h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                        <span className="text-2xl font-bold">{selectedTech.rating?.toFixed(1) || '5.0'}</span>
                        <span className="text-gray-500">({techRatings.length} reviews)</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Total Jobs</p>
                      <p className="font-semibold">{selectedTech.total_jobs || 0}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Phone</p>
                      <p className="font-semibold">{selectedTech.phone}</p>
                    </div>
                  </div>

                  {/* Skills */}
                  {selectedTech.skills_certifications?.length > 0 && (
                    <div className="mt-4">
                      <p className="text-sm font-semibold mb-2">Skills & Certifications:</p>
                      <div className="flex flex-wrap gap-1">
                        {selectedTech.skills_certifications.map((skill, idx) => (
                          <Badge key={idx} className="text-xs" style={{ backgroundColor: '#3D692B' }}>
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Specialties */}
                  {selectedTech.specialties?.length > 0 && (
                    <div className="mt-4">
                      <p className="text-sm font-semibold mb-2">Service Specialties:</p>
                      <div className="flex flex-wrap gap-1">
                        {selectedTech.specialties.map((specialty, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs" style={{ color: '#FF771D', borderColor: '#FF771D' }}>
                            {specialty}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Rating Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Rating Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {[5, 4, 3, 2, 1].map(stars => {
                      const count = techRatings.filter(r => r.rating === stars).length;
                      const percentage = techRatings.length > 0 ? (count / techRatings.length) * 100 : 0;
                      return (
                        <div key={stars} className="flex items-center gap-3">
                          <span className="text-sm font-medium w-12">{stars} star</span>
                          <div className="flex-1 h-3 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className="h-full rounded-full"
                              style={{ 
                                width: `${percentage}%`,
                                backgroundColor: '#FF771D'
                              }}
                            />
                          </div>
                          <span className="text-sm text-gray-600 w-12 text-right">{count}</span>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Individual Reviews */}
              <div>
                <h3 className="font-semibold text-lg mb-3">Customer Reviews</h3>
                {techRatings.length === 0 ? (
                  <div className="text-center py-8 bg-gray-50 rounded-lg">
                    <MessageSquare className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p className="text-gray-500">No reviews yet</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {techRatings.map((rating) => (
                      <Card key={rating.id} className="border">
                        <CardContent className="pt-4">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`w-4 h-4 ${
                                      i < rating.rating
                                        ? 'fill-yellow-400 text-yellow-400'
                                        : 'text-gray-300'
                                    }`}
                                  />
                                ))}
                              </div>
                              <span className="font-semibold">{rating.rating}.0</span>
                            </div>
                            <span className="text-xs text-gray-500">
                              {format(new Date(rating.created_date), 'MMM d, yyyy')}
                            </span>
                          </div>
                          
                          {rating.comment && (
                            <p className="text-sm text-gray-700 mt-2 p-3 bg-gray-50 rounded-lg">
                              "{rating.comment}"
                            </p>
                          )}
                          
                          <div className="mt-2 text-xs text-gray-500">
                            Customer ID: {rating.customer_id.substring(0, 12)}...
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}