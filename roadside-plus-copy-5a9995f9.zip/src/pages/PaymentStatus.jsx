import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle2, XCircle, Loader2, ArrowRight } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { simulatePaymentSuccess } from '../components/payments/initiatePayment';

export default function PaymentStatus() {
  const [requestId, setRequestId] = useState(null);
  const [simulating, setSimulating] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setRequestId(params.get('requestId'));
  }, []);

  const { data: request, isLoading, refetch } = useQuery({
    queryKey: ['payment-status', requestId],
    queryFn: async () => {
      const requests = await base44.entities.ServiceRequest.filter({ id: requestId });
      return requests[0];
    },
    enabled: !!requestId,
    refetchInterval: (data) => {
      // Stop polling if payment is completed or failed
      if (data?.payment_status === 'paid' || data?.payment_status === 'failed') {
        return false;
      }
      return 3000; // Poll every 3 seconds
    }
  });

  // Auto-simulate payment success after 3 seconds (for demo purposes)
  useEffect(() => {
    if (request && request.payment_status === 'initiated' && !simulating) {
      setSimulating(true);
      setTimeout(async () => {
        try {
          const result = await simulatePaymentSuccess(request.id, request.payment_reference);
          await base44.entities.ServiceRequest.update(request.id, {
            payment_status: 'paid',
            paid_at: result.paid_at
          });
          refetch();
        } catch (error) {
          console.error('Payment simulation error:', error);
        }
      }, 3000);
    }
  }, [request]);

  const handleRetry = () => {
    window.location.href = createPageUrl(`CustomerPayment?requestId=${requestId}`);
  };

  const handleGoHome = () => {
    window.location.href = createPageUrl('CustomerDashboard');
  };

  if (isLoading || !request) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF771D' }} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <Card className="max-w-md w-full">
        <CardContent className="pt-6">
          {/* Payment Processing */}
          {request.payment_status === 'initiated' && (
            <div className="text-center py-8">
              <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Processing Payment</h2>
              <p className="text-gray-600 mb-6">Please wait while we confirm your payment...</p>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  This usually takes a few seconds. Do not close this window.
                </p>
              </div>
            </div>
          )}

          {/* Payment Success */}
          {request.payment_status === 'paid' && (
            <div className="text-center py-8">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                <CheckCircle2 className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold mb-2" style={{ color: '#3D692B' }}>
                Payment Successful!
              </h2>
              <p className="text-gray-600 mb-2">Thank you for your payment</p>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-700">Amount Paid</span>
                  <span className="font-bold text-green-900">
                    ${(request.payment_amount || request.price || 0).toFixed(2)}
                  </span>
                </div>
                {request.payment_reference && (
                  <div className="flex justify-between text-xs mt-2 pt-2 border-t border-green-200">
                    <span className="text-gray-600">Reference</span>
                    <span className="font-mono text-gray-700">{request.payment_reference}</span>
                  </div>
                )}
              </div>
              <Button
                onClick={handleGoHome}
                className="w-full text-white py-6 text-lg hover:opacity-90"
                style={{ backgroundColor: '#FF771D' }}
              >
                Return to Dashboard
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          )}

          {/* Payment Failed */}
          {request.payment_status === 'failed' && (
            <div className="text-center py-8">
              <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <XCircle className="w-10 h-10 text-red-600" />
              </div>
              <h2 className="text-2xl font-bold mb-2 text-red-600">Payment Failed</h2>
              <p className="text-gray-600 mb-6">
                Your payment could not be processed. Please try again.
              </p>
              <div className="space-y-3">
                <Button
                  onClick={handleRetry}
                  className="w-full text-white py-6 text-lg hover:opacity-90"
                  style={{ backgroundColor: '#FF771D' }}
                >
                  Try Again
                </Button>
                <Button
                  onClick={handleGoHome}
                  variant="outline"
                  className="w-full py-6 text-lg"
                >
                  Return to Dashboard
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}