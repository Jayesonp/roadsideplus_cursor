import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { getCachedUser } from '@/components/utils/userCache';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useQueryWithTimeout } from '../components/common/useQueryWithTimeout';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ErrorState from '../components/common/ErrorState';
import ErrorBoundary from '../components/common/ErrorBoundary';
import { useAdManager } from '../components/ads/AdManager';
import BannerAd from '../components/ads/BannerAd';
import CarouselAd from '../components/ads/CarouselAd';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { MapPin, Navigation, User, LogOut, CheckCircle, Star, Radio, Coffee, Briefcase, Power, AlertTriangle, History } from 'lucide-react';
import { createPageUrl } from '@/utils';
import BrandLogo from '../components/branding/BrandLogo';
import StatusBadge from '../components/common/StatusBadge';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import TechniciansMap from '../components/map/TechniciansMap';
import NotificationBell from '../components/notifications/NotificationBell';
import JobNotificationAlert from '../components/technician/JobNotificationAlert';
import UrgentJobAlerts from '../components/technician/UrgentJobAlerts';

// Lazy load heavy components to fix render blocking
const EarningsInsights = React.lazy(() => import('../components/technician/EarningsInsights'));
const PersonalFeedbackInsights = React.lazy(() => import('../components/technician/PersonalFeedbackInsights'));
const SmartRouteOptimizer = React.lazy(() => import('../components/technician/SmartRouteOptimizer'));
const ActiveJobsMap = React.lazy(() => import('../components/technician/ActiveJobsMap'));
const PerformanceDashboard = React.lazy(() => import('../components/technician/PerformanceDashboard'));
import UberStyleJobAlert from '../components/technician/UberStyleJobAlert';
import { format } from 'date-fns';
import { useNetworkStatus } from '../components/offline/NetworkMonitor';
import { cacheServiceRequests } from '../components/offline/cacheServiceRequests';
import { offlineJobManager } from '../components/offline/OfflineJobManager';
import DashboardSkeleton from '../components/technician/DashboardSkeleton';

// Simplified distance calculation (Haversine formula) - Moved outside component
const calculateDistance = (lat1, lng1, lat2, lng2) => {
  const R = 3959; // Earth radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return (R * c).toFixed(1);
};

export default function TechnicianDashboard() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isOnline } = useNetworkStatus();
  
  // Always call hooks at top level - pass null if user not loaded yet
  const { adsEnabled, ads, recordImpression, recordClick } = useAdManager('technician_dashboard', user?.id || null, 'technician');

  useEffect(() => {
    loadUser();
    
    // Handle post-verification technician profile setup
    const needsProfile = localStorage.getItem('needs_technician_profile');
    if (needsProfile === 'true') {
      handleProfileSetup();
      localStorage.removeItem('needs_technician_profile');
    }
  }, []);

  const handleProfileSetup = async () => {
    try {
      const currentUser = await getCachedUser();
      if (!currentUser) return;
      
      // Check if profile exists
      const profiles = await base44.entities.TechnicianProfile.filter({ 
        user_id: currentUser.id 
      });
      
      if (profiles.length === 0) {
        // Create technician profile
        await base44.entities.TechnicianProfile.create({
          user_id: currentUser.id,
          phone: '',
          onboarding_completed: false
        });
        window.location.reload();
      }
    } catch (error) {
      console.error('Error setting up profile:', error);
    }
  };

  const loadUser = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const currentUser = await getCachedUser();
      setUser(currentUser);
      
      const profiles = await base44.entities.TechnicianProfile.filter({ user_id: currentUser.id });
      if (profiles.length === 0) {
        // Redirect to onboarding if no profile exists
        navigate(createPageUrl('TechnicianOnboardingChecklist'));
        return;
      }
      
      const techProfile = profiles[0];
      
      // Check if onboarding is incomplete
      if (!currentUser.onboarding_completed || !techProfile.onboarding_completed) {
        // Note: Using navigate instead of window.location for smoother UX
        navigate(createPageUrl('TechnicianOnboardingChecklist'));
        return;
      }
      
      setProfile(techProfile);
      setLoading(false);
      
      // Defer non-critical operations
      setTimeout(() => {
        if (currentUser.id) {
          offlineJobManager.cacheActiveJobs(currentUser.id).catch(console.error);
        }
        updateLocation();
      }, 500);
    } catch (err) {
      console.error('Failed to load user:', err);
      base44.auth.redirectToLogin();
    }
  };

  const updateLocation = () => {
    if (navigator.geolocation && profile?.is_available) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          if (profile) {
            await base44.entities.TechnicianProfile.update(profile.id, {
              current_lat: latitude,
              current_lng: longitude
            });
          }
        },
        (error) => console.log('Location access denied')
      );
    }
  };

  const { data: availableRequests = [], isError: requestsError, error: requestsErrorMsg, refetch: refetchRequests } = useQueryWithTimeout({
    queryKey: ['available-requests'],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter(
        { status: 'pending_dispatch' },
        '-created_date',
        5
      );
    },
    enabled: !!user && profile?.is_available,
    refetchInterval: 120000, // Increased polling to 2 mins
    retry: 1,
    staleTime: 60000, // Increased stale time
    refetchOnWindowFocus: false,
    networkMode: 'always'
  }, 10000);

  const { data: myJobs = [], isError: jobsError, error: jobsErrorMsg, refetch: refetchJobs } = useQueryWithTimeout({
    queryKey: ['my-jobs', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      if (!isOnline) {
        const cached = await cacheServiceRequests.getMyJobs(user.id);
        return cached || [];
      }
      
      const jobs = await base44.entities.ServiceRequest.filter(
        { technician_id: user.id },
        '-created_date',
        5
      );
      
      cacheServiceRequests.saveMultipleRequests(jobs).catch(console.error);
      return jobs;
    },
    enabled: !!user,
    refetchInterval: 120000, // Increased polling
    retry: 1,
    staleTime: 60000,
    refetchOnWindowFocus: false
  }, 10000);

  // Memoize filtered jobs to prevent re-renders
  const activeJob = React.useMemo(() => 
    myJobs.find(j => ['assigned', 'en_route', 'in_progress'].includes(j.status)), 
    [myJobs]
  );
  const activeJobs = React.useMemo(() => 
    myJobs.filter(j => ['assigned', 'en_route', 'in_progress'].includes(j.status)), 
    [myJobs]
  );

  const toggleAvailability = useMutation({
    mutationFn: async (available) => {
      return await base44.entities.TechnicianProfile.update(profile.id, {
        is_available: available
      });
    },
    onSuccess: (updated) => {
      setProfile(updated);
    }
  });

  const updateAvailabilityStatus = useMutation({
    mutationFn: async (status) => {
      return await base44.entities.TechnicianProfile.update(profile.id, {
        availability_status: status,
        is_available: status !== 'offline'
      });
    },
    onSuccess: (updated) => {
    setProfile(updated);
    // Removed invalidation of all-technicians as it's unused
    queryClient.invalidateQueries({ queryKey: ['available-technicians'] });
    }
  });

  const acceptJob = useMutation({
    mutationFn: async (requestId) => {
      // Optimized check - only query if not in cache
      const hasActiveJob = myJobs.some(j => 
        ['assigned', 'en_route', 'arrived', 'in_progress'].includes(j.status)
      );
      
      if (hasActiveJob) {
        throw new Error('You already have an active job. Please complete or cancel it before accepting another.');
      }
      
      return await base44.entities.ServiceRequest.update(requestId, {
        technician_id: user.id,
        status: 'assigned',
        current_offered_technician_id: null,
        offer_expires_at: null,
        estimated_arrival: new Date(Date.now() + 20 * 60000).toISOString()
      });
    },
    onSuccess: async (updatedRequest) => {
      queryClient.invalidateQueries(['available-requests']);
      queryClient.invalidateQueries(['my-jobs']);
      
      // Update technician profile availability
      if (profile) {
        await base44.entities.TechnicianProfile.update(profile.id, {
          availability_status: 'on_job'
        });
      }

      // Log event
      await base44.entities.Event.create({
        type: 'OFFER_ACCEPTED',
        request_id: updatedRequest.id,
        customer_id: updatedRequest.customer_id,
        technician_id: user.id,
        payload: { accepted_at: new Date().toISOString() }
      });

      // Notify customer
      if (updatedRequest.customer_id) {
        await base44.entities.Notification.create({
          user_id: updatedRequest.customer_id,
          type: 'technician_assigned',
          title: 'Technician Assigned!',
          message: 'A technician has accepted your request and is on the way!',
          related_id: updatedRequest.id
        });
      }

      // Notify technician about job assignment
      await base44.entities.Notification.create({
        user_id: user.id,
        type: 'job_assigned',
        title: 'Job Assigned',
        message: `You've been assigned a ${updatedRequest.service_type.replace(/_/g, ' ')} job. Tap to view details.`,
        related_id: updatedRequest.id
      });
    }
  });

  // Show skeleton loading
  if (loading || !user || !profile) {
    return <DashboardSkeleton />;
  }

  // Show partial dashboard even with data errors
  const hasDataError = requestsError || jobsError;

  const handleLogout = async () => {
    await base44.auth.logout();
  };



  return (
    <div className="min-h-screen bg-gray-50">
      {/* Data Error Banner */}
      {hasDataError && (
        <div className="bg-red-50 border-b border-red-200 p-3">
          <div className="max-w-6xl mx-auto flex items-center justify-between">
            <p className="text-sm text-red-800">
              {requestsErrorMsg?.message || jobsErrorMsg?.message || "Some data failed to load"}
            </p>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => {
                if (requestsError) refetchRequests();
                if (jobsError) refetchJobs();
              }}
              className="border-red-300 text-red-700 hover:bg-red-100"
            >
              Retry
            </Button>
          </div>
        </div>
      )}
      
      {/* Job Notification Alerts */}
      <JobNotificationAlert technicianId={user?.id} />

      {/* Header */}
      <div className="text-white p-4 md:p-6 shadow-lg relative z-10" style={{ background: 'linear-gradient(135deg, #E52C2D 0%, #FF771D 100%)' }}>
        <div className="max-w-6xl mx-auto">
          {/* Top Bar - Logo and Icons */}
          <div className="flex justify-between items-center mb-4">
            <BrandLogo variant="full" size="md" className="text-white" />
            <div className="flex items-center gap-2 md:gap-3">
              <NotificationBell userId={user?.id} />
              <Button 
                variant="outline" 
                size="icon"
                className="bg-white/10 border-white/30 text-white hover:bg-white/20 md:w-auto md:px-4"
                onClick={() => navigate(createPageUrl('JobHistory'))}
              >
                <History className="w-4 h-4 md:mr-2" />
                <span className="hidden md:inline">History</span>
              </Button>
              <Button 
                variant="outline" 
                size="icon"
                className="bg-white/10 border-white/30 text-white hover:bg-white/20 md:w-auto md:px-4"
                onClick={() => navigate(createPageUrl('TechnicianProfile'))}
              >
                <User className="w-4 h-4 md:mr-2" />
                <span className="hidden md:inline">Profile</span>
              </Button>
              <Button 
                variant="outline" 
                size="icon"
                className="bg-white/10 border-white/30 text-white hover:bg-white/20 md:w-auto md:px-4 hidden md:flex"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 md:mr-2" />
                <span className="hidden md:inline">Logout</span>
              </Button>
            </div>
          </div>

          {/* Technician Name & Status Badge */}
          {user && (
            <div className="mb-3 flex items-center justify-between">
              <div>
                <p className="text-sm opacity-75">Welcome back,</p>
                <h2 className="text-xl md:text-2xl font-bold">{user.full_name}</h2>
              </div>
              {profile && (
                <div className={`px-4 py-2 rounded-full text-sm font-bold flex items-center gap-2 shadow-lg border-2 border-white/20 backdrop-blur-md ${
                  profile.availability_status === 'available' 
                    ? 'bg-green-500 text-white shadow-green-500/30' 
                    : profile.availability_status === 'on_job' 
                      ? 'bg-red-500 text-white shadow-red-500/30'
                      : 'bg-gray-600 text-white'
                }`}>
                  <div className={`w-3 h-3 rounded-full bg-white ${profile.availability_status === 'available' ? 'animate-pulse' : ''}`} />
                  {profile.availability_status === 'available' ? 'AVAILABLE' : 
                   profile.availability_status === 'on_job' ? 'BUSY / ON JOB' : 'OFFLINE'}
                </div>
              )}
            </div>
          )}

          {/* Stats - Mobile Optimized */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
            {/* Total Jobs Card */}
            <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
              <div className="text-3xl md:text-2xl font-bold">{profile?.total_jobs || 0}</div>
              <div className="text-sm md:text-base opacity-90 mt-1">Total Jobs</div>
            </div>

            {/* Rating Card */}
            <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
              <div className="flex items-center gap-2 mb-1">
                <Star className="w-6 h-6 md:w-5 md:h-5 fill-yellow-300 text-yellow-300" />
                <span className="text-3xl md:text-2xl font-bold">{profile?.rating?.toFixed(1) || '5.0'}</span>
              </div>
              <div className="text-sm md:text-base opacity-90">Rating</div>
            </div>

            {/* Status Controls Card */}
            <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm sm:col-span-2 md:col-span-1">
              <div className="flex flex-wrap gap-2">
                <Button
                  size="sm"
                  variant={profile?.availability_status === 'available' ? 'default' : 'outline'}
                  onClick={() => updateAvailabilityStatus.mutate('available')}
                  disabled={!profile?.documents_approved_by_admin}
                  className={`${profile?.availability_status === 'available' ? 'bg-green-600 hover:bg-green-700 text-white border-none' : 'bg-white/20 border-white/40 text-white hover:bg-white/30'} ${!profile?.documents_approved_by_admin ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <Radio className="w-3 h-3 mr-1" />
                  Live
                </Button>
                <Button
                  size="sm"
                  variant={profile?.availability_status === 'on_job' ? 'default' : 'outline'}
                  onClick={() => updateAvailabilityStatus.mutate('on_job')}
                  className={profile?.availability_status === 'on_job' ? 'bg-blue-600 hover:bg-blue-700 text-white border-none' : 'bg-white/20 border-white/40 text-white hover:bg-white/30'}
                >
                  <Briefcase className="w-3 h-3 mr-1" />
                  On Job
                </Button>
                <Button
                  size="sm"
                  variant={profile?.availability_status === 'break' ? 'default' : 'outline'}
                  onClick={() => updateAvailabilityStatus.mutate('break')}
                  className={profile?.availability_status === 'break' ? 'bg-orange-600 hover:bg-orange-700 text-white border-none' : 'bg-white/20 border-white/40 text-white hover:bg-white/30'}
                >
                  <Coffee className="w-3 h-3 mr-1" />
                  Break
                </Button>
                <Button
                  size="sm"
                  variant={profile?.availability_status === 'offline' ? 'default' : 'outline'}
                  onClick={() => updateAvailabilityStatus.mutate('offline')}
                  className={profile?.availability_status === 'offline' ? 'bg-gray-600 hover:bg-gray-700 text-white border-none' : 'bg-white/20 border-white/40 text-white hover:bg-white/30'}
                >
                  <Power className="w-3 h-3 mr-1" />
                  Offline
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Onboarding Banner */}
      {profile && (!profile.onboarding_completed || !profile.bio || !profile.skills || profile.skills.length === 0) && (
        <div className="max-w-6xl mx-auto px-4 md:px-6 pt-4 md:pt-6">
          <Card className="border-2 border-orange-300 bg-orange-50">
            <CardContent className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-semibold text-orange-900">Complete Your Onboarding</h3>
                <p className="text-sm text-orange-700">Finish setup to start accepting jobs and earning money</p>
              </div>
              <div className="flex gap-2 w-full sm:w-auto">
                <Button 
                  variant="outline"
                  className="border-orange-300 text-orange-700 hover:bg-orange-100 flex-1 sm:flex-none"
                  onClick={() => navigate(createPageUrl('TechnicianOnboardingChecklist'))}
                >
                  View Checklist
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="max-w-6xl mx-auto p-4 md:p-6">
        {/* Verification Status Section */}
        {!profile?.documents_approved_by_admin && (
          <Card className="mb-6 border-0 shadow-md overflow-hidden">
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-5">
              <div className="flex items-start gap-4">
                <div className="relative flex-shrink-0">
                  <AlertTriangle className="w-6 h-6 text-yellow-600" />
                </div>
                <div>
                  <p className="font-bold text-lg mb-1 text-yellow-800">Verification in Progress</p>
                  <p className="text-base font-medium leading-relaxed text-yellow-700 mb-4">
                    We are currently reviewing your profile and documents. Please ensure all required items are uploaded.
                  </p>
                  
                  <div className="bg-white/50 rounded-lg p-4 border border-yellow-200">
                    <h4 className="font-semibold text-yellow-900 mb-3">Verification Checklist</h4>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <div className="flex items-center justify-between p-2 rounded bg-white border border-yellow-100">
                        <span className="text-sm font-medium text-gray-700">Identity Verification</span>
                        {profile?.photo_id_front_url ? (
                          <span className="flex items-center text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded-full">
                            <CheckCircle className="w-3 h-3 mr-1" /> UPLOADED
                          </span>
                        ) : (
                          <span className="flex items-center text-xs font-bold text-red-600 bg-red-50 px-2 py-1 rounded-full">
                            MISSING
                          </span>
                        )}
                      </div>
                      <div className="flex items-center justify-between p-2 rounded bg-white border border-yellow-100">
                        <span className="text-sm font-medium text-gray-700">Driver's License</span>
                        {profile?.drivers_license_url ? (
                          <span className="flex items-center text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded-full">
                            <CheckCircle className="w-3 h-3 mr-1" /> UPLOADED
                          </span>
                        ) : (
                          <span className="flex items-center text-xs font-bold text-red-600 bg-red-50 px-2 py-1 rounded-full">
                            MISSING
                          </span>
                        )}
                      </div>
                      <div className="flex items-center justify-between p-2 rounded bg-white border border-yellow-100">
                        <span className="text-sm font-medium text-gray-700">Vehicle Insurance</span>
                        {profile?.insurance_url ? (
                          <span className="flex items-center text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded-full">
                            <CheckCircle className="w-3 h-3 mr-1" /> UPLOADED
                          </span>
                        ) : (
                          <span className="flex items-center text-xs font-bold text-red-600 bg-red-50 px-2 py-1 rounded-full">
                            MISSING
                          </span>
                        )}
                      </div>
                      <div className="flex items-center justify-between p-2 rounded bg-white border border-yellow-100">
                        <span className="text-sm font-medium text-gray-700">Profile Status</span>
                        <span className={`flex items-center text-xs font-bold px-2 py-1 rounded-full ${
                          profile?.onboarding_status === 'approved' ? 'text-green-600 bg-green-50' : 
                          profile?.onboarding_status === 'rejected' ? 'text-red-600 bg-red-50' : 
                          'text-yellow-600 bg-yellow-100'
                        }`}>
                          {profile?.onboarding_status?.toUpperCase() || 'PENDING'}
                        </span>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex justify-end">
                       <Button 
                        size="sm" 
                        variant="outline"
                        className="border-yellow-300 text-yellow-800 hover:bg-yellow-100"
                        onClick={() => navigate(createPageUrl('TechnicianOnboardingChecklist'))}
                      >
                        Go to Onboarding Checklist
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Live Status Banner */}
        {profile?.availability_status === 'available' && profile?.documents_approved_by_admin && (
          <Card className="mb-6 border-0 shadow-md" style={{ backgroundColor: '#E8F6E8' }}>
            <CardContent className="p-5">
              <div className="flex items-start gap-4">
                <div className="relative flex-shrink-0">
                  <Radio className="w-6 h-6" style={{ color: '#2B4E1F' }} />
                  <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full animate-pulse" style={{ backgroundColor: '#3D692B' }}></div>
                </div>
                <div>
                  <p className="font-bold text-lg mb-1" style={{ color: '#2B4E1F' }}>You're Live!</p>
                  <p className="text-base font-medium leading-relaxed" style={{ color: '#3D692B' }}>Your location is being broadcast to customers looking for assistance</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Carousel Ads */}
        {adsEnabled && ads.filter(a => a.ad_type === 'carousel').length > 0 && (
          <div className="mb-6">
            <CarouselAd 
              ads={ads.filter(a => a.ad_type === 'carousel')} 
              onImpression={recordImpression}
              onClick={recordClick}
            />
          </div>
        )}

        {/* Uber-Style Job Alert (60s countdown) */}
        <UberStyleJobAlert 
          technicianId={user?.id}
          isAvailable={profile?.is_available}
        />

        {/* Urgent Job Alerts */}
        <UrgentJobAlerts
          technicianId={user?.id}
          technicianLocation={profile?.current_lat ? { lat: profile.current_lat, lng: profile.current_lng } : null}
          isAvailable={profile?.is_available}
        />

        {/* Active Jobs Map */}
        {profile?.current_lat && profile?.current_lng && (
          <Card className="mb-4 md:mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                <MapPin className="w-4 h-4 md:w-5 md:h-5" style={{ color: '#E52C2D' }} />
                Live Jobs & Requests Map
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] md:h-[500px]">
                <ErrorBoundary message="Unable to load the map. Check your connection or try again.">
                  <React.Suspense fallback={<div className="h-full w-full bg-gray-100 animate-pulse rounded-lg" />}>
                    <ActiveJobsMap
                      technicianLocation={{ lat: profile.current_lat, lng: profile.current_lng }}
                      activeJobs={activeJobs}
                      pendingRequests={availableRequests.filter(r => 
                        profile?.current_lat && calculateDistance(
                          profile.current_lat,
                          profile.current_lng,
                          r.location_lat,
                          r.location_lng
                        ) < 25
                      )}
                      serviceRadius={profile?.service_radius || 25}
                    />
                  </React.Suspense>
                </ErrorBoundary>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Active Job */}
        {activeJob && (
          <Card className="mb-4 md:mb-6 border-2" style={{ borderColor: '#E52C2D' }}>
            <CardContent className="p-4 md:p-6">
              <div className="flex flex-col sm:flex-row items-start justify-between mb-4 gap-3">
                <div className="w-full sm:w-auto">
                  <div className="flex items-center gap-3 mb-2">
                    <ServiceTypeIcon type={activeJob.service_type} />
                    <h3 className="text-lg md:text-xl font-bold">Active Job</h3>
                  </div>
                  <StatusBadge status={activeJob.status} />
                </div>
                <Button 
                  style={{ backgroundColor: '#E52C2D' }}
                  className="text-white hover:opacity-90 w-full sm:w-auto"
                  onClick={() => navigate(createPageUrl(`JobDetails?id=${activeJob.id}`))}
                >
                  Manage Job
                </Button>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex items-start gap-2 text-gray-600">
                  <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <span className="break-words">{activeJob.location_address || 'Location set'}</span>
                </div>
                {activeJob.vehicle_make && (
                  <div className="text-gray-600 break-words">
                    Vehicle: {activeJob.vehicle_year} {activeJob.vehicle_make} {activeJob.vehicle_model} ({activeJob.vehicle_color})
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Lazy Load Secondary Widgets */}
        <ErrorBoundary>
          <React.Suspense fallback={<div className="h-32 bg-gray-100 animate-pulse rounded-lg mb-6" />}>
            <div className="mb-4 md:mb-6">
              <PerformanceDashboard technicianId={user?.id} profile={profile} />
            </div>
          </React.Suspense>
        </ErrorBoundary>

        {profile?.current_lat && profile?.current_lng && (
          <ErrorBoundary>
            <React.Suspense fallback={<div className="h-32 bg-gray-100 animate-pulse rounded-lg mb-6" />}>
              <div className="mb-4 md:mb-6">
                <SmartRouteOptimizer 
                  technicianId={user?.id}
                  currentLocation={{ lat: profile.current_lat, lng: profile.current_lng }}
                  activeJobs={activeJobs}
                />
              </div>
            </React.Suspense>
          </ErrorBoundary>
        )}

        <React.Suspense fallback={<div className="h-32 bg-gray-100 animate-pulse rounded-lg mb-6" />}>
          <div className="mb-4 md:mb-6">
            <EarningsInsights technicianId={user?.id} technicianProfile={profile} />
          </div>
        </React.Suspense>

        <React.Suspense fallback={<div className="h-32 bg-gray-100 animate-pulse rounded-lg mb-6" />}>
          <div className="mb-4 md:mb-6">
            <PersonalFeedbackInsights technicianId={user?.id} />
          </div>
        </React.Suspense>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
          <AvailableRequestsList 
            requests={availableRequests} 
            profile={profile} 
            onAccept={(id) => acceptJob.mutate(id)}
            isAccepting={acceptJob.isLoading}
            hasActiveJob={!!activeJob}
          />
          
          <MyJobsList 
            jobs={myJobs} 
            onNavigate={(id) => navigate(createPageUrl(`JobDetails?id=${id}`))} 
          />
        </div>
      </div>

      {/* Banner Ads */}
      {adsEnabled && ads.filter(a => a.ad_type === 'banner').length > 0 && (
        <BannerAd 
          ads={ads.filter(a => a.ad_type === 'banner')} 
          onImpression={recordImpression}
          onClick={recordClick}
          position="bottom"
        />
      )}
    </div>
  );
}

// Memoized sub-components to prevent re-renders
const AvailableRequestsList = React.memo(({ requests, profile, onAccept, isAccepting, hasActiveJob }) => (
  <Card>
    <CardHeader>
      <CardTitle className="text-base md:text-lg">Available Requests</CardTitle>
    </CardHeader>
    <CardContent>
      {!profile?.is_available ? (
        <div className="text-center py-8 text-gray-500 text-sm">
          Turn on availability to see requests
        </div>
      ) : requests.length === 0 ? (
        <div className="text-center py-8 text-gray-500 text-sm">
          No requests available
        </div>
      ) : (
        <div className="space-y-3 max-h-[600px] overflow-y-auto">
          {requests.map(request => (
            <div key={request.id} className="border rounded-lg p-3 md:p-4 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3 gap-2">
                <div className="flex items-start gap-2 flex-1 min-w-0">
                  <ServiceTypeIcon type={request.service_type} className="flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <h4 className="font-semibold text-sm md:text-base break-words">
                      {(request.service_type || 'service').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </h4>
                    <p className="text-xs text-gray-600">
                      {request.created_date ? format(new Date(request.created_date), 'h:mm a') : ''}
                    </p>
                  </div>
                </div>
                {profile?.current_lat && (
                  <span className="text-sm font-semibold flex-shrink-0" style={{ color: '#FF771D' }}>
                    {calculateDistance(profile.current_lat, profile.current_lng, request.location_lat, request.location_lng)} mi
                  </span>
                )}
              </div>
              <div className="text-sm text-gray-600 mb-3 break-words">
                <MapPin className="w-3 h-3 inline mr-1 flex-shrink-0" />
                {request.location_address || `${request.location_lat?.toFixed(4)}, ${request.location_lng?.toFixed(4)}`}
              </div>
              {request.vehicle_make && (
                <p className="text-xs text-gray-500 mb-3 break-words">
                  {request.vehicle_year} {request.vehicle_make} {request.vehicle_model}
                </p>
              )}
              <Button 
                className="w-full text-white hover:opacity-90 text-sm md:text-base"
                style={{ backgroundColor: '#3D692B' }}
                onClick={() => onAccept(request.id)}
                disabled={hasActiveJob || isAccepting}
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                {hasActiveJob ? 'Complete Active Job First' : 'Accept Job'}
              </Button>
            </div>
          ))}
        </div>
      )}
    </CardContent>
  </Card>
));

const MyJobsList = React.memo(({ jobs, onNavigate }) => (
  <Card>
    <CardHeader>
      <CardTitle className="text-base md:text-lg">My Jobs</CardTitle>
    </CardHeader>
    <CardContent>
      {jobs.length === 0 ? (
        <div className="text-center py-8 text-gray-500 text-sm">No jobs yet</div>
      ) : (
        <div className="space-y-3 max-h-[600px] overflow-y-auto">
          {jobs.map(job => (
            <div 
              key={job.id}
              className="border rounded-lg p-3 md:p-4 hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => onNavigate(job.id)}
            >
              <div className="flex items-start justify-between mb-2 gap-2">
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <ServiceTypeIcon type={job.service_type} className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                  <h4 className="font-semibold text-sm md:text-base break-words">
                    {(job.service_type || 'service').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </h4>
                </div>
                <StatusBadge status={job.status} showIcon={false} />
              </div>
              <p className="text-xs md:text-sm text-gray-500">
                {job.created_date ? format(new Date(job.created_date), 'MMM d, h:mm a') : ''}
              </p>
            </div>
          ))}
        </div>
      )}
    </CardContent>
  </Card>
));