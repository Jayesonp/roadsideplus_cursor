import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Clock, Shield, AlertTriangle, MapPin } from 'lucide-react';

export default function SecurityAnalytics() {
  const [companyId] = useState(localStorage.getItem('security_company_id'));

  const { data: incidents = [] } = useQuery({
    queryKey: ['all-incidents', companyId],
    queryFn: () => base44.entities.SOSIncident.filter({ company_id: companyId }),
    enabled: !!companyId
  });

  const { data: officers = [] } = useQuery({
    queryKey: ['all-officers', companyId],
    queryFn: () => base44.entities.SecurityOfficer.filter({ company_id: companyId }),
    enabled: !!companyId
  });

  // Analytics calculations
  const totalIncidents = incidents.length;
  const resolvedIncidents = incidents.filter(i => i.status === 'resolved' || i.status === 'completed').length;
  const avgResponseTime = incidents.filter(i => i.response_time_minutes).reduce((sum, i) => sum + i.response_time_minutes, 0) / incidents.filter(i => i.response_time_minutes).length || 0;
  const criticalIncidents = incidents.filter(i => i.severity === 'critical').length;

  // Severity distribution
  const severityData = [
    { name: 'Critical', value: incidents.filter(i => i.severity === 'critical').length, color: '#E52C2D' },
    { name: 'High', value: incidents.filter(i => i.severity === 'high').length, color: '#FF771D' },
    { name: 'Medium', value: incidents.filter(i => i.severity === 'medium').length, color: '#FFA500' },
    { name: 'Low', value: incidents.filter(i => i.severity === 'low').length, color: '#3D692B' }
  ];

  // Daily incidents trend
  const last7Days = [...Array(7)].map((_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    const dayIncidents = incidents.filter(inc => {
      const incDate = new Date(inc.created_date);
      return incDate.toDateString() === date.toDateString();
    });
    return {
      day: date.toLocaleDateString('en-US', { weekday: 'short' }),
      incidents: dayIncidents.length
    };
  });

  // Officer performance
  const officerPerformance = officers.map(officer => ({
    badge: officer.officer_badge_number,
    incidents: officer.total_incidents_handled || 0,
    avgResponse: officer.average_response_time_minutes || 0
  })).sort((a, b) => b.incidents - a.incidents).slice(0, 5);

  return (
    <div className="min-h-screen bg-gray-900 p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-6 flex items-center gap-2">
          <TrendingUp className="w-8 h-8" style={{ color: '#FF771D' }} />
          Security Analytics
        </h1>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Total Incidents</p>
                  <p className="text-3xl font-bold text-white">{totalIncidents}</p>
                </div>
                <AlertTriangle className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Resolved</p>
                  <p className="text-3xl font-bold" style={{ color: '#3D692B' }}>{resolvedIncidents}</p>
                </div>
                <Shield className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Avg Response</p>
                  <p className="text-3xl font-bold text-white">{avgResponseTime.toFixed(1)}m</p>
                </div>
                <Clock className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Critical</p>
                  <p className="text-3xl font-bold" style={{ color: '#E52C2D' }}>{criticalIncidents}</p>
                </div>
                <AlertTriangle className="w-10 h-10 opacity-20" style={{ color: '#E52C2D' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Incident Trend */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">7-Day Incident Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={last7Days}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="day" stroke="#9CA3AF" />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none' }} />
                  <Line type="monotone" dataKey="incidents" stroke="#FF771D" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Severity Distribution */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Severity Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={severityData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => entry.name}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {severityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Officer Performance */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Top Officers Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={officerPerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="badge" stroke="#9CA3AF" />
                <YAxis stroke="#9CA3AF" />
                <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: 'none' }} />
                <Legend />
                <Bar dataKey="incidents" fill="#FF771D" name="Total Incidents" />
                <Bar dataKey="avgResponse" fill="#3D692B" name="Avg Response (min)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}