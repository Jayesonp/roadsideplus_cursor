import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { useQueryWithTimeout } from '../components/common/useQueryWithTimeout';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ErrorState from '../components/common/ErrorState';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { divIcon } from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { 
  Filter, AlertCircle, MapPin, Clock, User, 
  FileText, Eye, RefreshCw, Activity, Trash2
} from 'lucide-react';
import { format } from 'date-fns';
import StatusBadge from '../components/common/StatusBadge';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useMutation, useQueryClient } from '@tanstack/react-query';

const customerIcon = divIcon({
  html: `<div style="background: #FF771D; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3);"></div>`,
  className: '',
  iconSize: [20, 20],
  iconAnchor: [10, 10]
});

const technicianIcon = divIcon({
  html: `<div style="background: #3D692B; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3);"></div>`,
  className: '',
  iconSize: [20, 20],
  iconAnchor: [10, 10]
});

export default function AdminJobMonitoring() {
  const [user, setUser] = useState(null);
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedTechnician, setSelectedTechnician] = useState('all');
  const [selectedServiceType, setSelectedServiceType] = useState('all');
  const [selectedJob, setSelectedJob] = useState(null);
  const [showEventLogs, setShowEventLogs] = useState(false);
  const [jobToDelete, setJobToDelete] = useState(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [loading, setLoading] = useState(true);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error('Failed to load user:', error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch service requests with real-time updates every 5 seconds
  const { data: serviceRequests = [], refetch, isLoading: requestsLoading, isError: requestsError, error: requestsErrorMsg } = useQueryWithTimeout({
    queryKey: ['admin-service-requests', selectedStatus, selectedTechnician, selectedServiceType],
    queryFn: async () => {
      let filters = {};

      if (selectedStatus !== 'all') {
        filters.status = selectedStatus;
      }

      if (selectedTechnician !== 'all') {
        filters.technician_id = selectedTechnician;
      }

      if (selectedServiceType !== 'all') {
        filters.service_type = selectedServiceType;
      }

      const requests = await base44.entities.ServiceRequest.filter(filters, '-updated_date');

      // Only show non-completed jobs by default
      if (selectedStatus === 'all') {
        return requests.filter(req => !['completed', 'cancelled'].includes(req.status));
      }

      return requests;
    },
    refetchInterval: 15000, // Updates every 15 seconds
    enabled: !!user && user.role === 'admin',
    retry: 1,
    staleTime: 12000
  }, 15000);

  // Fetch technicians
  const { data: technicians = [] } = useQuery({
    queryKey: ['technicians'],
    queryFn: async () => {
      return await base44.entities.TechnicianProfile.list();
    },
    enabled: !!user && user.role === 'admin'
  });

  // Fetch real-time GPS locations for all active technicians
  const { data: technicianLocations = [] } = useQuery({
    queryKey: ['technician-locations'],
    queryFn: async () => {
      const activeTechIds = serviceRequests
        .filter(r => r.technician_id)
        .map(r => r.technician_id);
      
      if (activeTechIds.length === 0) return [];
      
      const locations = await base44.entities.TechnicianLocation.filter({}, '-created_date', 100);
      return locations.filter(loc => activeTechIds.includes(loc.technician_id));
    },
    enabled: !!user && user.role === 'admin' && serviceRequests.length > 0,
    refetchInterval: 10000 // Update GPS every 10 seconds
  });

  // Fetch job activity logs (accept/reject events)
  const { data: jobActivities = [] } = useQuery({
    queryKey: ['job-activities'],
    queryFn: async () => {
      return await base44.entities.TechnicianJobActivity.filter({}, '-created_date', 100);
    },
    enabled: !!user && user.role === 'admin',
    refetchInterval: 10000
  });

  // Fetch all ratings for completed jobs
  const { data: allRatings = [] } = useQuery({
    queryKey: ['all-ratings'],
    queryFn: async () => {
      const completedJobs = serviceRequests.filter(r => r.status === 'completed');
      if (completedJobs.length === 0) return [];
      
      return await base44.entities.Rating.filter({}, '-created_date', 200);
    },
    enabled: !!user && user.role === 'admin',
    refetchInterval: 10000
  });

  // Fetch event logs for selected job with real-time updates
  const { data: eventLogs = [] } = useQuery({
    queryKey: ['event-logs', selectedJob?.id],
    queryFn: async () => {
      const events = await base44.entities.Event.filter(
        { request_id: selectedJob.id },
        '-created_date'
      );
      return events;
    },
    enabled: !!selectedJob && !!user && user.role === 'admin',
    refetchInterval: 8000 // Event updates
  });

  // Get latest location for a technician
  const getTechnicianLocation = (techId) => {
    const locations = technicianLocations.filter(loc => loc.technician_id === techId);
    if (locations.length === 0) return null;
    return locations.sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
  };

  // Get job activities for a specific request
  const getJobActivities = (requestId) => {
    return jobActivities.filter(act => act.service_request_id === requestId);
  };

  // Get ratings for a specific request
  const getJobRatings = (requestId) => {
    return allRatings.filter(r => r.service_request_id === requestId);
  };

  const deleteServiceRequest = useMutation({
    mutationFn: async (requestId) => {
      const payments = await base44.entities.Payment.filter({ request_id: requestId });
      const messages = await base44.entities.Message.filter({ service_request_id: requestId });
      const attachments = await base44.entities.ServiceAttachment.filter({ service_request_id: requestId });
      const events = await base44.entities.Event.filter({ request_id: requestId });
      const ratings = await base44.entities.Rating.filter({ service_request_id: requestId });

      for (const payment of payments) {
        await base44.entities.Payment.delete(payment.id);
      }
      for (const message of messages) {
        await base44.entities.Message.delete(message.id);
      }
      for (const attachment of attachments) {
        await base44.entities.ServiceAttachment.delete(attachment.id);
      }
      for (const event of events) {
        await base44.entities.Event.delete(event.id);
      }
      for (const rating of ratings) {
        await base44.entities.Rating.delete(rating.id);
      }

      await base44.entities.ServiceRequest.delete(requestId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-service-requests']);
      setShowDeleteDialog(false);
      setJobToDelete(null);
      setShowEventLogs(false);
    }
  });

  // Check loading and admin access AFTER all hooks
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner message="Loading admin dashboard..." size="lg" />
      </div>
    );
  }

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8">
          <AlertCircle className="w-12 h-12 mx-auto mb-4" style={{ color: '#E52C2D' }} />
          <h2 className="text-xl font-bold text-center">Access Denied</h2>
          <p className="text-gray-600 text-center mt-2">
            This dashboard is only accessible to administrators.
          </p>
        </Card>
      </div>
    );
  }

  if (requestsError) {
    return (
      <div className="min-h-screen p-6">
        <ErrorState 
          message={requestsErrorMsg?.message || "Failed to load service requests"}
          onRetry={refetch}
        />
      </div>
    );
  }

  const activeStatuses = [
    'pending_payment', 'pending_dispatch', 'dispatched', 
    'assigned', 'en_route', 'arrived', 'in_progress', 'awaiting_review'
  ];

  const serviceTypes = [
    { value: 'tire_change', label: 'Tire Change' },
    { value: 'battery_jump', label: 'Battery Jump' },
    { value: 'fuel_delivery', label: 'Fuel Delivery' },
    { value: 'lockout', label: 'Lockout' },
    { value: 'towing', label: 'Towing' },
    { value: 'other', label: 'Other' }
  ];

  const viewEventLogs = (job) => {
    setSelectedJob(job);
    setShowEventLogs(true);
  };

  const getEventIcon = (type) => {
    const icons = {
      'REQUEST_CREATED': '📝',
      'PAYMENT_AUTHORIZED': '💳',
      'DISPATCH_STARTED': '🚀',
      'OFFER_SENT': '📨',
      'OFFER_ACCEPTED': '✅',
      'OFFER_REJECTED': '❌',
      'OFFER_TIMEOUT': '⏰',
      'STATUS_CHANGED': '🔄',
      'PHOTO_UPLOADED': '📷',
      'RATING_SUBMITTED': '⭐',
      'TIP_ADDED': '💵',
      'JOB_COMPLETED': '🎉',
      'JOB_CANCELED': '🚫'
    };
    return icons[type] || '📌';
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Job Monitoring</h1>
            <p className="text-gray-600 mt-1">Real-time tracking of all active service requests</p>
          </div>
          <Button
            onClick={() => refetch()}
            variant="outline"
            className="flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Jobs</p>
                  <p className="text-2xl font-bold mt-1">
                    {serviceRequests.filter(r => activeStatuses.includes(r.status)).length}
                  </p>
                </div>
                <Activity className="w-8 h-8" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Dispatch</p>
                  <p className="text-2xl font-bold mt-1">
                    {serviceRequests.filter(r => ['pending_dispatch', 'dispatched'].includes(r.status)).length}
                  </p>
                </div>
                <Clock className="w-8 h-8" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">In Progress</p>
                  <p className="text-2xl font-bold mt-1">
                    {serviceRequests.filter(r => ['assigned', 'en_route', 'arrived', 'in_progress'].includes(r.status)).length}
                  </p>
                </div>
                <User className="w-8 h-8" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Awaiting Review</p>
                  <p className="text-2xl font-bold mt-1">
                    {serviceRequests.filter(r => r.status === 'awaiting_review').length}
                  </p>
                </div>
                <FileText className="w-8 h-8" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" style={{ color: '#FF771D' }} />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Status</label>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Active</SelectItem>
                    <SelectItem value="pending_payment">Pending Payment</SelectItem>
                    <SelectItem value="pending_dispatch">Pending Dispatch</SelectItem>
                    <SelectItem value="dispatched">Dispatched</SelectItem>
                    <SelectItem value="assigned">Assigned</SelectItem>
                    <SelectItem value="en_route">En Route</SelectItem>
                    <SelectItem value="arrived">Arrived</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="awaiting_review">Awaiting Review</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Technician</label>
                <Select value={selectedTechnician} onValueChange={setSelectedTechnician}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Technicians</SelectItem>
                    {technicians.map(tech => (
                      <SelectItem key={tech.id} value={tech.user_id}>
                        Tech {tech.user_id.substring(0, 8)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Service Type</label>
                <Select value={selectedServiceType} onValueChange={setSelectedServiceType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Services</SelectItem>
                    {serviceTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Map */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" style={{ color: '#FF771D' }} />
                Live Map
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[500px] rounded-lg overflow-hidden relative z-0">
                {serviceRequests.length > 0 ? (
                  <MapContainer
                    center={[
                      serviceRequests[0].location_lat,
                      serviceRequests[0].location_lng
                    ]}
                    zoom={11}
                    style={{ height: '100%', width: '100%', zIndex: 0 }}
                  >
                    <TileLayer
                      attribution='&copy; OpenStreetMap'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    {serviceRequests.map(request => {
                      const techLocation = request.technician_id ? getTechnicianLocation(request.technician_id) : null;
                      return (
                        <React.Fragment key={request.id}>
                          {/* Customer Location */}
                          <Marker
                            position={[request.location_lat, request.location_lng]}
                            icon={customerIcon}
                          >
                            <Popup>
                              <div className="p-2">
                                <div className="flex items-center gap-2 mb-2">
                                  <ServiceTypeIcon type={request.service_type} className="w-5 h-5" />
                                  <span className="font-semibold">
                                    {request.service_type.replace(/_/g, ' ').toUpperCase()}
                                  </span>
                                </div>
                                <StatusBadge status={request.status} />
                                <p className="text-xs text-gray-600 mt-2">
                                  Customer Location
                                </p>
                                <p className="text-xs text-gray-500">
                                  {format(new Date(request.created_date), 'MMM d, h:mm a')}
                                </p>
                              </div>
                            </Popup>
                          </Marker>
                          
                          {/* Technician Location (if available) */}
                          {techLocation && (
                            <Marker
                              position={[techLocation.latitude, techLocation.longitude]}
                              icon={technicianIcon}
                            >
                              <Popup>
                                <div className="p-2">
                                  <p className="font-semibold mb-2">🔧 Technician</p>
                                  <p className="text-xs text-gray-600">
                                    Tech {request.technician_id.substring(0, 8)}
                                  </p>
                                  <p className="text-xs text-gray-500 mt-1">
                                    Last update: {format(new Date(techLocation.created_date), 'h:mm:ss a')}
                                  </p>
                                </div>
                              </Popup>
                            </Marker>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </MapContainer>
                ) : (
                  <div className="h-full flex items-center justify-center text-gray-500">
                    No active jobs to display
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Jobs List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5" style={{ color: '#FF771D' }} />
                Active Jobs ({serviceRequests.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-[500px] overflow-y-auto">
                {serviceRequests.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">No jobs found</p>
                ) : (
                  serviceRequests.map(request => (
                    <Card key={request.id} className="border hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <ServiceTypeIcon type={request.service_type} className="w-5 h-5" />
                            <span className="font-semibold">
                              {request.service_type.replace(/_/g, ' ').toUpperCase()}
                            </span>
                          </div>
                          <StatusBadge status={request.status} />
                        </div>

                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2 text-gray-600">
                            <Clock className="w-4 h-4" />
                            {format(new Date(request.created_date), 'MMM d, h:mm a')}
                          </div>
                          
                          {request.location_address && (
                            <div className="flex items-start gap-2 text-gray-600">
                              <MapPin className="w-4 h-4 mt-0.5" />
                              <span className="line-clamp-1">{request.location_address}</span>
                            </div>
                          )}

                          {request.technician_id && (
                            <div className="flex items-center gap-2 text-gray-600">
                              <User className="w-4 h-4" />
                              Tech {request.technician_id.substring(0, 8)}
                              {getTechnicianLocation(request.technician_id) && (
                                <span className="text-xs text-green-600">● Live</span>
                              )}
                            </div>
                          )}

                          {request.price && (
                            <div className="text-lg font-bold" style={{ color: '#3D692B' }}>
                              ${request.price.toFixed(2)}
                            </div>
                          )}

                          {/* Activity count indicator */}
                          {getJobActivities(request.id).length > 0 && (
                            <div className="text-xs text-blue-600">
                              {getJobActivities(request.id).length} action{getJobActivities(request.id).length !== 1 ? 's' : ''} logged
                            </div>
                          )}

                          {/* Ratings indicator */}
                          {getJobRatings(request.id).length > 0 && (
                            <div className="text-xs text-yellow-600 flex items-center gap-1">
                              ⭐ {getJobRatings(request.id).length} rating{getJobRatings(request.id).length !== 1 ? 's' : ''} submitted
                            </div>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-2 mt-3">
                          <Button
                            onClick={() => viewEventLogs(request)}
                            variant="outline"
                            size="sm"
                            className="flex items-center justify-center gap-2"
                          >
                            <Eye className="w-4 h-4" />
                            View Logs
                          </Button>
                          <Button
                            onClick={() => {
                              setJobToDelete(request);
                              setShowDeleteDialog(true);
                            }}
                            variant="outline"
                            size="sm"
                            className="text-red-600 border-red-300 hover:bg-red-50 flex items-center justify-center gap-2"
                          >
                            <Trash2 className="w-4 h-4" />
                            Delete
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Delete Service Request Dialog */}
        <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <AlertDialogContent className="z-[9999]">
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2 text-red-600">
                <Trash2 className="w-5 h-5" />
                Delete Service Request?
              </AlertDialogTitle>
              <AlertDialogDescription>
                <div className="space-y-3">
                  <p className="font-semibold">
                    This will permanently delete this {jobToDelete?.service_type?.replace(/_/g, ' ')} job and ALL associated data:
                  </p>
                  <ul className="list-disc list-inside text-sm space-y-1 text-gray-700">
                    <li>Service request and job history</li>
                    <li>All payment records</li>
                    <li>All messages between customer and technician</li>
                    <li>All photos and attachments</li>
                    <li>All event logs and tracking data</li>
                    <li>Customer ratings and reviews</li>
                  </ul>
                  <p className="font-bold text-red-600 mt-3">
                    This action cannot be undone!
                  </p>
                </div>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => deleteServiceRequest.mutate(jobToDelete.id)}
                className="bg-red-600 hover:bg-red-700"
              >
                {deleteServiceRequest.isLoading ? 'Deleting...' : 'Delete Permanently'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Event Logs Modal */}
        <Dialog open={showEventLogs} onOpenChange={setShowEventLogs}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" style={{ color: '#FF771D' }} />
                Event Logs - {selectedJob && selectedJob.service_type.replace(/_/g, ' ').toUpperCase()}
              </DialogTitle>
            </DialogHeader>

            {selectedJob && (
              <div className="space-y-4">
                {/* Job Summary */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600">Status</p>
                        <StatusBadge status={selectedJob.status} />
                      </div>
                      <div>
                        <p className="text-gray-600">Created</p>
                        <p className="font-semibold">
                          {format(new Date(selectedJob.created_date), 'MMM d, yyyy h:mm a')}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-600">Customer ID</p>
                        <p className="font-mono text-xs">
                          {selectedJob.customer_id?.substring(0, 16)}...
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-600">Technician ID</p>
                        <p className="font-mono text-xs">
                          {selectedJob.technician_id ? 
                            `${selectedJob.technician_id.substring(0, 16)}...` : 
                            'Not assigned'}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Technician Actions Log */}
                <div className="space-y-2">
                  <h3 className="font-semibold text-lg mb-3">Technician Actions</h3>
                  {getJobActivities(selectedJob.id).length === 0 ? (
                    <p className="text-center text-gray-500 py-4">No actions logged</p>
                  ) : (
                    <div className="space-y-2">
                      {getJobActivities(selectedJob.id).map((activity) => (
                        <div key={activity.id} className="flex gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                          <div className="text-xl">
                            {activity.activity_type === 'offer_accepted' ? '✅' :
                             activity.activity_type === 'offer_rejected' ? '❌' :
                             activity.activity_type === 'offer_viewed' ? '👁️' :
                             activity.activity_type === 'offer_timeout' ? '⏰' : '📌'}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-semibold text-sm">
                                {activity.activity_type.replace(/_/g, ' ').toUpperCase()}
                              </span>
                              <span className="text-xs text-gray-500">
                                {format(new Date(activity.created_date), 'MMM d, h:mm:ss a')}
                              </span>
                            </div>
                            {activity.reason && (
                              <p className="text-xs text-gray-600 mt-1">Reason: {activity.reason}</p>
                            )}
                            {activity.offer_duration_seconds && (
                              <p className="text-xs text-gray-600 mt-1">
                                Duration: {activity.offer_duration_seconds}s
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Ratings & Tips */}
                {getJobRatings(selectedJob.id).length > 0 && (
                  <div className="space-y-2">
                    <h3 className="font-semibold text-lg mb-3">Ratings & Reviews</h3>
                    <div className="space-y-2">
                      {getJobRatings(selectedJob.id).map((rating) => (
                        <div key={rating.id} className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-xl">⭐</span>
                              <span className="font-bold text-lg">{rating.rating}/5</span>
                            </div>
                            <span className="text-xs text-gray-500">
                              {format(new Date(rating.created_date), 'MMM d, h:mm a')}
                            </span>
                          </div>
                          {rating.comment && (
                            <p className="text-sm text-gray-700 mt-2 italic">"{rating.comment}"</p>
                          )}
                          <p className="text-xs text-gray-500 mt-2">
                            Rated by: {rating.customer_id ? 'Customer' : 'Technician'}
                          </p>
                        </div>
                      ))}
                    </div>
                    {selectedJob.payment_amount && (
                      <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold">Total Payment (including tip)</span>
                          <span className="text-xl font-bold" style={{ color: '#3D692B' }}>
                            ${selectedJob.payment_amount.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Event Timeline */}
                <div className="space-y-2">
                  <h3 className="font-semibold text-lg mb-3">Event Timeline</h3>
                  {eventLogs.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">No events logged yet</p>
                  ) : (
                    <div className="space-y-3">
                      {eventLogs.map((event, index) => (
                        <div
                          key={event.id}
                          className="flex gap-3 p-4 bg-gray-50 rounded-lg border border-gray-200"
                        >
                          <div className="text-2xl">{getEventIcon(event.type)}</div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-semibold text-sm">
                                {event.type.replace(/_/g, ' ')}
                              </span>
                              <span className="text-xs text-gray-500">
                                {format(new Date(event.created_date), 'MMM d, h:mm:ss a')}
                              </span>
                            </div>
                            {event.payload && Object.keys(event.payload).length > 0 && (
                              <pre className="text-xs bg-white p-2 rounded border mt-2 overflow-x-auto">
                                {JSON.stringify(event.payload, null, 2)}
                              </pre>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}