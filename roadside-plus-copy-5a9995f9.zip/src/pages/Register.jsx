import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { createPageUrl } from '@/utils';
import { User, Mail, Phone, Lock, Loader2, Users, Shield, Briefcase, Wrench, Gift } from 'lucide-react';
import BrandLogo from '../components/branding/BrandLogo';

export default function Register() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    role: 'customer',
    referralCode: ''
  });
  const [invitationToken, setInvitationToken] = useState(null);
  const [isInvited, setIsInvited] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [verifyingToken, setVerifyingToken] = useState(true);

  // Role definitions
  const roles = [
    { id: 'customer', label: 'Customer', icon: Users, color: 'blue' },
    { id: 'technician', label: 'Technician', icon: Wrench, color: 'orange' },
    { id: 'partner', label: 'Partner', icon: Briefcase, color: 'purple' },
    { id: 'security_company', label: 'Security Company', icon: Shield, color: 'green' },
    // Admin is hidden from selection unless invited
  ];

  useEffect(() => {
    const init = async () => {
      const params = new URLSearchParams(window.location.search);
      const token = params.get('token');
      const emailParam = params.get('email');
      const roleParam = params.get('role');
      const refCode = params.get('ref');

      // Handle Referral
      if (refCode) {
        setFormData(prev => ({ ...prev, referralCode: refCode }));
      }

      // Handle Invitation
      if (token) {
        setInvitationToken(token);
        try {
          const { data } = await base44.functions.invoke('verifyInvitation', { token });
          if (data.valid) {
            setIsInvited(true);
            setFormData(prev => ({
              ...prev,
              email: data.email,
              role: data.role // Auto-fill role from token
            }));
          } else {
            setError(`Invalid invitation: ${data.error}`);
          }
        } catch (err) {
          setError('Failed to verify invitation token.');
        }
      } else {
        // Handle manual role selection via URL (e.g., from RegisterSelection page)
        if (roleParam && roles.find(r => r.id === roleParam)) {
          setFormData(prev => ({ ...prev, role: roleParam }));
        } else if (emailParam) {
            setFormData(prev => ({ ...prev, email: emailParam }));
        }
      }
      setVerifyingToken(false);
    };

    init();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);

    try {
      // Register the user
      // This creates the user and session token immediately
      await base44.auth.register({
        email: formData.email,
        password: formData.password,
        full_name: formData.fullName,
        phone: formData.phone,
        role: formData.role // Write role to DB on sign-up
      });

      // CRITICAL: Force update the role to ensure it persists, 
      // in case the registration endpoint ignored the custom role field
      try {
        await base44.auth.updateMe({ role: formData.role });
      } catch (roleError) {
        console.error("Failed to force update role:", roleError);
        // Proceed anyway, as it might have worked during register
      }

      // Accept invitation if token exists
      if (invitationToken && isInvited) {
        try {
          await base44.functions.invoke('acceptInvitation', { token: invitationToken });
        } catch (err) {
          console.error("Failed to accept invitation", err);
          // Continue anyway as user is registered
        }
      }

      // Store referral code if needed
      if (formData.referralCode) {
        localStorage.setItem('pending_referral_code', formData.referralCode);
      }

      // Determine redirect dashboard based on role
      let dashboardPage = 'CustomerDashboard';
      if (formData.role === 'technician') dashboardPage = 'TechnicianDashboard';
      if (formData.role === 'partner') dashboardPage = 'PartnerDashboard';
      if (formData.role === 'security_company') dashboardPage = 'SecurityCommandCenter';
      if (formData.role === 'admin') dashboardPage = 'AdminDashboard';

      // Redirect to OTP verification
      // We rely on OTPVerification's default behavior (redirectToRoleDashboard) to handle 
      // profile creation and correct routing based on the user's role
      window.location.href = createPageUrl('OTPVerification') + 
        `?email=${encodeURIComponent(formData.email)}`;

    } catch (err) {
      console.error('Registration error:', err);
      setError(err.message || 'Registration failed. Please try again.');
      setLoading(false);
    }
  };

  if (verifyingToken && invitationToken) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'radial-gradient(circle at top right, #FF771D 0%, #E52C2D 100%)' }}>
        <Card className="w-full max-w-md text-center p-8 bg-white/95 backdrop-blur-sm shadow-2xl border-0">
          <Loader2 className="w-10 h-10 animate-spin mx-auto text-orange-500 mb-4" />
          <p className="text-lg font-medium text-gray-700">Verifying invitation...</p>
        </Card>
      </div>
    );
  }

  const currentRole = roles.find(r => r.id === formData.role) || roles[0];
  const RoleIcon = currentRole.icon;

  return (
    <div className="min-h-screen flex items-center justify-center p-4 lg:p-8" 
      style={{ 
        background: 'radial-gradient(circle at top right, #FF771D 0%, #E52C2D 50%, #991b1b 100%)',
      }}>
      
      <Card className="w-full max-w-lg border-0 shadow-2xl bg-white/95 backdrop-blur-md overflow-hidden rounded-2xl ring-1 ring-black/5">
        {/* Header with brand gradient */}
        <div className="relative bg-gradient-to-b from-orange-50/50 to-white p-8 text-center border-b border-orange-100/50">
           <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-[#FF771D] via-[#E52C2D] to-[#FF771D] bg-[length:200%_100%] animate-gradient" />
           <div className="flex justify-center mb-6 transform hover:scale-105 transition-transform duration-300 drop-shadow-sm">
             <BrandLogo variant="full" size="xl" />
           </div>
           <h1 className="text-3xl font-bold text-gray-900 tracking-tight mb-2">Create Account</h1>
           <p className="text-gray-500 font-medium">
             {isInvited ? `You have been invited as a ${formData.role.replace('_', ' ')}` : 'Join the RoadsidePlus network'}
           </p>
        </div>

        <CardContent className="p-8 pt-6">
          <form onSubmit={handleRegister} className="space-y-5">
            
            {/* Role Selection Dropdown */}
            <div className="space-y-1.5">
              <Label htmlFor="role" className="text-xs font-bold uppercase text-gray-500 tracking-wider ml-1">Account Type</Label>
              <div className="relative group">
                <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 group-focus-within:text-[#FF771D] transition-colors pointer-events-none z-10">
                    {isInvited ? <Lock className="w-5 h-5" /> : <RoleIcon className="w-5 h-5" />}
                </div>
                <select
                  id="role"
                  name="role"
                  value={formData.role}
                  onChange={handleChange}
                  disabled={isInvited}
                  className="flex h-12 w-full rounded-xl border border-gray-200 bg-gray-50/50 px-3 py-2 pl-11 text-sm ring-offset-background transition-all hover:bg-white hover:border-gray-300 focus:bg-white focus:border-[#FF771D] focus:ring-2 focus:ring-orange-100 focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50 appearance-none font-medium text-gray-900 shadow-sm"
                >
                  {roles.map(role => (
                    <option key={role.id} value={role.id}>
                      {role.label}
                    </option>
                  ))}
                  {isInvited && formData.role === 'admin' && (
                      <option value="admin">Administrator</option>
                  )}
                </select>
                {/* Custom Chevron */}
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400">
                   <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                </div>
              </div>
              {isInvited && (
                  <p className="text-xs text-orange-600 mt-1 font-medium ml-1">Role is locked by invitation</p>
              )}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="fullName" className="text-xs font-bold uppercase text-gray-500 tracking-wider ml-1">Full Name</Label>
              <div className="relative group">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-[#FF771D] transition-colors z-10" />
                <Input
                  id="fullName"
                  name="fullName"
                  type="text"
                  placeholder="John Doe"
                  value={formData.fullName}
                  onChange={handleChange}
                  className="pl-11 h-12 rounded-xl border-gray-200 bg-gray-50/50 focus:bg-white focus:border-[#FF771D] focus:ring-orange-100 transition-all shadow-sm"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-xs font-bold uppercase text-gray-500 tracking-wider ml-1">Email Address</Label>
              <div className="relative group">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-[#FF771D] transition-colors z-10" />
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={handleChange}
                  className="pl-11 h-12 rounded-xl border-gray-200 bg-gray-50/50 focus:bg-white focus:border-[#FF771D] focus:ring-orange-100 transition-all shadow-sm disabled:bg-gray-100 disabled:text-gray-500"
                  required
                  disabled={isInvited}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="phone" className="text-xs font-bold uppercase text-gray-500 tracking-wider ml-1">Phone Number</Label>
              <div className="relative group">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-[#FF771D] transition-colors z-10" />
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  value={formData.phone}
                  onChange={handleChange}
                  className="pl-11 h-12 rounded-xl border-gray-200 bg-gray-50/50 focus:bg-white focus:border-[#FF771D] focus:ring-orange-100 transition-all shadow-sm"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="space-y-1.5">
                  <Label htmlFor="password" className="text-xs font-bold uppercase text-gray-500 tracking-wider ml-1">Password</Label>
                  <div className="relative group">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-[#FF771D] transition-colors z-10" />
                    <Input
                      id="password"
                      name="password"
                      type="password"
                      placeholder="••••••••"
                      value={formData.password}
                      onChange={handleChange}
                      className="pl-11 h-12 rounded-xl border-gray-200 bg-gray-50/50 focus:bg-white focus:border-[#FF771D] focus:ring-orange-100 transition-all shadow-sm"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="confirmPassword" className="text-xs font-bold uppercase text-gray-500 tracking-wider ml-1">Confirm</Label>
                  <div className="relative group">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-[#FF771D] transition-colors z-10" />
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      placeholder="••••••••"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      className="pl-11 h-12 rounded-xl border-gray-200 bg-gray-50/50 focus:bg-white focus:border-[#FF771D] focus:ring-orange-100 transition-all shadow-sm"
                      required
                    />
                  </div>
                </div>
            </div>

            {!isInvited && (
                <div className="space-y-1.5">
                <Label htmlFor="referralCode" className="text-xs font-bold uppercase text-gray-500 tracking-wider ml-1">Referral Code (Optional)</Label>
                <div className="relative group">
                    <Gift className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-[#FF771D] transition-colors z-10" />
                    <Input
                    id="referralCode"
                    name="referralCode"
                    type="text"
                    placeholder="Enter referral code"
                    value={formData.referralCode}
                    onChange={handleChange}
                    className="pl-11 h-12 rounded-xl border-gray-200 bg-gray-50/50 focus:bg-white focus:border-[#FF771D] focus:ring-orange-100 transition-all shadow-sm"
                    />
                </div>
                </div>
            )}

            {error && (
              <div className="bg-red-50 border border-red-100 rounded-xl p-4 flex items-start gap-3 shadow-sm animate-in fade-in slide-in-from-top-2">
                <div className="p-1 bg-red-100 rounded-full">
                   <span className="text-red-600 text-lg block w-5 h-5 text-center leading-5">!</span>
                </div>
                <p className="text-sm text-red-800 pt-0.5 font-medium">{error}</p>
              </div>
            )}

            <Button
              type="submit"
              className="w-full h-12 text-base font-bold text-white shadow-lg shadow-orange-500/30 hover:shadow-orange-500/50 transition-all transform hover:-translate-y-0.5 rounded-xl bg-gradient-to-r from-[#FF771D] to-[#E52C2D] hover:from-[#FF8833] hover:to-[#F04040]"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Creating Account...
                </>
              ) : (
                'Create Account'
              )}
            </Button>

            <div className="text-center pt-4 border-t border-gray-100">
              <p className="text-sm text-gray-500">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => base44.auth.redirectToLogin()}
                  className="font-bold text-[#FF771D] hover:text-[#E52C2D] transition-colors hover:underline"
                >
                  Sign in
                </button>
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}