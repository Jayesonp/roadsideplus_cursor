import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, CreditCard, Loader2, CheckCircle2, Plus } from 'lucide-react';
import { createPageUrl } from '@/utils';
import ServiceTypeIcon from '../components/common/ServiceTypeIcon';
import { format } from 'date-fns';
import PaymentMethodTabs from '../components/payments/PaymentMethodTabs';

export default function CustomerPayment() {
  const [requestId, setRequestId] = useState(null);
  const [user, setUser] = useState(null);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setRequestId(params.get('requestId'));
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const { data: request, isLoading } = useQuery({
    queryKey: ['service-request', requestId],
    queryFn: async () => {
      const requests = await base44.entities.ServiceRequest.filter({ id: requestId });
      return requests[0];
    },
    enabled: !!requestId
  });

  const handlePaymentSuccess = (paymentData) => {
    setPaymentSuccess(true);
    setTimeout(() => {
      window.location.href = createPageUrl(`ServiceDetails?id=${request.id}`);
    }, 2000);
  };

  if (isLoading || !request) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF771D' }} />
      </div>
    );
  }

  const amount = request.payment_amount || request.price || 0;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-2xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20"
            onClick={() => window.location.href = createPageUrl(`ServiceDetails?id=${request.id}`)}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Payment</h1>
            <p className="text-sm opacity-90">Complete your service payment</p>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-6">
        {paymentSuccess && (
          <Card className="mb-6 border-2 border-green-500 bg-green-50">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-12 h-12 text-green-600" />
                <div>
                  <h3 className="text-xl font-bold text-green-900">Payment Successful!</h3>
                  <p className="text-green-700">Redirecting you back to service details...</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Service Summary */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <ServiceTypeIcon type={request.service_type} />
              Service Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center pb-4 border-b">
              <div>
                <p className="font-semibold">
                  {request.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </p>
                <p className="text-sm text-gray-600">{request.location_address}</p>
                {request.completed_at && (
                  <p className="text-xs text-gray-500 mt-1">
                    Completed: {format(new Date(request.completed_at), 'MMM d, yyyy h:mm a')}
                  </p>
                )}
              </div>
            </div>

            {request.vehicle_make && (
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-sm font-semibold mb-1">Vehicle</p>
                <p className="text-sm text-gray-700">
                  {request.vehicle_year} {request.vehicle_make} {request.vehicle_model}
                  {request.vehicle_color && ` - ${request.vehicle_color}`}
                </p>
                {request.vehicle_license_plate && (
                  <p className="text-xs text-gray-600 mt-1">Plate: {request.vehicle_license_plate}</p>
                )}
              </div>
            )}

            {/* Amount Breakdown */}
            <div className="space-y-2 pt-4 border-t">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Service Fee</span>
                <span className="font-semibold">${amount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Platform Fee</span>
                <span className="font-semibold">$0.00</span>
              </div>
              <div className="flex justify-between text-lg font-bold pt-2 border-t">
                <span>Total Amount</span>
                <span style={{ color: '#FF771D' }}>${amount.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Method Tabs */}
        {!paymentSuccess && (
          <PaymentMethodTabs
            amount={amount}
            requestId={request.id}
            onSuccess={handlePaymentSuccess}
          />
        )}
      </div>
    </div>
  );
}