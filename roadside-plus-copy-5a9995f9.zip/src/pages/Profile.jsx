import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Save, User, Loader2 } from 'lucide-react';
import { createPageUrl } from '@/utils';
import VehicleManager from '../components/customer/VehicleManager';
import ServiceHistory from '../components/customer/ServiceHistory';
import PaymentMethodsManager from '../components/customer/PaymentMethodsManager';

export default function Profile() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    full_name: '',
    phone: '',
    email: ''
  });

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      setFormData({
        full_name: currentUser.full_name || '',
        phone: currentUser.phone || '',
        email: currentUser.email || ''
      });
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = useMutation({
    mutationFn: async () => {
      return await base44.auth.updateMe({
        full_name: formData.full_name,
        phone: formData.phone
      });
    },
    onSuccess: (updated) => {
      setUser(updated);
      alert('Profile updated successfully!');
    }
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF771D' }} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-6xl mx-auto flex items-center gap-4">
          <Button 
            variant="ghost" 
            className="text-white hover:bg-white/20"
            onClick={() => window.location.href = createPageUrl(user?.user_type === 'customer' ? 'CustomerDashboard' : 'TechnicianDashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">My Profile</h1>
            <p className="text-sm opacity-90">Manage your account information</p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="personal">Personal Info</TabsTrigger>
            <TabsTrigger value="vehicles">My Vehicles</TabsTrigger>
            <TabsTrigger value="payment">Payment Methods</TabsTrigger>
            <TabsTrigger value="history">Service History</TabsTrigger>
          </TabsList>

          <TabsContent value="personal">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: '#FF771D' }}>
                    <User className="w-6 h-6 text-white" />
                  </div>
                  <span>Personal Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={(e) => { e.preventDefault(); updateProfile.mutate(); }} className="space-y-6">
                  <div>
                    <Label htmlFor="full_name">Full Name</Label>
                    <Input
                      id="full_name"
                      value={formData.full_name}
                      onChange={(e) => setFormData({...formData, full_name: e.target.value})}
                      className="mt-2"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      disabled
                      className="mt-2 bg-gray-100"
                    />
                    <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
                  </div>

                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className="mt-2"
                      placeholder="Enter your phone number"
                    />
                  </div>

                  <div className="pt-4">
                    <Button
                      type="submit"
                      disabled={updateProfile.isLoading}
                      className="w-full text-white py-6 text-lg font-semibold hover:opacity-90"
                      style={{ backgroundColor: '#FF771D' }}
                    >
                      {updateProfile.isLoading ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="w-5 h-5 mr-2" />
                          Save Changes
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* Account Type */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Account Type</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-semibold">
                      {user?.user_type === 'customer' ? 'Customer Account' : 'Technician Account'}
                    </p>
                    <p className="text-sm text-gray-600">
                      You're using ROADSIDEPLUS as a {user?.user_type}
                    </p>
                  </div>
                  <div 
                    className="px-4 py-2 rounded-full text-white font-semibold"
                    style={{ backgroundColor: user?.user_type === 'customer' ? '#FF771D' : '#E52C2D' }}
                  >
                    {user?.user_type?.toUpperCase()}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="vehicles">
            <VehicleManager userId={user.id} />
          </TabsContent>

          <TabsContent value="payment">
            <PaymentMethodsManager userId={user.id} />
          </TabsContent>

          <TabsContent value="history">
            <ServiceHistory userId={user.id} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}