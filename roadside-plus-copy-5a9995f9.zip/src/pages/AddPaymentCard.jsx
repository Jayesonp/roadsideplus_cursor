import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { CreditCard, Loader2, AlertCircle, Shield } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { createPageUrl } from '@/utils';

export default function AddPaymentCard() {
  const [cardData, setCardData] = useState({
    cardNumber: '',
    cardholderName: '',
    expiryMonth: '',
    expiryYear: '',
    cvc: '',
    billingZip: '',
    isDefault: true
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState(null);

  React.useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const handleCardNumberChange = (e) => {
    let value = e.target.value.replace(/\s/g, '');
    value = value.replace(/(\d{4})/g, '$1 ').trim();
    setCardData({ ...cardData, cardNumber: value });
  };

  const fillTestCard = () => {
    setCardData({
      cardNumber: '4242 4242 4242 4242',
      cardholderName: 'Test Customer',
      expiryMonth: '12',
      expiryYear: '2028',
      cvc: '123',
      billingZip: '12345',
      isDefault: true
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    try {
      const cardNumber = cardData.cardNumber.replace(/\s/g, '');
      if (cardNumber.length < 13 || cardNumber.length > 19) {
        throw new Error('Invalid card number');
      }

      const firstDigit = cardNumber[0];
      let cardBrand = 'Unknown';
      if (firstDigit === '4') cardBrand = 'Visa';
      else if (firstDigit === '5') cardBrand = 'Mastercard';
      else if (firstDigit === '3') cardBrand = 'Amex';
      else if (firstDigit === '6') cardBrand = 'Discover';

      const gatewayToken = `tok_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      await base44.entities.PaymentMethod.create({
        user_id: user.id,
        payment_type: 'credit_card',
        card_brand: cardBrand,
        last_four: cardNumber.slice(-4),
        expiry_month: cardData.expiryMonth,
        expiry_year: cardData.expiryYear,
        cardholder_name: cardData.cardholderName,
        is_default: cardData.isDefault,
        gateway_token: gatewayToken,
        billing_zip: cardData.billingZip
      });

      clearTimeout(timeoutId);
      window.location.href = createPageUrl('CustomerDashboard');
    } catch (error) {
      clearTimeout(timeoutId);
      setError(error.message || 'Failed to add payment method. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF771D' }} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <CreditCard className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Add Payment Card</h1>
          <p className="text-gray-600">Complete your account setup by adding a payment method</p>
        </div>

        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" style={{ color: '#3D692B' }} />
              Secure Payment Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Alert className="mb-4 border-blue-200 bg-blue-50">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800 text-sm">
                <strong>Test Mode:</strong> Use 4242 4242 4242 4242 for testing.
                <Button
                  type="button"
                  variant="link"
                  className="p-0 h-auto ml-2 text-blue-600"
                  onClick={fillTestCard}
                >
                  Fill Test Card
                </Button>
              </AlertDescription>
            </Alert>

            {error && (
              <Alert className="mb-4 border-red-200 bg-red-50">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800 text-sm">{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="cardholderName">Cardholder Name *</Label>
                <Input
                  id="cardholderName"
                  value={cardData.cardholderName}
                  onChange={(e) => setCardData({ ...cardData, cardholderName: e.target.value })}
                  placeholder="John Doe"
                  required
                  disabled={loading}
                />
              </div>

              <div>
                <Label htmlFor="cardNumber">Card Number *</Label>
                <Input
                  id="cardNumber"
                  value={cardData.cardNumber}
                  onChange={handleCardNumberChange}
                  placeholder="1234 5678 9012 3456"
                  maxLength={19}
                  required
                  disabled={loading}
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label htmlFor="expiryMonth">Month *</Label>
                  <Input
                    id="expiryMonth"
                    value={cardData.expiryMonth}
                    onChange={(e) => setCardData({ ...cardData, expiryMonth: e.target.value })}
                    placeholder="MM"
                    maxLength={2}
                    required
                    disabled={loading}
                  />
                </div>
                <div>
                  <Label htmlFor="expiryYear">Year *</Label>
                  <Input
                    id="expiryYear"
                    value={cardData.expiryYear}
                    onChange={(e) => setCardData({ ...cardData, expiryYear: e.target.value })}
                    placeholder="YYYY"
                    maxLength={4}
                    required
                    disabled={loading}
                  />
                </div>
                <div>
                  <Label htmlFor="cvc">CVV *</Label>
                  <Input
                    id="cvc"
                    type="text"
                    value={cardData.cvc}
                    onChange={(e) => setCardData({ ...cardData, cvc: e.target.value.replace(/\D/g, '') })}
                    placeholder="123"
                    maxLength={4}
                    required
                    disabled={loading}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="billingZip">Billing ZIP Code *</Label>
                <Input
                  id="billingZip"
                  value={cardData.billingZip}
                  onChange={(e) => setCardData({ ...cardData, billingZip: e.target.value })}
                  placeholder="12345"
                  maxLength={10}
                  required
                  disabled={loading}
                />
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full text-white text-lg py-6"
                style={{ backgroundColor: '#FF771D' }}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Adding Card...
                  </>
                ) : (
                  'Complete Setup'
                )}
              </Button>
            </form>

            <div className="mt-4 text-center text-xs text-gray-500">
              <Shield className="w-4 h-4 inline mr-1" />
              Your payment information is encrypted and secure
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}