import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  CheckCircle, Circle, ArrowRight, User, FileText, MapPin, 
  Award, Loader2, Wrench, PlayCircle
} from 'lucide-react';
import { createPageUrl } from '@/utils';
import OnboardingWalkthrough from '../components/technician/OnboardingWalkthrough';
import TechnicianOnboardingWizard from '../components/technician/TechnicianOnboardingWizard';

export default function TechnicianOnboardingChecklist() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showWalkthrough, setShowWalkthrough] = useState(false);
  const [showOnboardingWizard, setShowOnboardingWizard] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      const profiles = await base44.entities.TechnicianProfile.filter({ user_id: currentUser.id });
      if (profiles.length > 0) {
        setProfile(profiles[0]);
      } else {
        // No profile yet - show wizard immediately
        setShowOnboardingWizard(true);
      }
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setLoading(false);
    }
  };

  const checklistItems = [
    {
      id: 'profile',
      title: 'Complete Your Profile',
      description: 'Complete identity, driving, and vehicle verification',
      completed: profile?.onboarding_status === 'submitted' || profile?.onboarding_status === 'approved' || profile?.onboarding_status === 'reviewing',
      action: 'Start Onboarding',
      link: 'TechnicianOnboarding',
      icon: User,
      color: '#FF771D'
    },
    {
      id: 'skills',
      title: 'Add Your Skills',
      description: 'Select your technical skills and expertise areas',
      completed: !!(profile?.skills && profile.skills.length > 0),
      action: 'Add Skills',
      link: 'TechnicianProfile',
      icon: Wrench,
      color: '#3D692B'
    },
    {
      id: 'certifications',
      title: 'Upload Certifications',
      description: 'Add your professional certifications and documents',
      completed: !!(profile?.certifications && profile.certifications.length > 0),
      action: 'Add Certifications',
      link: 'TechnicianProfile',
      icon: Award,
      color: '#E52C2D'
    },
    {
      id: 'specialties',
      title: 'Select Service Specialties',
      description: 'Choose your service specialties and preferred service types',
      completed: !!(profile?.specialties && profile.specialties.length > 0) || 
                 !!(profile?.preferred_service_types && profile.preferred_service_types.length > 0),
      action: 'Add Specialties',
      link: 'TechnicianProfile',
      icon: Wrench,
      color: '#FF771D'
    },
    {
      id: 'service_area',
      title: 'Set Service Area',
      description: 'Define your preferred work zones and service radius',
      completed: !!(profile?.service_area_center_lat && profile?.service_area_center_lng),
      action: 'Set Area',
      link: 'TechnicianProfile',
      icon: MapPin,
      color: '#3D692B'
    },
    {
      id: 'documents',
      title: 'Upload Required Documents',
      description: "Driver's license and insurance documents",
      completed: !!(profile?.drivers_license_url && profile?.insurance_url),
      action: 'Upload',
      link: 'TechnicianProfile',
      icon: FileText,
      color: '#E52C2D'
    },
    {
      id: 'walkthrough',
      title: 'Take the Platform Tour',
      description: 'Learn how to use the dashboard and accept jobs',
      completed: localStorage.getItem('walkthrough_completed') === 'true',
      action: 'Start Tour',
      onClick: () => setShowWalkthrough(true),
      icon: PlayCircle,
      color: '#FF771D'
    }
  ];

  const completedCount = checklistItems.filter(item => item.completed).length;
  const progress = (completedCount / checklistItems.length) * 100;

  const handleWalkthroughComplete = () => {
    localStorage.setItem('walkthrough_completed', 'true');
    setShowWalkthrough(false);
    window.location.reload();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF771D' }} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header Card */}
        <Card className="mb-6 border-2" style={{ borderColor: '#FF771D' }}>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-2">Welcome to ROADSIDE+! 🚗</h1>
                <p className="text-gray-600 mb-4">
                  Complete your onboarding to start earning. Let's get you set up!
                </p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">Overall Progress</span>
                    <span className="font-bold" style={{ color: '#FF771D' }}>
                      {completedCount} of {checklistItems.length} completed
                    </span>
                  </div>
                  <Progress 
                    value={progress} 
                    className="h-3"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Next Steps Guide */}
        {progress < 100 && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-lg animate-pulse">
                !
              </div>
              <h2 className="text-xl font-bold text-gray-800">Next Step Required</h2>
            </div>
            
            {(() => {
              const nextItem = checklistItems.find(item => !item.completed);
              if (!nextItem) return null;
              
              const NextIcon = nextItem.icon || Circle;
              
              return (
                <Card className="border-2 border-blue-200 bg-blue-50 shadow-lg relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-10">
                    <NextIcon className="w-32 h-32" />
                  </div>
                  <CardContent className="p-6 relative z-10">
                    <div className="flex flex-col md:flex-row md:items-center gap-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold text-blue-900 mb-1">
                          {nextItem.title}
                        </h3>
                        <p className="text-blue-800 mb-0">
                          {nextItem.description}
                        </p>
                        <p className="text-sm text-blue-600 mt-2 font-medium">
                          Completing this will bring you to {Math.round(((completedCount + 1) / checklistItems.length) * 100)}% progress
                        </p>
                      </div>
                      <Button
                        onClick={() => {
                          if (nextItem.onClick) {
                            nextItem.onClick();
                          } else if (nextItem.link) {
                            window.location.href = createPageUrl(nextItem.link);
                          }
                        }}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all"
                      >
                        Complete Now
                        <ArrowRight className="w-5 h-5 ml-2" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })()}
          </div>
        )}

        {/* Checklist Items */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-6 h-6" style={{ color: '#FF771D' }} />
              Onboarding Steps
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {checklistItems.map((item) => {
                const Icon = item.icon || Circle;
                return (
                  <Card
                    key={item.id}
                    className={`transition-all ${
                      item.completed 
                        ? 'bg-green-50 border-green-200' 
                        : 'hover:shadow-md border-2'
                    }`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 flex-1">
                          <div
                            className="w-12 h-12 rounded-full flex items-center justify-center"
                            style={{ backgroundColor: item.completed ? '#3D692B' : item.color }}
                          >
                            {item.completed ? (
                              <CheckCircle className="w-6 h-6 text-white" />
                            ) : (
                              <Icon className="w-6 h-6 text-white" />
                            )}
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg">{item.title}</h3>
                            <p className="text-sm text-gray-600">{item.description}</p>
                          </div>
                        </div>
                        {!item.completed && (
                          <Button
                            onClick={() => {
                              if (item.onClick) {
                                item.onClick();
                              } else if (item.link) {
                                window.location.href = createPageUrl(item.link);
                              }
                            }}
                            className="ml-4 text-white"
                            style={{ backgroundColor: item.color }}
                          >
                            {item.action}
                            <ArrowRight className="w-4 h-4 ml-2" />
                          </Button>
                        )}
                        {item.completed && (
                          <span className="ml-4 text-green-600 font-semibold">✓ Done</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {(profile?.onboarding_status === 'submitted' || profile?.onboarding_status === 'reviewing') && (
              <Card className="mt-6 border-2 border-yellow-500 bg-yellow-50">
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 rounded-full bg-yellow-500 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-12 h-12 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-yellow-900 mb-2">
                    Application Submitted! 📝
                  </h3>
                  <p className="text-yellow-800 mb-6 text-lg">
                    Your application is under review. We will notify you once your documents are verified.
                  </p>
                </CardContent>
              </Card>
            )}

            {profile?.onboarding_status === 'approved' && (
              <Card className="mt-6 border-2 border-green-500 bg-green-50">
                <CardContent className="p-8 text-center">
                  <div className="w-20 h-20 rounded-full bg-green-500 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-12 h-12 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-green-900 mb-2">
                    Onboarding Approved! 🎉
                  </h3>
                  <p className="text-green-800 mb-6 text-lg">
                    Congratulations! You're all set to start earning. Head to your dashboard and toggle your availability to ON.
                  </p>
                  <Button
                    onClick={() => window.location.href = createPageUrl('TechnicianDashboard')}
                    className="text-white text-lg px-8 py-6"
                    style={{ backgroundColor: '#3D692B' }}
                  >
                    Go to Dashboard
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>

        {/* Help Card */}
        <Card className="mt-6 bg-blue-50 border-blue-200">
          <CardContent className="p-6">
            <h3 className="font-semibold text-blue-900 mb-2">Need Help?</h3>
            <p className="text-sm text-blue-800 mb-3">
              If you have any questions or need assistance, our support team is here to help!
            </p>
            <Button
              variant="outline"
              onClick={() => window.location.href = createPageUrl('AISupportChat')}
              className="border-blue-300 text-blue-700"
            >
              Contact Support
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Onboarding Wizard - First Time Setup */}
      {showOnboardingWizard && user && (
        <TechnicianOnboardingWizard
          user={user}
          onComplete={() => {
            setShowOnboardingWizard(false);
            loadUser();
          }}
        />
      )}

      {/* Walkthrough Modal */}
      {showWalkthrough && (
        <OnboardingWalkthrough
          onComplete={handleWalkthroughComplete}
          onSkip={handleWalkthroughComplete}
        />
      )}
    </div>
  );
}