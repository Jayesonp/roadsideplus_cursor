import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  DollarSign, Calendar, User, CheckCircle, Clock, 
  AlertCircle, TrendingUp, Download, Filter, Eye,
  Send, XCircle, Loader2
} from 'lucide-react';
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';

export default function AdminTechnicianPayouts() {
  const [user, setUser] = useState(null);
  const [selectedPeriod, setSelectedPeriod] = useState('current');
  const [selectedTech, setSelectedTech] = useState(null);
  const [processingPayout, setProcessingPayout] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  // Calculate period dates
  const getPeriodDates = () => {
    const now = new Date();
    if (selectedPeriod === 'current') {
      return { start: startOfMonth(now), end: endOfMonth(now) };
    } else if (selectedPeriod === 'last') {
      const lastMonth = subMonths(now, 1);
      return { start: startOfMonth(lastMonth), end: endOfMonth(lastMonth) };
    }
    return { start: startOfMonth(now), end: endOfMonth(now) };
  };

  const { start: periodStart, end: periodEnd } = getPeriodDates();

  const { data: technicians = [] } = useQuery({
    queryKey: ['payout-technicians'],
    queryFn: async () => {
      return await base44.entities.TechnicianProfile.list();
    },
    enabled: !!user && user.role === 'admin'
  });

  const { data: completedJobs = [] } = useQuery({
    queryKey: ['completed-jobs', selectedPeriod],
    queryFn: async () => {
      const jobs = await base44.entities.ServiceRequest.filter({
        status: 'completed'
      }, '-completed_at', 1000);
      
      return jobs.filter(job => {
        const completedDate = new Date(job.completed_at);
        return completedDate >= periodStart && completedDate <= periodEnd;
      });
    },
    enabled: !!user && user.role === 'admin'
  });

  const { data: ratings = [] } = useQuery({
    queryKey: ['payout-ratings'],
    queryFn: async () => {
      return await base44.entities.Rating.list('-created_date', 1000);
    },
    enabled: !!user && user.role === 'admin'
  });

  const createPayout = useMutation({
    mutationFn: async (payoutData) => {
      return await base44.entities.PartnerPayout.create(payoutData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['technician-payouts']);
      alert('Payout record created successfully!');
      setProcessingPayout(false);
    }
  });

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <AlertCircle className="w-12 h-12 mx-auto mb-4" style={{ color: '#E52C2D' }} />
          <h2 className="text-xl font-bold">Access Denied</h2>
        </Card>
      </div>
    );
  }

  // Calculate earnings per technician
  const technicianEarnings = technicians.map(tech => {
    const techJobs = completedJobs.filter(job => job.technician_id === tech.user_id);
    const totalRevenue = techJobs.reduce((sum, job) => sum + (job.price || 0), 0);
    const techRatings = ratings.filter(r => r.technician_id === tech.user_id);
    const avgRating = techRatings.length > 0
      ? techRatings.reduce((sum, r) => sum + r.rating, 0) / techRatings.length
      : 0;
    
    // Standard payout: 70% of revenue
    const payoutAmount = totalRevenue * 0.70;

    return {
      tech,
      jobCount: techJobs.length,
      totalRevenue,
      payoutAmount,
      avgRating,
      jobs: techJobs
    };
  }).filter(t => t.jobCount > 0);

  const totalPayouts = technicianEarnings.reduce((sum, t) => sum + t.payoutAmount, 0);
  const totalRevenue = technicianEarnings.reduce((sum, t) => sum + t.totalRevenue, 0);
  const totalJobs = technicianEarnings.reduce((sum, t) => sum + t.jobCount, 0);

  const processPayout = async (earning) => {
    if (!confirm(`Process payout of $${earning.payoutAmount.toFixed(2)} for ${getTechName(earning.tech.user_id)}?`)) {
      return;
    }

    setProcessingPayout(true);
    
    await createPayout.mutate({
      partner_id: earning.tech.user_id,
      period_start: periodStart.toISOString().split('T')[0],
      period_end: periodEnd.toISOString().split('T')[0],
      total_jobs: earning.jobCount,
      total_revenue: earning.totalRevenue,
      commission_rate: 70,
      commission_amount: earning.payoutAmount,
      status: 'pending',
      payment_method: 'stripe_connect',
      job_ids: earning.jobs.map(j => j.id)
    });
  };

  const getTechName = (techId) => {
    const tech = technicians.find(t => t.user_id === techId);
    return tech ? `Tech ${tech.user_id.substring(0, 8)}` : 'Unknown';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="text-white p-6 shadow-lg" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">Technician Payouts</h1>
            <p className="text-sm opacity-90">Manage earnings and payouts for technicians</p>
          </div>
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-48 bg-white/10 border-white/30 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current">Current Month</SelectItem>
              <SelectItem value="last">Last Month</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Summary Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-6">
          <Card className="border-l-4" style={{ borderLeftColor: '#3D692B' }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Payouts</p>
                  <p className="text-2xl font-bold" style={{ color: '#3D692B' }}>
                    ${totalPayouts.toFixed(2)}
                  </p>
                </div>
                <DollarSign className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4" style={{ borderLeftColor: '#FF771D' }}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Revenue</p>
                  <p className="text-2xl font-bold" style={{ color: '#FF771D' }}>
                    ${totalRevenue.toFixed(2)}
                  </p>
                </div>
                <TrendingUp className="w-10 h-10 opacity-20" style={{ color: '#FF771D' }} />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-blue-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Completed Jobs</p>
                  <p className="text-2xl font-bold text-blue-600">{totalJobs}</p>
                </div>
                <CheckCircle className="w-10 h-10 text-blue-500 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Active Techs</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {technicianEarnings.length}
                  </p>
                </div>
                <User className="w-10 h-10 text-purple-500 opacity-20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Period Info */}
        <Card className="mb-6 bg-blue-50 border-blue-200">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-600" />
                <span className="font-semibold text-blue-900">
                  Payout Period: {format(periodStart, 'MMM d, yyyy')} - {format(periodEnd, 'MMM d, yyyy')}
                </span>
              </div>
              <Badge className="bg-blue-600 text-white">
                {selectedPeriod === 'current' ? 'Current Month' : 'Last Month'}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Technician Earnings List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Technician Earnings Breakdown</span>
              <span className="text-sm font-normal text-gray-500">
                {technicianEarnings.length} technician(s)
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {technicianEarnings.length === 0 ? (
                <div className="text-center py-12">
                  <DollarSign className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-gray-500">No earnings recorded for this period</p>
                </div>
              ) : (
                technicianEarnings
                  .sort((a, b) => b.payoutAmount - a.payoutAmount)
                  .map((earning, idx) => (
                    <Card key={earning.tech.id} className="border-2 hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-4 flex-1">
                            <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg"
                                 style={{ backgroundColor: '#FF771D' }}>
                              {idx + 1}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <h3 className="font-bold text-lg">
                                  {getTechName(earning.tech.user_id)}
                                </h3>
                                <Badge variant="outline">
                                  {earning.tech.phone}
                                </Badge>
                              </div>

                              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
                                <div>
                                  <p className="text-gray-600">Jobs Completed</p>
                                  <p className="font-bold text-lg">{earning.jobCount}</p>
                                </div>
                                <div>
                                  <p className="text-gray-600">Total Revenue</p>
                                  <p className="font-bold text-lg" style={{ color: '#FF771D' }}>
                                    ${earning.totalRevenue.toFixed(2)}
                                  </p>
                                </div>
                                <div>
                                  <p className="text-gray-600">Payout (70%)</p>
                                  <p className="font-bold text-lg" style={{ color: '#3D692B' }}>
                                    ${earning.payoutAmount.toFixed(2)}
                                  </p>
                                </div>
                                <div>
                                  <p className="text-gray-600">Avg Rating</p>
                                  <p className="font-bold text-lg">
                                    {earning.avgRating > 0 ? earning.avgRating.toFixed(1) : 'N/A'} ⭐
                                  </p>
                                </div>
                              </div>

                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  onClick={() => setSelectedTech(earning)}
                                  variant="outline"
                                >
                                  <Eye className="w-3 h-3 mr-1" />
                                  View Jobs
                                </Button>
                                <Button
                                  size="sm"
                                  onClick={() => processPayout(earning)}
                                  disabled={processingPayout}
                                  className="text-white"
                                  style={{ backgroundColor: '#3D692B' }}
                                >
                                  {processingPayout ? (
                                    <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                                  ) : (
                                    <Send className="w-3 h-3 mr-1" />
                                  )}
                                  Process Payout
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Commission Structure Info */}
        <Card className="mt-6 bg-yellow-50 border-yellow-200">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-yellow-600" />
              Commission Structure
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex items-center justify-between py-2 border-b">
              <span className="text-gray-700">Technician Earnings</span>
              <span className="font-bold" style={{ color: '#3D692B' }}>70%</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b">
              <span className="text-gray-700">Platform Fee</span>
              <span className="font-bold" style={{ color: '#FF771D' }}>30%</span>
            </div>
            <p className="text-xs text-gray-600 pt-2">
              Technicians receive 70% of the service fee. Platform retains 30% for operations, insurance, and support.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Job Details Modal */}
      {selectedTech && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <Card className="w-full max-w-4xl my-8">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Jobs for {getTechName(selectedTech.tech.user_id)}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedTech(null)}
                >
                  <XCircle className="w-5 h-5" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-[60vh] overflow-y-auto">
                {selectedTech.jobs.map(job => (
                  <Card key={job.id} className="border">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <ServiceTypeIcon type={job.service_type} />
                            <h4 className="font-semibold">
                              {job.service_type.replace(/_/g, ' ').toUpperCase()}
                            </h4>
                          </div>
                          <div className="grid md:grid-cols-2 gap-2 text-sm text-gray-600">
                            <p className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {format(new Date(job.completed_at), 'MMM d, yyyy')}
                            </p>
                            {job.location_address && (
                              <p className="flex items-start gap-1">
                                <MapPin className="w-3 h-3 mt-0.5" />
                                <span className="line-clamp-1">{job.location_address}</span>
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-lg" style={{ color: '#3D692B' }}>
                            ${job.price?.toFixed(2)}
                          </p>
                          <p className="text-xs text-gray-500">
                            Tech gets: ${(job.price * 0.70).toFixed(2)}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}