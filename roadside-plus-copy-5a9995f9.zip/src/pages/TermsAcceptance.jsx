import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { CheckCircle, FileText, Shield } from 'lucide-react';
import { createPageUrl } from '@/utils';
import BrandLogo from '../components/branding/BrandLogo';

export default function TermsAcceptance() {
  const [user, setUser] = useState(null);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [privacyAccepted, setPrivacyAccepted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [userType, setUserType] = useState('customer');

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
    
    // Determine user type
    const techProfiles = await base44.entities.TechnicianProfile.filter({ user_id: currentUser.id });
    if (techProfiles.length > 0) {
      setUserType('technician');
    }
  };

  const handleAccept = async () => {
    if (!termsAccepted || !privacyAccepted) return;
    
    setLoading(true);
    try {
      await base44.auth.updateMe({
        terms_accepted: true,
        terms_accepted_date: new Date().toISOString(),
        privacy_accepted: true,
        privacy_accepted_date: new Date().toISOString()
      });

      // Use the central router to determine where to go next
      // This handles all roles correctly (technician onboarding, partner dashboard, etc.)
      const { redirectToRoleDashboard } = await import('../components/auth/RoleBasedRouter');
      await redirectToRoleDashboard();
    } catch (error) {
      console.error('Error accepting terms:', error);
      // Fallback redirect if router fails
      window.location.href = createPageUrl('CustomerDashboard');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-6 flex items-center justify-center">
      <div className="max-w-4xl w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mx-auto mb-4">
            <BrandLogo variant="full" size="lg" />
          </div>
          <h1 className="text-3xl font-bold mb-2">Legal Agreement</h1>
          <p className="text-gray-600">Please review and accept our terms to continue</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {/* Terms & Conditions */}
          <Card className={termsAccepted ? 'border-2 border-green-500' : ''}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" style={{ color: '#FF771D' }} />
                Terms & Conditions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[300px] border rounded-lg p-4 mb-4 bg-white">
                <div className="text-sm text-gray-700 space-y-4">
                  <h3 className="font-bold text-base">ROADSIDEPLUS Terms of Service</h3>
                  
                  <section>
                    <h4 className="font-semibold mb-2">1. Service Agreement</h4>
                    <p>By using ROADSIDEPLUS, you agree to these terms and conditions. Our platform connects customers with qualified roadside assistance technicians.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">2. User Responsibilities</h4>
                    <p>Users must provide accurate information, maintain account security, and use the service lawfully. Technicians must maintain proper certifications and insurance.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">3. Payment Terms</h4>
                    <p>Payment is processed securely through our platform. Customers authorize charges for requested services. Technicians receive payment according to our fee structure.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">4. Cancellation Policy</h4>
                    <p>Services may be cancelled with appropriate notice. Cancellation fees may apply depending on timing and circumstances.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">5. Liability</h4>
                    <p>ROADSIDEPLUS acts as a platform connecting users and technicians. We are not liable for the quality of services performed by independent technicians.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">6. Dispute Resolution</h4>
                    <p>Disputes should be reported through our support system. We facilitate resolution between parties but are not responsible for service quality issues.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">7. Service Modifications</h4>
                    <p>We reserve the right to modify, suspend, or discontinue services with notice. Changes to terms will be communicated to users.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">8. Account Termination</h4>
                    <p>We may suspend or terminate accounts for violations of these terms, fraudulent activity, or other serious breaches.</p>
                  </section>
                </div>
              </ScrollArea>

              <label className="flex items-start gap-3 cursor-pointer group">
                <Checkbox
                  checked={termsAccepted}
                  onCheckedChange={setTermsAccepted}
                  className="mt-1"
                />
                <span className="text-sm text-gray-700 group-hover:text-gray-900">
                  I have read and agree to the <span className="font-semibold" style={{ color: '#FF771D' }}>Terms & Conditions</span>
                </span>
              </label>
            </CardContent>
          </Card>

          {/* Privacy Policy */}
          <Card className={privacyAccepted ? 'border-2 border-green-500' : ''}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" style={{ color: '#3D692B' }} />
                Privacy Policy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[300px] border rounded-lg p-4 mb-4 bg-white">
                <div className="text-sm text-gray-700 space-y-4">
                  <h3 className="font-bold text-base">ROADSIDEPLUS Privacy Policy</h3>
                  <p className="text-xs text-gray-500">Effective Date: January 1, 2025</p>
                  
                  <section>
                    <h4 className="font-semibold mb-2">1. Introduction</h4>
                    <p>Welcome to Roadside+ ("we," "us," "our"). We are committed to protecting your privacy and ensuring your personal data is handled responsibly. This Privacy Policy explains how we collect, use, disclose, and protect your information when you use our platform and services, in accordance with the Data Protection Act of Trinidad and Tobago.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">2. Information We Collect</h4>
                    <p className="mb-2">We may collect the following types of information:</p>
                    <ul className="list-disc ml-5 space-y-1">
                      <li><strong>Personal Data:</strong> Name, contact details (phone number, email), date of birth, gender.</li>
                      <li><strong>Location Data:</strong> GPS coordinates and location history to provide roadside assistance services.</li>
                      <li><strong>Payment Information:</strong> Credit/debit card details, billing address (processed securely through third-party providers).</li>
                      <li><strong>Vehicle Details:</strong> Vehicle make, model, registration number.</li>
                      <li><strong>Usage Data:</strong> Records of your interactions with the app, service requests, and feedback.</li>
                      <li><strong>Device Data:</strong> IP address, device type, operating system, app version, and other technical data.</li>
                    </ul>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">3. How We Use Your Information</h4>
                    <p className="mb-2">Your information is used to:</p>
                    <ul className="list-disc ml-5 space-y-1">
                      <li>Provide roadside assistance services.</li>
                      <li>Verify your identity and process payments.</li>
                      <li>Improve our services and user experience.</li>
                      <li>Communicate with you about your account, bookings, or service updates.</li>
                      <li>Comply with legal obligations or enforce our terms of service.</li>
                    </ul>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">4. Sharing Your Information</h4>
                    <p className="mb-2">We may share your data with:</p>
                    <ul className="list-disc ml-5 space-y-1">
                      <li><strong>Service Providers:</strong> Tow trucks, repair services, payment processors, and technical support providers.</li>
                      <li><strong>Partner Companies:</strong> Insurance companies and white-label partners for service integration.</li>
                      <li><strong>Legal and Regulatory Authorities:</strong> When required by law or to protect our legal rights.</li>
                      <li><strong>Third Parties:</strong> With your consent or as necessary for essential service delivery.</li>
                    </ul>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">5. Data Storage and Security</h4>
                    <p>We implement appropriate technical and organizational measures to safeguard your data against unauthorized access, loss, or destruction. Your data is stored securely and retained only for as long as necessary to fulfill the purposes outlined in this policy or as required by law.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">6. Your Rights and Choices</h4>
                    <p className="mb-2">Under Trinidad and Tobago's Data Protection Act, you have rights including:</p>
                    <ul className="list-disc ml-5 space-y-1">
                      <li>Access to your personal data.</li>
                      <li>Correction of inaccurate or incomplete data.</li>
                      <li>Request for data deletion, subject to legal obligations.</li>
                      <li>Withdrawal of consent where applicable.</li>
                    </ul>
                    <p className="mt-2">To exercise these rights, contact us at privacy@roadsideplus.com.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">7. Data Transfer and International Processing</h4>
                    <p>Your data may be transferred to servers or third-party service providers outside Trinidad and Tobago, in jurisdictions with adequate data protection laws or appropriate safeguards.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">8. Cookies and Tracking Technologies</h4>
                    <p>We use cookies and similar technologies to enhance user experience, analyze usage, and support targeted advertising. You can manage your cookie preferences through your device or browser settings.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">9. Children's Privacy</h4>
                    <p>Our services are not directed at children under the age of 16, and we do not knowingly collect personal data from children.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">10. Changes to This Privacy Policy</h4>
                    <p>We may update this policy periodically. Changes will be notified via the app or our website, and your continued use signifies your acceptance of the updated policies.</p>
                  </section>

                  <section>
                    <h4 className="font-semibold mb-2">11. Contact Us</h4>
                    <p className="mb-2">For questions or requests regarding your personal data, please contact us at:</p>
                    <div className="ml-5">
                      <p><strong>Roadside+ Privacy Officer</strong></p>
                      <p>Email: privacy@roadsideplus.com</p>
                      <p>Phone: +1 (868) XXX-XXXX</p>
                      <p>Address: Trinidad and Tobago</p>
                    </div>
                  </section>
                </div>
              </ScrollArea>

              <label className="flex items-start gap-3 cursor-pointer group">
                <Checkbox
                  checked={privacyAccepted}
                  onCheckedChange={setPrivacyAccepted}
                  className="mt-1"
                />
                <span className="text-sm text-gray-700 group-hover:text-gray-900">
                  I have read and agree to the <span className="font-semibold" style={{ color: '#3D692B' }}>Privacy Policy</span>
                </span>
              </label>
            </CardContent>
          </Card>
        </div>

        {/* Accept Button */}
        <Card className="border-2" style={{ borderColor: termsAccepted && privacyAccepted ? '#3D692B' : '#e5e7eb' }}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {termsAccepted && privacyAccepted ? (
                  <>
                    <CheckCircle className="w-6 h-6 text-green-600" />
                    <div>
                      <p className="font-semibold text-green-900">Ready to continue</p>
                      <p className="text-sm text-gray-600">Click accept to start using ROADSIDEPLUS</p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="w-6 h-6 rounded-full border-2 border-gray-300"></div>
                    <div>
                      <p className="font-semibold text-gray-700">Accept both agreements</p>
                      <p className="text-sm text-gray-600">You must accept both to continue</p>
                    </div>
                  </>
                )}
              </div>
              <Button
                onClick={handleAccept}
                disabled={!termsAccepted || !privacyAccepted || loading}
                className="text-white hover:opacity-90 px-8 py-6 text-lg"
                style={{ backgroundColor: termsAccepted && privacyAccepted ? '#3D692B' : '#9ca3af' }}
              >
                {loading ? 'Processing...' : 'Accept & Continue'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}