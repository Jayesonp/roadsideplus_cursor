import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, ThumbsUp, Eye, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function KnowledgeBaseSearch({ userRole = 'customer' }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArticle, setSelectedArticle] = useState(null);

  const { data: articles = [], isLoading } = useQuery({
    queryKey: ['knowledge-base', searchQuery, userRole],
    queryFn: async () => {
      const filters = {
        is_published: true,
        target_audience: [userRole, 'both']
      };
      
      const allArticles = await base44.entities.KnowledgeBaseArticle.list('-views', 50);
      
      // Filter by search query if provided
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return allArticles.filter(article => 
          article.title.toLowerCase().includes(query) ||
          article.content.toLowerCase().includes(query) ||
          (article.tags && article.tags.some(tag => tag.toLowerCase().includes(query)))
        );
      }
      
      return allArticles.filter(a => 
        a.target_audience === userRole || a.target_audience === 'both'
      );
    },
    enabled: true
  });

  const handleArticleClick = async (article) => {
    setSelectedArticle(article);
    
    // Increment view count
    await base44.entities.KnowledgeBaseArticle.update(article.id, {
      views: (article.views || 0) + 1
    });
  };

  const handleMarkHelpful = async (articleId) => {
    const article = articles.find(a => a.id === articleId);
    if (article) {
      await base44.entities.KnowledgeBaseArticle.update(articleId, {
        helpful_count: (article.helpful_count || 0) + 1
      });
    }
  };

  const categoryColors = {
    getting_started: 'bg-blue-100 text-blue-800',
    payments: 'bg-green-100 text-green-800',
    technical_issues: 'bg-red-100 text-red-800',
    account: 'bg-purple-100 text-purple-800',
    troubleshooting: 'bg-orange-100 text-orange-800',
    faq: 'bg-gray-100 text-gray-800'
  };

  if (selectedArticle) {
    return (
      <div className="space-y-4">
        <Button
          variant="ghost"
          onClick={() => setSelectedArticle(null)}
          className="mb-4"
        >
          ← Back to Articles
        </Button>
        
        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <CardTitle className="text-2xl">{selectedArticle.title}</CardTitle>
                <div className="flex items-center gap-2">
                  <Badge className={categoryColors[selectedArticle.category]}>
                    {selectedArticle.category.replace(/_/g, ' ')}
                  </Badge>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {selectedArticle.views || 0}
                    </span>
                    <span className="flex items-center gap-1">
                      <ThumbsUp className="w-4 h-4" />
                      {selectedArticle.helpful_count || 0}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="prose max-w-none">
              {(selectedArticle.content || '').split('\n').map((paragraph, idx) => (
                <p key={idx} className="mb-3">{paragraph}</p>
              ))}
            </div>
            
            <div className="mt-6 pt-6 border-t">
              <p className="text-sm text-gray-600 mb-3">Was this article helpful?</p>
              <Button
                onClick={() => handleMarkHelpful(selectedArticle.id)}
                variant="outline"
                size="sm"
              >
                <ThumbsUp className="w-4 h-4 mr-2" />
                Yes, this helped
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        <Input
          placeholder="Search articles..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {isLoading ? (
        <div className="text-center py-8 text-gray-500">Loading articles...</div>
      ) : articles.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          No articles found. Try a different search.
        </div>
      ) : (
        <div className="grid gap-3">
          {articles.map(article => (
            <Card
              key={article.id}
              className="hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => handleArticleClick(article)}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold mb-2">{article.title}</h3>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className={`text-xs ${categoryColors[article.category]}`}>
                        {article.category.replace(/_/g, ' ')}
                      </Badge>
                      {article.tags && article.tags.slice(0, 2).map((tag, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {article.views || 0} views
                      </span>
                      <span className="flex items-center gap-1">
                        <ThumbsUp className="w-3 h-3" />
                        {article.helpful_count || 0} helpful
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}