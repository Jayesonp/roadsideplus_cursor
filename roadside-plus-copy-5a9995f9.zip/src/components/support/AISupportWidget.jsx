import React, { useState } from 'react';
import { Bot, X, Maximize2, Minimize2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import AISupportAssistant from './AISupportAssistant';

export default function AISupportWidget({ userId, userRole = 'customer' }) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed z-[40] w-14 h-14 rounded-full flex items-center justify-center text-white hover:scale-110 transition-transform"
        style={{ 
          backgroundColor: '#3D692B',
          bottom: 'calc(env(safe-area-inset-bottom) + 170px)',
          right: 'calc(env(safe-area-inset-right) + 20px)',
          boxShadow: '0px 4px 12px rgba(0,0,0,0.3)'
        }}
      >
        <Bot className="w-6 h-6" />
      </button>
    );
  }

  return (
    <Card 
      className={`fixed shadow-2xl z-[50] flex flex-col ${
        isMaximized 
          ? 'inset-0 m-4' 
          : 'w-full max-w-[calc(100vw-2rem)] sm:w-96 h-[600px] max-h-[calc(100vh-8rem)]'
      } transition-all`}
      style={!isMaximized ? {
        bottom: 'calc(env(safe-area-inset-bottom) + 170px)',
        right: 'calc(env(safe-area-inset-right) + 20px)'
      } : {
        top: 'calc(env(safe-area-inset-top) + 1rem)',
        bottom: 'calc(env(safe-area-inset-bottom) + 1rem)',
        left: 'calc(env(safe-area-inset-left) + 1rem)',
        right: 'calc(env(safe-area-inset-right) + 1rem)'
      }}
    >
      <div 
        className="flex items-center justify-between p-4 border-b text-white"
        style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}
      >
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5" />
          <span className="font-semibold">AI Support</span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMaximized(!isMaximized)}
            className="text-white hover:bg-white/20"
          >
            {isMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsOpen(false)}
            className="text-white hover:bg-white/20"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
      <div className="flex-1 overflow-hidden">
        <AISupportAssistant userId={userId} userRole={userRole} />
      </div>
    </Card>
  );
}