import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MessageCircle, X, Send, Loader2, Sparkles } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export default function AISupportBot({ userId, userType = 'customer' }) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([{
        role: 'assistant',
        content: `Hi! I'm your AI support assistant. I can help you with:\n\n• Service requests and tracking\n• Payment issues\n• Technical troubleshooting\n• Account management\n• General questions\n\nWhat can I help you with today?`
      }]);
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      // Get knowledge base articles for context
      const articles = await base44.entities.KnowledgeBaseArticle.filter(
        { is_published: true, target_audience: [userType, 'both'] },
        '-helpful_count',
        10
      );

      // Get user's recent service requests for context
      let recentRequests = [];
      if (userId) {
        if (userType === 'customer') {
          recentRequests = await base44.entities.ServiceRequest.filter(
            { customer_id: userId },
            '-created_date',
            5
          );
        } else {
          recentRequests = await base44.entities.ServiceRequest.filter(
            { technician_id: userId },
            '-created_date',
            5
          );
        }
      }

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a helpful AI support assistant for ROADSIDEPLUS, a roadside assistance platform. 
        
User Type: ${userType}
User Question: "${userMessage}"

CONTEXT - Recent Service Requests:
${recentRequests.map(r => `- ${r.service_type} (${r.status}) - ${r.location_address || 'Location set'}`).join('\n') || 'No recent requests'}

CONTEXT - Knowledge Base (use this to answer questions):
${articles.map(a => `
Title: ${a.title}
Category: ${a.category}
Content: ${a.content.substring(0, 500)}...
`).join('\n---\n')}

INSTRUCTIONS:
1. Answer the user's question helpfully and professionally
2. Reference knowledge base articles when relevant
3. Provide specific guidance based on their recent service requests if applicable
4. If the issue is complex, suggest creating a support ticket
5. Keep responses concise but complete
6. Use a friendly, supportive tone

Provide a helpful response:`,
        response_json_schema: {
          type: 'object',
          properties: {
            response: { type: 'string' },
            suggested_articles: {
              type: 'array',
              items: { type: 'string' },
              description: 'Article IDs that might help'
            },
            should_escalate: {
              type: 'boolean',
              description: 'Whether issue should be escalated to human support'
            }
          }
        }
      });

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: response.response,
        shouldEscalate: response.should_escalate
      }]);
    } catch (error) {
      console.error('AI Support error:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'I apologize, but I encountered an error. Please try again or contact human support for assistance.'
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleEscalate = async () => {
    try {
      const conversation = await base44.entities.SupportConversation.create({
        customer_id: userId,
        subject: 'Help Request from AI Bot',
        status: 'open'
      });

      // Add initial message
      await base44.entities.SupportMessage.create({
        conversation_id: conversation.id,
        sender_id: userId,
        sender_role: userType,
        message: messages.filter(m => m.role === 'user').slice(-1)[0]?.content || 'User needs assistance'
      });

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: '✅ I\'ve created a support ticket for you. A human support agent will respond shortly. You can check your support conversations in the support dashboard.'
      }]);
    } catch (error) {
      console.error('Escalation error:', error);
    }
  };

  if (!isOpen) {
    return (
      <Button
        className="fixed bottom-6 right-6 rounded-full w-14 h-14 shadow-lg z-50 hover:opacity-90"
        style={{ backgroundColor: '#FF771D' }}
        onClick={() => setIsOpen(true)}
      >
        <MessageCircle className="w-6 h-6 text-white" />
      </Button>
    );
  }

  return (
    <Card className="fixed bottom-6 right-6 w-96 h-[600px] shadow-2xl z-50 flex flex-col">
      <CardHeader className="flex-shrink-0 text-white" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            AI Support
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20"
            onClick={() => setIsOpen(false)}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                msg.role === 'user'
                  ? 'bg-orange-500 text-white'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              {msg.role === 'assistant' ? (
                <ReactMarkdown className="text-sm prose prose-sm">{msg.content}</ReactMarkdown>
              ) : (
                <p className="text-sm">{msg.content}</p>
              )}
              
              {msg.shouldEscalate && (
                <Button
                  size="sm"
                  variant="outline"
                  className="mt-2 w-full bg-white"
                  onClick={handleEscalate}
                >
                  Talk to Human Support
                </Button>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 rounded-lg p-3">
              <Loader2 className="w-4 h-4 animate-spin" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </CardContent>

      <div className="flex-shrink-0 p-4 border-t">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your question..."
            disabled={loading}
          />
          <Button
            onClick={handleSend}
            disabled={loading || !input.trim()}
            style={{ backgroundColor: '#FF771D' }}
            className="text-white"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}