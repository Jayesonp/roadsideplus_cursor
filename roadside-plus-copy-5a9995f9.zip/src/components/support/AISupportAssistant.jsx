import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bot, Send, Loader2, User, AlertCircle, CheckCircle, X } from 'lucide-react';
import { format } from 'date-fns';

export default function AISupportAssistant({ userId, userRole = 'customer' }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [context, setContext] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    loadContext();
    addMessage('assistant', 'Hello! I\'m your AI support assistant. I can help you with:\n\n• Service request updates\n• Common questions and troubleshooting\n• Account and billing inquiries\n• Platform navigation\n\nHow can I help you today?');
  }, [userId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadContext = async () => {
    try {
      const user = await base44.auth.me();
      const requests = await base44.entities.ServiceRequest.filter({ customer_id: userId });
      const kbArticles = await base44.entities.KnowledgeBaseArticle.filter({ is_published: true });
      
      let partnerInfo = null;
      if (userRole === 'partner') {
        const partners = await base44.entities.Partner.filter({ email: user.email });
        partnerInfo = partners[0];
      }

      setContext({
        user,
        requests: requests.slice(0, 10),
        kbArticles: kbArticles.slice(0, 20),
        partnerInfo,
        userRole
      });
    } catch (error) {
      console.error('Failed to load context:', error);
    }
  };

  const addMessage = (role, content, metadata = {}) => {
    setMessages(prev => [...prev, { role, content, timestamp: new Date(), ...metadata }]);
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput('');
    addMessage('user', userMessage);
    setLoading(true);

    try {
      const systemPrompt = buildSystemPrompt();
      const conversationHistory = messages.slice(-10).map(m => `${m.role}: ${m.content}`).join('\n');
      
      const prompt = `${systemPrompt}

CONVERSATION HISTORY:
${conversationHistory}

USER: ${userMessage}

Provide a helpful, concise response. If this is a complex issue that requires human support, include [ESCALATE] at the end of your response.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        add_context_from_internet: false
      });

      const shouldEscalate = response.includes('[ESCALATE]');
      const cleanResponse = response.replace('[ESCALATE]', '').trim();

      addMessage('assistant', cleanResponse, { shouldEscalate });

      if (shouldEscalate) {
        addMessage('system', 'This query has been flagged for human support escalation.', { 
          showEscalateButton: true 
        });
      }
    } catch (error) {
      addMessage('assistant', 'I apologize, but I encountered an error. Please try again or contact support directly.');
    } finally {
      setLoading(false);
    }
  };

  const handleEscalate = async () => {
    try {
      const conversationSummary = messages.map(m => `${m.role}: ${m.content}`).join('\n\n');
      
      const conversation = await base44.entities.SupportConversation.create({
        customer_id: userId,
        subject: 'AI Assistant Escalation',
        status: 'open',
        last_message_at: new Date().toISOString()
      });

      await base44.entities.SupportMessage.create({
        conversation_id: conversation.id,
        sender_id: userId,
        sender_role: userRole === 'partner' ? 'customer' : userRole,
        message: `AI Assistant Escalation:\n\n${conversationSummary}`
      });

      addMessage('system', '✅ Your conversation has been escalated to our support team. They will respond shortly.');
    } catch (error) {
      addMessage('system', 'Failed to escalate. Please contact support directly.');
    }
  };

  const buildSystemPrompt = () => {
    if (!context) return 'You are a helpful support assistant.';

    let prompt = `You are an AI support assistant for ROADSIDE+, a roadside assistance platform. Be helpful, concise, and professional.

CURRENT USER:
- Role: ${context.userRole}
- Name: ${context.user.full_name}
- Email: ${context.user.email}

`;

    if (context.userRole === 'partner' && context.partnerInfo) {
      prompt += `PARTNER INFORMATION:
- Company: ${context.partnerInfo.company_name}
- Status: ${context.partnerInfo.status}
- Commission Rate: ${context.partnerInfo.commission_rate}%
- Has Client Database Access: ${context.partnerInfo.has_client_database_access}

`;
    }

    if (context.requests.length > 0) {
      prompt += `RECENT SERVICE REQUESTS:
${context.requests.map(r => `- ${r.service_type} (Status: ${r.status}) - Created: ${format(new Date(r.created_date), 'MMM d, yyyy')}`).join('\n')}

`;
    }

    if (context.kbArticles.length > 0) {
      prompt += `KNOWLEDGE BASE ARTICLES:
${context.kbArticles.map(a => `- ${a.title} (Category: ${a.category})`).join('\n')}

`;
    }

    prompt += `CAPABILITIES:
- Answer questions about service requests, status updates, and ETAs
- Provide guidance on common issues (tire changes, battery jumps, lockouts, towing)
- Explain platform features and account management
- Help with billing and payment questions
${context.userRole === 'partner' ? '- Assist with partner portal, analytics, and commission payouts' : ''}

ESCALATION RULES:
- If user reports an emergency or safety issue
- If user disputes a charge or requests a refund
- If technical issue prevents platform usage
- If question requires account modifications
- If user is frustrated or unsatisfied

When escalating, add [ESCALATE] at the end of your response.`;

    return prompt;
  };

  return (
    <div className="flex flex-col h-full">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex gap-2 max-w-[80%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                msg.role === 'user' ? 'bg-blue-100' : msg.role === 'system' ? 'bg-yellow-100' : 'bg-gray-100'
              }`}>
                {msg.role === 'user' ? (
                  <User className="w-5 h-5 text-blue-600" />
                ) : msg.role === 'system' ? (
                  <AlertCircle className="w-5 h-5 text-yellow-600" />
                ) : (
                  <Bot className="w-5 h-5 text-gray-600" />
                )}
              </div>
              <div>
                <div className={`rounded-lg p-3 ${
                  msg.role === 'user' 
                    ? 'bg-blue-600 text-white' 
                    : msg.role === 'system'
                    ? 'bg-yellow-50 border border-yellow-200'
                    : 'bg-white border border-gray-200'
                }`}>
                  <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                </div>
                {msg.showEscalateButton && (
                  <Button
                    onClick={handleEscalate}
                    size="sm"
                    className="mt-2 text-white"
                    style={{ backgroundColor: '#FF771D' }}
                  >
                    Connect with Human Support
                  </Button>
                )}
                <p className="text-xs text-gray-500 mt-1">
                  {format(msg.timestamp, 'h:mm a')}
                </p>
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="flex gap-2">
              <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                <Bot className="w-5 h-5 text-gray-600" />
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-3">
                <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="border-t p-4 bg-white">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask me anything..."
            disabled={loading}
          />
          <Button
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="text-white"
            style={{ backgroundColor: '#FF771D' }}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}