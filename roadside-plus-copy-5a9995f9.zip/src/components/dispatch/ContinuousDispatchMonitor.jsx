import { useEffect } from 'react';
import { base44 } from '@/api/base44Client';

export default function ContinuousDispatchMonitor() {
  useEffect(() => {
    // Auto-retry dispatch every 30 seconds for pending requests
    const interval = setInterval(async () => {
      try {
        await base44.functions.invoke('autoRetryDispatch', {});
      } catch (error) {
        console.error('Auto-retry dispatch failed:', error);
      }
    }, 60000); // Every 60 seconds to reduce load

    return () => clearInterval(interval);
  }, []);

  return null; // This is a background monitor component
}