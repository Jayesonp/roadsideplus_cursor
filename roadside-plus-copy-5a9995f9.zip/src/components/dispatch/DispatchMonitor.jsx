import React, { useEffect, useRef } from 'react';
import { monitorPendingRequests } from './AutomatedDispatcher';

/**
 * Background component that monitors for pending dispatch requests
 * and automatically dispatches them using AI
 */
export default function DispatchMonitor() {
  const intervalRef = useRef(null);

  useEffect(() => {
    // Start monitoring when component mounts
    console.log('Dispatch Monitor: Starting automated dispatch system');
    
    // Run immediately on mount
    monitorPendingRequests();

    // Check every 2 minutes for new requests to reduce API load
    intervalRef.current = setInterval(() => {
      monitorPendingRequests();
    }, 120000);

    // Cleanup on unmount
    return () => {
      if (intervalRef.current) {
        console.log('Dispatch Monitor: Stopping automated dispatch system');
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  // This component doesn't render anything visible
  return null;
}