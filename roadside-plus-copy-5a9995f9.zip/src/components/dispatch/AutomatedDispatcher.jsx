import { base44 } from '@/api/base44Client';

// Haversine distance calculation
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

// Log dispatch events
const logEvent = async (type, requestId, customerId, technicianId, payload) => {
  try {
    await base44.entities.Event.create({
      type,
      request_id: requestId,
      customer_id: customerId,
      technician_id: technicianId,
      payload
    });
  } catch (error) {
    console.error('Error logging event:', error);
  }
};

// Check if technician has active job
const checkTechnicianActiveJob = async (technicianId) => {
  const activeJobs = await base44.entities.ServiceRequest.filter({
    technician_id: technicianId,
    status: ['assigned', 'en_route', 'in_progress', 'arrived']
  });
  return activeJobs.length > 0;
};

// Find available technicians with enriched data
const findAvailableTechnicians = async (serviceRequest) => {
  try {
    // Get all technician profiles
    const allProfiles = await base44.entities.TechnicianProfile.list();
    
    // Filter available technicians
    const availableProfiles = allProfiles.filter(profile => 
      profile.onboarding_completed &&
      profile.availability_status === 'available' &&
      profile.current_lat && 
      profile.current_lng
    );

    if (availableProfiles.length === 0) {
      return [];
    }

    // Get recent jobs for workload calculation
    const recentJobs = await base44.entities.ServiceRequest.filter({
      status: 'completed',
      completed_at: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString() }
    });

    // Check for active jobs and enrich with data
    const enrichedTechnicians = await Promise.all(
      availableProfiles.map(async (profile) => {
        const hasActiveJob = await checkTechnicianActiveJob(profile.user_id);
        if (hasActiveJob) return null;

        const distance = calculateDistance(
          serviceRequest.location_lat,
          serviceRequest.location_lng,
          profile.current_lat,
          profile.current_lng
        );

        const weeklyJobs = recentJobs.filter(job => 
          job.technician_id === profile.user_id
        ).length;

        return {
          ...profile,
          distance,
          weeklyJobs,
          hasActiveJob: false
        };
      })
    );

    return enrichedTechnicians
      .filter(tech => tech !== null)
      .sort((a, b) => a.distance - b.distance);

  } catch (error) {
    console.error('Error finding technicians:', error);
    return [];
  }
};

// AI-powered technician selection
const selectBestTechnicianWithAI = async (serviceRequest, availableTechnicians) => {
  try {
    const serviceTypeMapping = {
      tire_change: 'Tire Change',
      battery_jump: 'Battery Jump',
      fuel_delivery: 'Fuel Delivery',
      lockout: 'Lockout Service',
      towing: 'Towing',
      other: 'Other Service'
    };

    const prompt = `You are an intelligent dispatch system for roadside assistance. 
Analyze the following data and select the BEST technician for this job.

SERVICE REQUEST:
- Type: ${serviceTypeMapping[serviceRequest.service_type] || serviceRequest.service_type}
- Location: ${serviceRequest.location_address || 'Customer location'}
- Description: ${serviceRequest.description || 'No additional details'}

AVAILABLE TECHNICIANS:
${availableTechnicians.map((tech, idx) => `
${idx + 1}. Technician ID: ${tech.user_id}
   - Distance: ${tech.distance.toFixed(2)} km away
   - Rating: ${tech.rating}/5 (${tech.total_jobs} jobs completed)
   - Specialties: ${tech.specialties?.join(', ') || 'General'}
   - Skills: ${tech.skills_certifications?.join(', ') || 'None listed'}
   - Weekly workload: ${tech.weeklyJobs} jobs
   - Vehicle: ${tech.vehicle_type || 'Not specified'}
`).join('\n')}

SELECTION CRITERIA (in order of importance):
1. Has matching specialty for the service type (CRITICAL)
2. Proximity to customer (closer is better)
3. Rating and experience (higher is better)
4. Current workload (lower is better to distribute fairly)
5. Relevant skills and certifications

Return ONLY the technician's user_id of the best match. Consider all factors holistically.
If multiple technicians are equally qualified, prefer the closest one with the lightest workload.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          selected_technician_id: { type: "string" },
          reasoning: { type: "string" }
        },
        required: ["selected_technician_id", "reasoning"]
      }
    });

    const selectedTech = availableTechnicians.find(
      tech => tech.user_id === result.selected_technician_id
    );

    if (selectedTech) {
      console.log('AI Selection Reasoning:', result.reasoning);
      return selectedTech;
    }

    // Fallback to closest if AI selection invalid
    return availableTechnicians[0];

  } catch (error) {
    console.error('AI selection failed, using fallback:', error);
    // Fallback: closest technician with matching specialty or highest rating
    const withSpecialty = availableTechnicians.filter(tech => 
      tech.specialties?.some(s => 
        s.toLowerCase().includes(serviceRequest.service_type.replace(/_/g, ' '))
      )
    );
    return withSpecialty[0] || availableTechnicians[0];
  }
};

// Assign technician to service request
const assignTechnician = async (serviceRequest, technician) => {
  try {
    // Update service request
    await base44.entities.ServiceRequest.update(serviceRequest.id, {
      technician_id: technician.user_id,
      current_offered_technician_id: technician.user_id,
      status: 'dispatched',
      offer_expires_at: new Date(Date.now() + 60000).toISOString(), // 60 second to respond
      estimated_arrival: new Date(Date.now() + 15 * 60000).toISOString()
    });

    // Update technician availability
    await base44.entities.TechnicianProfile.update(technician.id, {
      availability_status: 'on_job'
    });

    // Log event
    await logEvent(
      'OFFER_SENT',
      serviceRequest.id,
      serviceRequest.customer_id,
      technician.user_id,
      {
        distance: technician.distance,
        technician_rating: technician.rating,
        dispatch_method: 'ai_automated',
        offer_expires_at: new Date(Date.now() + 60000).toISOString()
      }
    );

    // Send notification to technician
    await base44.entities.Notification.create({
      user_id: technician.user_id,
      type: 'new_service_request',
      title: 'New Job Available!',
      message: `New ${serviceRequest.service_type.replace(/_/g, ' ')} request ${technician.distance.toFixed(1)}km away. Respond within 60 seconds.`,
      related_id: serviceRequest.id
    });

    // Send urgent notification for high priority jobs
    if (serviceRequest.priority === 'high' || serviceRequest.priority === 'critical') {
      await base44.entities.Notification.create({
        user_id: technician.user_id,
        type: 'urgent_job_update',
        title: '🚨 High Priority Job',
        message: `Urgent ${serviceRequest.service_type.replace(/_/g, ' ')} request. Quick response needed!`,
        related_id: serviceRequest.id
      });
    }

    // Notify customer
    await base44.entities.Notification.create({
      user_id: serviceRequest.customer_id,
      type: 'technician_assigned',
      title: 'Technician Dispatched',
      message: 'A technician has been notified and will respond shortly.',
      related_id: serviceRequest.id
    });

    return { success: true, technician };

  } catch (error) {
    console.error('Error assigning technician:', error);
    return { success: false, error: error.message };
  }
};

// Main automated dispatch function
export const processAutomatedDispatch = async (serviceRequest) => {
  try {
    console.log('Starting automated dispatch for request:', serviceRequest.id);

    // Find available technicians
    const availableTechnicians = await findAvailableTechnicians(serviceRequest);

    if (availableTechnicians.length === 0) {
      console.log('No available technicians found');
      
      await base44.entities.ServiceRequest.update(serviceRequest.id, {
        status: 'no_technician_available'
      });

      await base44.entities.Notification.create({
        user_id: serviceRequest.customer_id,
        type: 'technician_assigned',
        title: 'No Technicians Available',
        message: 'We are unable to find an available technician at this time. Please try again later.',
        related_id: serviceRequest.id
      });

      await logEvent(
        'DISPATCH_STARTED',
        serviceRequest.id,
        serviceRequest.customer_id,
        null,
        { available_technicians: 0, reason: 'none_available' }
      );

      return { success: false, reason: 'no_technicians_available' };
    }

    console.log(`Found ${availableTechnicians.length} available technicians`);

    // Use AI to select best technician
    const selectedTechnician = await selectBestTechnicianWithAI(
      serviceRequest, 
      availableTechnicians
    );

    if (!selectedTechnician) {
      throw new Error('Failed to select technician');
    }

    console.log('AI selected technician:', selectedTechnician.user_id);

    // Assign the selected technician
    const result = await assignTechnician(serviceRequest, selectedTechnician);

    return result;

  } catch (error) {
    console.error('Automated dispatch error:', error);
    
    await logEvent(
      'DISPATCH_STARTED',
      serviceRequest.id,
      serviceRequest.customer_id,
      null,
      { error: error.message, status: 'failed' }
    );

    return { success: false, error: error.message };
  }
};

// Monitor and process pending requests
export const monitorPendingRequests = async () => {
  try {
    const pendingRequests = await base44.entities.ServiceRequest.filter({
      status: 'pending_dispatch'
    }, 'created_date');

    if (pendingRequests.length > 0) {
      console.log(`Found ${pendingRequests.length} pending dispatch requests`);
      
      for (const request of pendingRequests) {
        await processAutomatedDispatch(request);
      }
    }

  } catch (error) {
    console.error('Error monitoring pending requests:', error);
  }
};