import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export default function UberStyleDispatcher() {
  const [processing, setProcessing] = useState(new Set());

  // Monitor for expired offers every 10 seconds
  useQuery({
    queryKey: ['expired-offers'],
    queryFn: async () => {
      const now = new Date().toISOString();
      
      // Find all requests with expired offers
      const requests = await base44.entities.ServiceRequest.filter({
        status: 'pending_dispatch'
      });

      const expiredOffers = requests.filter(req => 
        req.current_offered_technician_id && 
        req.offer_expires_at && 
        new Date(req.offer_expires_at) < new Date() &&
        !processing.has(req.id)
      );

      // Re-dispatch expired offers
      for (const request of expiredOffers) {
        if (!processing.has(request.id)) {
          setProcessing(prev => new Set([...prev, request.id]));
          
          try {
            // Log timeout event
            await base44.entities.Event.create({
              type: 'OFFER_TIMEOUT',
              request_id: request.id,
              customer_id: request.customer_id,
              technician_id: request.current_offered_technician_id,
              payload: { 
                expired_at: request.offer_expires_at 
              }
            });

            // Re-dispatch to next technician
            await base44.functions.invoke('dispatchServiceRequest', {
              requestId: request.id
            });

            console.log(`Re-dispatched request ${request.id} after timeout`);
          } catch (error) {
            console.error('Re-dispatch error:', error);
          } finally {
            setProcessing(prev => {
              const newSet = new Set(prev);
              newSet.delete(request.id);
              return newSet;
            });
          }
        }
      }

      return expiredOffers.length;
    },
    refetchInterval: 45000, // Check every 45 seconds to reduce load
    retry: 1
  });

  return null; // This is a background monitoring component
}