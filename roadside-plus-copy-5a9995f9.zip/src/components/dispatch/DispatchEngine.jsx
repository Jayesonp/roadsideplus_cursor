import { base44 } from '@/api/base44Client';

// Haversine formula to calculate distance between two coordinates
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

// Log event
const logEvent = async (type, data) => {
  await base44.entities.Event.create({
    type,
    request_id: data.request_id,
    customer_id: data.customer_id,
    technician_id: data.technician_id,
    payload: data.payload || {}
  });
};

// Find available technicians sorted by distance
const findAvailableTechnicians = async (customerLat, customerLng) => {
  // Get all technician profiles
  const allProfiles = await base44.entities.TechnicianProfile.list();
  
  // Filter for online technicians
  const onlineProfiles = allProfiles.filter(p => p.is_available);
  
  // Get active jobs to filter out busy technicians
  const activeJobs = await base44.entities.ServiceRequest.filter({});
  const busyTechnicianIds = activeJobs
    .filter(job => ['assigned', 'en_route', 'arrived', 'in_progress', 'awaiting_review', 'dispatched'].includes(job.status))
    .map(job => job.technician_id || job.current_offered_technician_id)
    .filter(Boolean);
  
  // Get available technicians (online and not busy)
  const availableProfiles = onlineProfiles.filter(p => !busyTechnicianIds.includes(p.user_id));
  
  // Get locations for available technicians
  const locations = await base44.entities.TechnicianLocation.list();
  const locationMap = {};
  locations.forEach(loc => {
    locationMap[loc.technician_id] = loc;
  });
  
  // Calculate distances and sort
  const techniciansWithDistance = availableProfiles
    .filter(p => locationMap[p.user_id])
    .map(profile => ({
      profile,
      location: locationMap[profile.user_id],
      distance: calculateDistance(
        customerLat,
        customerLng,
        locationMap[profile.user_id].latitude,
        locationMap[profile.user_id].longitude
      )
    }))
    .sort((a, b) => a.distance - b.distance);
  
  return techniciansWithDistance;
};

// Offer job to next technician in sequence
const offerToNextTechnician = async (requestId, technicians, attemptedTechIds = []) => {
  // Find next technician who hasn't been offered yet
  const nextTech = technicians.find(t => !attemptedTechIds.includes(t.profile.user_id));
  
  if (!nextTech) {
    // No more technicians available
    await base44.entities.ServiceRequest.update(requestId, {
      status: 'no_technician_available',
      current_offered_technician_id: null
    });
    
    const request = await base44.entities.ServiceRequest.filter({ id: requestId });
    await logEvent('DISPATCH_STARTED', {
      request_id: requestId,
      customer_id: request[0]?.customer_id,
      payload: { result: 'no_technician_available' }
    });
    
    return null;
  }
  
  // Set offer expiry (60 seconds from now)
  const expiresAt = new Date(Date.now() + 60000).toISOString();
  
  // Update request with offer
  await base44.entities.ServiceRequest.update(requestId, {
    status: 'dispatched',
    current_offered_technician_id: nextTech.profile.user_id,
    offer_expires_at: expiresAt
  });
  
  const request = await base44.entities.ServiceRequest.filter({ id: requestId });
  
  // Send notification to technician
  await base44.entities.Notification.create({
    user_id: nextTech.profile.user_id,
    type: 'new_service_request',
    title: 'New Job Offer',
    message: `New ${request[0]?.service_type.replace(/_/g, ' ')} request nearby`,
    related_id: requestId
  });
  
  // Log event
  await logEvent('OFFER_SENT', {
    request_id: requestId,
    customer_id: request[0]?.customer_id,
    technician_id: nextTech.profile.user_id,
    payload: {
      distance_km: nextTech.distance,
      expires_at: expiresAt
    }
  });
  
  return nextTech.profile.user_id;
};

// Main dispatch function
export const dispatchServiceRequest = async (requestId) => {
  try {
    const requests = await base44.entities.ServiceRequest.filter({ id: requestId });
    const request = requests[0];
    
    if (!request || request.status !== 'pending_dispatch') {
      return { success: false, message: 'Invalid request status' };
    }
    
    // Log dispatch start
    await logEvent('DISPATCH_STARTED', {
      request_id: requestId,
      customer_id: request.customer_id,
      payload: {
        service_type: request.service_type,
        location: { lat: request.location_lat, lng: request.location_lng }
      }
    });
    
    // Find available technicians
    const technicians = await findAvailableTechnicians(
      request.location_lat,
      request.location_lng
    );
    
    if (technicians.length === 0) {
      await base44.entities.ServiceRequest.update(requestId, {
        status: 'no_technician_available'
      });
      return { success: false, message: 'No technicians available' };
    }
    
    // Offer to first technician
    await offerToNextTechnician(requestId, technicians, []);
    
    return { success: true, message: 'Dispatch initiated' };
  } catch (error) {
    console.error('Dispatch error:', error);
    return { success: false, message: error.message };
  }
};

// Handle technician response
export const handleTechnicianResponse = async (requestId, technicianId, accepted) => {
  try {
    const requests = await base44.entities.ServiceRequest.filter({ id: requestId });
    const request = requests[0];
    
    if (!request || request.status !== 'dispatched') {
      return { success: false, message: 'Invalid request status' };
    }
    
    if (request.current_offered_technician_id !== technicianId) {
      return { success: false, message: 'Offer not for this technician' };
    }
    
    if (accepted) {
      // Accept job
      await base44.entities.ServiceRequest.update(requestId, {
        status: 'assigned',
        technician_id: technicianId,
        current_offered_technician_id: null,
        offer_expires_at: null
      });
      
      await logEvent('OFFER_ACCEPTED', {
        request_id: requestId,
        customer_id: request.customer_id,
        technician_id: technicianId,
        payload: { accepted_at: new Date().toISOString() }
      });
      
      // Notify customer
      await base44.entities.Notification.create({
        user_id: request.customer_id,
        type: 'technician_assigned',
        title: 'Technician Assigned',
        message: 'A technician has accepted your request and is on the way!',
        related_id: requestId
      });
      
      return { success: true, message: 'Job accepted' };
    } else {
      // Reject job - offer to next technician
      await logEvent('OFFER_REJECTED', {
        request_id: requestId,
        customer_id: request.customer_id,
        technician_id: technicianId,
        payload: { rejected_at: new Date().toISOString() }
      });
      
      // Get list of technicians and attempted ones
      const technicians = await findAvailableTechnicians(
        request.location_lat,
        request.location_lng
      );
      
      // Get all previous offer events to track attempted techs
      const events = await base44.entities.Event.filter({ request_id: requestId });
      const attemptedTechIds = events
        .filter(e => ['OFFER_SENT', 'OFFER_REJECTED', 'OFFER_TIMEOUT'].includes(e.type))
        .map(e => e.technician_id)
        .filter(Boolean);
      
      // Offer to next
      await offerToNextTechnician(requestId, technicians, attemptedTechIds);
      
      return { success: true, message: 'Offering to next technician' };
    }
  } catch (error) {
    console.error('Response handling error:', error);
    return { success: false, message: error.message };
  }
};

// Check for expired offers (should be called periodically)
export const checkExpiredOffers = async () => {
  try {
    const dispatchedJobs = await base44.entities.ServiceRequest.filter({ status: 'dispatched' });
    const now = new Date();
    
    for (const job of dispatchedJobs) {
      if (job.offer_expires_at && new Date(job.offer_expires_at) <= now) {
        // Offer expired - treat as rejection
        await logEvent('OFFER_TIMEOUT', {
          request_id: job.id,
          customer_id: job.customer_id,
          technician_id: job.current_offered_technician_id,
          payload: { expired_at: now.toISOString() }
        });
        
        // Handle as rejection
        await handleTechnicianResponse(job.id, job.current_offered_technician_id, false);
      }
    }
  } catch (error) {
    console.error('Expired offer check error:', error);
  }
};