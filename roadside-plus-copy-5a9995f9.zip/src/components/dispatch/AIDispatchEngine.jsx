import { base44 } from '@/api/base44Client';
import { sortRequestsByPriority } from './PriorityAssessment';

// Haversine formula to calculate distance
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

// Get technician performance metrics
const getTechnicianMetrics = async (technicianId) => {
  const recentJobs = await base44.entities.ServiceRequest.filter({
    technician_id: technicianId,
    status: 'completed'
  }, '-completed_at', 50);

  const ratings = await base44.entities.Rating.filter({
    technician_id: technicianId
  }, '-created_date', 50);

  const avgResponseTime = recentJobs.length > 0 
    ? recentJobs.reduce((sum, job) => {
        const created = new Date(job.created_date).getTime();
        const arrived = new Date(job.estimated_arrival || job.updated_date).getTime();
        return sum + (arrived - created);
      }, 0) / recentJobs.length / 60000 // Convert to minutes
    : 30;

  const completionRate = recentJobs.length > 0
    ? (recentJobs.filter(j => j.status === 'completed').length / recentJobs.length) * 100
    : 100;

  const avgRating = ratings.length > 0
    ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length
    : 5;

  const todayJobs = recentJobs.filter(job => {
    const jobDate = new Date(job.created_date).toDateString();
    return jobDate === new Date().toDateString();
  }).length;

  return {
    avgResponseTime: Math.round(avgResponseTime),
    completionRate: Math.round(completionRate),
    avgRating: avgRating.toFixed(1),
    totalJobs: recentJobs.length,
    todayJobs,
    recentRatings: ratings.slice(0, 5)
  };
};

// AI-powered technician selection with enhanced metrics
export const selectOptimalTechnician = async (serviceRequest, dispatchRules = {}) => {
  try {
    // Get all available technicians
    const allProfiles = await base44.entities.TechnicianProfile.list();
    
    const availableProfiles = allProfiles.filter(profile => 
      profile.onboarding_completed &&
      profile.availability_status === 'available' &&
      profile.current_lat && 
      profile.current_lng
    );

    if (availableProfiles.length === 0) {
      return null;
    }

    // Check for active jobs
    const activeJobs = await base44.entities.ServiceRequest.filter({
      status: ['assigned', 'en_route', 'in_progress', 'arrived', 'dispatched']
    });

    const busyTechIds = new Set(activeJobs.map(j => j.technician_id || j.current_offered_technician_id).filter(Boolean));

    // Enrich technician data with performance metrics
    const enrichedTechnicians = await Promise.all(
      availableProfiles
        .filter(profile => !busyTechIds.has(profile.user_id))
        .map(async (profile) => {
          const distance = calculateDistance(
            serviceRequest.location_lat,
            serviceRequest.location_lng,
            profile.current_lat,
            profile.current_lng
          );

          const metrics = await getTechnicianMetrics(profile.user_id);

          return {
            ...profile,
            distance,
            metrics
          };
        })
    );

    // Filter by max distance if specified in rules
    const maxDistance = dispatchRules.maxDistance || 50; // km
    const withinRange = enrichedTechnicians.filter(t => t.distance <= maxDistance);

    if (withinRange.length === 0) {
      return null;
    }

    // Use AI to select the best technician
    const serviceTypeMapping = {
      tire_change: 'Tire Change',
      battery_jump: 'Battery Jump',
      fuel_delivery: 'Fuel Delivery',
      lockout: 'Lockout Service',
      towing: 'Towing',
      other: 'Other Service'
    };

    const priorityEmoji = {
      critical: '🚨',
      high: '⚠️',
      normal: '📋',
      low: '📝'
    };

    const prompt = `You are an advanced AI dispatch system for roadside assistance. Analyze all factors and select the OPTIMAL technician.

SERVICE REQUEST:
- Type: ${serviceTypeMapping[serviceRequest.service_type] || serviceRequest.service_type}
- Location: ${serviceRequest.location_address || 'Customer location'}
- Description: ${serviceRequest.description || 'No additional details'}
- Priority: ${priorityEmoji[serviceRequest.priority] || '📋'} ${(serviceRequest.priority || 'normal').toUpperCase()} (Score: ${serviceRequest.priority_score || 50}/100)
- Priority Reasoning: ${serviceRequest.priority_reasoning || 'Standard priority'}
- Urgency: ${serviceRequest.priority === 'critical' ? 'CRITICAL - Immediate response required' : serviceRequest.priority === 'high' ? 'HIGH - Urgent attention needed' : 'Standard'}

AVAILABLE TECHNICIANS:
${withinRange.map((tech, idx) => `
${idx + 1}. ID: ${tech.user_id.substring(0, 12)}
   Distance: ${tech.distance.toFixed(1)} km
   Rating: ${tech.metrics.avgRating}/5 (${tech.metrics.totalJobs} total jobs)
   Specialties: ${tech.specialties?.join(', ') || 'General'}
   Skills: ${tech.skills_certifications?.join(', ') || 'None'}
   Performance:
     - Avg Response: ${tech.metrics.avgResponseTime} minutes
     - Completion Rate: ${tech.metrics.completionRate}%
     - Jobs Today: ${tech.metrics.todayJobs}
   Vehicle: ${tech.vehicle_type || 'Not specified'}
`).join('\n')}

DISPATCH RULES:
- Max Distance: ${maxDistance} km
- Prefer specialists: ${dispatchRules.preferSpecialists !== false}
- Workload balancing: ${dispatchRules.balanceWorkload !== false}
- Min rating threshold: ${dispatchRules.minRating || 4.0}

SELECTION CRITERIA (weighted based on priority):
${serviceRequest.priority === 'critical' || serviceRequest.priority === 'high' 
  ? '1. Proximity (40%) - CRITICAL: Fastest response needed\n2. Service specialty match (30%) - Quality matters\n3. Performance metrics (20%) - Reliability\n4. Workload balance (10%) - Secondary concern'
  : '1. Service specialty match (30%) - Critical for quality\n2. Proximity (25%) - Faster response time\n3. Performance metrics (25%) - Rating, completion rate, response time\n4. Workload balance (20%) - Distribute work fairly'
}

Return the technician ID who best matches ALL criteria. Explain your reasoning considering trade-offs.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          selected_technician_id: { type: "string" },
          reasoning: { type: "string" },
          confidence_score: { type: "number" },
          alternative_options: {
            type: "array",
            items: { type: "string" }
          }
        },
        required: ["selected_technician_id", "reasoning"]
      }
    });

    const selectedTech = withinRange.find(
      tech => tech.user_id.startsWith(result.selected_technician_id.substring(0, 12))
    );

    if (selectedTech) {
      // Log AI decision
      await base44.entities.Event.create({
        type: 'DISPATCH_STARTED',
        request_id: serviceRequest.id,
        customer_id: serviceRequest.customer_id,
        technician_id: selectedTech.user_id,
        payload: {
          ai_reasoning: result.reasoning,
          confidence: result.confidence_score,
          alternatives: result.alternative_options,
          distance: selectedTech.distance,
          metrics: selectedTech.metrics,
          dispatch_method: 'ai_optimized'
        }
      });

      return {
        technician: selectedTech,
        reasoning: result.reasoning,
        confidence: result.confidence_score
      };
    }

    // Fallback to rule-based selection
    return fallbackSelection(withinRange, serviceRequest, dispatchRules);

  } catch (error) {
    console.error('AI dispatch error:', error);
    // Fallback to rule-based
    const allProfiles = await base44.entities.TechnicianProfile.list();
    const available = allProfiles.filter(p => 
      p.onboarding_completed && 
      p.availability_status === 'available' &&
      p.current_lat && p.current_lng
    );
    
    if (available.length === 0) return null;

    const withDistance = available.map(p => ({
      ...p,
      distance: calculateDistance(
        serviceRequest.location_lat,
        serviceRequest.location_lng,
        p.current_lat,
        p.current_lng
      )
    })).sort((a, b) => a.distance - b.distance);

    return { technician: withDistance[0], reasoning: 'Fallback: closest available', confidence: 0.5 };
  }
};

// Fallback rule-based selection
const fallbackSelection = (technicians, serviceRequest, rules) => {
  // Score technicians
  const scored = technicians.map(tech => {
    let score = 0;

    // Specialty match (highest priority)
    if (tech.specialties?.some(s => 
      s.toLowerCase().includes(serviceRequest.service_type.replace(/_/g, ' '))
    )) {
      score += 40;
    }

    // Distance (closer is better)
    score += Math.max(0, 30 - tech.distance);

    // Rating
    score += parseFloat(tech.metrics.avgRating) * 5;

    // Completion rate
    score += tech.metrics.completionRate / 5;

    // Workload balance (fewer jobs today is better)
    score += Math.max(0, 10 - tech.metrics.todayJobs * 2);

    return { tech, score };
  });

  scored.sort((a, b) => b.score - a.score);

  return {
    technician: scored[0].tech,
    reasoning: `Rule-based selection: specialty match, distance ${scored[0].tech.distance.toFixed(1)}km, rating ${scored[0].tech.metrics.avgRating}`,
    confidence: 0.7
  };
};

// Assign technician to request
export const assignTechnicianToRequest = async (serviceRequest, technician, reasoning) => {
  try {
    const expiresAt = new Date(Date.now() + 60000).toISOString();

    await base44.entities.ServiceRequest.update(serviceRequest.id, {
      technician_id: technician.user_id,
      current_offered_technician_id: technician.user_id,
      status: 'dispatched',
      offer_expires_at: expiresAt,
      estimated_arrival: new Date(Date.now() + (technician.distance * 3 + 10) * 60000).toISOString()
    });

    await base44.entities.TechnicianProfile.update(technician.id, {
      availability_status: 'on_job'
    });

    await base44.entities.Event.create({
      type: 'OFFER_SENT',
      request_id: serviceRequest.id,
      customer_id: serviceRequest.customer_id,
      technician_id: technician.user_id,
      payload: {
        distance: technician.distance,
        reasoning,
        expires_at: expiresAt
      }
    });

    const notification = await base44.entities.Notification.create({
      user_id: technician.user_id,
      type: 'new_service_request',
      title: '🚨 New Job Offer - AI Selected',
      message: `${serviceRequest.service_type.replace(/_/g, ' ')} - ${technician.distance.toFixed(1)}km away. Accept within 60 seconds.`,
      related_id: serviceRequest.id
    });

    // Immediate push notification for urgent job offers
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      new Notification('🚨 New Job Offer', {
        body: `${serviceRequest.service_type.replace(/_/g, ' ')} - ${technician.distance.toFixed(1)}km away`,
        icon: '/icon-192.png',
        tag: `job-offer-${serviceRequest.id}`,
        requireInteraction: true,
        vibrate: [200, 100, 200, 100, 200]
      });
    }

    await base44.entities.Notification.create({
      user_id: serviceRequest.customer_id,
      type: 'technician_assigned',
      title: 'Technician Dispatched',
      message: `A technician has been selected and notified. ETA: ${Math.round(technician.distance * 3 + 10)} minutes.`,
      related_id: serviceRequest.id
    });

    return { success: true, technician };
  } catch (error) {
    console.error('Assignment error:', error);
    return { success: false, error: error.message };
  }
};