import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, Star, MapPin, Briefcase, Trophy, Clock } from 'lucide-react';

const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

export default function IntelligentDispatchSuggestions({ serviceRequest, onAssign }) {
  const [analyzing, setAnalyzing] = useState(false);
  const [suggestions, setSuggestions] = useState(null);

  const { data: technicians = [] } = useQuery({
    queryKey: ['available-technicians'],
    queryFn: async () => {
      const profiles = await base44.entities.TechnicianProfile.filter(
        { availability_status: 'available', onboarding_completed: true }
      );
      return profiles.filter(p => p.current_lat && p.current_lng);
    }
  });

  const analyzeTechnicians = async () => {
    if (!serviceRequest || technicians.length === 0) return;

    setAnalyzing(true);
    try {
      // Get active jobs for workload assessment
      const activeJobs = await base44.entities.ServiceRequest.filter({
        status: ['assigned', 'en_route', 'in_progress']
      });

      // Get ratings for all technicians
      const allRatings = await base44.entities.Rating.list();

      // Enrich technician data
      const enrichedTechs = await Promise.all(
        technicians.map(async (tech) => {
          const distance = calculateDistance(
            serviceRequest.location_lat,
            serviceRequest.location_lng,
            tech.current_lat,
            tech.current_lng
          );

          const techRatings = allRatings.filter(r => r.technician_id === tech.user_id);
          const avgRating = techRatings.length > 0
            ? techRatings.reduce((sum, r) => sum + r.rating, 0) / techRatings.length
            : 5;

          const currentWorkload = activeJobs.filter(j => j.technician_id === tech.user_id).length;

          const techUser = await base44.entities.User.filter({ id: tech.user_id });

          return {
            ...tech,
            name: techUser[0]?.full_name || 'Technician',
            distance,
            avgRating,
            currentWorkload,
            ratingCount: techRatings.length
          };
        })
      );

      // AI analysis
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze and rank technicians for optimal job assignment.

SERVICE REQUEST:
- Type: ${serviceRequest.service_type.replace(/_/g, ' ').toUpperCase()}
- Location: ${serviceRequest.location_address || 'Customer location'}
- Description: ${serviceRequest.description || 'Standard service'}
- Priority: ${serviceRequest.priority || 'normal'}

AVAILABLE TECHNICIANS:
${enrichedTechs.map((tech, i) => `
${i + 1}. ${tech.name}
   - Distance: ${tech.distance.toFixed(1)} km
   - Rating: ${tech.avgRating.toFixed(1)}/5.0 (${tech.ratingCount} reviews)
   - Current Workload: ${tech.currentWorkload} active jobs
   - Specialties: ${tech.specialties?.join(', ') || 'General'}
   - Skills: ${tech.skills_certifications?.join(', ') || 'Standard'}
   - Total Jobs: ${tech.total_jobs || 0}
   - Vehicle: ${tech.vehicle_type || 'Service vehicle'}
`).join('\n')}

Rank TOP 3 technicians considering:
1. Service specialty match (important for quality)
2. Proximity (faster response)
3. Rating & experience
4. Current workload balance
5. Overall reliability

For each ranked technician, provide:
- Match score (0-100)
- Strengths
- Why they're a good fit
- Estimated response time`,
        response_json_schema: {
          type: 'object',
          properties: {
            rankings: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  technician_id: { type: 'string' },
                  rank: { type: 'number' },
                  match_score: { type: 'number' },
                  strengths: {
                    type: 'array',
                    items: { type: 'string' }
                  },
                  reasoning: { type: 'string' },
                  estimated_eta: { type: 'string' }
                }
              }
            },
            overall_analysis: { type: 'string' }
          }
        }
      });

      // Map rankings to full technician data
      const rankedTechs = response.rankings.map(ranking => {
        const tech = enrichedTechs.find(t => t.user_id.includes(ranking.technician_id.substring(0, 12)));
        return tech ? { ...tech, ...ranking } : null;
      }).filter(Boolean);

      setSuggestions({
        technicians: rankedTechs,
        analysis: response.overall_analysis
      });

    } catch (error) {
      console.error('Analysis error:', error);
      alert('Failed to analyze technicians. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'bg-green-100 text-green-800 border-green-300';
    if (score >= 75) return 'bg-blue-100 text-blue-800 border-blue-300';
    if (score >= 60) return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    return 'bg-gray-100 text-gray-800 border-gray-300';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5" style={{ color: '#FF771D' }} />
          Intelligent Dispatch Assistant
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!suggestions ? (
          <Button
            onClick={analyzeTechnicians}
            disabled={analyzing || technicians.length === 0}
            className="w-full text-white py-6"
            style={{ backgroundColor: '#FF771D' }}
          >
            {analyzing ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Analyzing {technicians.length} Technicians...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Find Best Technicians ({technicians.length} available)
              </>
            )}
          </Button>
        ) : (
          <div className="space-y-4">
            {suggestions.analysis && (
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-sm text-blue-900">{suggestions.analysis}</p>
              </div>
            )}

            <div className="space-y-3">
              {suggestions.technicians.map((tech) => (
                <div key={tech.user_id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start gap-3">
                      <div className="text-2xl font-bold" style={{ color: '#FF771D' }}>
                        #{tech.rank}
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">{tech.name}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge className={`${getScoreColor(tech.match_score)} border font-semibold`}>
                            {tech.match_score}% Match
                          </Badge>
                          {tech.rank === 1 && (
                            <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300">
                              <Trophy className="w-3 h-3 mr-1" />
                              Best Match
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-3 text-sm">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <span>{tech.distance.toFixed(1)} km away</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span>{tech.avgRating.toFixed(1)}/5.0 ({tech.ratingCount})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-gray-500" />
                      <span>{tech.currentWorkload} active jobs</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span>ETA: {tech.estimated_eta}</span>
                    </div>
                  </div>

                  <div className="mb-3">
                    <p className="text-sm text-gray-700 mb-2">{tech.reasoning}</p>
                    <div className="flex flex-wrap gap-1">
                      {tech.strengths?.map((strength, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          ✓ {strength}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Button
                    onClick={() => onAssign(tech)}
                    className="w-full text-white"
                    style={{ backgroundColor: tech.rank === 1 ? '#3D692B' : '#FF771D' }}
                  >
                    Assign to {tech.name}
                  </Button>
                </div>
              ))}
            </div>

            <Button
              variant="outline"
              onClick={() => setSuggestions(null)}
              className="w-full"
            >
              Analyze Again
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}