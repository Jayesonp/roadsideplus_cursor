import { base44 } from '@/api/base44Client';

// Assess priority using AI
export const assessRequestPriority = async (serviceRequest, customerId) => {
  try {
    // Get customer history
    const customerHistory = await base44.entities.ServiceRequest.filter(
      { customer_id: customerId, status: 'completed' },
      '-completed_at',
      20
    );

    const customerRatings = await base44.entities.Rating.filter(
      { customer_id: customerId },
      '-created_date',
      10
    );

    // Get current time context
    const now = new Date();
    const hour = now.getHours();
    const isNightTime = hour < 6 || hour > 22;
    const isWeekend = now.getDay() === 0 || now.getDay() === 6;

    // Calculate customer metrics
    const totalSpent = customerHistory.reduce((sum, req) => sum + (req.price || 0), 0);
    const avgRating = customerRatings.length > 0
      ? customerRatings.reduce((sum, r) => sum + r.rating, 0) / customerRatings.length
      : 0;

    const prompt = `You are an intelligent priority assessment system for roadside assistance. Analyze this service request and assign a priority level.

SERVICE REQUEST:
- Type: ${serviceRequest.service_type.replace(/_/g, ' ')}
- Description: ${serviceRequest.description || 'No additional details'}
- Location: ${serviceRequest.location_address || 'Location provided'}
- Time: ${now.toLocaleString()} ${isNightTime ? '(Night time - reduced visibility/safety)' : ''} ${isWeekend ? '(Weekend)' : '(Weekday)'}

CUSTOMER PROFILE:
- Total Previous Services: ${customerHistory.length}
- Total Spent: $${totalSpent.toFixed(2)}
- Average Rating Given: ${avgRating.toFixed(1)}/5 (${customerRatings.length} ratings)
- Customer Since: ${customerHistory[0]?.created_date ? new Date(customerHistory[0].created_date).toLocaleDateString() : 'First time'}

PRIORITY FACTORS:
1. Safety & Urgency:
   - Towing/vehicle disabled = Critical
   - Battery jump = High (stranded)
   - Fuel delivery = High (stranded)
   - Lockout = Medium-High (security concern)
   - Tire change = Medium (mobility issue)
   - Night time adds urgency (+1 level)
   
2. Customer Value:
   - Repeat customers with good history get priority
   - High spenders get slight boost
   - First-time customers = normal priority

3. Situational Context:
   - Dangerous locations (highway, remote areas)
   - Weather conditions mentioned
   - Special circumstances in description

PRIORITY LEVELS:
- CRITICAL (90-100): Immediate safety concern, high-value customer stranded
- HIGH (70-89): Vehicle disabled, stranded, or urgent safety need
- NORMAL (40-69): Standard service, no immediate danger
- LOW (0-39): Non-urgent, can wait

Provide a priority score (0-100) and level. Be fair but prioritize safety and customer loyalty.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          priority_level: {
            type: "string",
            enum: ["low", "normal", "high", "critical"]
          },
          priority_score: {
            type: "number"
          },
          reasoning: {
            type: "string"
          },
          estimated_wait_tolerance: {
            type: "string"
          }
        },
        required: ["priority_level", "priority_score", "reasoning"]
      }
    });

    console.log(`Priority Assessment: ${result.priority_level} (${result.priority_score}) - ${result.reasoning}`);

    return {
      priority: result.priority_level,
      priority_score: result.priority_score,
      priority_reasoning: result.reasoning,
      wait_tolerance: result.estimated_wait_tolerance
    };

  } catch (error) {
    console.error('Priority assessment error:', error);
    
    // Fallback rule-based priority
    let priority = 'normal';
    let score = 50;
    
    if (['towing'].includes(serviceRequest.service_type)) {
      priority = 'critical';
      score = 95;
    } else if (['battery_jump', 'fuel_delivery'].includes(serviceRequest.service_type)) {
      priority = 'high';
      score = 75;
    } else if (['lockout'].includes(serviceRequest.service_type)) {
      priority = 'high';
      score = 70;
    }

    return {
      priority,
      priority_score: score,
      priority_reasoning: 'Fallback rule-based assessment'
    };
  }
};

// Sort requests by priority for dispatch queue
export const sortRequestsByPriority = (requests) => {
  const priorityWeights = {
    critical: 1000,
    high: 100,
    normal: 10,
    low: 1
  };

  return [...requests].sort((a, b) => {
    const scoreA = (a.priority_score || 50) + priorityWeights[a.priority || 'normal'];
    const scoreB = (b.priority_score || 50) + priorityWeights[b.priority || 'normal'];
    
    if (scoreB !== scoreA) {
      return scoreB - scoreA; // Higher priority first
    }
    
    // If same priority, older requests first
    return new Date(a.created_date) - new Date(b.created_date);
  });
};