import { useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';

// Check if location is stale (no update in last 5 minutes)
const isLocationStale = (lastUpdate) => {
  if (!lastUpdate) return true;
  const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
  return new Date(lastUpdate).getTime() < fiveMinutesAgo;
};

// Calculate distance between two points
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

// Find and select best replacement technician
const findReplacementTechnician = async (serviceRequest, originalTechId) => {
  try {
    // Get available technicians
    const allProfiles = await base44.entities.TechnicianProfile.list();
    
    const availableProfiles = allProfiles.filter(profile => 
      profile.user_id !== originalTechId && // Exclude original technician
      profile.onboarding_completed &&
      profile.availability_status === 'available' &&
      profile.current_lat && 
      profile.current_lng
    );

    if (availableProfiles.length === 0) return null;

    // Check for active jobs and calculate distances
    const candidates = await Promise.all(
      availableProfiles.map(async (profile) => {
        const activeJobs = await base44.entities.ServiceRequest.filter({
          technician_id: profile.user_id,
          status: ['assigned', 'en_route', 'in_progress', 'arrived']
        });

        if (activeJobs.length > 0) return null;

        const distance = calculateDistance(
          serviceRequest.location_lat,
          serviceRequest.location_lng,
          profile.current_lat,
          profile.current_lng
        );

        return { ...profile, distance };
      })
    );

    const validCandidates = candidates
      .filter(c => c !== null)
      .sort((a, b) => a.distance - b.distance);

    return validCandidates[0] || null;

  } catch (error) {
    console.error('Error finding replacement technician:', error);
    return null;
  }
};

// Perform job reassignment
const reassignJob = async (serviceRequest, originalTechProfile, reason) => {
  try {
    console.log(`Reassigning job ${serviceRequest.id}, reason: ${reason}`);

    // Find replacement technician
    const newTechnician = await findReplacementTechnician(
      serviceRequest, 
      originalTechProfile.user_id
    );

    if (!newTechnician) {
      // No replacement available - mark as needing dispatch
      await base44.entities.ServiceRequest.update(serviceRequest.id, {
        status: 'pending_dispatch',
        technician_id: null
      });

      // Notify customer
      await base44.entities.Notification.create({
        user_id: serviceRequest.customer_id,
        type: 'urgent_job_update',
        title: 'Job Being Reassigned',
        message: `Your technician became unavailable. We're finding you a replacement immediately.`,
        related_id: serviceRequest.id
      });

      return { success: false, reason: 'no_replacement_available' };
    }

    // Update service request with new technician
    await base44.entities.ServiceRequest.update(serviceRequest.id, {
      technician_id: newTechnician.user_id,
      status: 'assigned',
      estimated_arrival: new Date(Date.now() + 15 * 60000).toISOString()
    });

    // Update original technician availability
    if (originalTechProfile.availability_status === 'on_job') {
      await base44.entities.TechnicianProfile.update(originalTechProfile.id, {
        availability_status: 'available'
      });
    }

    // Update new technician availability
    await base44.entities.TechnicianProfile.update(newTechnician.id, {
      availability_status: 'on_job'
    });

    // Log event
    await base44.entities.Event.create({
      type: 'JOB_REASSIGNED',
      request_id: serviceRequest.id,
      customer_id: serviceRequest.customer_id,
      technician_id: newTechnician.user_id,
      payload: {
        original_technician: originalTechProfile.user_id,
        new_technician: newTechnician.user_id,
        reason,
        distance: newTechnician.distance,
        timestamp: new Date().toISOString()
      }
    });

    // Notify customer
    await base44.entities.Notification.create({
      user_id: serviceRequest.customer_id,
      type: 'urgent_job_update',
      title: 'New Technician Assigned',
      message: `Your job has been reassigned to a new technician who is ${newTechnician.distance.toFixed(1)}km away.`,
      related_id: serviceRequest.id
    });

    // Notify original technician
    await base44.entities.Notification.create({
      user_id: originalTechProfile.user_id,
      type: 'job_reassigned',
      title: 'Job Reassigned',
      message: `Your job has been reassigned due to ${reason}. You are now available for new jobs.`,
      related_id: serviceRequest.id
    });

    // Notify new technician
    await base44.entities.Notification.create({
      user_id: newTechnician.user_id,
      type: 'job_assigned',
      title: '🚨 Urgent Job Assigned',
      message: `You've been assigned a ${serviceRequest.service_type.replace(/_/g, ' ')} job (reassigned due to ${reason}). Customer is waiting!`,
      related_id: serviceRequest.id
    });

    console.log(`Job ${serviceRequest.id} reassigned to ${newTechnician.user_id}`);
    return { success: true, newTechnician };

  } catch (error) {
    console.error('Error during job reassignment:', error);
    return { success: false, error: error.message };
  }
};

// Check active jobs for reassignment needs
const checkActiveJobs = async () => {
  try {
    // Get all active jobs
    const activeJobs = await base44.entities.ServiceRequest.filter({
      status: ['assigned', 'en_route']
    });

    for (const job of activeJobs) {
      if (!job.technician_id) continue;

      // Get technician profile
      const techProfiles = await base44.entities.TechnicianProfile.filter({
        user_id: job.technician_id
      });

      if (techProfiles.length === 0) continue;
      const techProfile = techProfiles[0];

      // Check if technician needs reassignment
      let shouldReassign = false;
      let reason = '';

      // Reason 1: Technician went offline
      if (techProfile.availability_status === 'offline') {
        shouldReassign = true;
        reason = 'technician went offline';
      }

      // Reason 2: Location updates are stale (no update in 5 minutes for assigned/en_route jobs)
      if (!shouldReassign && isLocationStale(techProfile.updated_date)) {
        shouldReassign = true;
        reason = 'lost contact with technician';
      }

      // Reason 3: Technician manually set to break or unavailable
      if (!shouldReassign && ['break', 'unavailable'].includes(techProfile.availability_status)) {
        shouldReassign = true;
        reason = 'technician became unavailable';
      }

      if (shouldReassign) {
        console.log(`Triggering reassignment for job ${job.id}: ${reason}`);
        await reassignJob(job, techProfile, reason);
      }
    }

  } catch (error) {
    console.error('Error checking active jobs:', error);
  }
};

export default function JobReassignmentMonitor() {
  const queryClient = useQueryClient();
  const intervalRef = useRef(null);

  useEffect(() => {
    // Check every 5 minutes to reduce API load
    intervalRef.current = setInterval(() => {
      checkActiveJobs();
    }, 5 * 60 * 1000);

    // Initial check
    checkActiveJobs();

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  return null;
}

// Export function for manual triggering
export const triggerJobReassignment = async (jobId, reason = 'manual reassignment') => {
  try {
    const jobs = await base44.entities.ServiceRequest.filter({ id: jobId });
    if (jobs.length === 0) return { success: false, error: 'Job not found' };

    const job = jobs[0];
    if (!job.technician_id) return { success: false, error: 'No technician assigned' };

    const techProfiles = await base44.entities.TechnicianProfile.filter({
      user_id: job.technician_id
    });

    if (techProfiles.length === 0) return { success: false, error: 'Technician profile not found' };

    return await reassignJob(job, techProfiles[0], reason);
  } catch (error) {
    console.error('Error triggering manual reassignment:', error);
    return { success: false, error: error.message };
  }
};