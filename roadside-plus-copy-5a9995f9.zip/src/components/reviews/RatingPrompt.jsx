import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Star, ThumbsUp } from 'lucide-react';
import { motion } from 'framer-motion';

export default function RatingPrompt({ serviceRequest, onComplete }) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const queryClient = useQueryClient();

  const submitRating = useMutation({
    mutationFn: async () => {
      const newRating = await base44.entities.Rating.create({
        service_request_id: serviceRequest.id,
        technician_id: serviceRequest.technician_id,
        customer_id: serviceRequest.customer_id,
        rating: rating,
        comment: comment
      });

      // Update technician's average rating
      const allRatings = await base44.entities.Rating.filter({ 
        technician_id: serviceRequest.technician_id 
      });
      const avgRating = allRatings.reduce((sum, r) => sum + r.rating, 0) / allRatings.length;

      const techProfiles = await base44.entities.TechnicianProfile.filter({ 
        user_id: serviceRequest.technician_id 
      });
      if (techProfiles[0]) {
        await base44.entities.TechnicianProfile.update(techProfiles[0].id, {
          rating: avgRating,
          total_jobs: (techProfiles[0].total_jobs || 0) + 1
        });
      }

      // Auto-charge payment
      const paymentMethods = await base44.entities.PaymentMethod.filter({ 
        user_id: serviceRequest.customer_id,
        is_default: true 
      });

      if (paymentMethods.length > 0) {
        // Create payment intent and auto-charge
        const { data: paymentResult } = await base44.functions.invoke('stripePayment', {
          action: 'create_payment_intent',
          amount: serviceRequest.payment_amount || serviceRequest.price,
          metadata: { request_id: serviceRequest.id }
        });

        // Simulate successful payment (in production, use real Stripe)
        await base44.functions.invoke('stripePayment', {
          action: 'confirm_payment',
          requestId: serviceRequest.id,
          paymentIntentId: `pi_auto_${Date.now()}`,
          tipAmount: 0
        });
      }

      // Update service request status
      await base44.entities.ServiceRequest.update(serviceRequest.id, {
        status: 'completed'
      });

      return newRating;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['rating', serviceRequest.id]);
      queryClient.invalidateQueries(['service-request', serviceRequest.id]);
      onComplete?.();
    }
  });

  const handleSubmit = async () => {
    if (rating === 0) {
      alert('Please select a rating');
      return;
    }

    setSubmitting(true);
    try {
      await submitRating.mutateAsync();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
    >
      <Card className="border-2" style={{ borderColor: '#FF771D' }}>
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <ThumbsUp className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-xl font-bold mb-2">Service Complete!</h3>
            <p className="text-gray-600">How was your experience?</p>
          </div>

          <div className="space-y-4">
            {/* Star Rating */}
            <div className="flex justify-center gap-2 py-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <motion.button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  whileHover={{ scale: 1.2 }}
                  whileTap={{ scale: 0.9 }}
                  className="transition-all"
                >
                  <Star
                    className={`w-12 h-12 ${
                      star <= (hoveredRating || rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                </motion.button>
              ))}
            </div>

            {rating > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center text-lg font-semibold"
                style={{ color: '#FF771D' }}
              >
                {rating === 5 && '⭐ Excellent!'}
                {rating === 4 && '👍 Great!'}
                {rating === 3 && '😊 Good'}
                {rating === 2 && '😕 Fair'}
                {rating === 1 && '😞 Poor'}
              </motion.div>
            )}

            {/* Comment */}
            <div>
              <Textarea
                placeholder="Share your experience with this technician (optional)"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="h-24"
              />
            </div>

            {/* Submit Button */}
            <Button
              onClick={handleSubmit}
              disabled={rating === 0 || submitting}
              className="w-full text-white py-6 text-lg font-semibold"
              style={{ backgroundColor: '#3D692B' }}
            >
              {submitting ? 'Submitting...' : 'Submit Review'}
            </Button>

            <p className="text-xs text-center text-gray-500">
              Your feedback helps us maintain quality service
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}