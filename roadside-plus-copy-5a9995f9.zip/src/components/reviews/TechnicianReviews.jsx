import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Star, User, Calendar, Flag, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Textarea } from '@/components/ui/textarea';

export default function TechnicianReviews({ technicianId, limit = null, allowFlagging = false }) {
  const [flagReviewId, setFlagReviewId] = useState(null);
  const [flagReason, setFlagReason] = useState('');
  const queryClient = useQueryClient();
  const { data: reviews = [], isLoading } = useQuery({
    queryKey: ['technician-reviews', technicianId, limit],
    queryFn: async () => {
      const allRatings = await base44.entities.Rating.filter(
        { technician_id: technicianId },
        '-created_date',
        limit || 50
      );
      
      // Filter out non-visible reviews (removed by admin)
      const ratings = allRatings.filter(r => r.is_visible !== false);

      // Fetch customer details for each rating
      const reviewsWithCustomers = await Promise.all(
        ratings.map(async (rating) => {
          try {
            const customers = await base44.entities.User.filter({ id: rating.customer_id });
            return {
              ...rating,
              customerName: customers[0]?.full_name || 'Customer'
            };
          } catch {
            return { ...rating, customerName: 'Customer' };
          }
        })
      );

      return reviewsWithCustomers;
    },
    enabled: !!technicianId
  });

  const averageRating = reviews.length > 0 
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : '5.0';

  const ratingDistribution = {
    5: reviews.filter(r => r.rating === 5).length,
    4: reviews.filter(r => r.rating === 4).length,
    3: reviews.filter(r => r.rating === 3).length,
    2: reviews.filter(r => r.rating === 2).length,
    1: reviews.filter(r => r.rating === 1).length,
  };

  const flagReview = useMutation({
    mutationFn: async ({ reviewId, reason }) => {
      const user = await base44.auth.me();
      await base44.entities.Rating.update(reviewId, {
        is_flagged: true,
        flag_reason: reason,
        flagged_by: user.id,
        flagged_at: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['technician-reviews']);
      setFlagReviewId(null);
      setFlagReason('');
      alert('Review flagged successfully. An administrator will review it.');
    }
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-gray-500">
          Loading reviews...
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
          Customer Reviews ({reviews.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Rating Summary */}
        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-4 mb-3">
            <div className="text-center">
              <div className="text-4xl font-bold">{averageRating}</div>
              <div className="flex items-center justify-center gap-1 mt-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-4 h-4 ${
                      star <= Math.round(averageRating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <p className="text-xs text-gray-600 mt-1">{reviews.length} reviews</p>
            </div>

            <div className="flex-1 space-y-1">
              {[5, 4, 3, 2, 1].map((rating) => (
                <div key={rating} className="flex items-center gap-2 text-sm">
                  <span className="w-3">{rating}</span>
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-yellow-400 h-2 rounded-full"
                      style={{
                        width: `${reviews.length > 0 ? (ratingDistribution[rating] / reviews.length) * 100 : 0}%`
                      }}
                    />
                  </div>
                  <span className="w-8 text-xs text-gray-600">{ratingDistribution[rating]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Reviews List */}
        {reviews.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Star className="w-12 h-12 mx-auto mb-2 text-gray-300" />
            <p>No reviews yet</p>
          </div>
        ) : (
          <div className="space-y-4 max-h-[500px] overflow-y-auto">
            {reviews.map((review) => (
              <div key={review.id} className="border-b pb-4 last:border-0">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2 flex-1">
                    <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                      <User className="w-4 h-4 text-gray-600" />
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-sm">{review.customerName}</p>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-3 h-3 ${
                              star <= review.rating
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      <Calendar className="w-3 h-3" />
                      {format(new Date(review.created_date), 'MMM d, yyyy')}
                    </div>
                    {allowFlagging && !review.is_flagged && (
                      <AlertDialog open={flagReviewId === review.id} onOpenChange={(open) => !open && setFlagReviewId(null)}>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setFlagReviewId(review.id)}
                            className="h-6 w-6 text-gray-400 hover:text-red-600"
                          >
                            <Flag className="w-3 h-3" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Flag Inappropriate Review</AlertDialogTitle>
                            <AlertDialogDescription>
                              Please provide a reason for flagging this review. An administrator will review your report.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <Textarea
                            placeholder="Explain why this review is inappropriate..."
                            value={flagReason}
                            onChange={(e) => setFlagReason(e.target.value)}
                            className="min-h-[100px]"
                          />
                          <AlertDialogFooter>
                            <AlertDialogCancel onClick={() => { setFlagReviewId(null); setFlagReason(''); }}>
                              Cancel
                            </AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => flagReview.mutate({ reviewId: review.id, reason: flagReason })}
                              disabled={!flagReason.trim() || flagReview.isLoading}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Submit Report
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                    {review.is_flagged && (
                      <div className="flex items-center gap-1 text-xs text-orange-600">
                        <AlertCircle className="w-3 h-3" />
                        <span>Flagged</span>
                      </div>
                    )}
                  </div>
                </div>
                {review.comment && (
                  <p className="text-sm text-gray-700 ml-10">{review.comment}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}