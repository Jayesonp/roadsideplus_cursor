import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, MapPin } from 'lucide-react';
import { format } from 'date-fns';

export default function SecurityOfficerStatus({ officers }) {
  const getStatusColor = (status) => {
    switch (status) {
      case 'available': return { bg: '#3D692B', text: 'white' };
      case 'busy': return { bg: '#FFA500', text: 'white' };
      case 'offline': return { bg: '#666', text: 'white' };
      default: return { bg: '#666', text: 'white' };
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'available': return '🟢';
      case 'busy': return '🟡';
      case 'offline': return '🔴';
      default: return '⚪';
    }
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Users className="w-5 h-5" style={{ color: '#3D692B' }} />
          Officer Status
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-[600px] overflow-y-auto">
          {officers.map(officer => {
            const statusColor = getStatusColor(officer.status);
            return (
              <div
                key={officer.id}
                className="border border-gray-700 rounded-lg p-3 bg-gray-900"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{getStatusIcon(officer.status)}</span>
                    <div>
                      <p className="font-semibold text-white text-sm">
                        Badge #{officer.officer_badge_number}
                      </p>
                      <p className="text-xs text-gray-400">{officer.role}</p>
                    </div>
                  </div>
                  <Badge style={{ backgroundColor: statusColor.bg, color: statusColor.text }}>
                    {officer.status.toUpperCase()}
                  </Badge>
                </div>

                {officer.current_lat && officer.current_lng && (
                  <div className="flex items-center gap-1 text-xs text-gray-400 mt-2">
                    <MapPin className="w-3 h-3" />
                    <span>
                      {officer.current_lat.toFixed(4)}, {officer.current_lng.toFixed(4)}
                    </span>
                  </div>
                )}

                {officer.last_active && (
                  <p className="text-xs text-gray-500 mt-2">
                    Last active: {format(new Date(officer.last_active), 'h:mm a')}
                  </p>
                )}

                <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
                  <div className="text-gray-400">
                    <p>Total Incidents</p>
                    <p className="text-white font-semibold">{officer.total_incidents_handled || 0}</p>
                  </div>
                  <div className="text-gray-400">
                    <p>Avg Response</p>
                    <p className="text-white font-semibold">{officer.average_response_time_minutes || 0} min</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}