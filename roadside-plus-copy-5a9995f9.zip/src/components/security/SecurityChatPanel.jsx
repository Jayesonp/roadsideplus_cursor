import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Send, AlertTriangle, User, Shield } from 'lucide-react';
import { format } from 'date-fns';

const MESSAGE_TEMPLATES = [
  { id: 'eta_5', text: 'ETA 5 minutes', category: 'status' },
  { id: 'arrived', text: 'I have arrived at the location', category: 'status' },
  { id: 'secure', text: 'Area is now secure', category: 'status' },
  { id: 'safe_stay', text: 'Stay in your vehicle with doors locked', category: 'instruction' },
  { id: 'safe_move', text: 'Move to a safe, well-lit area if possible', category: 'instruction' },
  { id: 'emergency', text: 'If you feel immediate danger, call 911', category: 'emergency' },
  { id: 'documenting', text: 'Documenting the scene and gathering information', category: 'status' },
  { id: 'resolution', text: 'Incident resolved, completing report', category: 'status' }
];

export default function SecurityChatPanel({ 
  companyId, 
  userId, 
  userRole, 
  incidentId = null,
  chatType = 'officer_dispatcher',
  recipientId = null 
}) {
  const [message, setMessage] = useState('');
  const [showTemplates, setShowTemplates] = useState(false);
  const messagesEndRef = useRef(null);
  const queryClient = useQueryClient();

  const { data: messages = [] } = useQuery({
    queryKey: ['security-chat', companyId, incidentId, chatType],
    queryFn: () => {
      const filter = { company_id: companyId, chat_type: chatType };
      if (incidentId) filter.incident_id = incidentId;
      return base44.entities.SecurityChat.filter(filter, '-created_date', 100);
    },
    enabled: !!companyId,
    refetchInterval: 2000
  });

  const sendMessage = useMutation({
    mutationFn: async (messageData) => {
      const chat = await base44.entities.SecurityChat.create({
        company_id: companyId,
        incident_id: incidentId,
        chat_type: chatType,
        sender_id: userId,
        sender_role: userRole,
        recipient_id: recipientId,
        message: messageData.message,
        message_template: messageData.template,
        is_emergency: messageData.isEmergency || false
      });

      // Log security event
      if (incidentId) {
        await base44.entities.SecurityEvent.create({
          incident_id: incidentId,
          company_id: companyId,
          officer_id: userRole === 'officer' ? userId : null,
          event_type: 'message_sent',
          event_data: { 
            chat_type: chatType,
            is_emergency: messageData.isEmergency 
          }
        });
      }

      // Notify recipient
      if (recipientId) {
        await base44.entities.Notification.create({
          user_id: recipientId,
          type: 'new_message',
          title: messageData.isEmergency ? 'Emergency Message' : 'New Message',
          message: messageData.message.substring(0, 100),
          related_id: incidentId || chat.id
        });
      }

      return chat;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['security-chat'] });
      setMessage('');
      setShowTemplates(false);
    }
  });

  const handleSend = () => {
    if (!message.trim()) return;
    sendMessage.mutate({ message: message.trim() });
  };

  const handleTemplateSelect = (template) => {
    sendMessage.mutate({
      message: template.text,
      template: template.id,
      isEmergency: template.category === 'emergency'
    });
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const getSenderIcon = (role) => {
    switch (role) {
      case 'officer': return <Shield className="w-4 h-4" style={{ color: '#3D692B' }} />;
      case 'dispatcher': return <MessageSquare className="w-4 h-4" style={{ color: '#FF771D' }} />;
      case 'customer': return <User className="w-4 h-4" style={{ color: '#666' }} />;
      default: return null;
    }
  };

  return (
    <Card className="bg-gray-800 border-gray-700 h-full flex flex-col">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-sm flex items-center gap-2">
          <MessageSquare className="w-4 h-4" />
          {chatType === 'officer_dispatcher' ? 'Dispatcher Chat' : 'Customer Chat'}
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col p-0">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 space-y-3 max-h-[400px] min-h-[300px]">
          {messages.length === 0 ? (
            <div className="text-center text-gray-500 py-8 text-sm">No messages yet</div>
          ) : (
            messages.map((msg) => {
              const isMe = msg.sender_id === userId;
              return (
                <div
                  key={msg.id}
                  className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[80%] ${isMe ? 'bg-gray-700' : 'bg-gray-600'} rounded-lg p-3`}>
                    <div className="flex items-center gap-2 mb-1">
                      {getSenderIcon(msg.sender_role)}
                      <span className="text-xs text-gray-400">
                        {msg.sender_role}
                      </span>
                      {msg.is_emergency && (
                        <Badge className="text-xs" style={{ backgroundColor: '#E52C2D' }}>
                          Emergency
                        </Badge>
                      )}
                    </div>
                    <p className="text-white text-sm">{msg.message}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {format(new Date(msg.created_date), 'h:mm a')}
                    </p>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Templates */}
        {showTemplates && (
          <div className="px-4 py-3 border-t border-gray-700">
            <p className="text-xs text-gray-400 mb-2">Quick Messages:</p>
            <div className="grid grid-cols-2 gap-2">
              {MESSAGE_TEMPLATES.map(template => (
                <Button
                  key={template.id}
                  size="sm"
                  variant="outline"
                  className="text-white border-gray-600 hover:bg-gray-700 text-xs justify-start"
                  onClick={() => handleTemplateSelect(template)}
                >
                  {template.category === 'emergency' && (
                    <AlertTriangle className="w-3 h-3 mr-1" style={{ color: '#E52C2D' }} />
                  )}
                  {template.text}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="p-4 border-t border-gray-700">
          <div className="flex gap-2 mb-2">
            <Button
              size="sm"
              variant="outline"
              className="text-white border-gray-600"
              onClick={() => setShowTemplates(!showTemplates)}
            >
              {showTemplates ? 'Hide' : 'Templates'}
            </Button>
          </div>
          <div className="flex gap-2">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Type a message..."
              className="bg-gray-900 text-white border-gray-600"
            />
            <Button
              onClick={handleSend}
              disabled={!message.trim() || sendMessage.isLoading}
              className="text-white"
              style={{ backgroundColor: '#FF771D' }}
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}