import React, { useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';

export default function OfficerLocationTracker({ officerId, companyId, incidentId = null }) {
  const watchIdRef = useRef(null);
  const lastUpdateRef = useRef(0);

  useEffect(() => {
    startTracking();
    return () => stopTracking();
  }, [officerId, incidentId]);

  const startTracking = () => {
    if (!navigator.geolocation) return;

    // High accuracy location tracking for officers
    watchIdRef.current = navigator.geolocation.watchPosition(
      updateLocation,
      handleError,
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  };

  const updateLocation = async (position) => {
    const { latitude, longitude, heading, speed, accuracy } = position.coords;
    const now = Date.now();

    // Update every 5 seconds for high fidelity
    if (now - lastUpdateRef.current < 5000) return;
    lastUpdateRef.current = now;

    try {
      // Update officer location
      await base44.entities.SecurityOfficer.update(officerId, {
        current_lat: latitude,
        current_lng: longitude,
        last_active: new Date().toISOString()
      });

      // Save GPS trail for incident tracking
      await base44.entities.GPSTrail.create({
        entity_id: officerId,
        entity_type: 'officer',
        latitude,
        longitude,
        heading: heading || 0,
        speed: speed || 0,
        accuracy: accuracy || 0
      });

      // Update incident location if officer is en route
      if (incidentId) {
        await base44.entities.SecurityEvent.create({
          incident_id: incidentId,
          company_id: companyId,
          officer_id: officerId,
          event_type: 'location_updated',
          event_data: { accuracy },
          location_lat: latitude,
          location_lng: longitude
        });
      }
    } catch (error) {
      console.error('Location update failed:', error);
    }
  };

  const handleError = (error) => {
    console.error('Location error:', error.message);
  };

  const stopTracking = () => {
    if (watchIdRef.current) {
      navigator.geolocation.clearWatch(watchIdRef.current);
    }
  };

  return null; // Background service
}