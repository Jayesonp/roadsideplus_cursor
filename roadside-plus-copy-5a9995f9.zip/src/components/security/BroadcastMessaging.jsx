import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Radio, AlertTriangle, Bell } from 'lucide-react';
import { format } from 'date-fns';

export default function BroadcastMessaging({ companyId, senderId }) {
  const [message, setMessage] = useState('');
  const [isEmergency, setIsEmergency] = useState(false);
  const queryClient = useQueryClient();

  const { data: officers = [] } = useQuery({
    queryKey: ['company-officers', companyId],
    queryFn: () => base44.entities.SecurityOfficer.filter({ company_id: companyId }),
    enabled: !!companyId
  });

  const { data: recentBroadcasts = [] } = useQuery({
    queryKey: ['broadcasts', companyId],
    queryFn: () => base44.entities.SecurityChat.filter(
      { company_id: companyId, is_broadcast: true },
      '-created_date',
      10
    ),
    enabled: !!companyId,
    refetchInterval: 5000
  });

  const sendBroadcast = useMutation({
    mutationFn: async () => {
      // Create broadcast message
      const broadcast = await base44.entities.SecurityChat.create({
        company_id: companyId,
        chat_type: 'broadcast',
        sender_id: senderId,
        sender_role: 'dispatcher',
        message: message.trim(),
        is_broadcast: true,
        is_emergency: isEmergency
      });

      // Notify all officers
      const notifications = officers.map(officer => 
        base44.entities.Notification.create({
          user_id: officer.user_id,
          type: 'new_message',
          title: isEmergency ? '🚨 EMERGENCY BROADCAST' : '📢 Company Broadcast',
          message: message.substring(0, 100),
          related_id: broadcast.id
        })
      );

      await Promise.all(notifications);

      // Log event
      await base44.entities.SecurityEvent.create({
        company_id: companyId,
        event_type: 'message_sent',
        event_data: {
          broadcast: true,
          is_emergency: isEmergency,
          recipients_count: officers.length
        }
      });

      return broadcast;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['broadcasts'] });
      setMessage('');
      setIsEmergency(false);
      alert('Broadcast sent to all officers!');
    }
  });

  const handleSend = () => {
    if (!message.trim()) return;
    if (window.confirm(`Send broadcast to ${officers.length} officers?`)) {
      sendBroadcast.mutate();
    }
  };

  return (
    <div className="space-y-4">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Radio className="w-5 h-5" style={{ color: '#FF771D' }} />
            Broadcast to All Officers
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your broadcast message..."
              className="bg-gray-900 text-white border-gray-600 min-h-[100px]"
            />
          </div>

          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-white text-sm cursor-pointer">
              <input
                type="checkbox"
                checked={isEmergency}
                onChange={(e) => setIsEmergency(e.target.checked)}
                className="rounded"
              />
              <AlertTriangle className="w-4 h-4" style={{ color: '#E52C2D' }} />
              Mark as Emergency
            </label>
          </div>

          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-400">
              Will notify <strong>{officers.length}</strong> officers
            </p>
            <Button
              onClick={handleSend}
              disabled={!message.trim() || sendBroadcast.isLoading}
              className="text-white"
              style={{ backgroundColor: isEmergency ? '#E52C2D' : '#FF771D' }}
            >
              {sendBroadcast.isLoading ? 'Sending...' : 'Send Broadcast'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Broadcasts */}
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Bell className="w-4 h-4" />
            Recent Broadcasts
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recentBroadcasts.length === 0 ? (
            <p className="text-gray-500 text-sm text-center py-4">No recent broadcasts</p>
          ) : (
            <div className="space-y-3">
              {recentBroadcasts.map(broadcast => (
                <div key={broadcast.id} className="border border-gray-700 rounded-lg p-3">
                  <div className="flex items-start justify-between mb-2">
                    <Badge style={{ backgroundColor: broadcast.is_emergency ? '#E52C2D' : '#FF771D' }}>
                      {broadcast.is_emergency ? 'Emergency' : 'Broadcast'}
                    </Badge>
                    <span className="text-xs text-gray-500">
                      {format(new Date(broadcast.created_date), 'MMM d, h:mm a')}
                    </span>
                  </div>
                  <p className="text-white text-sm">{broadcast.message}</p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}