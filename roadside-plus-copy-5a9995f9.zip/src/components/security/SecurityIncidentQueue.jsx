import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, MapPin, Clock, User, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';

export default function SecurityIncidentQueue({ incidents, companyId }) {
  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return '#E52C2D';
      case 'high': return '#FF771D';
      case 'medium': return '#FFA500';
      case 'low': return '#3D692B';
      default: return '#666';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-red-100 text-red-800';
      case 'assigned': return 'bg-blue-100 text-blue-800';
      case 'en_route': return 'bg-yellow-100 text-yellow-800';
      case 'arrived': return 'bg-green-100 text-green-800';
      case 'securing_area': return 'bg-purple-100 text-purple-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <AlertTriangle className="w-5 h-5" style={{ color: '#E52C2D' }} />
          Active SOS Incidents
        </CardTitle>
      </CardHeader>
      <CardContent>
        {incidents.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <AlertTriangle className="w-16 h-16 mx-auto mb-3 opacity-20" />
            <p>No active incidents</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[600px] overflow-y-auto">
            {incidents.map(incident => (
              <div
                key={incident.id}
                className="border border-gray-700 rounded-lg p-4 hover:border-gray-600 transition-all cursor-pointer bg-gray-900"
                onClick={() => window.location.href = createPageUrl(`SecurityIncidentDetail?id=${incident.id}`)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full animate-pulse"
                         style={{ backgroundColor: getSeverityColor(incident.severity) }}></div>
                    <div>
                      <Badge className={getStatusColor(incident.status)}>
                        {incident.status.replace(/_/g, ' ').toUpperCase()}
                      </Badge>
                      <p className="text-xs text-gray-400 mt-1">
                        ID: {incident.id.slice(0, 8)}
                      </p>
                    </div>
                  </div>
                  <Badge style={{ backgroundColor: getSeverityColor(incident.severity), color: 'white' }}>
                    {incident.severity.toUpperCase()}
                  </Badge>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-start gap-2 text-gray-300">
                    <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: '#FF771D' }} />
                    <span>{incident.location_address || 'Location data available'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-400">
                    <Clock className="w-4 h-4" />
                    <span>{format(new Date(incident.created_date), 'MMM d, h:mm a')}</span>
                  </div>
                  {incident.assigned_officer_id && (
                    <div className="flex items-center gap-2 text-gray-400">
                      <User className="w-4 h-4" />
                      <span>Officer assigned</span>
                    </div>
                  )}
                </div>

                <Button
                  className="w-full mt-3 text-white"
                  style={{ backgroundColor: '#FF771D' }}
                  onClick={(e) => {
                    e.stopPropagation();
                    window.location.href = createPageUrl(`SecurityIncidentDetail?id=${incident.id}`);
                  }}
                >
                  View Details
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}