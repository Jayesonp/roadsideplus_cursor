import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Camera, Upload, X, Image, Video } from 'lucide-react';

export default function OfficerEvidenceUpload({ incidentId, officerId, companyId }) {
  const [uploading, setUploading] = useState(false);
  const [description, setDescription] = useState('');
  const queryClient = useQueryClient();

  const { data: incident } = useQuery({
    queryKey: ['incident', incidentId],
    queryFn: () => base44.entities.SOSIncident.filter({ id: incidentId })
  });

  const uploadEvidence = useMutation({
    mutationFn: async (file) => {
      setUploading(true);
      
      // Upload file
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      // Determine if photo or video
      const isVideo = file.type.startsWith('video/');
      const currentIncident = incident?.[0];
      
      // Update incident with evidence
      const updates = {};
      if (isVideo) {
        updates.evidence_videos = [...(currentIncident?.evidence_videos || []), file_url];
      } else {
        updates.evidence_photos = [...(currentIncident?.evidence_photos || []), file_url];
      }
      
      await base44.entities.SOSIncident.update(incidentId, updates);
      
      // Log event
      await base44.entities.SecurityEvent.create({
        incident_id: incidentId,
        company_id: companyId,
        officer_id: officerId,
        event_type: 'evidence_uploaded',
        event_data: {
          file_type: isVideo ? 'video' : 'photo',
          file_url,
          description
        }
      });
      
      return file_url;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['incident'] });
      setDescription('');
      setUploading(false);
      alert('Evidence uploaded successfully');
    },
    onError: () => {
      setUploading(false);
      alert('Upload failed');
    }
  });

  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) { // 50MB limit
        alert('File too large. Maximum 50MB');
        return;
      }
      uploadEvidence.mutate(file);
    }
  };

  const currentIncident = incident?.[0];
  const photos = currentIncident?.evidence_photos || [];
  const videos = currentIncident?.evidence_videos || [];

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Camera className="w-5 h-5" style={{ color: '#FF771D' }} />
          Evidence Upload
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Add description (optional)..."
            className="bg-gray-900 text-white border-gray-600 mb-2"
          />
        </div>

        <div className="grid grid-cols-2 gap-2">
          <label className="cursor-pointer">
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleFileSelect}
              className="hidden"
              disabled={uploading}
            />
            <Button
              variant="outline"
              className="w-full border-gray-600 text-white"
              disabled={uploading}
              asChild
            >
              <span>
                <Camera className="w-4 h-4 mr-2" />
                Take Photo
              </span>
            </Button>
          </label>

          <label className="cursor-pointer">
            <input
              type="file"
              accept="video/*"
              capture="environment"
              onChange={handleFileSelect}
              className="hidden"
              disabled={uploading}
            />
            <Button
              variant="outline"
              className="w-full border-gray-600 text-white"
              disabled={uploading}
              asChild
            >
              <span>
                <Video className="w-4 h-4 mr-2" />
                Record Video
              </span>
            </Button>
          </label>
        </div>

        {uploading && (
          <p className="text-sm text-center" style={{ color: '#FF771D' }}>
            Uploading evidence...
          </p>
        )}

        {/* Evidence Gallery */}
        {(photos.length > 0 || videos.length > 0) && (
          <div className="mt-4">
            <p className="text-sm text-gray-400 mb-2">Uploaded Evidence ({photos.length + videos.length})</p>
            <div className="grid grid-cols-3 gap-2">
              {photos.map((url, idx) => (
                <div key={idx} className="relative aspect-square">
                  <img
                    src={url}
                    alt={`Evidence ${idx + 1}`}
                    className="w-full h-full object-cover rounded border border-gray-700"
                  />
                  <Image className="absolute top-1 right-1 w-4 h-4 text-white bg-black/50 rounded p-0.5" />
                </div>
              ))}
              {videos.map((url, idx) => (
                <div key={idx} className="relative aspect-square bg-gray-900 rounded border border-gray-700 flex items-center justify-center">
                  <Video className="w-8 h-8 text-gray-600" />
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}