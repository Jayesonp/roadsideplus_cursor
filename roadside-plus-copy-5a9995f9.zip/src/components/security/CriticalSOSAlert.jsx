import React, { useEffect, useState, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { AlertTriangle, MapPin, Phone, Navigation, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import { createPageUrl } from '@/utils';

export default function CriticalSOSAlert({ userId, userRole }) {
  const [activeAlert, setActiveAlert] = useState(null);
  const [isDismissed, setIsDismissed] = useState(false);
  const audioRef = useRef(null);
  const volumeIntervalRef = useRef(null);

  // Fetch critical SOS incidents
  const { data: incidents = [] } = useQuery({
    queryKey: ['critical-sos', userId, userRole],
    queryFn: async () => {
      let filter = { 
        severity: 'critical',
        status: 'pending'
      };

      // Admin sees all
      // Partner sees their clients' SOS
      if (userRole === 'partner') {
        const partner = await base44.entities.Partner.filter({ user_id: userId });
        if (partner.length > 0) {
          // Get partner's clients (customers)
          const clients = await base44.entities.ServiceRequest.filter({ 
            partner_id: partner[0].id 
          });
          const clientIds = [...new Set(clients.map(c => c.customer_id))];
          if (clientIds.length > 0) {
            filter.customer_id = clientIds[0]; // Simplified - would need better filtering
          }
        }
      }

      const allIncidents = await base44.entities.SOSIncident.filter(
        filter,
        '-created_date',
        10
      );

      return allIncidents;
    },
    enabled: !!userId,
    refetchInterval: 30000,
    retry: 1,
    retryDelay: 8000,
    staleTime: 25000
  });

  useEffect(() => {
    if (incidents.length > 0 && !activeAlert && !isDismissed) {
      const incident = incidents[0];
      setActiveAlert(incident);
      startSiren();
    } else if (incidents.length === 0 && activeAlert) {
      stopSiren();
      setActiveAlert(null);
    }
  }, [incidents]);

  const startSiren = () => {
    if (!audioRef.current) {
      try {
        // Create oscillating siren sound
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClass) return;

        const audioContext = new AudioContextClass();
        const oscillator1 = audioContext.createOscillator();
        const oscillator2 = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator1.type = 'sine';
        oscillator2.type = 'sine';
        oscillator1.frequency.value = 600;
        oscillator2.frequency.value = 800;

        oscillator1.connect(gainNode);
        oscillator2.connect(gainNode);
        gainNode.connect(audioContext.destination);

        gainNode.gain.value = 0.3;

        oscillator1.start();
        oscillator2.start();

        audioRef.current = { audioContext, oscillator1, oscillator2, gainNode };

        // Gradually increase volume
        let volumeStep = 0;
        volumeIntervalRef.current = setInterval(() => {
          volumeStep++;
          if (audioRef.current && volumeStep <= 15) {
            audioRef.current.gainNode.gain.value = Math.min(0.3 + (volumeStep * 0.04), 0.9);
            
            // Oscillate frequency for siren effect
            const freq1 = 600 + Math.sin(volumeStep / 2) * 200;
            const freq2 = 800 + Math.cos(volumeStep / 2) * 200;
            audioRef.current.oscillator1.frequency.value = freq1;
            audioRef.current.oscillator2.frequency.value = freq2;
          }
        }, 200);
      } catch (e) {
        console.warn('AudioContext constructor failed (Despia Runtime):', e);
      }
    }
  };

  const stopSiren = () => {
    if (audioRef.current) {
      audioRef.current.oscillator1.stop();
      audioRef.current.oscillator2.stop();
      audioRef.current.audioContext.close();
      audioRef.current = null;
    }
    if (volumeIntervalRef.current) {
      clearInterval(volumeIntervalRef.current);
      volumeIntervalRef.current = null;
    }
  };

  const handleAcknowledge = async () => {
    if (activeAlert) {
      await base44.entities.SOSIncident.update(activeAlert.id, {
        status: 'assigned',
        company_id: activeAlert.company_id || 'default'
      });
      
      await base44.entities.SecurityEvent.create({
        incident_id: activeAlert.id,
        event_type: 'officer_accepted',
        event_data: { 
          acknowledged_by: userId,
          role: userRole
        }
      });

      stopSiren();
      setActiveAlert(null);
      
      // Redirect to incident detail
      window.location.href = createPageUrl(`SecurityIncidentDetail?id=${activeAlert.id}`);
    }
  };

  const handleDismiss = () => {
    stopSiren();
    setIsDismissed(true);
    setActiveAlert(null);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => stopSiren();
  }, []);

  if (!activeAlert) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center"
        style={{
          paddingTop: 'env(safe-area-inset-top)',
          paddingLeft: 'env(safe-area-inset-left)',
          paddingRight: 'env(safe-area-inset-right)',
          paddingBottom: 'env(safe-area-inset-bottom)',
          pointerEvents: 'all'
        }}
      >
        {/* Animated Red Background */}
        <motion.div
          animate={{
            backgroundColor: ['rgba(229, 44, 45, 0.95)', 'rgba(180, 0, 0, 0.98)', 'rgba(229, 44, 45, 0.95)']
          }}
          transition={{
            repeat: Infinity,
            duration: 1.5
          }}
          className="absolute inset-0"
        />

        {/* Content */}
        <motion.div
          animate={{
            scale: [1, 1.02, 1],
            rotate: [0, -1, 1, 0]
          }}
          transition={{
            repeat: Infinity,
            duration: 0.8
          }}
          className="relative bg-white rounded-3xl overflow-hidden max-w-lg w-full mx-4 shadow-2xl"
        >
          {/* Cannot dismiss easily - small X */}
          <Button
            variant="ghost"
            size="icon"
            onClick={handleDismiss}
            className="absolute top-2 right-2 z-10 text-gray-400 hover:text-gray-600"
          >
            <X className="w-4 h-4" />
          </Button>

          {/* Pulsing Alert Icon */}
          <div className="bg-red-600 p-8 flex flex-col items-center">
            <motion.div
              animate={{
                scale: [1, 1.3, 1],
                rotate: [0, 10, -10, 0]
              }}
              transition={{
                repeat: Infinity,
                duration: 1
              }}
              className="w-32 h-32 rounded-full bg-white flex items-center justify-center mb-4"
            >
              <AlertTriangle className="w-20 h-20 text-red-600" />
            </motion.div>
            
            <motion.h1
              animate={{
                scale: [1, 1.1, 1]
              }}
              transition={{
                repeat: Infinity,
                duration: 0.5
              }}
              className="text-4xl font-black text-white mb-2"
            >
              EMERGENCY SOS
            </motion.h1>
            <p className="text-white text-lg font-semibold">IMMEDIATE RESPONSE REQUIRED</p>
          </div>

          {/* Incident Details */}
          <div className="p-6 space-y-4">
            <div className="bg-red-50 rounded-xl p-4 border-2 border-red-200">
              <div className="flex items-start gap-3 mb-3">
                <MapPin className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <p className="font-bold text-red-900 mb-1">Location</p>
                  <p className="text-sm text-red-800">
                    {activeAlert.location_address || `${activeAlert.location_lat?.toFixed(4)}, ${activeAlert.location_lng?.toFixed(4)}`}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-sm text-red-700">
                <Phone className="w-5 h-5" />
                <span className="font-semibold">
                  Triggered {formatDistanceToNow(new Date(activeAlert.created_date), { addSuffix: true })}
                </span>
              </div>

              {activeAlert.customer_device_battery && (
                <p className="text-xs text-red-600 mt-2">
                  Device Battery: {activeAlert.customer_device_battery}%
                </p>
              )}
            </div>

            {activeAlert.description && (
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-sm text-gray-700">{activeAlert.description}</p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-3 pt-2">
              <Button
                onClick={handleAcknowledge}
                className="w-full text-white font-bold text-xl py-8 rounded-xl"
                style={{ backgroundColor: '#E52C2D' }}
              >
                <Navigation className="w-6 h-6 mr-3" />
                RESPOND NOW
              </Button>

              <p className="text-center text-xs text-gray-500">
                This alert will continue until acknowledged
              </p>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}