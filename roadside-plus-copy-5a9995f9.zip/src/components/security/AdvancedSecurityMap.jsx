import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { MapPin, Navigation, Activity, Route } from 'lucide-react';
import 'leaflet/dist/leaflet.css';

// Custom icons
const officerIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxNiIgY3k9IjE2IiByPSIxMiIgZmlsbD0iIzNENjkyQiIvPjxwYXRoIGQ9Ik0xNiA4QzEyLjcgOCAxMCAxMC43IDEwIDE0QzEwIDE4IDEzIDE5LjUgMTYgMjRDMTkgMTkuNSAyMiAxOCAyMiAxNEMyMiAxMC43IDE5LjMgOCAxNiA4WiIgZmlsbD0id2hpdGUiLz48L3N2Zz4=',
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32]
});

const sosIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxNiIgY3k9IjE2IiByPSIxMiIgZmlsbD0iI0U1MkMyRCIvPjxwYXRoIGQ9Ik0xNiA4QzEyLjcgOCAxMCAxMC43IDEwIDE0QzEwIDE4IDEzIDE5LjUgMTYgMjRDMTkgMTkuNSAyMiAxOCAyMiAxNEMyMiAxMC43IDE5LjMgOCAxNiA4WiIgZmlsbD0id2hpdGUiLz48L3N2Zz4=',
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32]
});



export default function AdvancedSecurityMap({ incidents, officers, companyId, height = '600px' }) {
  const [showTrails, setShowTrails] = useState(false);
  const [showGeofences, setShowGeofences] = useState(true);
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [selectedOfficer, setSelectedOfficer] = useState(null);

  const { data: geofences = [] } = useQuery({
    queryKey: ['geofences', companyId],
    queryFn: () => base44.entities.Geofence.filter({ company_id: companyId }),
    enabled: !!companyId
  });

  const { data: gpsTrails = [] } = useQuery({
    queryKey: ['gps-trails', selectedOfficer],
    queryFn: () => base44.entities.GPSTrail.filter(
      { entity_id: selectedOfficer, entity_type: 'officer' },
      '-created_date',
      100
    ),
    enabled: !!selectedOfficer && showTrails,
    refetchInterval: 5000
  });

  const checkGeofenceViolations = (lat, lng, officerId) => {
    geofences.forEach(fence => {
      if (!fence.is_active) return;
      
      const distance = calculateDistance(lat, lng, fence.center_lat, fence.center_lng);
      const isInside = distance <= fence.radius_meters;

      // Check for violations
      if (fence.alert_on_entry && isInside) {
        base44.entities.SecurityEvent.create({
          company_id: companyId,
          officer_id: officerId,
          event_type: 'location_updated',
          event_data: { 
            alert: 'Geofence entered',
            zone: fence.name,
            zone_type: fence.zone_type
          },
          location_lat: lat,
          location_lng: lng
        });
      }
    });
  };

  const calculateDistance = (lat1, lng1, lat2, lng2) => {
    const R = 6371e3; // Earth radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lng2 - lng1) * Math.PI / 180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c;
  };

  const getGeofenceColor = (type) => {
    switch (type) {
      case 'critical': return '#E52C2D';
      case 'restricted': return '#FF771D';
      case 'safe': return '#3D692B';
      case 'patrol': return '#3B82F6';
      default: return '#666';
    }
  };

  const allLocations = [
    ...incidents.filter(i => i.location_lat && i.location_lng).map(i => [i.location_lat, i.location_lng]),
    ...officers.filter(o => o.current_lat && o.current_lng).map(o => [o.current_lat, o.current_lng])
  ];

  const center = allLocations.length > 0
    ? [
        allLocations.reduce((sum, loc) => sum + loc[0], 0) / allLocations.length,
        allLocations.reduce((sum, loc) => sum + loc[1], 0) / allLocations.length
      ]
    : [37.7749, -122.4194];

  const incidentHeatmapData = incidents
    .filter(i => i.location_lat && i.location_lng)
    .map(i => [i.location_lat, i.location_lng]);

  const trailCoordinates = gpsTrails.map(t => [t.latitude, t.longitude]);

  return (
    <div className="space-y-4">
      {/* Controls */}
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-6">
            <div className="flex items-center gap-2">
              <Switch
                id="trails"
                checked={showTrails}
                onCheckedChange={setShowTrails}
              />
              <Label htmlFor="trails" className="text-white flex items-center gap-1">
                <Navigation className="w-4 h-4" />
                GPS Trails
              </Label>
            </div>

            <div className="flex items-center gap-2">
              <Switch
                id="geofences"
                checked={showGeofences}
                onCheckedChange={setShowGeofences}
              />
              <Label htmlFor="geofences" className="text-white flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                Geofences
              </Label>
            </div>

            <div className="flex items-center gap-2">
              <Switch
                id="heatmap"
                checked={showHeatmap}
                onCheckedChange={setShowHeatmap}
              />
              <Label htmlFor="heatmap" className="text-white flex items-center gap-1">
                <Activity className="w-4 h-4" />
                Incident Heatmap
              </Label>
            </div>

            <Button
              variant="outline"
              size="sm"
              className="text-white border-gray-600"
              onClick={() => window.location.href = '/SecurityRouteOptimizer'}
            >
              <Route className="w-4 h-4 mr-2" />
              Route Optimizer
            </Button>
          </div>

          {showTrails && (
            <div className="mt-4">
              <Label className="text-white mb-2 block">Select Officer for Trail</Label>
              <select
                className="bg-gray-900 text-white border-gray-600 rounded px-3 py-2"
                value={selectedOfficer || ''}
                onChange={(e) => setSelectedOfficer(e.target.value)}
              >
                <option value="">None</option>
                {officers.map(o => (
                  <option key={o.id} value={o.id}>Badge #{o.officer_badge_number}</option>
                ))}
              </select>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Map */}
      <div className="rounded-lg overflow-hidden border border-gray-700">
        <MapContainer
          center={center}
          zoom={12}
          style={{ height, width: '100%' }}
        >
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

          {/* Heatmap - Simple circle overlay implementation */}
          {showHeatmap && incidents.map((incident, idx) => (
            incident.location_lat && incident.location_lng && (
              <Circle
                key={`heat-${idx}`}
                center={[incident.location_lat, incident.location_lng]}
                radius={500}
                pathOptions={{
                  color: incident.severity === 'critical' ? '#E52C2D' : '#FF771D',
                  fillColor: incident.severity === 'critical' ? '#E52C2D' : '#FF771D',
                  fillOpacity: 0.3,
                  weight: 0
                }}
              />
            )
          ))}

          {/* Geofences */}
          {showGeofences && geofences.map(fence => (
            <Circle
              key={fence.id}
              center={[fence.center_lat, fence.center_lng]}
              radius={fence.radius_meters}
              pathOptions={{
                color: getGeofenceColor(fence.zone_type),
                fillColor: getGeofenceColor(fence.zone_type),
                fillOpacity: 0.15,
                weight: 2,
                dashArray: '5, 10'
              }}
            >
              <Popup>
                <div className="text-sm">
                  <p className="font-bold">{fence.name}</p>
                  <Badge style={{ backgroundColor: getGeofenceColor(fence.zone_type) }}>
                    {fence.zone_type}
                  </Badge>
                </div>
              </Popup>
            </Circle>
          ))}

          {/* GPS Trail */}
          {showTrails && trailCoordinates.length > 0 && (
            <Polyline
              positions={trailCoordinates}
              pathOptions={{ color: '#3D692B', weight: 3, opacity: 0.7 }}
            />
          )}

          {/* SOS Incidents */}
          {incidents.map(incident => (
            incident.location_lat && incident.location_lng && (
              <React.Fragment key={incident.id}>
                <Marker
                  position={[incident.location_lat, incident.location_lng]}
                  icon={sosIcon}
                >
                  <Popup>
                    <div className="text-sm">
                      <p className="font-bold text-red-600">SOS ALERT</p>
                      <p>Severity: {incident.severity}</p>
                      <p>Status: {incident.status}</p>
                    </div>
                  </Popup>
                </Marker>
                <Circle
                  center={[incident.location_lat, incident.location_lng]}
                  radius={100}
                  pathOptions={{ color: '#E52C2D', fillColor: '#E52C2D', fillOpacity: 0.2 }}
                />
              </React.Fragment>
            )
          ))}

          {/* Officers */}
          {officers.map(officer => (
            officer.current_lat && officer.current_lng && (
              <Marker
                key={officer.id}
                position={[officer.current_lat, officer.current_lng]}
                icon={officerIcon}
                eventHandlers={{
                  click: () => setSelectedOfficer(officer.id)
                }}
              >
                <Popup>
                  <div className="text-sm">
                    <p className="font-bold" style={{ color: '#3D692B' }}>Officer</p>
                    <p>Badge: {officer.officer_badge_number}</p>
                    <p>Status: {officer.status}</p>
                  </div>
                </Popup>
              </Marker>
            )
          ))}
        </MapContainer>
      </div>

      {/* Active Geofences Legend */}
      {showGeofences && geofences.length > 0 && (
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white text-sm">Active Geofences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {geofences.filter(f => f.is_active).map(fence => (
                <div key={fence.id} className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: getGeofenceColor(fence.zone_type) }}
                  />
                  <span className="text-sm text-gray-300">{fence.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}