import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Custom icons
const officerIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxNiIgY3k9IjE2IiByPSIxMiIgZmlsbD0iIzNENjkyQiIvPjxwYXRoIGQ9Ik0xNiA4QzEyLjcgOCAxMCAxMC43IDEwIDE0QzEwIDE4IDEzIDE5LjUgMTYgMjRDMTkgMTkuNSAyMiAxOCAyMiAxNEMyMiAxMC43IDE5LjMgOCAxNiA4WiIgZmlsbD0id2hpdGUiLz48L3N2Zz4=',
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32]
});

const sosIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxNiIgY3k9IjE2IiByPSIxMiIgZmlsbD0iI0U1MkMyRCIvPjxwYXRoIGQ9Ik0xNiA4QzEyLjcgOCAxMCAxMC43IDEwIDE0QzEwIDE4IDEzIDE5LjUgMTYgMjRDMTkgMTkuNSAyMiAxOCAyMiAxNEMyMiAxMC43IDE5LjMgOCAxNiA4WiIgZmlsbD0id2hpdGUiLz48L3N2Zz4=',
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32]
});

export default function SecurityLiveMap({ incidents, officers, height = '400px' }) {
  const allLocations = [
    ...incidents.filter(i => i.location_lat && i.location_lng).map(i => [i.location_lat, i.location_lng]),
    ...officers.filter(o => o.current_lat && o.current_lng).map(o => [o.current_lat, o.current_lng])
  ];

  const center = allLocations.length > 0
    ? [
        allLocations.reduce((sum, loc) => sum + loc[0], 0) / allLocations.length,
        allLocations.reduce((sum, loc) => sum + loc[1], 0) / allLocations.length
      ]
    : [37.7749, -122.4194];

  return (
    <MapContainer
      center={center}
      zoom={12}
      style={{ height, width: '100%' }}
    >
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

      {/* SOS Incidents */}
      {incidents.map(incident => (
        incident.location_lat && incident.location_lng && (
          <React.Fragment key={incident.id}>
            <Marker
              position={[incident.location_lat, incident.location_lng]}
              icon={sosIcon}
            >
              <Popup>
                <div className="text-sm">
                  <p className="font-bold text-red-600">SOS ALERT</p>
                  <p>Severity: {incident.severity}</p>
                  <p>Status: {incident.status}</p>
                </div>
              </Popup>
            </Marker>
            <Circle
              center={[incident.location_lat, incident.location_lng]}
              radius={100}
              pathOptions={{ color: '#E52C2D', fillColor: '#E52C2D', fillOpacity: 0.2 }}
            />
          </React.Fragment>
        )
      ))}

      {/* Officers */}
      {officers.map(officer => (
        officer.current_lat && officer.current_lng && (
          <Marker
            key={officer.id}
            position={[officer.current_lat, officer.current_lng]}
            icon={officerIcon}
          >
            <Popup>
              <div className="text-sm">
                <p className="font-bold" style={{ color: '#3D692B' }}>Officer</p>
                <p>Badge: {officer.officer_badge_number}</p>
                <p>Status: {officer.status}</p>
              </div>
            </Popup>
          </Marker>
        )
      ))}
    </MapContainer>
  );
}