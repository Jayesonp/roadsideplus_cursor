# Performance Optimization Guide

## Critical Performance Standards

**All pages must meet these requirements:**
- Initial paint: <1 second
- Time to interactive: <3 seconds  
- Full data load: <8 seconds max
- Never show infinite loading spinners

## Frontend Optimization Checklist

### 1. Query Timeouts
✅ **Use `useQueryWithTimeout` for ALL data fetching**
```jsx
import { useQueryWithTimeout } from '../components/common/useQueryWithTimeout';

const { data, isLoading } = useQueryWithTimeout({
  queryKey: ['key'],
  queryFn: async () => { /* fetch data */ },
  enabled: !!dependency,
  staleTime: 60000,
  retry: 1
}, 8000); // 8 second timeout
```

### 2. Progressive Loading
✅ **Show skeleton UI with granular sections**
```jsx
if (loading) {
  return (
    <div className="space-y-6">
      {/* Header Skeleton */}
      <div className="h-10 bg-gray-200 rounded animate-pulse"></div>
      
      {/* Content Sections */}
      <Card>
        <CardHeader>
          <div className="h-6 w-32 bg-gray-200 rounded animate-pulse"></div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="h-10 bg-gray-100 rounded animate-pulse"></div>
          <div className="h-10 bg-gray-100 rounded animate-pulse"></div>
        </CardContent>
      </Card>
    </div>
  );
}
```

### 3. Component Memoization
✅ **Use React.memo for pure components**
```jsx
// Create memoized wrapper
export default React.memo(MyComponent, (prevProps, nextProps) => {
  return prevProps.key === nextProps.key;
});
```

### 4. Lazy Loading
✅ **Defer non-critical components**
```jsx
const HeavyComponent = lazy(() => import('../components/HeavyComponent'));

<Suspense fallback={<Skeleton />}>
  {showHeavy && <HeavyComponent />}
</Suspense>
```

### 5. Async Operations
✅ **Don't block navigation with background tasks**
```jsx
// ❌ Bad - blocks navigation
await backgroundTask();
navigate();

// ✅ Good - non-blocking
navigate();
backgroundTask().catch(console.error);
```

### 6. State Management
✅ **Prevent cascading re-renders**
```jsx
// Use useCallback for stable function references
const handleChange = useCallback((value) => {
  setState(value);
}, [dependency]);

// Use useMemo for expensive calculations
const computed = useMemo(() => {
  return expensiveOperation(data);
}, [data]);
```

### 7. Query Configuration
✅ **Optimize React Query settings**
```jsx
{
  staleTime: 60000,        // Cache for 1 minute
  retry: 1,                // Only retry once
  retryDelay: 3000,        // Wait 3s before retry
  refetchOnWindowFocus: false,
  refetchOnMount: false
}
```

## Backend Optimization Guidelines

### Database Queries
- Add indexes on frequently queried columns
- Filter at database level, not in application
- Limit result sets appropriately
- Use batch operations when possible

### API Responses
- Only return required fields
- Implement pagination for large datasets
- Set response size limits
- Use compression

### Timeouts
- Set 8 second maximum timeout on all API calls
- Implement graceful degradation on timeout
- Return partial data if possible

## Common Performance Issues

### Issue: Infinite Loading Spinner
**Cause:** No timeout on data fetching
**Fix:** Use `useQueryWithTimeout` with 8s timeout

### Issue: Slow Initial Render
**Cause:** Fetching all data before showing UI
**Fix:** Show skeleton UI immediately, load data progressively

### Issue: Excessive Re-renders
**Cause:** Unstable function references, unnecessary state updates
**Fix:** Use useCallback, useMemo, React.memo

### Issue: Heavy Components Block UI
**Cause:** Large components loaded synchronously
**Fix:** Use lazy loading with Suspense

### Issue: Navigation Blocked
**Cause:** Waiting for background operations
**Fix:** Navigate first, run background tasks async

## Testing Checklist

Before marking performance optimization complete:

- [ ] Page loads within 3 seconds on slow 3G
- [ ] Skeleton UI appears within 1 second
- [ ] No infinite loading spinners
- [ ] Form is interactive even if data is still loading
- [ ] Navigation is never blocked
- [ ] Console shows no excessive re-renders
- [ ] All queries have timeouts
- [ ] Heavy components are lazy loaded

## Quick Reference

**When you see performance issues:**
1. Add `useQueryWithTimeout` to all queries
2. Replace generic loading with granular skeleton UI
3. Memoize pure components with React.memo
4. Move background tasks after navigation
5. Add lazy loading for heavy components
6. Test on slow network conditions

**Remember:** User experience > complete data load. Show something immediately, load the rest in background.