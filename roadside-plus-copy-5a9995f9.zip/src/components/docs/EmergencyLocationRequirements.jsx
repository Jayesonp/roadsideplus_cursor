# Emergency Location Requirements - DO NOT MODIFY

## ⚠️ CRITICAL EMERGENCY FEATURE - LOCKED CONFIGURATION

This document outlines location tracking requirements for emergency roadside assistance. These settings are **LOCKED** and must **NOT** be changed by AI or developers without explicit approval.

---

## Location Accuracy Preferences

### Overview
The location accuracy system provides three modes for technicians to balance accuracy and battery usage. This is critical for emergency response where immediate, accurate location detection is essential.

### Locked Features

#### 1. High Accuracy Mode (Default & Recommended)
- **Uses**: GPS + Wi-Fi + Cellular networks
- **Purpose**: Emergency response requires the most precise location
- **Benefits**:
  - Most accurate positioning
  - Fastest location fix
  - Best for emergency scenarios
  - Works well indoors and outdoors
- **Trade-off**: Higher battery consumption (acceptable for emergency services)

#### 2. Battery Saving Mode
- **Uses**: Wi-Fi + Cellular networks (no GPS)
- **Purpose**: Extended shifts with lower battery drain
- **Benefits**:
  - Reduced battery usage
  - Good accuracy in urban areas
- **Trade-off**: Less accurate in rural/remote areas

#### 3. Device Only Mode
- **Uses**: GPS only
- **Purpose**: Areas without network coverage
- **Benefits**:
  - Works without internet
  - Good for outdoor locations
- **Trade-off**: Slower initial fix, poor indoor performance

---

## Implementation Details - DO NOT CHANGE

### TechnicianProfile Entity
```json
{
  "location_accuracy_preference": {
    "type": "string",
    "enum": ["high_accuracy", "battery_saving", "device_only"],
    "default": "high_accuracy"
  }
}
```

### BackgroundLocationTracker Component
- Reads user preference from TechnicianProfile
- Applies appropriate geolocation options:
  - **high_accuracy**: `enableHighAccuracy: true, maximumAge: 30000, timeout: 27000`
  - **battery_saving**: `enableHighAccuracy: false, maximumAge: 60000, timeout: 20000`
  - **device_only**: `enableHighAccuracy: true, maximumAge: 45000, timeout: 30000`

### Settings Page
- Provides UI for technicians to select preference
- Shows clear explanations of each mode
- Recommends High Accuracy for emergency services

---

## Why This is Locked

1. **Emergency Response**: Lives depend on accurate, fast location detection
2. **Customer Safety**: Customers in distress need immediate assistance
3. **Technician Efficiency**: Quick location fixes reduce response time
4. **Legal/Liability**: Accurate tracking protects both customers and technicians
5. **Service Quality**: Core differentiator for emergency roadside assistance

---

## Modification Policy

**DO NOT**:
- Remove or disable location accuracy options
- Change default to anything other than "high_accuracy"
- Simplify the system to remove user choice
- Add delays or throttling to location updates
- Modify geolocation timeout values without testing

**ONLY MODIFY IF**:
- Explicit customer approval with written justification
- Testing shows critical battery issues affecting service
- New emergency regulations require changes
- New browser APIs provide better emergency location capabilities

---

## Files Affected - Protected

- `entities/TechnicianProfile.json` - Contains location_accuracy_preference field
- `components/location/BackgroundLocationTracker.jsx` - Implements accuracy modes
- `pages/Settings.jsx` - Provides user interface for preferences

---

## Last Updated
2025-11-23

## Status
🔒 **LOCKED** - Emergency Critical Feature