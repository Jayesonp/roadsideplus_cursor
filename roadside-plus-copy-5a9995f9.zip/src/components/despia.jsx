/**
 * Despia Native SDK Wrapper
 * This provides the despia() function for native feature calls
 */

// The despia function is injected globally by the Despia Native Runtime
// This wrapper ensures it's available for import throughout the app
const despiaWrapper = (command) => {
  if (typeof window !== 'undefined' && window.despia) {
    return window.despia(command);
  }
  // Fallback for "It's despia() not window.despia" - check global scope
  // Note: In a browser, global vars are on window, but this covers edge cases/mocks
  try {
    // eslint-disable-next-line no-undef
    if (typeof despia === 'function') {
      // eslint-disable-next-line no-undef
      return despia(command);
    }
  } catch (e) {
    // Ignore reference errors
  }
  
  console.warn('Despia runtime not available. Command not executed:', command);
};

export default despiaWrapper;