// Centralized Mapbox configuration for the entire application
// Prioritize environment variable, fallback to hardcoded token if provided
const HARDCODED_TOKEN = 'pk.eyJ1IjoiY2lyczEyMzQ1Njc4IiwiYSI6ImNtaWU1bm94eDA5a24ybG9sa2RnZ3czMm0ifQ.PlQL3yV2AqLaitzQwU3IHw';
const rawToken = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN || (typeof process !== 'undefined' && process.env && process.env.VITE_MAPBOX_ACCESS_TOKEN) || HARDCODED_TOKEN;
export const MAPBOX_TOKEN = (typeof rawToken === 'string' && rawToken !== 'undefined') ? rawToken : '';

// Validation - ensure token starts with pk. for public tokens
if (MAPBOX_TOKEN && typeof MAPBOX_TOKEN === 'string' && !MAPBOX_TOKEN.startsWith('pk.')) {
  console.warn('⚠️ Invalid Mapbox token format. Public tokens must start with "pk."');
}

// Log warning if token is missing
if (!MAPBOX_TOKEN) {
  console.warn('⚠️ VITE_MAPBOX_ACCESS_TOKEN not found. Maps will use fallback tiles.');
}

// Mapbox tile URL with the configured token - Falls back to OSM if no token
export const MAPBOX_TILE_URL = (token) => {
  if (!token && !MAPBOX_TOKEN) {
    return 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
  }
  return `https://api.mapbox.com/styles/v1/mapbox/streets-v12/tiles/{z}/{x}/{y}@2x?access_token=${token || MAPBOX_TOKEN}`;
};

// Mapbox tile configuration for Leaflet
export const MAPBOX_TILE_CONFIG = {
  attribution: MAPBOX_TOKEN ? '© Mapbox © OpenStreetMap Contributors' : '© OpenStreetMap Contributors',
  tileSize: MAPBOX_TOKEN ? 512 : 256,
  zoomOffset: MAPBOX_TOKEN ? -1 : 0
};

// Mapbox Directions API helper
export const getMapboxRoute = async (start, end) => {
  if (!MAPBOX_TOKEN) {
    console.error('Mapbox token not configured');
    return null;
  }

  try {
    const url = `https://api.mapbox.com/directions/v5/mapbox/driving/${start[1]},${start[0]};${end[1]},${end[0]}?geometries=geojson&access_token=${MAPBOX_TOKEN}`;
    const response = await fetch(url);
    const data = await response.json();

    if (data.routes && data.routes.length > 0) {
      const route = data.routes[0];
      return {
        coordinates: route.geometry.coordinates.map(coord => [coord[1], coord[0]]), // Convert to [lat, lng]
        duration: route.duration, // in seconds
        distance: route.distance, // in meters
        durationMinutes: Math.ceil(route.duration / 60),
        distanceMiles: (route.distance / 1609.34).toFixed(1)
      };
    }
    return null;
  } catch (error) {
    console.error('Error fetching Mapbox route:', error);
    return null;
  }
};

// Mapbox Geocoding API helper
export const geocodeAddress = async (address) => {
  if (!MAPBOX_TOKEN) {
    console.error('Mapbox token not configured');
    return null;
  }

  try {
    const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(address)}.json?access_token=${MAPBOX_TOKEN}`;
    const response = await fetch(url);
    const data = await response.json();

    if (data.features && data.features.length > 0) {
      const [lng, lat] = data.features[0].center;
      return {
        lat,
        lng,
        placeName: data.features[0].place_name
      };
    }
    return null;
  } catch (error) {
    console.error('Error geocoding address:', error);
    return null;
  }
};

// Reverse geocoding - get address from coordinates
export const reverseGeocode = async (lat, lng) => {
  if (!MAPBOX_TOKEN) {
    console.error('Mapbox token not configured');
    return null;
  }

  try {
    const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${lng},${lat}.json?access_token=${MAPBOX_TOKEN}`;
    const response = await fetch(url);
    const data = await response.json();

    if (data.features && data.features.length > 0) {
      return data.features[0].place_name;
    }
    return null;
  } catch (error) {
    console.error('Error reverse geocoding:', error);
    return null;
  }
};