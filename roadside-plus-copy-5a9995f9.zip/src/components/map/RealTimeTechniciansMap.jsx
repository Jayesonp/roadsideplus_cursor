import React, { useState, useEffect, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Navigation, Clock, RefreshCw } from 'lucide-react';
import TechniciansMap from './TechniciansMap';
import { Button } from '@/components/ui/button';

// Calculate distance between two coordinates (Haversine formula)
const calculateDistance = (lat1, lng1, lat2, lng2) => {
  const R = 3959; // Earth radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

// Calculate ETA (distance / avg speed + response time)
const calculateETA = (distanceMiles) => {
  const avgSpeed = 35; // mph average in mixed traffic
  const responseTime = 3; // minutes to prepare and start
  const travelMinutes = (distanceMiles / avgSpeed) * 60;
  return Math.round(travelMinutes + responseTime);
};

const RealTimeTechniciansMap = React.memo(function RealTimeTechniciansMap({ 
  customerLocation = null, 
  showCustomer = false,
  serviceType = null,
  highlightClosest = true 
}) {
  const [lastUpdate, setLastUpdate] = useState(Date.now());

  // Query with aggressive real-time updates
  const { data: availableTechs = [], isLoading, refetch } = useQuery({
    queryKey: ['realtime-technicians', customerLocation],
    queryFn: async () => {
      const profiles = await base44.entities.TechnicianProfile.filter(
        { availability_status: 'available' },
        '-rating',
        50
      );
      
      const validProfiles = profiles.filter(p => 
        p.current_lat && p.current_lng && 
        !isNaN(p.current_lat) && !isNaN(p.current_lng)
      );
      
      // If customer location provided, calculate distances and sort by proximity
      if (customerLocation && customerLocation.length === 2 && 
          !isNaN(customerLocation[0]) && !isNaN(customerLocation[1])) {
        const [custLat, custLng] = customerLocation;
        return validProfiles.map(tech => ({
          ...tech,
          distance: calculateDistance(custLat, custLng, tech.current_lat, tech.current_lng),
          eta: calculateETA(calculateDistance(custLat, custLng, tech.current_lat, tech.current_lng))
        })).sort((a, b) => a.distance - b.distance);
      }
      
      return validProfiles;
    },
    refetchInterval: 30000, // Update every 30 seconds
    retry: 1,
    staleTime: 25000
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdate(Date.now());
    }, 30000);
    
    return () => clearInterval(interval);
  }, []);

  // Get closest technicians (top 5)
  const closestTechs = useMemo(() => {
    if (!customerLocation || availableTechs.length === 0) return [];
    return availableTechs.slice(0, 5);
  }, [availableTechs, customerLocation]);

  const handleManualRefresh = () => {
    refetch();
    setLastUpdate(Date.now());
  };

  const getUpdateStatus = () => {
    const seconds = Math.floor((Date.now() - lastUpdate) / 1000);
    if (seconds < 5) return 'Just now';
    if (seconds < 60) return `${seconds}s ago`;
    return `${Math.floor(seconds / 60)}m ago`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-2" style={{ color: '#FF771D' }} />
          <p className="text-gray-600">Loading live technician locations...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Main Map Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Navigation className="w-5 h-5" style={{ color: '#FF771D' }} />
              Live Technician Locations
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge className="bg-green-100 text-green-800 border-green-300 flex items-center gap-1">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-1"></div>
                {availableTechs.length} Available
              </Badge>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={handleManualRefresh}
                className="h-7 text-xs"
              >
                <RefreshCw className="w-3 h-3 mr-1" />
                {getUpdateStatus()}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {availableTechs.length === 0 ? (
            <div className="text-center py-8">
              <MapPin className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-gray-600">No technicians available right now</p>
              <p className="text-sm text-gray-500 mt-1">Please check back shortly</p>
            </div>
          ) : (
            <TechniciansMap 
              technicians={availableTechs}
              customerLocation={customerLocation}
              showCustomer={showCustomer}
              height="450px"
              zoom={customerLocation ? 13 : 12}
            />
          )}
        </CardContent>
      </Card>

      {/* Closest Technicians List with ETA */}
      {customerLocation && closestTechs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Clock className="w-5 h-5" style={{ color: '#3D692B' }} />
              Closest Technicians
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {closestTechs.map((tech, index) => (
                <div 
                  key={tech.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-gray-50 border border-gray-200 hover:border-orange-300 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold"
                      style={{ backgroundColor: index === 0 ? '#3D692B' : '#FF771D' }}
                    >
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-semibold text-sm">
                        {tech.distance ? `${tech.distance.toFixed(1)} mi away` : 'Nearby'}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-gray-600">
                        <span>Rating: {tech.rating?.toFixed(1) || '5.0'} ⭐</span>
                        <span>•</span>
                        <span>{tech.total_jobs || 0} jobs</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge 
                      className="text-white"
                      style={{ backgroundColor: tech.eta <= 15 ? '#3D692B' : '#FF771D' }}
                    >
                      <Clock className="w-3 h-3 mr-1" />
                      ETA: {tech.eta} min
                    </Badge>
                    {index === 0 && (
                      <p className="text-xs text-green-700 font-semibold mt-1">Fastest</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-3 text-center">
              💡 ETAs update every 30 seconds based on live locations
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
});

export default RealTimeTechniciansMap;