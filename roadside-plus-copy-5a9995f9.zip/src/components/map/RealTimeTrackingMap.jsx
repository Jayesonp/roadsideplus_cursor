import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Navigation, Clock, Car, MapPin } from 'lucide-react';
import MapboxServiceMap from './MapboxServiceMap';
import { getMapboxRoute } from './mapboxConfig';

const RealTimeTrackingMap = React.memo(function RealTimeTrackingMap({ request, showActions = true }) {
  const [route, setRoute] = useState(null);
  const [eta, setEta] = useState(null);
  const [distance, setDistance] = useState(null);
  const [locationUpdated, setLocationUpdated] = useState(Date.now());

  // Fetch technician profile for real-time location
  const { data: techProfile } = useQuery({
    queryKey: ['tech-profile', request.technician_id],
    queryFn: async () => {
      if (!request.technician_id) return null;
      const profiles = await base44.entities.TechnicianProfile.filter({
        user_id: request.technician_id
      });
      return profiles[0];
    },
    enabled: !!request.technician_id,
    refetchInterval: 10000,
    retry: 1,
    retryDelay: 5000,
    staleTime: 3000,
    onSuccess: () => {
      setLocationUpdated(Date.now());
    }
  });

  const technicianLocation = techProfile?.current_lat && techProfile?.current_lng
    ? [techProfile.current_lat, techProfile.current_lng]
    : null;

  const customerLocation = [request.location_lat, request.location_lng];

  // Fetch route and ETA from Mapbox Directions API
  useEffect(() => {
    if (!technicianLocation || !customerLocation) return;

    const fetchRouteAndETA = async () => {
      try {
        const routeData = await getMapboxRoute(technicianLocation, customerLocation);
        
        if (routeData) {
          setRoute(routeData.coordinates);
          
          // Calculate ETA
          const arrivalTime = new Date(Date.now() + routeData.duration * 1000);
          setEta({
            minutes: routeData.durationMinutes,
            arrivalTime: arrivalTime
          });

          setDistance(routeData.distanceMiles);

          // Update estimated_arrival in the service request
          await base44.entities.ServiceRequest.update(request.id, {
            estimated_arrival: arrivalTime.toISOString()
          });
        }
      } catch (error) {
        console.error('Error fetching route:', error);
      }
    };

    fetchRouteAndETA();
    
    // Refresh route every 30 seconds
    const interval = setInterval(fetchRouteAndETA, 30000);
    return () => clearInterval(interval);
  }, [technicianLocation, customerLocation, request.id]);

  const openInGoogleMaps = () => {
    if (technicianLocation) {
      const url = `https://www.google.com/maps/dir/${technicianLocation[0]},${technicianLocation[1]}/${customerLocation[0]},${customerLocation[1]}`;
      window.open(url, '_blank');
    } else {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${customerLocation[0]},${customerLocation[1]}`;
      window.open(url, '_blank');
    }
  };

  const getStatusMessage = () => {
    switch (request.status) {
      case 'assigned':
        return { 
          title: 'Technician Assigned', 
          message: technicianLocation ? 'Preparing to depart' : 'Waiting for location updates',
          color: 'blue' 
        };
      case 'en_route':
        return { 
          title: 'Technician En Route', 
          message: 'Your technician is on the way',
          color: 'orange' 
        };
      case 'arrived':
        return { 
          title: 'Technician Arrived', 
          message: 'Your technician has arrived at your location',
          color: 'green' 
        };
      case 'in_progress':
        return { 
          title: 'Service In Progress', 
          message: 'Your vehicle is being serviced',
          color: 'purple' 
        };
      default:
        return null;
    }
  };

  const statusInfo = getStatusMessage();

  return (
    <Card className="border-2 border-orange-200 shadow-lg">
      <CardHeader className="bg-gradient-to-r from-orange-50 to-red-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-md">
              <MapPin className="w-5 h-5" style={{ color: '#E52C2D' }} />
            </div>
            <div>
              <CardTitle className="text-xl">Live Tracking</CardTitle>
              {statusInfo && (
                <div className="text-sm text-gray-600 mt-0.5">{statusInfo.message}</div>
              )}
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={openInGoogleMaps}
            className="flex items-center gap-2 border-orange-300 hover:bg-orange-50"
          >
            <Navigation className="w-4 h-4" />
            Navigate
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4 pt-6">
        {/* Status Banner */}
        {statusInfo && (
          <div className={`rounded-xl p-4 border-2 ${
            statusInfo.color === 'blue' ? 'bg-blue-50 border-blue-300' :
            statusInfo.color === 'orange' ? 'bg-orange-50 border-orange-300' :
            statusInfo.color === 'green' ? 'bg-green-50 border-green-300' :
            'bg-purple-50 border-purple-300'
          }`}>
            <div className={`text-lg font-bold mb-1 ${
              statusInfo.color === 'blue' ? 'text-blue-800' :
              statusInfo.color === 'orange' ? 'text-orange-800' :
              statusInfo.color === 'green' ? 'text-green-800' :
              'text-purple-800'
            }`}>
              {statusInfo.title}
            </div>
            <div className={`text-sm ${
              statusInfo.color === 'blue' ? 'text-blue-600' :
              statusInfo.color === 'orange' ? 'text-orange-600' :
              statusInfo.color === 'green' ? 'text-green-600' :
              'text-purple-600'
            }`}>
              {statusInfo.message}
            </div>
          </div>
        )}

        {/* ETA Counter - Prominent Display */}
        {eta && technicianLocation && request.status === 'en_route' && (
          <div className="bg-gradient-to-br from-orange-500 to-red-600 text-white rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="bg-white/20 backdrop-blur-sm p-3 rounded-full">
                  <Car className="w-8 h-8 text-white" />
                </div>
                <div>
                  <div className="text-sm opacity-90 font-medium mb-1">Arriving in</div>
                  <div className="text-5xl font-bold tracking-tight">
                    {eta.minutes}
                  </div>
                  <div className="text-lg font-semibold">minutes</div>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 text-white/90 mb-2">
                  <Clock className="w-5 h-5" />
                  <span className="text-xl font-semibold">
                    {eta.arrivalTime.toLocaleTimeString('en-US', { 
                      hour: 'numeric', 
                      minute: '2-digit' 
                    })}
                  </span>
                </div>
                {distance && (
                  <div className="text-white/80 text-sm font-medium">
                    {distance} miles away
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Map */}
        <div className="rounded-xl overflow-hidden border-2 border-gray-200">
          <MapboxServiceMap
            customerLocation={customerLocation}
            technicianLocation={technicianLocation}
            routeCoordinates={route}
            height="450px"
            showCustomer={true}
            showTechnician={!!technicianLocation}
            showRoute={!!route}
            zoom={13}
          />
        </div>

        {/* Real-time status indicator */}
        {technicianLocation && (
          <div className="flex items-center justify-center gap-2 text-sm bg-green-50 border border-green-200 rounded-lg py-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="font-medium text-green-700">
              Location updating every 5 seconds
            </span>
          </div>
        )}

        {/* Waiting for location */}
        {!technicianLocation && request.status === 'assigned' && (
          <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4 text-center">
            <div className="text-blue-700 font-bold text-lg mb-1">Technician Assigned</div>
            <div className="text-sm text-blue-600">Waiting for GPS location...</div>
          </div>
        )}
      </CardContent>
    </Card>
  );
});

export default RealTimeTrackingMap;