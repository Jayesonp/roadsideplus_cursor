import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import { divIcon } from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { MAPBOX_TOKEN, MAPBOX_TILE_URL, MAPBOX_TILE_CONFIG } from './mapboxConfig';
import { Button } from '@/components/ui/button';
import { AlertCircle, RefreshCw } from 'lucide-react';

// Map updater component
function MapUpdater({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.setView(center, zoom);
    }
  }, [center, zoom, map]);
  return null;
}

// Custom icons
const customerIcon = divIcon({
  html: `<div style="
    width: 32px;
    height: 32px;
    background: #E52C2D;
    border-radius: 50%;
    border: 3px solid white;
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
  "></div>`,
  className: '',
  iconSize: [32, 32],
  iconAnchor: [16, 16]
});

const technicianIcon = divIcon({
  html: `<div style="
    width: 36px;
    height: 36px;
    background: #FF771D;
    border-radius: 50%;
    border: 3px solid white;
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    display: flex;
    align-items: center;
    justify-content: center;
  ">
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="white">
      <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
    </svg>
  </div>`,
  className: '',
  iconSize: [36, 36],
  iconAnchor: [18, 18]
});

export default function MapboxServiceMap({
  customerLocation,
  technicianLocation,
  routeCoordinates,
  height = '400px',
  showCustomer = true,
  showTechnician = true,
  showRoute = false,
  zoom = 13
}) {
  const [mapError, setMapError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const center = technicianLocation || customerLocation || [40.7128, -74.0060];

  if (!MAPBOX_TOKEN || !MAPBOX_TOKEN.startsWith("pk.")) {
    console.warn("⚠️ Mapbox token missing or invalid. Map may not render.");
  }

  // Use OpenStreetMap as fallback if Mapbox token not available
  const useMapboxTiles = MAPBOX_TOKEN && 
                         MAPBOX_TOKEN !== 'undefined' && 
                         MAPBOX_TOKEN !== '' && 
                         MAPBOX_TOKEN.startsWith('pk.');
  
  const tileUrl = useMapboxTiles 
    ? `https://api.mapbox.com/styles/v1/mapbox/streets-v12/tiles/{z}/{x}/{y}?access_token=${MAPBOX_TOKEN}`
    : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
  
  const tileConfig = useMapboxTiles ? {
    attribution: MAPBOX_TILE_CONFIG.attribution,
    tileSize: MAPBOX_TILE_CONFIG.tileSize,
    zoomOffset: MAPBOX_TILE_CONFIG.zoomOffset
  } : {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    tileSize: 256,
    zoomOffset: 0
  };

  const handleRetry = () => {
    setMapError(false);
    setRetryCount(prev => prev + 1);
  };

  if (mapError) {
    return (
      <div style={{ height, width: '100%', borderRadius: '12px', overflow: 'hidden', background: '#fef3c7', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
        <div style={{ textAlign: 'center' }}>
          <AlertCircle className="w-12 h-12 mx-auto mb-3 text-orange-600" />
          <p className="font-semibold text-gray-800 mb-2">Map Temporarily Unavailable</p>
          <p className="text-sm text-gray-600 mb-3">Unable to load map tiles</p>
          <Button onClick={handleRetry} className="mb-3" variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Retry
          </Button>
          {customerLocation && (
            <div className="text-xs text-gray-600 mt-4 p-3 bg-white rounded border">
              <strong>Service Location:</strong><br/>
              Lat: {customerLocation[0].toFixed(6)}, Lng: {customerLocation[1].toFixed(6)}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div style={{ height: height || "500px", width: "100%", borderRadius: '12px', overflow: 'hidden' }}>
      <MapContainer
        key={retryCount}
        center={center}
        zoom={zoom}
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={false}
      >
        <TileLayer
          url={MAPBOX_TILE_URL(MAPBOX_TOKEN)}
          {...MAPBOX_TILE_CONFIG}
        />
        <MapUpdater center={center} zoom={zoom} />

        {/* Customer marker */}
        {showCustomer && customerLocation && (
          <Marker position={customerLocation} icon={customerIcon}>
            <Popup>
              <div style={{ textAlign: 'center', padding: '8px' }}>
                <strong>Customer Location</strong>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Technician marker */}
        {showTechnician && technicianLocation && (
          <Marker position={technicianLocation} icon={technicianIcon}>
            <Popup>
              <div style={{ textAlign: 'center', padding: '8px' }}>
                <strong>Technician</strong>
                <div style={{ fontSize: '12px', color: '#666' }}>Current location</div>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Route line */}
        {showRoute && routeCoordinates && routeCoordinates.length > 0 && (
          <Polyline
            positions={routeCoordinates}
            pathOptions={{
              color: '#FF771D',
              weight: 4,
              opacity: 0.8
            }}
          />
        )}
      </MapContainer>
    </div>
  );
}