import React, { useMemo, useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { Car, Star, Search, X, Navigation } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { base44 } from '@/api/base44Client';
import { MAPBOX_TOKEN, MAPBOX_TILE_CONFIG } from './mapboxConfig';
import { AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useMultipleTechnicianLocations } from './useRealTimeTechnicianLocation';

// Fix for default marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

let technicianIcon;
let customerIcon;

try {
  technicianIcon = new L.Icon({
    iconUrl: 'data:image/svg+xml;base64,' + btoa(`
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="#E52C2D">
        <circle cx="12" cy="12" r="10" fill="#E52C2D"/>
        <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z" fill="white"/>
      </svg>
    `),
    iconSize: [32, 32],
    iconAnchor: [16, 16],
    popupAnchor: [0, -16]
  });

  customerIcon = new L.Icon({
    iconUrl: 'data:image/svg+xml;base64,' + btoa(`
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="#FF771D">
        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
      </svg>
    `),
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  });
} catch (e) {
  console.warn('Leaflet Icon constructor failed (Despia Runtime):', e);
}

function MapUpdater({ center, zoom }) {
  const map = useMap();
  
  React.useEffect(() => {
    if (center) {
      map.setView(center, zoom || map.getZoom());
    }
  }, [center, zoom, map]);
  
  return null;
}

function SearchControl({ technicians, onSelectTechnician }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [techUsers, setTechUsers] = useState({});

  useEffect(() => {
    loadTechnicianUsers();
  }, [technicians]);

  const loadTechnicianUsers = async () => {
    const userIds = [...new Set(technicians.map(t => t.user_id))];
    const users = await Promise.all(
      userIds.map(async (id) => {
        const result = await base44.entities.User.filter({ id });
        return result[0];
      })
    );
    const userMap = {};
    users.forEach(u => { if (u) userMap[u.id] = u; });
    setTechUsers(userMap);
  };

  const filteredTechs = technicians.filter(tech => {
    const user = techUsers[tech.user_id];
    const name = user?.full_name || 'Technician';
    return name.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="absolute top-4 left-4 z-[1000] bg-white rounded-lg shadow-lg p-3 w-64">
      <div className="relative mb-2">
        <Search className="absolute left-2 top-2.5 w-4 h-4 text-gray-400" />
        <Input
          placeholder="Search technician..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-8 pr-8"
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="absolute right-2 top-2.5 text-gray-400 hover:text-gray-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
      {searchTerm && filteredTechs.length > 0 && (
        <div className="max-h-48 overflow-y-auto space-y-1">
          {filteredTechs.map(tech => {
            const user = techUsers[tech.user_id];
            return (
              <button
                key={tech.id}
                onClick={() => {
                  onSelectTechnician(tech);
                  setSearchTerm('');
                }}
                className="w-full text-left px-3 py-2 hover:bg-gray-100 rounded text-sm"
              >
                <div className="font-semibold">{user?.full_name || 'Technician'}</div>
                <div className="text-xs text-gray-500 flex items-center gap-1">
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  {tech.rating?.toFixed(1) || '5.0'}
                </div>
              </button>
            );
          })}
        </div>
      )}
      {searchTerm && filteredTechs.length === 0 && (
        <p className="text-xs text-gray-500 text-center py-2">No technicians found</p>
      )}
    </div>
  );
}

export default function TechniciansMap({ 
  technicians = [],
  customerLocation = null,
  height = "500px",
  zoom = 12,
  showCustomer = false,
  enableRealTimeTracking = false,
  showLiveIndicator = true
}) {
  const [selectedTech, setSelectedTech] = useState(null);
  const [techUsers, setTechUsers] = useState({});
  const [mapError, setMapError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  // Get real-time locations for all technicians
  const technicianIds = useMemo(() => technicians.map(t => t.user_id), [technicians]);
  const realtimeLocations = useMultipleTechnicianLocations(technicianIds, enableRealTimeTracking);

  // Merge real-time locations with technician data
  const techniciansWithLiveLocation = useMemo(() => {
    if (!enableRealTimeTracking || realtimeLocations.length === 0) {
      return technicians;
    }
    return technicians.map(tech => {
      const liveLocation = realtimeLocations.find(loc => loc.techId === tech.user_id);
      if (liveLocation) {
        return {
          ...tech,
          current_lat: liveLocation.lat,
          current_lng: liveLocation.lng,
          lastUpdate: liveLocation.timestamp
        };
      }
      return tech;
    });
  }, [technicians, realtimeLocations, enableRealTimeTracking]);

  const center = useMemo(() => {
    // Validate customer location
    if (customerLocation && Array.isArray(customerLocation) && 
        !isNaN(customerLocation[0]) && !isNaN(customerLocation[1])) {
      return customerLocation;
    }
    // Find first technician with valid coordinates
    const validTech = techniciansWithLiveLocation.find(t => 
      t.current_lat && t.current_lng && 
      !isNaN(t.current_lat) && !isNaN(t.current_lng)
    );
    if (validTech) {
      return [validTech.current_lat, validTech.current_lng];
    }
    return [6.8013, -58.1551]; // Default Georgetown, Guyana
  }, [techniciansWithLiveLocation, customerLocation]);

  useEffect(() => {
    loadTechnicianUsers();
  }, [technicians]);

  const loadTechnicianUsers = async () => {
    const userIds = [...new Set(technicians.map(t => t.user_id))];
    const users = await Promise.all(
      userIds.map(async (id) => {
        const result = await base44.entities.User.filter({ id });
        return result[0];
      })
    );
    const userMap = {};
    users.forEach(u => { if (u) userMap[u.id] = u; });
    setTechUsers(userMap);
  };

  const handleSelectTechnician = (tech) => {
    setSelectedTech(tech);
  };

  const handleRetry = () => {
    setMapError(false);
    setRetryCount(prev => prev + 1);
  };

  // Use OpenStreetMap as fallback if Mapbox token not configured
  const useMapbox = MAPBOX_TOKEN && MAPBOX_TOKEN !== 'undefined' && MAPBOX_TOKEN !== '';
  const tileUrl = useMapbox 
    ? `https://api.mapbox.com/styles/v1/mapbox/streets-v12/tiles/{z}/{x}/{y}?access_token=${MAPBOX_TOKEN}`
    : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
  
  const tileAttribution = useMapbox 
    ? MAPBOX_TILE_CONFIG.attribution
    : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

  if (mapError) {
    return (
      <div style={{ height: height || "500px", width: "100%", borderRadius: '12px', background: '#fef3c7', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
        <div style={{ textAlign: 'center' }}>
          <AlertCircle className="w-10 h-10 mx-auto mb-2 text-orange-600" />
          <p className="text-sm font-semibold text-gray-800 mb-1">Map Temporarily Unavailable</p>
          <p className="text-xs text-gray-600 mb-3">{technicians.length} technicians available nearby</p>
          <Button onClick={handleRetry} size="sm" variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Retry Map
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ height: height || "500px", width: "100%", borderRadius: '12px', overflow: 'hidden', position: 'relative' }}>
      {enableRealTimeTracking && showLiveIndicator && (
        <div className="absolute top-4 right-4 z-[1000]">
          <Badge className="bg-green-500 text-white flex items-center gap-2 px-3 py-2 shadow-lg">
            <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
            <Navigation className="w-4 h-4" />
            Live Tracking
          </Badge>
        </div>
      )}
      <SearchControl technicians={techniciansWithLiveLocation} onSelectTechnician={handleSelectTechnician} />
      
      <MapContainer 
        key={retryCount}
        center={selectedTech ? [selectedTech.current_lat, selectedTech.current_lng] : center} 
        zoom={selectedTech ? 15 : zoom} 
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={true}
      >
        <TileLayer
          url={tileUrl}
          attribution={tileAttribution}
          {...(useMapbox ? { tileSize: MAPBOX_TILE_CONFIG.tileSize, zoomOffset: MAPBOX_TILE_CONFIG.zoomOffset } : {})}
          errorTileUrl="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mN8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=="
          eventHandlers={{
            tileerror: (e) => {
              console.error('Map tile error:', e);
              setMapError(true);
            }
          }}
        />
        <MapUpdater 
          center={selectedTech ? [selectedTech.current_lat, selectedTech.current_lng] : center} 
          zoom={selectedTech ? 15 : zoom} 
        />
        
        {/* Customer Location */}
        {showCustomer && customerLocation && 
         Array.isArray(customerLocation) && 
         !isNaN(customerLocation[0]) && !isNaN(customerLocation[1]) && (
          <Marker position={customerLocation} icon={customerIcon}>
            <Popup>
              <div className="text-center p-2">
                <strong className="block mb-1">Your Location</strong>
                <p className="text-xs text-gray-600">Technicians nearby will see your request</p>
              </div>
            </Popup>
          </Marker>
        )}
        
        {/* Technicians */}
        {techniciansWithLiveLocation.map((tech) => {
          // Validate coordinates are valid numbers
          if (!tech.current_lat || !tech.current_lng || 
              isNaN(tech.current_lat) || isNaN(tech.current_lng)) return null;
          const user = techUsers[tech.user_id];
          const techName = user?.full_name || 'Technician';
          const status = tech.is_available ? 'Available' : 'Offline';
          
          return (
            <Marker 
              key={tech.id} 
              position={[tech.current_lat, tech.current_lng]}
              icon={technicianIcon}
              title={`${techName} - ${status}`}
            >
              <Popup>
                <div className="p-2 min-w-[200px]">
                  <div className="flex items-center gap-2 mb-2">
                    <Car className="w-5 h-5" style={{ color: '#E52C2D' }} />
                    <strong className="text-base">{techName}</strong>
                  </div>
                  
                  {enableRealTimeTracking && tech.lastUpdate && (
                    <div className="mb-2 text-xs text-green-600 flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                      Live • {new Date(tech.lastUpdate).toLocaleTimeString()}
                    </div>
                  )}
                  
                  <div className="mb-2">
                    <span className={`text-xs px-2 py-1 rounded ${tech.is_available ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                      {status}
                    </span>
                  </div>
                  
                  {tech.specialties && tech.specialties.length > 0 && (
                    <div className="mb-2">
                      <p className="text-xs text-gray-600 mb-1">Specialties:</p>
                      <div className="flex flex-wrap gap-1">
                        {tech.specialties.slice(0, 3).map((spec, idx) => (
                          <span key={idx} className="text-xs bg-gray-100 px-2 py-0.5 rounded">
                            {spec}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div className="flex items-center gap-2 text-sm">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">{tech.rating?.toFixed(1) || '5.0'}</span>
                    <span className="text-gray-500">({tech.total_jobs || 0} jobs)</span>
                  </div>
                  
                  {tech.vehicle_type && (
                    <p className="text-xs text-gray-600 mt-2">
                      Vehicle: {tech.vehicle_type}
                    </p>
                  )}
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
}