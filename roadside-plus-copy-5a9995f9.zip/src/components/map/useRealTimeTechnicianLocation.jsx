import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export function useRealTimeTechnicianLocation(technicianId, enabled = true) {
  const [location, setLocation] = useState(null);

  const { data: techLocation } = useQuery({
    queryKey: ['realtime-tech-location', technicianId],
    queryFn: async () => {
      if (!technicianId) return null;
      
      // Fetch from TechnicianLocation entity
      const locations = await base44.entities.TechnicianLocation.filter(
        { technician_id: technicianId },
        '-created_date',
        1
      );
      
      if (locations.length > 0) {
        return {
          lat: locations[0].latitude,
          lng: locations[0].longitude,
          timestamp: locations[0].created_date
        };
      }

      // Fallback to TechnicianProfile
      const profiles = await base44.entities.TechnicianProfile.filter({
        user_id: technicianId
      });
      
      if (profiles.length > 0 && profiles[0].current_lat && profiles[0].current_lng) {
        return {
          lat: profiles[0].current_lat,
          lng: profiles[0].current_lng,
          timestamp: profiles[0].updated_date
        };
      }

      return null;
    },
    enabled: enabled && !!technicianId,
    refetchInterval: 5000, // Update every 5 seconds
    staleTime: 3000
  });

  useEffect(() => {
    if (techLocation) {
      setLocation([techLocation.lat, techLocation.lng]);
    }
  }, [techLocation]);

  return { location, lastUpdate: techLocation?.timestamp };
}

export function useMultipleTechnicianLocations(technicianIds = [], enabled = true) {
  const { data: locations } = useQuery({
    queryKey: ['realtime-multiple-tech-locations', technicianIds],
    queryFn: async () => {
      if (technicianIds.length === 0) return [];

      const techLocations = await Promise.all(
        technicianIds.map(async (techId) => {
          const locations = await base44.entities.TechnicianLocation.filter(
            { technician_id: techId },
            '-created_date',
            1
          );

          if (locations.length > 0) {
            return {
              techId,
              lat: locations[0].latitude,
              lng: locations[0].longitude,
              timestamp: locations[0].created_date
            };
          }

          const profiles = await base44.entities.TechnicianProfile.filter({
            user_id: techId
          });

          if (profiles.length > 0 && profiles[0].current_lat && profiles[0].current_lng) {
            return {
              techId,
              lat: profiles[0].current_lat,
              lng: profiles[0].current_lng,
              timestamp: profiles[0].updated_date
            };
          }

          return null;
        })
      );

      return techLocations.filter(loc => loc !== null);
    },
    enabled: enabled && technicianIds.length > 0,
    refetchInterval: 5000,
    staleTime: 3000
  });

  return locations || [];
}