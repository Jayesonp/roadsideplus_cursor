import React, { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import { Car, MapPin } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { MAPBOX_TOKEN, MAPBOX_TILE_URL, MAPBOX_TILE_CONFIG } from './mapboxConfig';
import { AlertCircle } from 'lucide-react';
import { useRealTimeTechnicianLocation } from './useRealTimeTechnicianLocation';

// Fix for default marker icons in React-Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

// Custom icons
let customerIcon;
let technicianIcon;

try {
  customerIcon = new L.Icon({
    iconUrl: 'data:image/svg+xml;base64,' + btoa(`
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="#E52C2D">
        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
      </svg>
    `),
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  });

  technicianIcon = new L.Icon({
    iconUrl: 'data:image/svg+xml;base64,' + btoa(`
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="#FF771D">
        <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
      </svg>
    `),
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  });
} catch (e) {
  console.warn('Leaflet Icon constructor failed (Despia Runtime):', e);
}

function MapUpdater({ center, zoom }) {
  const map = useMap();
  
  useEffect(() => {
    if (center) {
      map.setView(center, zoom || map.getZoom());
    }
  }, [center, zoom, map]);
  
  return null;
}

export default function ServiceMap({ 
  customerLocation, 
  technicianLocation,
  technicianId,
  height = "400px",
  zoom = 13,
  showCustomer = true,
  showTechnician = true,
  showRoute = false,
  enableRealTimeTracking = false
}) {
  const [mapError, setMapError] = React.useState(false);
  
  // Use real-time tracking if enabled
  const { location: realtimeTechLocation, lastUpdate } = useRealTimeTechnicianLocation(
    technicianId,
    enableRealTimeTracking
  );

  // Use real-time location if available, otherwise use prop
  const activeTechLocation = enableRealTimeTracking && realtimeTechLocation 
    ? realtimeTechLocation 
    : technicianLocation;

  const center = customerLocation || activeTechLocation || [40.7128, -74.0060];

  if (!MAPBOX_TOKEN || !MAPBOX_TOKEN.startsWith("pk.")) {
    console.warn("⚠️ Mapbox token missing or invalid. Map may not render.");
  }

  if (mapError) {
    return (
      <div style={{ height, width: '100%', borderRadius: '12px', background: '#fef3c7', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
        <div style={{ textAlign: 'center' }}>
          <AlertCircle className="w-8 h-8 mx-auto mb-2 text-orange-600" />
          <p className="text-sm font-semibold text-gray-700">Map Temporarily Unavailable</p>
        </div>
      </div>
    );
  }

  const mapboxTileUrl = `https://api.mapbox.com/styles/v1/mapbox/streets-v12/tiles/{z}/{x}/{y}?access_token=${MAPBOX_TOKEN}`;
  
  return (
    <div style={{ height: height || "500px", width: "100%", borderRadius: '12px', overflow: 'hidden' }}>
      <MapContainer 
        center={center} 
        zoom={zoom} 
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={false}
      >
        <TileLayer
          url={MAPBOX_TILE_URL(MAPBOX_TOKEN)}
          {...MAPBOX_TILE_CONFIG}
        />
        <MapUpdater center={center} zoom={zoom} />
        
        {showCustomer && customerLocation && (
          <Marker position={customerLocation} icon={customerIcon}>
            <Popup>
              <div className="text-center">
                <MapPin className="w-5 h-5 text-red-600 mx-auto mb-1" />
                <strong>Customer Location</strong>
              </div>
            </Popup>
          </Marker>
        )}
        
        {showTechnician && activeTechLocation && (
          <>
            <Marker position={activeTechLocation} icon={technicianIcon}>
              <Popup>
                <div className="text-center">
                  <Car className="w-5 h-5 mx-auto mb-1" style={{ color: '#FF771D' }} />
                  <strong>Technician</strong>
                  {enableRealTimeTracking && lastUpdate ? (
                    <div>
                      <p className="text-xs font-semibold text-green-600">🟢 Live Tracking</p>
                      <p className="text-xs text-gray-600">
                        Updated {new Date(lastUpdate).toLocaleTimeString()}
                      </p>
                    </div>
                  ) : (
                    <p className="text-xs text-gray-600">Current location</p>
                  )}
                </div>
              </Popup>
            </Marker>
            {showRoute && customerLocation && (
              <Polyline
                positions={[activeTechLocation, customerLocation]}
                pathOptions={{
                  color: '#FF771D',
                  weight: 4,
                  opacity: 0.7,
                  dashArray: '10, 10'
                }}
              />
            )}
          </>
        )}
      </MapContainer>
    </div>
  );
}