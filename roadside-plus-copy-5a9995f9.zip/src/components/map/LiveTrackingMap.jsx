import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Polyline, useMap } from 'react-leaflet';
import { divIcon } from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Navigation, Phone, MessageSquare } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { MAPBOX_TOKEN, MAPBOX_TILE_URL, MAPBOX_TILE_CONFIG } from './mapboxConfig';

// Map center updater
function MapUpdater({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.setView(center, zoom);
    }
  }, [center, zoom, map]);
  return null;
}

// Custom icons
let customerIcon;
let technicianIcon;

try {
  customerIcon = divIcon({
    html: `<div style="background: #FF771D; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3);"></div>`,
    className: '',
    iconSize: [24, 24],
    iconAnchor: [12, 12]
  });

  technicianIcon = divIcon({
    html: `<div style="background: #3D692B; width: 28px; height: 28px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3);"></div>`,
    className: '',
    iconSize: [28, 28],
    iconAnchor: [14, 14]
  });
} catch (e) {
  console.warn('Leaflet divIcon constructor failed (Despia Runtime):', e);
}

export default function LiveTrackingMap({ 
  request, 
  userRole, 
  onStatusChange,
  showActions = true 
}) {
  const [techLocation, setTechLocation] = useState(null);

  // Fetch technician location in real-time
  const { data: locations = [] } = useQuery({
    queryKey: ['tech-location', request.technician_id],
    queryFn: async () => {
      const locs = await base44.entities.TechnicianLocation.filter({
        technician_id: request.technician_id
      });
      return locs;
    },
    enabled: !!request.technician_id,
    refetchInterval: 15000,
    retry: 1,
    retryDelay: 5000,
    staleTime: 12000
  });

  useEffect(() => {
    if (locations.length > 0) {
      const latest = locations.sort((a, b) => 
        new Date(b.created_date) - new Date(a.created_date)
      )[0];
      setTechLocation([latest.latitude, latest.longitude]);
    }
  }, [locations]);

  const customerLocation = [request.location_lat, request.location_lng];
  const mapCenter = techLocation || customerLocation;

  const statusActions = {
    assigned: { label: 'Start En Route', nextStatus: 'en_route', color: '#FF771D' },
    en_route: { label: 'Mark as Arrived', nextStatus: 'arrived', color: '#FF771D' },
    arrived: { label: 'Start Job', nextStatus: 'in_progress', color: '#3D692B' },
    in_progress: { label: 'Complete Job', nextStatus: 'awaiting_review', color: '#3D692B' }
  };

  const currentAction = statusActions[request.status];

  const handleStatusChange = async () => {
    if (!currentAction) return;
    
    await base44.entities.ServiceRequest.update(request.id, {
      status: currentAction.nextStatus
    });

    // Log status change
    await base44.entities.Event.create({
      type: 'STATUS_CHANGED',
      request_id: request.id,
      customer_id: request.customer_id,
      technician_id: request.technician_id,
      payload: {
        from: request.status,
        to: currentAction.nextStatus,
        timestamp: new Date().toISOString()
      }
    });

    onStatusChange?.(currentAction.nextStatus);
  };

  const openInGoogleMaps = () => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${request.location_lat},${request.location_lng}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-40 bg-gray-50">
      {/* Map */}
      <div className="h-[calc(100vh-200px)]">
        <MapContainer
          center={mapCenter}
          zoom={14}
          style={{ height: '100%', width: '100%' }}
          zoomControl={false}
        >
          <TileLayer
            url={MAPBOX_TILE_URL(import.meta.env.VITE_MAPBOX_ACCESS_TOKEN)}
            {...MAPBOX_TILE_CONFIG}
          />
          <MapUpdater center={mapCenter} zoom={14} />
          
          {/* Customer marker */}
          <Marker position={customerLocation} icon={customerIcon} />
          
          {/* Technician marker */}
          {techLocation && (
            <>
              <Marker position={techLocation} icon={technicianIcon} />
              {/* Route line */}
              <Polyline
                positions={[techLocation, customerLocation]}
                color="#FF771D"
                weight={3}
                opacity={0.7}
                dashArray="10, 10"
              />
            </>
          )}
        </MapContainer>
      </div>

      {/* Bottom panel */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg z-50">
        <div className="p-4 space-y-3">
          {/* Status indicator */}
          <div className="text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-white font-semibold"
              style={{ backgroundColor: currentAction?.color || '#3D692B' }}>
              <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
              {request.status === 'assigned' && 'Technician Assigned'}
              {request.status === 'en_route' && 'Technician En Route'}
              {request.status === 'arrived' && 'Technician Arrived'}
              {request.status === 'in_progress' && 'Service In Progress'}
            </div>
          </div>

          {/* Action buttons */}
          {userRole === 'technician' && showActions && currentAction && (
            <Button
              className="w-full h-12 text-lg font-semibold text-white"
              style={{ backgroundColor: currentAction.color }}
              onClick={handleStatusChange}
            >
              {currentAction.label}
            </Button>
          )}

          {/* Quick actions */}
          <div className="grid grid-cols-3 gap-2">
            <Button
              variant="outline"
              className="flex items-center gap-2"
              onClick={openInGoogleMaps}
            >
              <Navigation className="w-4 h-4" />
              Navigate
            </Button>
            <Button
              variant="outline"
              className="flex items-center gap-2"
              onClick={() => window.location.href = `tel:${request.technician_phone || ''}`}
            >
              <Phone className="w-4 h-4" />
              Call
            </Button>
            <Button
              variant="outline"
              className="flex items-center gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              Chat
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}