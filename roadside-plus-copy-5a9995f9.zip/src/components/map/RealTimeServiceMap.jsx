import React from 'react';
import ServiceMap from './ServiceMap';
import { Badge } from '@/components/ui/badge';
import { Navigation } from 'lucide-react';

export default function RealTimeServiceMap({
  customerLocation,
  technicianId,
  height = "450px",
  zoom = 13,
  showLiveIndicator = true
}) {
  return (
    <div className="relative">
      {showLiveIndicator && (
        <div className="absolute top-4 left-4 z-[1000]">
          <Badge className="bg-green-500 text-white flex items-center gap-2 px-3 py-2 shadow-lg">
            <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
            <Navigation className="w-4 h-4" />
            Live Tracking
          </Badge>
        </div>
      )}
      
      <ServiceMap
        customerLocation={customerLocation}
        technicianId={technicianId}
        height={height}
        zoom={zoom}
        enableRealTimeTracking={true}
        showCustomer={true}
        showTechnician={true}
        showRoute={true}
      />
    </div>
  );
}