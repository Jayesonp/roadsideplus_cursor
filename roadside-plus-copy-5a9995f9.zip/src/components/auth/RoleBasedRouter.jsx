import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';

/**
 * Role-based routing configuration
 * Maps user roles to their default dashboard pages
 */
const ROLE_ROUTES = {
  admin: 'AdminDashboard',
  customer: 'CustomerDashboard',
  technician: 'TechnicianDashboard',
  partner: 'PartnerDashboard',
  security_company: 'SecurityCommandCenter'
};

/**
 * Profile entity mapping for each role
 */
const PROFILE_ENTITIES = {
  customer: 'CustomerProfile',
  technician: 'TechnicianProfile',
  partner: 'PartnerProfile',
  security_company: 'SecurityCompanyProfile'
};

/**
 * Onboarding page mapping for incomplete profiles
 */
const ONBOARDING_ROUTES = {
  customer: 'CustomerDashboard', // Has built-in onboarding
  technician: 'TechnicianOnboardingChecklist',
  partner: 'PartnerDashboard', // Has built-in setup
  security_company: 'SecurityCommandCenter'
};

/**
 * Get or create profile for a user based on their role
 */
export async function ensureUserProfile(user) {
  const entityName = PROFILE_ENTITIES[user.role];
  
  // Admin doesn't need a profile
  if (!entityName) return null;
  
  try {
    // Check if profile exists
    const profiles = await base44.entities[entityName].filter({ user_id: user.id });
    
    if (profiles.length > 0) {
      return profiles[0];
    }
    
    // Create profile if it doesn't exist
    const newProfile = await base44.entities[entityName].create({
      user_id: user.id,
      phone: user.phone || 'Pending', // Ensure required field is populated
      onboarding_completed: false
    });
    
    return newProfile;
  } catch (error) {
    console.error(`Error ensuring ${entityName}:`, error);
    return null;
  }
}

/**
 * Route user to appropriate dashboard based on role and profile status
 */
export async function routeUserByRole(user) {
  if (!user || !user.role) {
    console.error('Invalid user object:', user);
    return 'Login'; // Safety fallback to login instead of customer dashboard to avoid leaks
  }
  
  // Check T&C Acceptance for ALL roles
  if (!user.terms_accepted || !user.privacy_accepted) {
    return 'TermsAcceptance';
  }

  // Explicit routing based on role
  let defaultRoute;
  switch (user.role) {
    case 'admin':
      defaultRoute = 'AdminDashboard';
      break;
    case 'technician':
      defaultRoute = 'TechnicianDashboard';
      break;
    case 'partner':
      defaultRoute = 'PartnerDashboard';
      break;
    case 'security_company':
      defaultRoute = 'SecurityCommandCenter';
      break;
    case 'customer':
      defaultRoute = 'CustomerDashboard';
      break;
    default:
      // If role is unknown, send to role selection or login to prevent unauthorized access
      console.warn('Unknown user role:', user.role);
      return 'Login'; 
  }
  
  // Admin users go straight to their dashboard
  if (user.role === 'admin') {
    return defaultRoute;
  }
  
  // Ensure profile exists for non-admin users
  const profile = await ensureUserProfile(user);

  // Technician specific onboarding check
  if (user.role === 'technician' && profile) {
    // If status is not approved, always go to checklist/status page
    if (profile.onboarding_status !== 'approved') {
      return 'TechnicianOnboardingChecklist';
    }
  }

  // Only redirect to onboarding if we successfully checked profile and it's incomplete
  // If profile check failed (profile is null) but user exists, safest to go to default dashboard to avoid loops
  if (profile && !user.profile_completed) {
    return ONBOARDING_ROUTES[user.role] || defaultRoute;
  }
  
  return defaultRoute;
}

/**
 * Redirect user to their role-appropriate page
 * Call this after successful login/verification
 */
export async function redirectToRoleDashboard() {
  try {
    // Verify user is authenticated
    const isAuth = await base44.auth.isAuthenticated();
    if (!isAuth) {
      throw new Error('User not authenticated');
    }

    // Get user details
    const user = await base44.auth.me();
    if (!user) {
      throw new Error('Could not fetch user details');
    }

    console.log('Redirecting user:', user.email, 'Role:', user.role);
    
    // Determine target page
    const targetPage = await routeUserByRole(user);
    console.log('Target page:', targetPage);
    
    // Perform redirect
    window.location.href = createPageUrl(targetPage);
  } catch (error) {
    console.error('Error routing user:', error);
    throw error; // Re-throw to let caller handle it
  }
}

/**
 * Hook version for React components
 */
export function useRoleBasedRedirect() {
  return async () => {
    await redirectToRoleDashboard();
  };
}

/**
 * Get profile entity name for a given role
 */
export function getProfileEntityName(role) {
  return PROFILE_ENTITIES[role];
}

/**
 * Check if user has required profile for their role
 */
export async function hasRequiredProfile(user) {
  if (user.role === 'admin') return true;
  
  const entityName = PROFILE_ENTITIES[user.role];
  if (!entityName) return false;
  
  try {
    const profiles = await base44.entities[entityName].filter({ user_id: user.id });
    return profiles.length > 0;
  } catch (error) {
    return false;
  }
}