import { useEffect, useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';

export default function BackgroundLocationTracker({ technicianId, isAvailable, hasActiveJob }) {
  const intervalRef = useRef(null);
  const watchIdRef = useRef(null);
  const [accuracyPreference, setAccuracyPreference] = useState('high_accuracy');
  const [activeJobId, setActiveJobId] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      if (technicianId) {
        const profiles = await base44.entities.TechnicianProfile.filter({ user_id: technicianId });
        if (profiles[0]?.location_accuracy_preference) {
          setAccuracyPreference(profiles[0].location_accuracy_preference);
        }

        // Check for active job
        const activeStatuses = ['assigned', 'en_route', 'in_progress'];
        const jobs = await base44.entities.ServiceRequest.filter({ technician_id: technicianId });
        const activeJob = jobs.find(job => activeStatuses.includes(job.status));
        setActiveJobId(activeJob?.id || null);
      }
    };
    loadData();

    // Poll for active job changes every 2 minutes to reduce API load
    const interval = setInterval(loadData, 120000);
    return () => clearInterval(interval);
  }, [technicianId]);

  useEffect(() => {
    // Track when available OR when has active job
    if (technicianId && (isAvailable || activeJobId)) {
      startTracking();
    } else {
      stopTracking();
    }

    return () => stopTracking();
  }, [technicianId, isAvailable, activeJobId, accuracyPreference]);

  const calculateDistance = (lat1, lng1, lat2, lng2) => {
    const R = 3959; // Earth radius in miles
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const checkGeofence = async (latitude, longitude, profile) => {
    if (!profile.auto_geofence_enabled || !profile.service_area_center_lat || !profile.service_area_center_lng) {
      return;
    }

    const distance = calculateDistance(
      latitude,
      longitude,
      profile.service_area_center_lat,
      profile.service_area_center_lng
    );

    const isWithinArea = distance <= profile.service_area_radius_miles;
    const wasWithinArea = profile.is_within_service_area;

    // Only update if status changed
    if (isWithinArea !== wasWithinArea) {
      const newStatus = isWithinArea ? 'available' : 'offline';
      await base44.entities.TechnicianProfile.update(profile.id, {
        is_within_service_area: isWithinArea,
        availability_status: newStatus,
        is_available: isWithinArea,
        geofence_last_check: new Date().toISOString()
      });

      // Notify technician
      await base44.entities.Notification.create({
        user_id: technicianId,
        type: 'job_completed',
        title: isWithinArea ? 'Entered Service Area' : 'Left Service Area',
        message: isWithinArea 
          ? 'You are now within your service area and automatically available for jobs.'
          : 'You have left your service area and are now offline.',
        related_id: profile.id
      });
    }
  };

  const startTracking = () => {
    if (!navigator.geolocation) return;

    // Determine geolocation options based on active job status
    const getGeolocationOptions = () => {
      // Force high accuracy during active jobs
      if (activeJobId) {
        return {
          enableHighAccuracy: true,
          maximumAge: 0,
          timeout: 5000
        };
      }

      // Use preference when just available
      switch (accuracyPreference) {
        case 'high_accuracy':
          return {
            enableHighAccuracy: true,
            maximumAge: 30000,
            timeout: 27000
          };
        case 'battery_saving':
          return {
            enableHighAccuracy: false,
            maximumAge: 60000,
            timeout: 20000
          };
        case 'device_only':
          return {
            enableHighAccuracy: true,
            maximumAge: 45000,
            timeout: 30000
          };
        default:
          return {
            enableHighAccuracy: true,
            maximumAge: 30000,
            timeout: 27000
          };
      }
    };

    // Real-time GPS streaming during active jobs
    watchIdRef.current = navigator.geolocation.watchPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        
        try {
          const profiles = await base44.entities.TechnicianProfile.filter({ user_id: technicianId });
          
          if (profiles[0]) {
            const profile = profiles[0];
            
            // Only check geofence when not on active job
            if (!activeJobId) {
              await checkGeofence(latitude, longitude, profile);
            }
            
            // Update location in profile
            await base44.entities.TechnicianProfile.update(profile.id, {
              current_lat: latitude,
              current_lng: longitude
            });
          }

          // Update TechnicianLocation for real-time streaming to customer
          await base44.entities.TechnicianLocation.create({
            technician_id: technicianId,
            latitude,
            longitude
          });
        } catch (error) {
          console.error('Location update failed:', error);
        }
      },
      (error) => console.error('Geolocation error:', error),
      getGeolocationOptions()
    );
  };

  const stopTracking = () => {
    if (watchIdRef.current) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  return null;
}