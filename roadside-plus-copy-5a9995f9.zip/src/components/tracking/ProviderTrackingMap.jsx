import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import { Navigation, Clock, Phone, User, MapPin } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icons in react-leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom icons
const createCustomIcon = (color, iconHtml) => {
  return L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="
        background: ${color};
        width: 40px;
        height: 40px;
        border-radius: 50% 50% 50% 0;
        border: 3px solid white;
        transform: rotate(-45deg);
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <div style="transform: rotate(45deg); color: white; font-size: 20px;">
          ${iconHtml}
        </div>
      </div>
    `,
    iconSize: [40, 40],
    iconAnchor: [20, 40],
  });
};

const technicianIcon = createCustomIcon('#FF771D', '🚗');
const customerIcon = createCustomIcon('#E52C2D', '📍');

// Component to auto-center map
function MapUpdater({ center, zoom }) {
  const map = useMap();
  
  useEffect(() => {
    if (center) {
      map.setView(center, zoom);
    }
  }, [center, zoom, map]);
  
  return null;
}

export default function ProviderTrackingMap({ 
  serviceRequest, 
  technicianLocation,
  technicianProfile,
  onCallTechnician 
}) {
  const [eta, setEta] = useState(null);
  const [distance, setDistance] = useState(null);
  const [mapCenter, setMapCenter] = useState(null);
  const [route, setRoute] = useState([]);

  // Calculate distance and ETA
  useEffect(() => {
    if (technicianLocation && serviceRequest?.location_latitude && serviceRequest?.location_longitude) {
      const techLat = technicianLocation.latitude;
      const techLon = technicianLocation.longitude;
      const custLat = serviceRequest.location_latitude;
      const custLon = serviceRequest.location_longitude;

      // Calculate distance using Haversine formula
      const R = 6371; // Earth's radius in km
      const dLat = (custLat - techLat) * Math.PI / 180;
      const dLon = (custLon - techLon) * Math.PI / 180;
      const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(techLat * Math.PI / 180) * Math.cos(custLat * Math.PI / 180) *
        Math.sin(dLon/2) * Math.sin(dLon/2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
      const distanceInKm = R * c;

      setDistance(distanceInKm);

      // Estimate ETA (assuming average speed of 40 km/h in city)
      const avgSpeed = 40;
      const timeInHours = distanceInKm / avgSpeed;
      const timeInMinutes = Math.round(timeInHours * 60);
      setEta(timeInMinutes);

      // Set map center to midpoint
      const centerLat = (techLat + custLat) / 2;
      const centerLon = (techLon + custLon) / 2;
      setMapCenter([centerLat, centerLon]);

      // Create route line
      setRoute([
        [techLat, techLon],
        [custLat, custLon]
      ]);
    }
  }, [technicianLocation, serviceRequest]);

  if (!serviceRequest?.location_latitude || !serviceRequest?.location_longitude) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-100 dark:bg-gray-800 rounded-lg">
        <p className="text-gray-500">Location information not available</p>
      </div>
    );
  }

  const customerPosition = [serviceRequest.location_latitude, serviceRequest.location_longitude];
  const technicianPosition = technicianLocation 
    ? [technicianLocation.latitude, technicianLocation.longitude]
    : null;

  const defaultCenter = technicianPosition || customerPosition;

  return (
    <div className="space-y-4">
      {/* Status Card */}
      {technicianProfile && (
        <Card className="border-l-4 border-l-orange-500 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center text-white text-2xl font-bold shadow-lg">
                  {technicianProfile.name?.charAt(0) || 'T'}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                    {technicianProfile.name}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {technicianProfile.vehicle_type || 'Service Vehicle'} • {technicianProfile.license_plate || 'N/A'}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge className="bg-green-100 text-green-800 border-green-200">
                      <Navigation className="w-3 h-3 mr-1" />
                      En Route
                    </Badge>
                  </div>
                </div>
              </div>
              {technicianProfile.phone && onCallTechnician && (
                <Button 
                  onClick={onCallTechnician}
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Call
                </Button>
              )}
            </div>

            {eta !== null && distance !== null && (
              <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t dark:border-gray-700">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                    <Clock className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {eta} min
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Estimated Arrival</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {distance.toFixed(1)} km
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Distance Away</p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Map */}
      <Card className="overflow-hidden shadow-xl">
        <div className="h-[400px] md:h-[500px] relative">
          <MapContainer 
            center={mapCenter || defaultCenter} 
            zoom={13} 
            style={{ height: '100%', width: '100%' }}
            className="z-0"
          >
            <MapUpdater center={mapCenter || defaultCenter} zoom={mapCenter ? 13 : 15} />
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            {/* Customer location marker */}
            <Marker position={customerPosition} icon={customerIcon}>
              <Popup>
                <div className="text-center">
                  <p className="font-semibold">Your Location</p>
                  <p className="text-sm text-gray-600">{serviceRequest.location_address || 'Service location'}</p>
                </div>
              </Popup>
            </Marker>
            
            {/* Technician location marker */}
            {technicianPosition && (
              <>
                <Marker position={technicianPosition} icon={technicianIcon}>
                  <Popup>
                    <div className="text-center">
                      <p className="font-semibold">{technicianProfile?.name || 'Technician'}</p>
                      <p className="text-sm text-gray-600">Current location</p>
                      {eta && <p className="text-sm font-semibold text-orange-600 mt-1">{eta} min away</p>}
                    </div>
                  </Popup>
                </Marker>
                
                {/* Route line */}
                {route.length > 0 && (
                  <Polyline 
                    positions={route} 
                    color="#FF771D" 
                    weight={4}
                    opacity={0.7}
                    dashArray="10, 10"
                  />
                )}
              </>
            )}
          </MapContainer>

          {!technicianPosition && (
            <div className="absolute top-4 left-4 right-4 bg-yellow-50 dark:bg-yellow-900 border-l-4 border-yellow-400 p-3 rounded-lg shadow-lg z-10">
              <div className="flex items-center gap-2">
                <Navigation className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
                <p className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                  Waiting for provider location update...
                </p>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Legend */}
      <div className="flex items-center justify-center gap-6 text-sm text-gray-600 dark:text-gray-400">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🚗</span>
          <span>Service Provider</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-2xl">📍</span>
          <span>Your Location</span>
        </div>
      </div>
    </div>
  );
}