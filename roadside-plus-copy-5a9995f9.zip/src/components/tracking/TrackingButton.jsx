import React from 'react';
import { Button } from '@/components/ui/button';
import { MapPin, Navigation } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function TrackingButton({ serviceRequest, variant = 'default', className = '' }) {
  const canTrack = serviceRequest?.assigned_technician_id && 
                   ['assigned', 'en_route', 'in_progress'].includes(serviceRequest?.status);

  if (!canTrack) {
    return null;
  }

  const handleClick = () => {
    window.location.href = createPageUrl('TrackProvider') + `?requestId=${serviceRequest.id}`;
  };

  if (variant === 'icon') {
    return (
      <Button
        onClick={handleClick}
        size="icon"
        className={`bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 ${className}`}
        title="Track Provider"
      >
        <Navigation className="w-4 h-4" />
      </Button>
    );
  }

  return (
    <Button
      onClick={handleClick}
      className={`bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 ${className}`}
    >
      <MapPin className="w-4 h-4 mr-2" />
      Track Provider
    </Button>
  );
}