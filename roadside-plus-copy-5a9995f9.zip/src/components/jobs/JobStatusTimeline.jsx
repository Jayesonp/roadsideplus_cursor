import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, CheckCircle, AlertTriangle, User, MapPin, Star } from 'lucide-react';
import { format } from 'date-fns';

export default function JobStatusTimeline({ requestId }) {
  const { data: events = [] } = useQuery({
    queryKey: ['job-timeline', requestId],
    queryFn: async () => {
      const eventList = await base44.entities.Event.filter(
        { request_id: requestId },
        'created_date'
      );
      return eventList;
    },
    enabled: !!requestId,
    refetchInterval: 5000
  });

  const eventConfig = {
    REQUEST_CREATED: { 
      icon: Clock, 
      color: 'bg-blue-500', 
      label: 'Request Created' 
    },
    PAYMENT_AUTHORIZED: { 
      icon: CheckCircle, 
      color: 'bg-green-500', 
      label: 'Payment Authorized' 
    },
    DISPATCH_STARTED: { 
      icon: MapPin, 
      color: 'bg-orange-500', 
      label: 'Dispatch Started' 
    },
    OFFER_SENT: { 
      icon: User, 
      color: 'bg-purple-500', 
      label: 'Offer Sent to Technician' 
    },
    OFFER_ACCEPTED: { 
      icon: CheckCircle, 
      color: 'bg-green-600', 
      label: 'Technician Accepted' 
    },
    OFFER_REJECTED: { 
      icon: AlertTriangle, 
      color: 'bg-red-500', 
      label: 'Offer Rejected' 
    },
    OFFER_TIMEOUT: { 
      icon: Clock, 
      color: 'bg-gray-500', 
      label: 'Offer Timeout' 
    },
    STATUS_CHANGED: { 
      icon: MapPin, 
      color: 'bg-blue-600', 
      label: 'Status Updated' 
    },
    PHOTO_UPLOADED: { 
      icon: CheckCircle, 
      color: 'bg-teal-500', 
      label: 'Photo Uploaded' 
    },
    RATING_SUBMITTED: { 
      icon: Star, 
      color: 'bg-yellow-500', 
      label: 'Rating Submitted' 
    },
    TIP_ADDED: { 
      icon: CheckCircle, 
      color: 'bg-green-400', 
      label: 'Tip Added' 
    },
    JOB_COMPLETED: { 
      icon: CheckCircle, 
      color: 'bg-green-700', 
      label: 'Job Completed' 
    },
    JOB_CANCELED: { 
      icon: AlertTriangle, 
      color: 'bg-red-600', 
      label: 'Job Canceled' 
    }
  };

  if (events.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Job Timeline</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500">No activity yet</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Job Timeline</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {events.map((event, idx) => {
            const config = eventConfig[event.type] || eventConfig.STATUS_CHANGED;
            const Icon = config.icon;
            
            return (
              <div key={event.id} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className={`w-8 h-8 rounded-full ${config.color} flex items-center justify-center`}>
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  {idx < events.length - 1 && (
                    <div className="w-0.5 h-full bg-gray-200 my-1" />
                  )}
                </div>
                <div className="flex-1 pb-4">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-semibold text-sm">{config.label}</h4>
                    <span className="text-xs text-gray-500">
                      {format(new Date(event.created_date), 'MMM d, h:mm a')}
                    </span>
                  </div>
                  {event.payload && (
                    <div className="text-xs text-gray-600 space-y-1">
                      {event.payload.new_status && (
                        <Badge variant="outline" className="text-xs">
                          {event.payload.new_status.replace(/_/g, ' ')}
                        </Badge>
                      )}
                      {event.payload.technician_name && (
                        <p>Technician: {event.payload.technician_name}</p>
                      )}
                      {event.payload.reason && (
                        <p>Reason: {event.payload.reason}</p>
                      )}
                      {event.payload.rating && (
                        <p>Rating: {event.payload.rating}/5 ⭐</p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}