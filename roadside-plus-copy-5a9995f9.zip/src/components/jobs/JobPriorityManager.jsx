import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { AlertTriangle, AlertCircle, Info, Circle } from 'lucide-react';

const priorityConfig = {
  low: {
    icon: Circle,
    color: 'bg-gray-100 text-gray-700 border-gray-300',
    label: 'Low Priority'
  },
  normal: {
    icon: Info,
    color: 'bg-blue-100 text-blue-700 border-blue-300',
    label: 'Normal Priority'
  },
  high: {
    icon: AlertCircle,
    color: 'bg-orange-100 text-orange-700 border-orange-300',
    label: 'High Priority'
  },
  critical: {
    icon: AlertTriangle,
    color: 'bg-red-100 text-red-700 border-red-300',
    label: 'Critical Priority'
  }
};

export default function JobPriorityManager({ request, compact = false }) {
  const [isEditing, setIsEditing] = useState(false);
  const [selectedPriority, setSelectedPriority] = useState(request.priority || 'normal');
  const queryClient = useQueryClient();

  const updatePriority = useMutation({
    mutationFn: async (newPriority) => {
      const updated = await base44.entities.ServiceRequest.update(request.id, {
        priority: newPriority,
        priority_score: { low: 25, normal: 50, high: 75, critical: 100 }[newPriority]
      });

      // Log event
      await base44.entities.Event.create({
        type: 'STATUS_CHANGED',
        request_id: request.id,
        customer_id: request.customer_id,
        technician_id: request.technician_id,
        payload: {
          change_type: 'priority_updated',
          old_priority: request.priority,
          new_priority: newPriority,
          updated_by: 'admin'
        }
      });

      // Notify technician if assigned
      if (request.technician_id && newPriority === 'critical') {
        await base44.entities.Notification.create({
          user_id: request.technician_id,
          type: 'job_assigned',
          title: '🚨 Critical Priority Job',
          message: `Job #${request.id.substring(0, 8)} has been marked as CRITICAL priority. Please prioritize this request.`,
          related_id: request.id
        });
      }

      return updated;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['service-requests']);
      queryClient.invalidateQueries(['active-requests']);
      queryClient.invalidateQueries(['my-jobs']);
      setIsEditing(false);
    }
  });

  const config = priorityConfig[request.priority || 'normal'];
  const Icon = config.icon;

  if (compact && !isEditing) {
    return (
      <Badge 
        className={`${config.color} border cursor-pointer`}
        onClick={() => setIsEditing(true)}
      >
        <Icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    );
  }

  if (isEditing) {
    return (
      <div className="flex items-center gap-2">
        <Select value={selectedPriority} onValueChange={setSelectedPriority}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {Object.entries(priorityConfig).map(([key, cfg]) => {
              const PriorityIcon = cfg.icon;
              return (
                <SelectItem key={key} value={key}>
                  <div className="flex items-center gap-2">
                    <PriorityIcon className="w-4 h-4" />
                    {cfg.label}
                  </div>
                </SelectItem>
              );
            })}
          </SelectContent>
        </Select>
        <Button 
          size="sm" 
          onClick={() => updatePriority.mutate(selectedPriority)}
          disabled={updatePriority.isLoading || selectedPriority === request.priority}
        >
          Save
        </Button>
        <Button 
          size="sm" 
          variant="ghost" 
          onClick={() => {
            setIsEditing(false);
            setSelectedPriority(request.priority || 'normal');
          }}
        >
          Cancel
        </Button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <Badge className={`${config.color} border`}>
        <Icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
      <Button size="sm" variant="outline" onClick={() => setIsEditing(true)}>
        Change
      </Button>
    </div>
  );
}