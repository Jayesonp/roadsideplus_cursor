import { useEffect } from 'react';
import { base44 } from '@/api/base44Client';

/**
 * Hook to automatically send notifications when job status changes
 * Usage: useJobStatusNotifications(requestId, currentStatus, previousStatus)
 */
export const useJobStatusNotifications = (request, previousStatus) => {
  useEffect(() => {
    if (!request || !previousStatus || request.status === previousStatus) return;

    const sendNotifications = async () => {
      const statusMessages = {
        pending_payment: {
          customer: { title: '💳 Payment Required', message: 'Please complete payment to dispatch your service request.' },
          technician: null
        },
        pending_dispatch: {
          customer: { title: '🔍 Finding Technician', message: 'We are locating the nearest available technician for your request.' },
          technician: null
        },
        dispatched: {
          customer: { title: '📋 Technician Notified', message: 'A technician has been notified about your request and will respond shortly.' },
          technician: { title: '🚨 New Job Offer', message: 'You have a new job offer. Tap to review and accept.' }
        },
        assigned: {
          customer: { title: '✅ Technician Assigned', message: 'A technician has accepted your request and will arrive soon!' },
          technician: { title: '📋 Job Assigned', message: 'You have been assigned a new job. View details to get started.' }
        },
        en_route: {
          customer: { title: '🚗 Technician En Route', message: 'Your technician is on the way to your location!' },
          technician: null
        },
        arrived: {
          customer: { title: '📍 Technician Arrived', message: 'Your technician has arrived at your location.' },
          technician: null
        },
        in_progress: {
          customer: { title: '🔧 Service In Progress', message: 'Your technician is working on your vehicle.' },
          technician: null
        },
        awaiting_review: {
          customer: { title: '⭐ Rate Your Experience', message: 'Your service is complete! Please rate your experience.' },
          technician: { title: '✅ Job Complete', message: 'Service marked as complete. Waiting for customer review.' }
        },
        completed: {
          customer: { title: '✅ Service Completed', message: 'Thank you for using ROADSIDE+! Your service is complete.' },
          technician: { title: '💰 Payment Processed', message: 'Service completed and payment has been processed.' }
        },
        cancelled: {
          customer: { title: '❌ Service Cancelled', message: 'Your service request has been cancelled.' },
          technician: { title: '❌ Job Cancelled', message: 'The service request has been cancelled by the customer.' }
        }
      };

      const messages = statusMessages[request.status];
      if (!messages) return;

      try {
        // Notify customer
        if (messages.customer && request.customer_id) {
          await base44.entities.Notification.create({
            user_id: request.customer_id,
            type: 'job_status_update',
            title: messages.customer.title,
            message: messages.customer.message,
            related_id: request.id
          });
        }

        // Notify technician
        if (messages.technician && request.technician_id) {
          await base44.entities.Notification.create({
            user_id: request.technician_id,
            type: 'job_status_update',
            title: messages.technician.title,
            message: messages.technician.message,
            related_id: request.id
          });
        }

        // Log status change event
        await base44.entities.Event.create({
          type: 'STATUS_CHANGED',
          request_id: request.id,
          customer_id: request.customer_id,
          technician_id: request.technician_id,
          payload: {
            old_status: previousStatus,
            new_status: request.status,
            timestamp: new Date().toISOString()
          }
        });
      } catch (error) {
        console.error('Error sending status notifications:', error);
      }
    };

    sendNotifications();
  }, [request?.status, previousStatus, request?.id]);
};

export default useJobStatusNotifications;