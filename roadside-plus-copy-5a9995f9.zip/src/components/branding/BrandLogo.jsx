import React from 'react';


export default function BrandLogo({ variant = 'full', size = 'md', className = '' }) {
  const sizes = {
    sm: { container: 'h-8', icon: 'w-6 h-6', text: 'text-sm' },
    md: { container: 'h-12', icon: 'w-10 h-10', text: 'text-xl' },
    lg: { container: 'h-16', icon: 'w-14 h-14', text: 'text-2xl' },
    xl: { container: 'h-20', icon: 'w-16 h-16', text: 'text-3xl' }
  };

  const s = sizes[size] || sizes.md;

  // Icon only
  if (variant === 'icon') {
    return (
      <div className={`${s.icon} ${className}`}>
        <img 
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69204e59ba6ee1b55a9995f9/0c18a5db3_icon_512_512.png"
          alt="ROADSIDE+"
          className="w-full h-full object-contain rounded-md"
        />
      </div>
    );
  }

  // Text only
  if (variant === 'text') {
    return (
      <div className={`font-bold ${s.text} text-black dark:text-white ${className}`}>
        ROADSIDE+
      </div>
    );
  }

  // Full logo - icon + text
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <img 
        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69204e59ba6ee1b55a9995f9/0c18a5db3_icon_512_512.png"
        alt="ROADSIDE+ Icon"
        className={`${s.icon} object-contain rounded-md`}
      />
      <div className={`font-bold ${s.text} text-black dark:text-white ${className}`}>
        ROADSIDE+
      </div>
    </div>
  );
}