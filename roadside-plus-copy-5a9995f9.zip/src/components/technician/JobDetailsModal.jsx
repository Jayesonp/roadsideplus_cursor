import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, Clock, Navigation, DollarSign, Image as ImageIcon } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import ServiceTypeIcon from '../common/ServiceTypeIcon';
import ServiceMap from '../map/ServiceMap';
import { checkTechnicianActiveJob } from '../utils/lockingHelpers';

export default function JobDetailsModal({ job, technicianId, onClose, onAccepted }) {
  const [accepting, setAccepting] = useState(false);
  const [error, setError] = useState('');

  // Fetch attachments
  const { data: attachments = [] } = useQuery({
    queryKey: ['job-attachments', job.id],
    queryFn: async () => {
      return await base44.entities.ServiceAttachment.filter({
        service_request_id: job.id
      });
    }
  });

  const handleAccept = async () => {
    setAccepting(true);
    setError('');

    try {
      // Check technician doesn't have active job
      const lockCheck = await checkTechnicianActiveJob(technicianId);
      if (!lockCheck.allowed) {
        setError(lockCheck.message);
        setAccepting(false);
        return;
      }

      // Re-fetch job to ensure it's still available
      const currentJobs = await base44.entities.ServiceRequest.filter({ id: job.id });
      const currentJob = currentJobs[0];

      if (!currentJob) {
        setError('Job no longer exists');
        setAccepting(false);
        return;
      }

      if (currentJob.status !== 'pending_dispatch') {
        setError('Job has already been assigned to another technician');
        setAccepting(false);
        return;
      }

      if (currentJob.technician_id) {
        setError('Job has already been assigned');
        setAccepting(false);
        return;
      }

      // Accept the job
      await base44.entities.ServiceRequest.update(job.id, {
        technician_id: technicianId,
        status: 'assigned',
        estimated_arrival: new Date(Date.now() + 15 * 60000).toISOString() // 15 min ETA
      });

      // Log event
      await base44.entities.Event.create({
        type: 'OFFER_ACCEPTED',
        request_id: job.id,
        customer_id: job.customer_id,
        technician_id: technicianId,
        payload: { 
          accepted_at: new Date().toISOString(),
          source: 'job_queue'
        }
      });

      // Notify customer
      await base44.entities.Notification.create({
        user_id: job.customer_id,
        type: 'technician_assigned',
        title: 'Technician Assigned',
        message: 'A technician has accepted your request and is on the way!',
        related_id: job.id
      });

      onAccepted();
    } catch (err) {
      setError('Failed to accept job. Please try again.');
      setAccepting(false);
    }
  };

  const handleReject = () => {
    // Simply close modal - no DB changes needed
    onClose();
  };

  const openInMaps = () => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${job.location_lat},${job.location_lng}`;
    window.open(url, '_blank');
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <ServiceTypeIcon type={job.service_type} className="w-6 h-6" />
            {job.service_type.replace(/_/g, ' ').toUpperCase()}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Time and Distance */}
          <div className="flex gap-3">
            <Badge variant="outline" className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {formatDistanceToNow(new Date(job.created_date), { addSuffix: true })}
            </Badge>
            {job.distance && (
              <Badge 
                className="text-white flex items-center gap-1"
                style={{ backgroundColor: '#3D692B' }}
              >
                <MapPin className="w-3 h-3" />
                {job.distance.toFixed(1)} km away
              </Badge>
            )}
          </div>

          {/* Price */}
          {job.price && (
            <div className="flex items-center gap-2 p-3 bg-green-50 rounded-lg">
              <DollarSign className="w-5 h-5" style={{ color: '#3D692B' }} />
              <div>
                <p className="text-sm text-gray-600">Estimated Payout</p>
                <p className="text-2xl font-bold" style={{ color: '#3D692B' }}>
                  ${job.price.toFixed(2)}
                </p>
              </div>
            </div>
          )}

          {/* Description */}
          {job.description && (
            <div>
              <h4 className="font-semibold mb-2">Description</h4>
              <p className="text-gray-700 bg-gray-50 p-3 rounded-lg">
                {job.description}
              </p>
            </div>
          )}

          {/* Vehicle Details */}
          {job.vehicle_make && (
            <div>
              <h4 className="font-semibold mb-2">Vehicle Information</h4>
              <p className="text-gray-700">
                {job.vehicle_year} {job.vehicle_make} {job.vehicle_model}
                {job.vehicle_color && ` - ${job.vehicle_color}`}
              </p>
            </div>
          )}

          {/* Location */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold">Location</h4>
              <Button
                variant="outline"
                size="sm"
                onClick={openInMaps}
                className="flex items-center gap-1"
              >
                <Navigation className="w-3 h-3" />
                Navigate
              </Button>
            </div>
            {job.location_address && (
              <p className="text-sm text-gray-600 mb-3">{job.location_address}</p>
            )}
            <div className="rounded-lg overflow-hidden border">
              <ServiceMap
                customerLocation={[job.location_lat, job.location_lng]}
                height="250px"
                zoom={14}
              />
            </div>
          </div>

          {/* Photos */}
          {attachments.length > 0 && (
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <ImageIcon className="w-4 h-4" />
                Customer Photos ({attachments.length})
              </h4>
              <div className="grid grid-cols-3 gap-2">
                {attachments.map(att => (
                  <a
                    key={att.id}
                    href={att.file_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="aspect-square rounded-lg overflow-hidden border hover:opacity-80 transition-opacity"
                  >
                    <img
                      src={att.file_url}
                      alt={att.file_name}
                      className="w-full h-full object-cover"
                    />
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-800 text-sm">
              {error}
            </div>
          )}

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3 pt-4">
            <Button
              variant="outline"
              onClick={handleReject}
              disabled={accepting}
              className="h-12"
            >
              Reject
            </Button>
            <Button
              onClick={handleAccept}
              disabled={accepting}
              className="h-12 text-white font-semibold"
              style={{ backgroundColor: '#FF771D' }}
            >
              {accepting ? 'Accepting...' : 'Accept Job'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}