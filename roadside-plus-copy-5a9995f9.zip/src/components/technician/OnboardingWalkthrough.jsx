import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X, ArrowRight, ArrowLeft, CheckCircle } from 'lucide-react';

const walkthroughSteps = [
  {
    id: 'welcome',
    title: 'Welcome to ROADSIDE+! 👋',
    description: 'Let\'s take a quick tour to help you get started. This will only take a minute!',
    target: null,
    position: 'center'
  },
  {
    id: 'availability',
    title: 'Toggle Your Availability',
    description: 'Use this switch to control when you receive job offers. Turn it ON when you\'re ready to accept jobs.',
    target: '.availability-toggle',
    position: 'bottom'
  },
  {
    id: 'jobs',
    title: 'Available Jobs',
    description: 'Jobs matching your location and skills will appear here. The closer you are, the higher priority you get!',
    target: '.available-jobs-section',
    position: 'top'
  },
  {
    id: 'accept',
    title: 'Accepting Jobs',
    description: 'When you receive a job offer, you\'ll have 60 seconds to accept. Tap the job to view details and accept.',
    target: '.job-card',
    position: 'top'
  },
  {
    id: 'profile',
    title: 'Complete Your Profile',
    description: 'Add your bio, skills, and certifications to stand out and get matched with better jobs.',
    target: '.profile-link',
    position: 'bottom'
  },
  {
    id: 'earnings',
    title: 'Track Your Earnings',
    description: 'Monitor your daily, weekly, and monthly earnings right from your dashboard.',
    target: '.earnings-section',
    position: 'top'
  },
  {
    id: 'complete',
    title: 'You\'re All Set! 🎉',
    description: 'You\'re ready to start earning! Toggle your availability to ON and wait for your first job.',
    target: null,
    position: 'center'
  }
];

export default function OnboardingWalkthrough({ onComplete, onSkip }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [position, setPosition] = useState({ top: 0, left: 0 });

  useEffect(() => {
    const step = walkthroughSteps[currentStep];
    if (step.target) {
      const element = document.querySelector(step.target);
      if (element) {
        const rect = element.getBoundingClientRect();
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        let top = rect.bottom + scrollTop + 10;
        let left = rect.left + rect.width / 2;

        if (step.position === 'top') {
          top = rect.top + scrollTop - 220;
        } else if (step.position === 'center') {
          top = window.innerHeight / 2 - 150;
          left = window.innerWidth / 2;
        }

        setPosition({ top, left });

        // Highlight target element
        element.classList.add('walkthrough-highlight');
        
        // Scroll to element
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });

        return () => {
          element.classList.remove('walkthrough-highlight');
        };
      }
    } else {
      setPosition({
        top: window.innerHeight / 2 - 150,
        left: window.innerWidth / 2
      });
    }
  }, [currentStep]);

  const step = walkthroughSteps[currentStep];
  const isLastStep = currentStep === walkthroughSteps.length - 1;
  const isFirstStep = currentStep === 0;

  const handleNext = () => {
    if (isLastStep) {
      onComplete();
    } else {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <>
      {/* Overlay */}
      <div className="fixed inset-0 bg-black/60 z-[100]" onClick={onSkip} />

      {/* Walkthrough Card */}
      <Card
        className="fixed z-[101] w-[90vw] max-w-md shadow-2xl"
        style={{
          top: `${position.top}px`,
          left: `${position.left}px`,
          transform: 'translateX(-50%)'
        }}
      >
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-xl font-bold">{step.title}</h3>
                {isLastStep && <CheckCircle className="w-6 h-6 text-green-600" />}
              </div>
              <p className="text-gray-600">{step.description}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onSkip}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Progress */}
          <div className="mb-4">
            <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
              <span>Step {currentStep + 1} of {walkthroughSteps.length}</span>
              <button
                onClick={onSkip}
                className="text-gray-400 hover:text-gray-600"
              >
                Skip Tour
              </button>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full transition-all duration-300"
                style={{
                  width: `${((currentStep + 1) / walkthroughSteps.length) * 100}%`,
                  backgroundColor: '#FF771D'
                }}
              />
            </div>
          </div>

          {/* Navigation */}
          <div className="flex gap-2">
            {!isFirstStep && (
              <Button
                variant="outline"
                onClick={handlePrev}
                className="flex-1"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            )}
            <Button
              onClick={handleNext}
              className="flex-1 text-white"
              style={{ backgroundColor: '#FF771D' }}
            >
              {isLastStep ? 'Get Started' : 'Next'}
              {!isLastStep && <ArrowRight className="w-4 h-4 ml-2" />}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* CSS for highlight effect */}
      <style>{`
        .walkthrough-highlight {
          position: relative;
          z-index: 99;
          box-shadow: 0 0 0 4px #FF771D, 0 0 0 8px rgba(255, 119, 29, 0.3);
          border-radius: 8px;
          animation: pulse-highlight 2s infinite;
        }
        
        @keyframes pulse-highlight {
          0%, 100% {
            box-shadow: 0 0 0 4px #FF771D, 0 0 0 8px rgba(255, 119, 29, 0.3);
          }
          50% {
            box-shadow: 0 0 0 4px #FF771D, 0 0 0 12px rgba(255, 119, 29, 0.2);
          }
        }
      `}</style>
    </>
  );
}