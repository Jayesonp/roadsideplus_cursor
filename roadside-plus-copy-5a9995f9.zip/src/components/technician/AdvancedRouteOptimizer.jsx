import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Loader2, Sparkles } from 'lucide-react';
import OptimizedRouteDisplay from './OptimizedRouteDisplay';

export default function AdvancedRouteOptimizer({ technicianId, currentLocation }) {
  const [optimizedRoute, setOptimizedRoute] = useState(null);
  const [loading, setLoading] = useState(false);

  const { data: activeJobs = [] } = useQuery({
    queryKey: ['active-route-jobs', technicianId],
    queryFn: async () => {
      const jobs = await base44.entities.ServiceRequest.filter(
        { technician_id: technicianId, status: ['assigned', 'en_route'] },
        'created_date',
        20
      );
      return jobs;
    },
    enabled: !!technicianId,
    refetchInterval: 10000
  });

  const { data: availableRequests = [] } = useQuery({
    queryKey: ['available-route-requests', technicianId],
    queryFn: async () => {
      const requests = await base44.entities.ServiceRequest.filter(
        { status: 'pending_dispatch' },
        '-priority_score',
        10
      );
      return requests.filter(r => r.location_lat && r.location_lng);
    },
    enabled: !!technicianId,
    refetchInterval: 15000
  });

  const { data: techProfile } = useQuery({
    queryKey: ['tech-profile-routing'],
    queryFn: async () => {
      const profiles = await base44.entities.TechnicianProfile.filter({ user_id: technicianId });
      return profiles[0];
    },
    enabled: !!technicianId
  });

  const getEstimatedServiceTime = (serviceType) => {
    const times = {
      tire_change: 30,
      battery_jump: 15,
      fuel_delivery: 10,
      lockout: 20,
      towing: 45,
      other: 25
    };
    return times[serviceType] || 20;
  };

  const calculateDistance = (lat1, lng1, lat2, lng2) => {
    const R = 3959; // miles
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const optimizeRoute = async () => {
    if ((activeJobs.length + availableRequests.length) === 0 || !currentLocation) return;
    
    setLoading(true);
    try {
      const currentHour = new Date().getHours();
      const isRushHour = (currentHour >= 7 && currentHour <= 9) || (currentHour >= 16 && currentHour <= 19);
      const isWeekend = [0, 6].includes(new Date().getDay());
      
      // Get route preferences
      const routePrefs = techProfile?.route_preferences || {};
      const trafficEnabled = techProfile?.traffic_awareness_enabled !== false;
      const workZones = techProfile?.preferred_work_zones || [];

      // Combine active jobs and nearby available requests
      const nearbyRequests = availableRequests.filter(req => {
        const distance = calculateDistance(
          currentLocation.lat, currentLocation.lng,
          req.location_lat, req.location_lng
        );
        return distance <= 15; // Within 15 miles
      }).slice(0, 3); // Max 3 available requests

      const allJobs = [...activeJobs, ...nearbyRequests];

      // Calculate distances and priorities
      const jobsWithMetrics = allJobs.map(job => {
        const distance = calculateDistance(
          currentLocation.lat, currentLocation.lng,
          job.location_lat, job.location_lng
        );
        const waitTime = (Date.now() - new Date(job.created_date).getTime()) / 60000; // minutes
        const isActive = activeJobs.some(aj => aj.id === job.id);
        const priority = job.status === 'en_route' ? 'critical' : isActive ? 'high' : waitTime > 30 ? 'high' : 'normal';

        return {
          id: job.id,
          service_type: job.service_type,
          location: { lat: job.location_lat, lng: job.location_lng, address: job.location_address },
          distance,
          wait_time: waitTime,
          priority,
          estimated_service_time: getEstimatedServiceTime(job.service_type),
          status: job.status,
          vehicle: `${job.vehicle_year || ''} ${job.vehicle_make || ''} ${job.vehicle_model || ''}`.trim(),
          is_active: isActive,
          is_available: !isActive
        };
      });

      const trafficMultiplier = trafficEnabled && isRushHour ? 1.5 : isWeekend ? 0.8 : 1.0;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an advanced AI route optimization system for roadside assistance. Optimize the multi-stop route considering all factors.

CURRENT CONTEXT:
- Technician Location: Lat ${currentLocation.lat}, Lng ${currentLocation.lng}
- Current Time: ${new Date().toLocaleTimeString()} (${isRushHour ? '🚨 RUSH HOUR' : isWeekend ? '🏖️ Weekend' : '✓ Normal'})
- Traffic Awareness: ${trafficEnabled ? 'ENABLED' : 'DISABLED'}
- Traffic Multiplier: ${trafficMultiplier}x

ROUTE PREFERENCES:
- Avoid Tolls: ${routePrefs.avoid_tolls ? 'YES' : 'NO'}
- Avoid Highways: ${routePrefs.avoid_highways ? 'YES' : 'NO'}
- Prefer Faster Routes: ${routePrefs.prefer_faster_routes !== false ? 'YES' : 'NO'}

PREFERRED WORK ZONES (${workZones.length}):
${workZones.map((zone, i) => `
Zone ${i + 1}: ${zone.name}
- Center: ${zone.center_lat}, ${zone.center_lng}
- Radius: ${zone.radius_miles} miles
- Priority: ${zone.priority}/5 ${zone.priority >= 4 ? '⭐⭐⭐' : zone.priority >= 2 ? '⭐⭐' : '⭐'}
`).join('\n')}

JOBS TO ROUTE (${allJobs.length}):
${jobsWithMetrics.map((job, i) => `
Job ${i + 1} [${job.is_active ? '🔴 ACTIVE JOB' : '🟢 AVAILABLE REQUEST'}]:
- ID: ${job.id}
- Service: ${job.service_type.replace(/_/g, ' ').toUpperCase()}
- Location: ${job.location.address || `${job.location.lat}, ${job.location.lng}`}
- Distance: ${job.distance.toFixed(1)} miles
- Priority: ${job.priority.toUpperCase()} ${job.priority === 'critical' ? '🚨' : job.priority === 'high' ? '⚠️' : ''}
- Wait Time: ${Math.floor(job.wait_time)} minutes
- Est. Service Time: ${job.estimated_service_time} min
- Status: ${job.status.toUpperCase()}
- Vehicle: ${job.vehicle || 'N/A'}
- Travel Time (traffic-adjusted): ${Math.ceil(job.distance * 2 * trafficMultiplier)} min
`).join('\n')}

OPTIMIZATION PRIORITY:
1. CRITICAL: Active jobs (en_route) MUST be completed first
2. HIGH: Active assigned jobs should be prioritized
3. MEDIUM: Jobs in preferred work zones should be prioritized based on zone priority
4. LOW: Available requests can be picked up if they're on the route
5. Consider clustering available requests near active jobs to maximize efficiency
6. ${routePrefs.avoid_tolls ? 'Avoid toll roads in routing' : ''}
7. ${routePrefs.avoid_highways ? 'Prefer local roads over highways' : ''}
8. ${routePrefs.prefer_faster_routes !== false ? 'Optimize for fastest arrival times' : 'Balance speed and distance'}

PROVIDE:
1. Optimized job sequence (job IDs in order)
2. For EACH stop provide turn-by-turn directions from previous location
3. ETA for each stop
4. Total metrics (time, distance, time saved)
5. Recommendations

For turn-by-turn directions, provide step-by-step navigation like:
- "Head north on Main St for 0.5 miles"
- "Turn right onto Oak Ave"
- "Continue for 1.2 miles"
- "Destination will be on your left"`,
        response_json_schema: {
          type: 'object',
          properties: {
            optimized_order: {
              type: 'array',
              items: { type: 'string' }
            },
            stops: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  job_id: { type: 'string' },
                  eta: { type: 'string' },
                  distance_from_previous: { type: 'number' },
                  service_duration: { type: 'number' },
                  traffic_delay: { type: 'number' },
                  turn_by_turn: {
                    type: 'array',
                    items: { type: 'string' }
                  }
                }
              }
            },
            total_time: { type: 'number' },
            total_distance: { type: 'number' },
            time_saved: { type: 'number' },
            optimization_notes: { type: 'string' },
            recommendations: {
              type: 'array',
              items: { type: 'string' }
            }
          }
        }
      });

      // Build optimized route with full job details
      const optimizedStops = response.stops.map(stop => {
        const job = jobsWithMetrics.find(j => j.id === stop.job_id);
        return {
          ...job,
          eta: stop.eta,
          distance_from_previous: stop.distance_from_previous,
          service_duration: stop.service_duration,
          traffic_delay: stop.traffic_delay,
          turn_by_turn: stop.turn_by_turn || [],
          address: job.location.address
        };
      });

      setOptimizedRoute({
        stops: optimizedStops,
        total_time: response.total_time,
        total_distance: response.total_distance,
        time_saved: response.time_saved,
        optimization_notes: response.optimization_notes,
        recommendations: response.recommendations,
        current_location: currentLocation
      });

    } catch (error) {
      console.error('Route optimization error:', error);
      alert('Failed to optimize route. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleNavigate = (stop) => {
    if (stop === 'all') {
      // Open Google Maps with waypoints for all stops
      const waypoints = optimizedRoute.stops.slice(0, -1).map(s => `${s.location.lat},${s.location.lng}`).join('|');
      const lastStop = optimizedRoute.stops[optimizedRoute.stops.length - 1];
      const url = `https://www.google.com/maps/dir/?api=1&origin=${currentLocation.lat},${currentLocation.lng}&destination=${lastStop.location.lat},${lastStop.location.lng}&waypoints=${waypoints}&travelmode=driving`;
      window.open(url, '_blank');
    } else {
      // Navigate to single stop
      const url = `https://www.google.com/maps/dir/?api=1&origin=${currentLocation.lat},${currentLocation.lng}&destination=${stop.location.lat},${stop.location.lng}&travelmode=driving`;
      window.open(url, '_blank');
    }
  };

  const totalJobs = activeJobs.length + availableRequests.filter(req => {
    const distance = calculateDistance(
      currentLocation.lat, currentLocation.lng,
      req.location_lat, req.location_lng
    );
    return distance <= 15;
  }).slice(0, 3).length;

  if (totalJobs === 0) {
    return null;
  }

  if (totalJobs === 1) {
    return null; // No optimization needed for single job
  }

  return (
    <div className="space-y-4">
      {!optimizedRoute && (
        <Button
          onClick={optimizeRoute}
          disabled={loading}
          className="w-full text-white py-6 text-lg hover:opacity-90"
          style={{ backgroundColor: '#3D692B' }}
        >
          {loading ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Optimizing Multi-Stop Route...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 mr-2" />
              Optimize Route ({activeJobs.length} Active + {totalJobs - activeJobs.length} Available)
            </>
          )}
        </Button>
      )}

      {optimizedRoute && (
        <OptimizedRouteDisplay 
          route={optimizedRoute} 
          onNavigate={handleNavigate}
          currentLocation={currentLocation}
        />
      )}
    </div>
  );
}