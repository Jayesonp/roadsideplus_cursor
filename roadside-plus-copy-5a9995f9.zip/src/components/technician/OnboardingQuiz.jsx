import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, Award } from 'lucide-react';

export default function OnboardingQuiz({ onComplete }) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);

  const questions = [
    {
      question: 'What should you do FIRST when arriving at a service location?',
      options: [
        'Start working on the vehicle immediately',
        'Set up safety equipment and verify the customer',
        'Take photos of the vehicle',
        'Call the support team'
      ],
      correct: 1
    },
    {
      question: 'How should you communicate with customers during service?',
      options: [
        'Only speak when asked',
        'Keep them informed about the progress',
        'Work silently to save time',
        'Only communicate through the app'
      ],
      correct: 1
    },
    {
      question: 'What is the proper way to handle payment?',
      options: [
        'Request cash tips upfront',
        'All payments are processed through the app',
        'Ask for payment before starting service',
        'Accept personal checks'
      ],
      correct: 1
    },
    {
      question: 'When should you update your job status in the app?',
      options: [
        'Only at the end of the job',
        'Never, the system updates automatically',
        'At each stage of the service',
        'Only when the customer asks'
      ],
      correct: 2
    },
    {
      question: 'What should you do if you encounter an issue during service?',
      options: [
        'Try to fix it without telling anyone',
        'Cancel the job immediately',
        'Contact support through the app and inform the customer',
        'Leave the job site'
      ],
      correct: 2
    }
  ];

  const handleAnswer = (optionIndex) => {
    setAnswers({ ...answers, [currentQuestion]: optionIndex });
    
    if (currentQuestion < questions.length - 1) {
      setTimeout(() => setCurrentQuestion(currentQuestion + 1), 300);
    } else {
      setTimeout(() => setShowResults(true), 300);
    }
  };

  const calculateScore = () => {
    let correct = 0;
    questions.forEach((q, index) => {
      if (answers[index] === q.correct) correct++;
    });
    return (correct / questions.length) * 100;
  };

  const handleRetry = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
  };

  if (showResults) {
    const score = calculateScore();
    const passed = score >= 80;

    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="w-5 h-5" style={{ color: passed ? '#3D692B' : '#E52C2D' }} />
            Quiz Results
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center space-y-6">
            <div>
              <div className="text-6xl font-bold mb-2" style={{ color: passed ? '#3D692B' : '#E52C2D' }}>
                {score.toFixed(0)}%
              </div>
              <p className="text-lg font-semibold">
                {passed ? '🎉 Congratulations!' : 'Keep Learning'}
              </p>
              <p className="text-gray-600 mt-2">
                {passed
                  ? 'You passed the knowledge test!'
                  : 'You need 80% to pass. Review the training materials and try again.'}
              </p>
            </div>

            <div className="space-y-3">
              {questions.map((q, index) => {
                const isCorrect = answers[index] === q.correct;
                return (
                  <div key={index} className="flex items-center gap-2 text-sm">
                    {isCorrect ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-600" />
                    )}
                    <span className={isCorrect ? 'text-green-800' : 'text-red-800'}>
                      Question {index + 1}: {isCorrect ? 'Correct' : 'Incorrect'}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="flex gap-3">
              {passed ? (
                <Button
                  onClick={() => onComplete(true)}
                  className="flex-1 text-white"
                  style={{ backgroundColor: '#3D692B' }}
                >
                  Continue to Next Step
                </Button>
              ) : (
                <>
                  <Button
                    variant="outline"
                    onClick={handleRetry}
                    className="flex-1"
                  >
                    Retry Quiz
                  </Button>
                  <Button
                    onClick={() => onComplete(false)}
                    className="flex-1"
                    style={{ backgroundColor: '#FF771D' }}
                  >
                    Review Training
                  </Button>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const question = questions[currentQuestion];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Award className="w-5 h-5" style={{ color: '#FF771D' }} />
          Knowledge Test
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Progress */}
          <div className="flex items-center justify-between text-sm text-gray-600">
            <span>Question {currentQuestion + 1} of {questions.length}</span>
            <span>{Object.keys(answers).length} answered</span>
          </div>

          <div className="flex gap-2">
            {questions.map((_, index) => (
              <div
                key={index}
                className={`flex-1 h-2 rounded-full ${
                  answers[index] !== undefined
                    ? 'bg-green-500'
                    : index === currentQuestion
                    ? 'bg-orange-500'
                    : 'bg-gray-200'
                }`}
              />
            ))}
          </div>

          {/* Question */}
          <div>
            <h3 className="text-lg font-semibold mb-4">{question.question}</h3>
            <div className="space-y-3">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswer(index)}
                  className="w-full text-left p-4 border-2 rounded-lg hover:border-orange-500 hover:bg-orange-50 transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-6 h-6 rounded-full border-2 flex items-center justify-center"
                      style={{ borderColor: '#FF771D' }}
                    >
                      <span className="text-sm font-semibold">{String.fromCharCode(65 + index)}</span>
                    </div>
                    <span>{option}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}