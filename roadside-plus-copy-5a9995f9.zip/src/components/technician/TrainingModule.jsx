import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BookOpen, CheckCircle, ChevronRight } from 'lucide-react';

export default function TrainingModule({ onComplete }) {
  const [currentModule, setCurrentModule] = useState(0);
  const [completedModules, setCompletedModules] = useState([]);

  const modules = [
    {
      title: 'Safety Protocols',
      content: `
        **Personal Safety First**
        - Always wear high-visibility clothing
        - Use proper safety equipment
        - Be aware of traffic at all times
        - Set up warning triangles or flares

        **Customer Safety**
        - Verify identity before starting service
        - Maintain professional distance
        - Follow COVID-19 protocols
        - Report any safety concerns immediately
      `
    },
    {
      title: 'Service Standards',
      content: `
        **Professional Conduct**
        - Arrive within estimated time
        - Introduce yourself professionally
        - Explain the service process
        - Keep customer informed

        **Quality Service**
        - Inspect the issue thoroughly
        - Use proper tools and equipment
        - Document before/after with photos
        - Verify customer satisfaction
      `
    },
    {
      title: 'App Usage',
      content: `
        **Accepting Jobs**
        - Check job details carefully
        - Estimate arrival time accurately
        - Update status as you progress
        - Use in-app navigation

        **Communication**
        - Use in-app chat for updates
        - Call customer if needed
        - Report issues immediately
        - Complete job documentation
      `
    },
    {
      title: 'Payment & Ratings',
      content: `
        **Payment Process**
        - Payment is handled through the app
        - Tips are appreciated but optional
        - Earnings are tracked in real-time
        - Payouts occur weekly

        **Customer Ratings**
        - Ratings impact your visibility
        - Respond professionally to feedback
        - Maintain high service standards
        - Contact support for rating disputes
      `
    }
  ];

  const handleModuleComplete = () => {
    if (!completedModules.includes(currentModule)) {
      setCompletedModules([...completedModules, currentModule]);
    }

    if (currentModule < modules.length - 1) {
      setCurrentModule(currentModule + 1);
    } else {
      onComplete();
    }
  };

  const currentContent = modules[currentModule];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="w-5 h-5" style={{ color: '#FF771D' }} />
          Training Modules
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Progress */}
          <div className="flex gap-2">
            {modules.map((_, index) => (
              <div
                key={index}
                className={`flex-1 h-2 rounded-full ${
                  completedModules.includes(index)
                    ? 'bg-green-500'
                    : index === currentModule
                    ? 'bg-orange-500'
                    : 'bg-gray-200'
                }`}
              />
            ))}
          </div>

          {/* Module Content */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">{currentContent.title}</h3>
              <span className="text-sm text-gray-600">
                Module {currentModule + 1} of {modules.length}
              </span>
            </div>

            <div className="prose prose-sm max-w-none">
              {currentContent.content.split('\n\n').map((section, idx) => {
                if (section.trim().startsWith('**')) {
                  const title = section.match(/\*\*(.*?)\*\*/)[1];
                  const items = section
                    .split('\n')
                    .slice(1)
                    .filter(line => line.trim())
                    .map(line => line.replace('- ', ''));
                  
                  return (
                    <div key={idx} className="mb-6">
                      <h4 className="font-semibold mb-2" style={{ color: '#FF771D' }}>
                        {title}
                      </h4>
                      <ul className="space-y-2">
                        {items.map((item, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: '#3D692B' }} />
                            <span className="text-gray-700">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  );
                }
                return null;
              })}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between pt-4">
            <Button
              variant="outline"
              onClick={() => setCurrentModule(Math.max(0, currentModule - 1))}
              disabled={currentModule === 0}
            >
              Previous
            </Button>

            <Button
              onClick={handleModuleComplete}
              className="text-white"
              style={{ backgroundColor: '#FF771D' }}
            >
              {currentModule === modules.length - 1 ? (
                'Complete Training'
              ) : (
                <>
                  Next Module
                  <ChevronRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}