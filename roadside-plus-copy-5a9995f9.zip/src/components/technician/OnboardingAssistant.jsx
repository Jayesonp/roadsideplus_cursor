import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { MessageCircle, Send, Loader2, Sparkles } from 'lucide-react';

export default function OnboardingAssistant({ currentStep }) {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: 'Hi! I\'m your onboarding assistant. I can answer any questions about the training material, procedures, safety protocols, or anything else related to your onboarding. How can I help?'
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const conversationHistory = messages.map(m => `${m.role === 'user' ? 'Technician' : 'Assistant'}: ${m.content}`).join('\n');
      
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an onboarding assistant for ROADSIDEPLUS technicians. You help new technicians understand procedures, answer questions about training material, and provide guidance.

Current onboarding step: ${currentStep?.title || 'Not specified'}

Your knowledge includes:
- Tire change procedures and safety
- Battery jump-start techniques and protocols
- Fuel delivery procedures and safety
- General roadside assistance best practices
- Customer service guidelines
- Safety protocols and emergency procedures

Previous conversation:
${conversationHistory}

Technician's question: ${input}

Provide a helpful, clear, and concise response. Be encouraging and supportive. If the question is outside your knowledge area, be honest and suggest they contact their supervisor.`,
        response_json_schema: {
          type: 'object',
          properties: {
            message: {
              type: 'string',
              description: 'Your helpful response'
            }
          }
        }
      });

      setMessages(prev => [...prev, { role: 'assistant', content: response.message }]);
    } catch (error) {
      console.error('Assistant error:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try asking your question again.'
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="sticky top-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Sparkles className="w-5 h-5" style={{ color: '#FF771D' }} />
          AI Assistant
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Messages */}
        <div className="h-[400px] overflow-y-auto space-y-3 pr-2">
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[90%] rounded-2xl px-3 py-2 text-sm ${
                  msg.role === 'user'
                    ? 'text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}
                style={msg.role === 'user' ? { backgroundColor: '#FF771D' } : {}}
              >
                {msg.content}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-gray-100 rounded-2xl px-3 py-2">
                <Loader2 className="w-4 h-4 animate-spin" style={{ color: '#FF771D' }} />
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="flex gap-2">
          <Textarea
            placeholder="Ask a question..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            className="flex-1 min-h-[60px] max-h-[100px] resize-none text-sm"
            disabled={loading}
          />
          <Button
            onClick={sendMessage}
            disabled={!input.trim() || loading}
            size="icon"
            className="text-white hover:opacity-90"
            style={{ backgroundColor: '#FF771D' }}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}