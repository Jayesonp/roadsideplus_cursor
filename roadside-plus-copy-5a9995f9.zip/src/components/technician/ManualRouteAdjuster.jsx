import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowUp, ArrowDown, Trash2, Save, RotateCcw } from 'lucide-react';

export default function ManualRouteAdjuster({ route, onSave, onReset }) {
  const [stops, setStops] = useState(route?.stops || []);
  const [hasChanges, setHasChanges] = useState(false);

  const moveUp = (index) => {
    if (index === 0) return;
    const newStops = [...stops];
    [newStops[index], newStops[index - 1]] = [newStops[index - 1], newStops[index]];
    setStops(newStops);
    setHasChanges(true);
  };

  const moveDown = (index) => {
    if (index === stops.length - 1) return;
    const newStops = [...stops];
    [newStops[index], newStops[index + 1]] = [newStops[index + 1], newStops[index]];
    setStops(newStops);
    setHasChanges(true);
  };

  const removeStop = (index) => {
    const newStops = stops.filter((_, i) => i !== index);
    setStops(newStops);
    setHasChanges(true);
  };

  const handleSave = () => {
    onSave({ ...route, stops });
    setHasChanges(false);
  };

  const handleReset = () => {
    setStops(route?.stops || []);
    setHasChanges(false);
    onReset();
  };

  if (!route || stops.length === 0) return null;

  return (
    <Card className="border-2" style={{ borderColor: '#FF771D' }}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Manual Route Adjustment</CardTitle>
          <div className="flex gap-2">
            {hasChanges && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleReset}
                  className="text-gray-600"
                >
                  <RotateCcw className="w-4 h-4 mr-1" />
                  Reset
                </Button>
                <Button
                  size="sm"
                  onClick={handleSave}
                  style={{ backgroundColor: '#3D692B' }}
                  className="text-white"
                >
                  <Save className="w-4 h-4 mr-1" />
                  Save Changes
                </Button>
              </>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {stops.map((stop, index) => (
            <div
              key={stop.job_id || index}
              className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg border"
            >
              <div className="flex flex-col gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={() => moveUp(index)}
                  disabled={index === 0}
                >
                  <ArrowUp className="w-3 h-3" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={() => moveDown(index)}
                  disabled={index === stops.length - 1}
                >
                  <ArrowDown className="w-3 h-3" />
                </Button>
              </div>

              <div className="flex items-center gap-2 flex-1">
                <span
                  className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                  style={{ backgroundColor: stop.is_active ? '#E52C2D' : '#3D692B' }}
                >
                  {index + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <h5 className="font-semibold text-sm truncate">
                    {stop.service_type?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </h5>
                  <p className="text-xs text-gray-500 truncate">{stop.address}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs font-semibold" style={{ color: '#FF771D' }}>
                    {stop.distance?.toFixed(1)} mi
                  </p>
                  <p className="text-xs text-gray-500">{stop.estimated_service_time} min</p>
                </div>
              </div>

              <Button
                variant="ghost"
                size="icon"
                className="text-red-600 hover:bg-red-50 flex-shrink-0"
                onClick={() => removeStop(index)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>

        {hasChanges && (
          <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-xs text-yellow-800">
              ⚠️ You have unsaved changes. Save to update your route or reset to discard.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}