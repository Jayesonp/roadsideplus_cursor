import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, Star, DollarSign, Zap, Medal, Crown } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function Leaderboard({ currentTechnicianId }) {
  const [period, setPeriod] = useState('month');

  const { data: technicians = [] } = useQuery({
    queryKey: ['leaderboard', period],
    queryFn: async () => {
      const profiles = await base44.entities.TechnicianProfile.filter({}, '-rating', 100);
      const users = await base44.entities.User.filter({}, '-created_date', 100);
      
      // Get jobs for each technician
      const techsWithStats = await Promise.all(
        profiles.map(async (profile) => {
          const jobs = await base44.entities.ServiceRequest.filter({
            technician_id: profile.user_id,
            status: 'completed'
          }, '-completed_at', 200);

          // Filter by period
          const now = new Date();
          const filteredJobs = jobs.filter(job => {
            if (!job.completed_at) return false;
            const completedDate = new Date(job.completed_at);
            
            if (period === 'week') {
              const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
              return completedDate >= weekAgo;
            } else if (period === 'month') {
              const monthAgo = new Date(now.getFullYear(), now.getMonth(), 1);
              return completedDate >= monthAgo;
            } else {
              return true; // all time
            }
          });

          const earnings = filteredJobs.reduce((sum, job) => sum + (job.payment_amount || job.price || 0), 0);
          const user = users.find(u => u.id === profile.user_id);

          return {
            id: profile.user_id,
            name: user?.full_name || 'Technician',
            rating: profile.rating || 5.0,
            totalJobs: profile.total_jobs || 0,
            periodJobs: filteredJobs.length,
            earnings: earnings,
            avgRating: profile.rating || 5.0
          };
        })
      );

      return techsWithStats;
    },
    enabled: true
  });

  const leaderboards = {
    jobs: {
      title: 'Most Jobs',
      icon: Zap,
      color: '#FF771D',
      data: [...technicians].sort((a, b) => b.periodJobs - a.periodJobs),
      valueKey: 'periodJobs',
      suffix: ' jobs'
    },
    rating: {
      title: 'Highest Rated',
      icon: Star,
      color: '#FFB800',
      data: [...technicians].sort((a, b) => b.avgRating - a.avgRating),
      valueKey: 'avgRating',
      suffix: ' ⭐',
      decimals: 1
    },
    earnings: {
      title: 'Top Earners',
      icon: DollarSign,
      color: '#10B981',
      data: [...technicians].sort((a, b) => b.earnings - a.earnings),
      valueKey: 'earnings',
      prefix: '$',
      suffix: ''
    }
  };

  const getRankIcon = (rank) => {
    if (rank === 0) return <Crown className="w-5 h-5 text-yellow-500" />;
    if (rank === 1) return <Medal className="w-5 h-5 text-gray-400" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-amber-700" />;
    return <span className="text-gray-500 font-semibold">{rank + 1}</span>;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            Leaderboard
          </CardTitle>
          <Tabs value={period} onValueChange={setPeriod}>
            <TabsList className="h-8">
              <TabsTrigger value="week" className="text-xs">Week</TabsTrigger>
              <TabsTrigger value="month" className="text-xs">Month</TabsTrigger>
              <TabsTrigger value="all" className="text-xs">All Time</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="jobs">
          <TabsList className="grid w-full grid-cols-3 mb-4">
            <TabsTrigger value="jobs">Jobs</TabsTrigger>
            <TabsTrigger value="rating">Rating</TabsTrigger>
            <TabsTrigger value="earnings">Earnings</TabsTrigger>
          </TabsList>

          {Object.entries(leaderboards).map(([key, board]) => (
            <TabsContent key={key} value={key} className="space-y-3">
              {board.data.slice(0, 10).map((tech, idx) => {
                const isCurrentUser = tech.id === currentTechnicianId;
                const value = board.decimals 
                  ? tech[board.valueKey].toFixed(board.decimals)
                  : Math.round(tech[board.valueKey]);

                return (
                  <div 
                    key={tech.id}
                    className={`flex items-center justify-between p-3 rounded-lg border transition-all ${
                      isCurrentUser 
                        ? 'bg-orange-50 border-orange-300 border-2' 
                        : 'bg-white hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 flex items-center justify-center">
                        {getRankIcon(idx)}
                      </div>
                      <div>
                        <p className={`font-semibold ${isCurrentUser ? 'text-orange-900' : ''}`}>
                          {tech.name}
                          {isCurrentUser && (
                            <Badge className="ml-2 text-xs" style={{ backgroundColor: '#FF771D' }}>
                              You
                            </Badge>
                          )}
                        </p>
                        <p className="text-xs text-gray-500">
                          {tech.totalJobs} total jobs
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg" style={{ color: board.color }}>
                        {board.prefix}{value}{board.suffix}
                      </p>
                    </div>
                  </div>
                );
              })}
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}