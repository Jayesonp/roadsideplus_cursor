import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Navigation, Clock, AlertTriangle, TrendingUp, 
  MapPin, Zap, Loader2, Route 
} from 'lucide-react';

export default function SmartRouteOptimizer({ technicianId, currentLocation, activeJobs = [] }) {
  const [routeSuggestion, setRouteSuggestion] = useState(null);
  const [loading, setLoading] = useState(false);

  const { data: allPendingJobs = [] } = useQuery({
    queryKey: ['pending-jobs-for-route'],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter(
        { status: 'pending_dispatch' },
        '-priority_score'
      );
    },
    enabled: !!technicianId,
    refetchInterval: 60000
  });

  useEffect(() => {
    if (currentLocation && (activeJobs.length > 0 || allPendingJobs.length > 0)) {
      optimizeRoute();
    }
  }, [currentLocation, activeJobs.length, allPendingJobs.length]);

  const calculateDistance = (lat1, lng1, lat2, lng2) => {
    const R = 3959;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const getTrafficMultiplier = () => {
    const hour = new Date().getHours();
    // Rush hour multipliers
    if ((hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 18)) {
      return 1.5;
    }
    // Lunch hour
    if (hour >= 12 && hour <= 13) {
      return 1.2;
    }
    return 1.0;
  };

  const optimizeRoute = async () => {
    if (!currentLocation) return;

    setLoading(true);
    try {
      const trafficMultiplier = getTrafficMultiplier();
      const currentHour = new Date().getHours();

      // Combine active and nearby pending jobs
      const nearbyPending = allPendingJobs
        .filter(job => {
          const distance = calculateDistance(
            currentLocation.lat,
            currentLocation.lng,
            job.location_lat,
            job.location_lng
          );
          return distance < 15; // Within 15 miles
        })
        .map(job => ({
          ...job,
          distance: calculateDistance(
            currentLocation.lat,
            currentLocation.lng,
            job.location_lat,
            job.location_lng
          )
        }));

      const allJobs = [...activeJobs, ...nearbyPending];

      if (allJobs.length === 0) {
        setRouteSuggestion(null);
        return;
      }

      // Use AI for intelligent route optimization
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert logistics AI optimizing routes for a roadside assistance technician.

CURRENT SITUATION:
- Technician Location: ${currentLocation.lat.toFixed(4)}, ${currentLocation.lng.toFixed(4)}
- Current Time: ${new Date().toLocaleTimeString()}
- Traffic Conditions: ${trafficMultiplier > 1.3 ? 'Heavy' : trafficMultiplier > 1.1 ? 'Moderate' : 'Light'}

JOBS TO OPTIMIZE:
${allJobs.map((job, i) => `
${i + 1}. ${job.service_type.replace(/_/g, ' ')} - ${job.distance?.toFixed(1) || 'N/A'} miles away
   Priority: ${job.priority || 'normal'} (Score: ${job.priority_score || 50})
   Status: ${job.status}
   Location: ${job.location_address || 'Set'}
   Estimated Travel: ${Math.round((job.distance || 5) * trafficMultiplier * 3)} min
`).join('\n')}

Provide an optimized route considering:
1. Job priority and urgency (critical jobs first)
2. Distance and traffic conditions
3. Job status (active jobs have higher priority)
4. Time efficiency (minimize total travel time)
5. Customer wait times
6. Revenue optimization (group nearby jobs)

Suggest the best route sequence and explain your reasoning.`,
        response_json_schema: {
          type: 'object',
          properties: {
            recommended_sequence: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  job_index: { type: 'number' },
                  reason: { type: 'string' }
                }
              }
            },
            total_estimated_time: { type: 'string' },
            total_distance: { type: 'string' },
            optimization_strategy: { type: 'string' },
            traffic_impact: { type: 'string' },
            revenue_potential: { type: 'string' },
            alternative_suggestion: { type: 'string' },
            key_insights: {
              type: 'array',
              items: { type: 'string' }
            }
          }
        }
      });

      setRouteSuggestion({
        ...response,
        jobs: allJobs
      });
    } catch (error) {
      console.error('Route optimization error:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!currentLocation) return null;

  return (
    <Card className="border-2" style={{ borderColor: '#3D692B' }}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Route className="w-5 h-5" style={{ color: '#3D692B' }} />
            Smart Route Optimizer
          </CardTitle>
          <Button
            size="sm"
            onClick={optimizeRoute}
            disabled={loading}
            style={{ backgroundColor: '#3D692B' }}
            className="text-white"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                Optimizing...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-1" />
                Optimize
              </>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin" style={{ color: '#3D692B' }} />
            <span className="ml-2">Analyzing optimal route with traffic data...</span>
          </div>
        ) : routeSuggestion ? (
          <div className="space-y-4">
            {/* Overview */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-blue-50 rounded-lg p-3 text-center">
                <Clock className="w-5 h-5 mx-auto mb-1 text-blue-600" />
                <p className="text-xs text-gray-600">Total Time</p>
                <p className="font-bold text-sm">{routeSuggestion.total_estimated_time}</p>
              </div>
              <div className="bg-purple-50 rounded-lg p-3 text-center">
                <Navigation className="w-5 h-5 mx-auto mb-1 text-purple-600" />
                <p className="text-xs text-gray-600">Distance</p>
                <p className="font-bold text-sm">{routeSuggestion.total_distance}</p>
              </div>
              <div className="bg-green-50 rounded-lg p-3 text-center">
                <TrendingUp className="w-5 h-5 mx-auto mb-1 text-green-600" />
                <p className="text-xs text-gray-600">Revenue</p>
                <p className="font-bold text-sm">{routeSuggestion.revenue_potential}</p>
              </div>
            </div>

            {/* Strategy */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Zap className="w-4 h-4" style={{ color: '#3D692B' }} />
                Optimization Strategy
              </h4>
              <p className="text-sm text-gray-700 mb-3">{routeSuggestion.optimization_strategy}</p>
              <p className="text-xs text-gray-600">
                <strong>Traffic Impact:</strong> {routeSuggestion.traffic_impact}
              </p>
            </div>

            {/* Recommended Sequence */}
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Route className="w-4 h-4" />
                Recommended Route Sequence
              </h4>
              <div className="space-y-2">
                {routeSuggestion.recommended_sequence?.map((item, i) => {
                  const job = routeSuggestion.jobs[item.job_index];
                  if (!job) return null;

                  return (
                    <div key={i} className="flex items-start gap-3 p-3 bg-white border rounded-lg">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 font-bold text-white"
                           style={{ backgroundColor: i === 0 ? '#E52C2D' : i === 1 ? '#FF771D' : '#3D692B' }}>
                        {i + 1}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-semibold text-sm">
                            {job.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                          </p>
                          {job.priority && job.priority !== 'normal' && (
                            <Badge className={
                              job.priority === 'critical' ? 'bg-red-600' :
                              job.priority === 'high' ? 'bg-orange-600' :
                              'bg-yellow-600'
                            }>
                              {job.priority}
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-gray-600 mb-1">
                          📍 {job.distance?.toFixed(1)} miles • Est. {Math.round(job.distance * getTrafficMultiplier() * 3)} min
                        </p>
                        <p className="text-xs text-gray-700 italic">{item.reason}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Key Insights */}
            {routeSuggestion.key_insights?.length > 0 && (
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <h5 className="font-semibold mb-2">💡 Key Insights</h5>
                <ul className="space-y-1 text-sm">
                  {routeSuggestion.key_insights.map((insight, i) => (
                    <li key={i}>• {insight}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Alternative */}
            {routeSuggestion.alternative_suggestion && (
              <div className="bg-gray-50 border border-gray-300 rounded-lg p-3">
                <p className="text-xs text-gray-600 mb-1">Alternative:</p>
                <p className="text-sm text-gray-700">{routeSuggestion.alternative_suggestion}</p>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-6 text-gray-500">
            <Route className="w-12 h-12 mx-auto mb-2 text-gray-300" />
            <p className="text-sm">No jobs to optimize. Accept jobs to see route suggestions.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}