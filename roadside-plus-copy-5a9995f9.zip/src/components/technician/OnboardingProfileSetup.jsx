import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { User, Upload, Loader2 } from 'lucide-react';

export default function OnboardingProfileSetup({ profile, user, onComplete }) {
  const [formData, setFormData] = useState({
    phone: profile.phone || user.phone || '',
    vehicle_type: profile.vehicle_type || '',
    license_plate: profile.license_plate || '',
    bio: profile.bio || ''
  });
  const [profilePicture, setProfilePicture] = useState(null);
  const [uploading, setUploading] = useState(false);

  const updateProfile = useMutation({
    mutationFn: async () => {
      let profilePictureUrl = profile.profile_picture;

      if (profilePicture) {
        setUploading(true);
        const { file_url } = await base44.integrations.Core.UploadFile({ file: profilePicture });
        profilePictureUrl = file_url;
        setUploading(false);
      }

      const updated = await base44.entities.TechnicianProfile.update(profile.id, {
        ...formData,
        profile_picture: profilePictureUrl
      });

      return updated;
    },
    onSuccess: (updated) => {
      onComplete(updated);
    }
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User className="w-5 h-5" style={{ color: '#FF771D' }} />
          Profile Setup
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            updateProfile.mutate();
          }}
          className="space-y-4"
        >
          {/* Profile Picture */}
          <div>
            <label className="text-sm font-medium mb-2 block">Profile Picture</label>
            <div className="flex items-center gap-4">
              {(profile.profile_picture || profilePicture) && (
                <img
                  src={profilePicture ? URL.createObjectURL(profilePicture) : profile.profile_picture}
                  alt="Profile"
                  className="w-20 h-20 rounded-full object-cover"
                />
              )}
              <input
               type="file"
               id="profile-picture-upload"
               accept="image/*"
               className="hidden"
               onChange={(e) => {
                 if (e.target.files && e.target.files[0]) {
                   setProfilePicture(e.target.files[0]);
                 }
               }}
              />
              <Button 
               type="button" 
               variant="outline"
               onClick={() => document.getElementById('profile-picture-upload').click()}
              >
               <Upload className="w-4 h-4 mr-2" />
               Upload Photo
              </Button>
            </div>
          </div>

          {/* Phone */}
          <div>
            <label className="text-sm font-medium mb-2 block">Phone Number *</label>
            <Input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="+1 (555) 123-4567"
              required
            />
          </div>

          {/* Vehicle Type */}
          <div>
            <label className="text-sm font-medium mb-2 block">Vehicle Type *</label>
            <Input
              value={formData.vehicle_type}
              onChange={(e) => setFormData({ ...formData, vehicle_type: e.target.value })}
              placeholder="e.g., Tow Truck, Service Van"
              required
            />
          </div>

          {/* License Plate */}
          <div>
            <label className="text-sm font-medium mb-2 block">License Plate *</label>
            <Input
              value={formData.license_plate}
              onChange={(e) => setFormData({ ...formData, license_plate: e.target.value })}
              placeholder="ABC-1234"
              required
            />
          </div>

          {/* Bio */}
          <div>
            <label className="text-sm font-medium mb-2 block">About You</label>
            <Textarea
              value={formData.bio}
              onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
              placeholder="Tell customers about your experience and specialties..."
              rows={4}
            />
          </div>

          <Button
            type="submit"
            disabled={updateProfile.isLoading || uploading}
            className="w-full text-white"
            style={{ backgroundColor: '#FF771D' }}
          >
            {updateProfile.isLoading || uploading ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
            ) : (
              'Save & Continue'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}