import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, Clock, DollarSign, Navigation } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import ServiceTypeIcon from '../common/ServiceTypeIcon';
import { handleTechnicianResponse } from '../dispatch/DispatchEngine';

export default function IncomingJobScreen({ request, onAccept, onReject, onTimeout }) {
  const [timeLeft, setTimeLeft] = useState(60);
  const [isResponding, setIsResponding] = useState(false);
  const audioRef = useRef(null);

  useEffect(() => {
    // Play alert sound on mount using Audio constructor safely
    if (typeof Audio !== 'undefined') {
      let alertSound = null;
      try {
        alertSound = new Audio("data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjtZq+rXnlAOFVq37t+hVBELTaHh7beRQAcyh9Xz0opaEw5ftu3cqWwgCz2Q1/LQgiwHJnvE8N2YRA4XZrLq36hUEgpJpuLyo10aDD2Y2/PBdiYFLYTO8tyJNgYYa7vo6ZJBAhBNo+XxsmYdBj2V2vPDeSgHK37Q8d+NOwcdfrPr46VTEQlGo+XuqWEcBD2W2/K9cSMHLH3J8dyLOQgZaLrrwnYoCzqJ1/PTdCkGKXzI8N+YQg4WZrTq4qtXFQpLqOXxsmYdBTmT2vLAfSUEKnzP8d2QQQ0VYbbr4qtXFQpLp+Hzr2ImBTqV2/PEeyYEKXvI8N+SQw0WZrTp5K5aFwxHpeLxsmQdBj2X2vLDeSgHKX3Q8d2NOwcdfrTq46VTEQlGo+XuqWAcBT6W2/O/dCQGLH7J8tyKOggbabvo6ZJBA1BNo+XxsWUdBj2V2vLDeSgGK3/Q8N6NOwcdfbLq46VTEQlFouXvqV8cBT+Y2/O/ciIGLIHN8dyKOQgbaLvn5pJBAhJPp+Tyr2EcBT6V2vPDeCgGK37Q8t6MOQgbbr/s46NXEQlHouXvqGAcBT+Y2vLCdyQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOg==");
      } catch (e) {
        console.warn('Audio blocked:', e);
      }

      if (alertSound) {
        alertSound.loop = true;
        alertSound.play().catch(err => console.log('Audio play failed:', err));
        audioRef.current = alertSound;
      }
    }

    // Countdown timer
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleTimeout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      clearInterval(timer);
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
    };
  }, []);

  const handleTimeout = () => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    onTimeout?.();
  };

  const handleAccept = async () => {
    if (isResponding) return;
    setIsResponding(true);
    
    if (audioRef.current) {
      audioRef.current.pause();
    }

    const result = await handleTechnicianResponse(request.id, request.current_offered_technician_id, true);
    
    if (result.success) {
      onAccept?.();
    } else {
      alert(result.message);
      setIsResponding(false);
    }
  };

  const handleReject = async () => {
    if (isResponding) return;
    setIsResponding(true);
    
    if (audioRef.current) {
      audioRef.current.pause();
    }

    await handleTechnicianResponse(request.id, request.current_offered_technician_id, false);
    onReject?.();
  };

  const distance = request.distance ? `${request.distance.toFixed(1)} km away` : 'Nearby';

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
      >
        {/* Alert sound (silent audio element, actual sound would need audio file) */}
        <audio ref={audioRef} src="data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjtZq+rXnlAOFVq37t+hVBELTaHh7beRQAcyh9Xz0opaEw5ftu3cqWwgCz2Q1/LQgiwHJnvE8N2YRA4XZrLq36hUEgpJpuLyo10aDD2Y2/PBdiYFLYTO8tyJNgYYa7vo6ZJBAhBNo+XxsmYdBj2V2vPDeSgHK37Q8d+NOwcdfrPr46VTEQlGo+XuqWEcBD2W2/K9cSMHLH3J8dyLOQgZaLrrwnYoCzqJ1/PTdCkGKXzI8N+YQg4WZrTq4qtXFQpLqOXxsmYdBTmT2vLAfSUEKnzP8d2QQQ0VYbbr4qtXFQpLp+Hzr2ImBTqV2/PEeyYEKXvI8N+SQw0WZrTp5K5aFwxHpeLxsmQdBj2X2vLDeSgHKX3Q8d2NOwcdfrTq46VTEQlGo+XuqWAcBT6W2/O/dCQGLH7J8tyKOggbabvo6ZJBA1BNo+XxsWUdBj2V2vLDeSgGK3/Q8N6NOwcdfbLq46VTEQlFouXvqV8cBT+Y2/O/ciIGLIHN8dyKOQgbaLvn5pJBAhJPp+Tyr2EcBT6V2vPDeCgGK37Q8t6MOQgbbr/s46NXEQlHouXvqGAcBT+Y2vLCdyQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOgkcabvn5pFBAxJPp+PwsGMdBTyV2vLDeCgGK37Q8d6MOQgbbr/r46JYEQpHouXvqGAcBT+Y2vLCeCQGLIDN8dyJOg==" />

        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="w-full max-w-md"
        >
          <Card className="border-4" style={{ borderColor: '#FF771D' }}>
            <CardHeader className="text-white text-center" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
              <motion.div
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ repeat: Infinity, duration: 1 }}
              >
                <CardTitle className="text-2xl font-bold">New Job Offer!</CardTitle>
              </motion.div>
              <div className="mt-4 flex items-center justify-center gap-2">
                <Clock className="w-6 h-6" />
                <motion.span
                  className="text-3xl font-bold"
                  animate={{ opacity: timeLeft < 10 ? [1, 0.5, 1] : 1 }}
                  transition={{ repeat: timeLeft < 10 ? Infinity : 0, duration: 0.5 }}
                >
                  {timeLeft}s
                </motion.span>
              </div>
            </CardHeader>

            <CardContent className="p-6 space-y-4">
              {/* Service Type */}
              <div className="flex items-center justify-center gap-3 p-4 bg-gray-50 rounded-lg">
                <ServiceTypeIcon type={request.service_type} className="w-8 h-8" />
                <span className="text-xl font-semibold">
                  {request.service_type.replace(/_/g, ' ').toUpperCase()}
                </span>
              </div>

              {/* Location */}
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <MapPin className="w-5 h-5" style={{ color: '#FF771D' }} />
                <div>
                  <p className="text-sm text-gray-600">Location</p>
                  <p className="font-semibold">{distance}</p>
                  {request.location_address && (
                    <p className="text-xs text-gray-500">{request.location_address}</p>
                  )}
                </div>
              </div>

              {/* Estimated Payout */}
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                <DollarSign className="w-5 h-5" style={{ color: '#3D692B' }} />
                <div>
                  <p className="text-sm text-gray-600">Estimated Payout</p>
                  <p className="text-xl font-bold" style={{ color: '#3D692B' }}>
                    ${request.price ? request.price.toFixed(2) : '50.00'}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3 pt-4">
                <Button
                  onClick={handleReject}
                  disabled={isResponding}
                  variant="outline"
                  className="h-14 text-lg font-semibold border-2"
                  style={{ borderColor: '#E52C2D', color: '#E52C2D' }}
                >
                  Decline
                </Button>
                <Button
                  onClick={handleAccept}
                  disabled={isResponding}
                  className="h-14 text-lg font-semibold text-white"
                  style={{ backgroundColor: '#FF771D' }}
                >
                  {isResponding ? 'Accepting...' : 'Accept'}
                </Button>
              </div>

              {/* Navigation hint */}
              <p className="text-xs text-center text-gray-500 pt-2">
                <Navigation className="w-3 h-3 inline mr-1" />
                Full navigation will be available after accepting
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}