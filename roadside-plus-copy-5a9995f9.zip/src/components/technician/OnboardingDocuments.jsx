import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, FileText, CheckCircle, Loader2, AlertCircle, X, Plus } from 'lucide-react';
import { toast } from 'sonner';

export default function OnboardingDocuments({ profile, onComplete }) {
  // State to hold selected files before upload
  const [selectedFiles, setSelectedFiles] = useState({
    drivers_license: null,
    insurance: null,
    certification: null
  });
  
  // State to hold already uploaded URLs (from profile or new uploads)
  const [uploadedUrls, setUploadedUrls] = useState({
    drivers_license: profile?.drivers_license_url || null,
    insurance: profile?.insurance_url || null,
    certification: profile?.certification_url || null
  });

  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({});

  // Handle file selection
  const handleFileSelect = (type, file) => {
    setSelectedFiles(prev => ({ ...prev, [type]: file }));
  };

  // Handle file removal
  const handleFileRemove = (type) => {
    setSelectedFiles(prev => ({ ...prev, [type]: null }));
  };

  // Bulk upload function
  const handleBulkUpload = async () => {
    setUploading(true);
    const newUrls = { ...uploadedUrls };
    let hasError = false;

    // Create an array of upload promises
    const uploadPromises = Object.entries(selectedFiles).map(async ([type, file]) => {
      if (!file) return; // Skip if no file selected

      setUploadProgress(prev => ({ ...prev, [type]: 'uploading' }));
      try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        newUrls[type] = file_url;
        setUploadProgress(prev => ({ ...prev, [type]: 'completed' }));
      } catch (error) {
        console.error(`Error uploading ${type}:`, error);
        setUploadProgress(prev => ({ ...prev, [type]: 'failed' }));
        hasError = true;
      }
    });

    await Promise.all(uploadPromises);
    setUploadedUrls(newUrls);
    setUploading(false);
    
    // Clear selected files that were successfully uploaded
    const remainingFiles = { ...selectedFiles };
    Object.keys(selectedFiles).forEach(key => {
      if (uploadProgress[key] !== 'failed' && newUrls[key]) {
        remainingFiles[key] = null;
      }
    });
    setSelectedFiles(remainingFiles);

    if (hasError) {
      toast.error("Some files failed to upload. Please try again.");
    } else {
      // If successful, save the profile URLs
      saveDocuments.mutate(newUrls);
    }
  };

  const saveDocuments = useMutation({
    mutationFn: async (urls) => {
      await base44.entities.TechnicianProfile.update(profile.id, {
        drivers_license_url: urls.drivers_license,
        insurance_url: urls.insurance,
        certification_url: urls.certification
      });
    },
    onSuccess: () => {
      toast.success("Documents saved successfully!");
      onComplete();
    },
    onError: () => {
      toast.error("Failed to save document references.");
    }
  });

  const hasFilesToUpload = Object.values(selectedFiles).some(f => f !== null);
  const allRequiredPresent = (uploadedUrls.drivers_license || selectedFiles.drivers_license) && 
                             (uploadedUrls.insurance || selectedFiles.insurance);

  const renderUploadField = (type, label, description, required = false) => {
    const isUploaded = !!uploadedUrls[type];
    const isSelected = !!selectedFiles[type];
    const status = uploadProgress[type];

    return (
      <div className="border rounded-lg p-4 bg-white shadow-sm transition-all hover:shadow-md">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h4 className="font-semibold flex items-center gap-2">
              {label} {required && <span className="text-red-500">*</span>}
            </h4>
            <p className="text-sm text-gray-600">{description}</p>
          </div>
          {isUploaded && !isSelected && (
            <div className="flex items-center text-green-600 bg-green-50 px-3 py-1 rounded-full text-xs font-bold">
              <CheckCircle className="w-3 h-3 mr-1" /> Uploaded
            </div>
          )}
          {isSelected && status === 'completed' && (
            <div className="flex items-center text-green-600 bg-green-50 px-3 py-1 rounded-full text-xs font-bold">
              <CheckCircle className="w-3 h-3 mr-1" /> Ready
            </div>
          )}
          {status === 'failed' && (
            <div className="flex items-center text-red-600 bg-red-50 px-3 py-1 rounded-full text-xs font-bold">
              <AlertCircle className="w-3 h-3 mr-1" /> Failed
            </div>
          )}
        </div>

        {isSelected ? (
          <div className="flex items-center justify-between bg-gray-50 p-3 rounded-md border">
            <div className="flex items-center gap-2 overflow-hidden">
              <FileText className="w-4 h-4 text-gray-500 flex-shrink-0" />
              <span className="text-sm truncate font-medium">{selectedFiles[type].name}</span>
            </div>
            {!uploading && (
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0 text-gray-500 hover:text-red-500"
                onClick={() => handleFileRemove(type)}
              >
                <X className="w-4 h-4" />
              </Button>
            )}
            {uploading && status === 'uploading' && (
              <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
            )}
          </div>
        ) : (
          <label className="cursor-pointer block">
            <input
              type="file"
              className="hidden"
              accept="image/*,.pdf"
              onChange={(e) => {
                const file = e.target.files[0];
                if (file) handleFileSelect(type, file);
              }}
              disabled={uploading}
            />
            <div className="border-2 border-dashed border-gray-200 rounded-md p-4 flex flex-col items-center justify-center hover:bg-gray-50 hover:border-orange-300 transition-colors">
              <Upload className="w-6 h-6 text-gray-400 mb-2" />
              <span className="text-sm font-medium text-gray-600">Click to select file</span>
            </div>
          </label>
        )}
      </div>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="w-5 h-5" style={{ color: '#FF771D' }} />
          Bulk Document Upload
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-gray-700">
                <p className="font-semibold mb-1">Instructions</p>
                <p>Select all your documents below, then click "Upload All Documents" to submit them at once.</p>
              </div>
            </div>
          </div>

          <div className="grid gap-4">
            {renderUploadField('drivers_license', "Driver's License", "Valid state-issued license", true)}
            {renderUploadField('insurance', "Insurance Certificate", "Proof of vehicle insurance", true)}
            {renderUploadField('certification', "Professional Certifications", "Optional certificates")}
          </div>

          <div className="pt-4 border-t mt-6">
            <Button
              onClick={handleBulkUpload}
              disabled={!hasFilesToUpload || uploading}
              className="w-full text-white py-6 text-lg"
              style={{ backgroundColor: '#FF771D' }}
            >
              {uploading ? (
                <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Uploading Files...</>
              ) : hasFilesToUpload ? (
                <><Upload className="w-5 h-5 mr-2" /> Upload All Documents</>
              ) : (
                <><CheckCircle className="w-5 h-5 mr-2" /> Select Files to Upload</>
              )}
            </Button>
            
            {!hasFilesToUpload && allRequiredPresent && (
               <div className="text-center mt-4">
                 <p className="text-green-600 font-medium mb-2">All required documents are present!</p>
                 <Button 
                   onClick={onComplete} 
                   variant="outline"
                   className="border-green-500 text-green-700 hover:bg-green-50"
                 >
                   Continue to Next Step
                 </Button>
               </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}