import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { TrendingUp, DollarSign, Loader2, BarChart3, Sparkles } from 'lucide-react';

export default function EarningsInsights({ technicianId, technicianProfile }) {
  const [insights, setInsights] = useState(null);
  const [loadingInsights, setLoadingInsights] = useState(false);

  // Fetch completed jobs with prices
  const { data: completedJobs = [] } = useQuery({
    queryKey: ['completed-jobs', technicianId],
    queryFn: async () => {
      const jobs = await base44.entities.ServiceRequest.filter(
        { technician_id: technicianId, status: 'completed' },
        '-completed_at',
        100
      );
      return jobs.filter(j => j.price);
    },
    enabled: !!technicianId
  });

  // Fetch ratings
  const { data: ratings = [] } = useQuery({
    queryKey: ['technician-ratings', technicianId],
    queryFn: async () => {
      return await base44.entities.Rating.filter(
        { technician_id: technicianId },
        '-created_date',
        100
      );
    },
    enabled: !!technicianId
  });

  // Calculate earnings by service type
  const earningsByType = completedJobs.reduce((acc, job) => {
    const type = job.service_type;
    if (!acc[type]) {
      acc[type] = { total: 0, count: 0, avgRating: 0 };
    }
    acc[type].total += job.price;
    acc[type].count += 1;
    
    const jobRating = ratings.find(r => r.service_request_id === job.id);
    if (jobRating) {
      acc[type].avgRating = (acc[type].avgRating * (acc[type].count - 1) + jobRating.rating) / acc[type].count;
    }
    
    return acc;
  }, {});

  const totalEarnings = completedJobs.reduce((sum, job) => sum + (job.price || 0), 0);
  const avgEarningsPerJob = completedJobs.length > 0 ? totalEarnings / completedJobs.length : 0;

  const getInsights = async () => {
    setLoadingInsights(true);
    try {
      const earningsData = Object.entries(earningsByType).map(([type, data]) => ({
        service_type: type,
        total_earnings: data.total,
        job_count: data.count,
        avg_per_job: data.total / data.count,
        avg_rating: data.avgRating.toFixed(1)
      }));

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an AI analyst for ROADSIDEPLUS. Analyze this technician's performance and provide actionable insights and earnings forecasts.

Technician Performance Data:
- Total Completed Jobs: ${completedJobs.length}
- Total Earnings: $${totalEarnings.toFixed(2)}
- Average Earnings Per Job: $${avgEarningsPerJob.toFixed(2)}
- Overall Rating: ${technicianProfile?.rating?.toFixed(1) || 'N/A'}

Earnings Breakdown by Service Type:
${earningsData.map(d => `- ${d.service_type}: ${d.job_count} jobs, $${d.total_earnings.toFixed(2)} total, $${d.avg_per_job.toFixed(2)} avg, ${d.avg_rating}★ rating`).join('\n')}

Recent Job Completion Times (last 10 jobs):
${completedJobs.slice(0, 10).map(j => {
  const start = new Date(j.created_date);
  const end = new Date(j.completed_at);
  const minutes = Math.round((end - start) / 60000);
  return `- ${j.service_type}: ${minutes} minutes`;
}).join('\n')}

Provide:
1. Key performance insights (2-3 bullet points)
2. Service type recommendations (which to focus on)
3. Weekly earnings forecast based on current performance
4. Monthly earnings forecast
5. Actionable tips to increase earnings (2-3 tips)`,
        response_json_schema: {
          type: 'object',
          properties: {
            key_insights: {
              type: 'array',
              items: { type: 'string' },
              description: 'Key performance insights'
            },
            recommendations: {
              type: 'array',
              items: { type: 'string' },
              description: 'Service type recommendations'
            },
            weekly_forecast: {
              type: 'string',
              description: 'Estimated weekly earnings'
            },
            monthly_forecast: {
              type: 'string',
              description: 'Estimated monthly earnings'
            },
            improvement_tips: {
              type: 'array',
              items: { type: 'string' },
              description: 'Tips to increase earnings'
            }
          }
        }
      });

      setInsights(response);
    } catch (error) {
      console.error('Error getting insights:', error);
      alert('Failed to generate insights. Please try again.');
    } finally {
      setLoadingInsights(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" style={{ color: '#3D692B' }} />
            Earnings Insights
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={getInsights}
            disabled={loadingInsights || completedJobs.length === 0}
            style={{ borderColor: '#3D692B', color: '#3D692B' }}
          >
            {loadingInsights ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Get AI Insights
              </>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Earnings Summary */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-green-50 rounded-lg p-4 border border-green-200">
            <div className="flex items-center gap-2 mb-1">
              <DollarSign className="w-4 h-4 text-green-600" />
              <span className="text-xs font-semibold text-green-800">Total Earnings</span>
            </div>
            <p className="text-2xl font-bold text-green-900">${totalEarnings.toFixed(2)}</p>
            <p className="text-xs text-green-600 mt-1">{completedJobs.length} completed jobs</p>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <div className="flex items-center gap-2 mb-1">
              <BarChart3 className="w-4 h-4 text-blue-600" />
              <span className="text-xs font-semibold text-blue-800">Avg Per Job</span>
            </div>
            <p className="text-2xl font-bold text-blue-900">${avgEarningsPerJob.toFixed(2)}</p>
            <p className="text-xs text-blue-600 mt-1">Across all services</p>
          </div>
        </div>

        {/* Earnings by Service Type */}
        {Object.keys(earningsByType).length > 0 && (
          <div>
            <h4 className="text-sm font-semibold mb-2">Earnings by Service Type</h4>
            <div className="space-y-2">
              {Object.entries(earningsByType)
                .sort(([, a], [, b]) => b.total - a.total)
                .map(([type, data]) => (
                  <div key={type} className="border rounded-lg p-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium capitalize">
                        {type.replace(/_/g, ' ')}
                      </span>
                      <span className="text-sm font-bold" style={{ color: '#3D692B' }}>
                        ${data.total.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-600">
                      <span>{data.count} jobs • ${(data.total / data.count).toFixed(2)} avg</span>
                      <span>{data.avgRating > 0 ? `${data.avgRating.toFixed(1)}★` : 'No ratings yet'}</span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* AI Insights */}
        {insights && (
          <div className="space-y-3 pt-3 border-t">
            <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
              <h5 className="font-semibold text-sm mb-2 text-purple-900 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                Key Insights
              </h5>
              <ul className="text-sm space-y-1">
                {insights.key_insights?.map((insight, i) => (
                  <li key={i} className="text-purple-800">• {insight}</li>
                ))}
              </ul>
            </div>

            <div className="bg-green-50 rounded-lg p-4 border border-green-200">
              <h5 className="font-semibold text-sm mb-2 text-green-900">📊 Earnings Forecast</h5>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-green-600">Weekly Estimate</p>
                  <p className="text-lg font-bold text-green-900">{insights.weekly_forecast}</p>
                </div>
                <div>
                  <p className="text-xs text-green-600">Monthly Estimate</p>
                  <p className="text-lg font-bold text-green-900">{insights.monthly_forecast}</p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
              <h5 className="font-semibold text-sm mb-2 text-blue-900">💡 Recommendations</h5>
              <ul className="text-sm space-y-1">
                {insights.recommendations?.map((rec, i) => (
                  <li key={i} className="text-blue-800">• {rec}</li>
                ))}
              </ul>
            </div>

            <div className="bg-orange-50 rounded-lg p-4 border border-orange-200">
              <h5 className="font-semibold text-sm mb-2 text-orange-900">🚀 Tips to Increase Earnings</h5>
              <ul className="text-sm space-y-1">
                {insights.improvement_tips?.map((tip, i) => (
                  <li key={i} className="text-orange-800">• {tip}</li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {completedJobs.length === 0 && (
          <p className="text-center text-gray-500 py-4 text-sm">
            Complete jobs to see earnings insights
          </p>
        )}
      </CardContent>
    </Card>
  );
}