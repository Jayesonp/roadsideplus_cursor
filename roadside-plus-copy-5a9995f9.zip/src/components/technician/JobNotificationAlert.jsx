import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X, AlertCircle, CheckCircle, XCircle, Clock, MapPin } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { createPageUrl } from '@/utils';
import ServiceTypeIcon from '../common/ServiceTypeIcon';

export default function JobNotificationAlert({ technicianId }) {
  const [dismissedIds, setDismissedIds] = useState(new Set());

  // Fetch unread notifications for technician
  const { data: notifications = [] } = useQuery({
    queryKey: ['technician-alerts', technicianId],
    queryFn: async () => {
      if (!technicianId) return [];
      
      const allNotifications = await base44.entities.Notification.filter(
        { 
          user_id: technicianId,
          is_read: false
        },
        '-created_date',
        10
      );

      // Filter for job-related notifications only - EXCLUDE job offers as they're handled by UberStyleJobAlert
      const jobTypes = [
        'job_assigned',
        'job_cancelled', 
        'urgent_job_update',
        'customer_waiting'
      ];

      return allNotifications.filter(n => jobTypes.includes(n.type));
    },
    enabled: !!technicianId,
    refetchInterval: 10000,
    retry: 1,
    staleTime: 8000
  });

  // Filter out dismissed notifications
  const activeNotifications = notifications.filter(n => !dismissedIds.has(n.id));

  const handleDismiss = async (notificationId) => {
    setDismissedIds(prev => new Set(prev).add(notificationId));
    
    // Mark as read
    try {
      await base44.entities.Notification.update(notificationId, { is_read: true });
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const handleAction = async (notification) => {
    await handleDismiss(notification.id);
    
    // Navigate to appropriate page
    if (notification.related_id) {
      window.location.href = createPageUrl(`JobDetails?id=${notification.related_id}`);
    } else {
      window.location.href = createPageUrl('TechnicianDashboard');
    }
  };

  const getAlertStyle = (type) => {
    switch (type) {
      case 'job_assigned':
        return {
          bg: 'bg-green-50',
          border: 'border-green-300',
          icon: CheckCircle,
          iconColor: 'text-green-600',
          title: 'Job Available'
        };
      case 'job_cancelled':
        return {
          bg: 'bg-red-50',
          border: 'border-red-300',
          icon: XCircle,
          iconColor: 'text-red-600',
          title: 'Job Cancelled'
        };
      case 'urgent_job_update':
      case 'customer_waiting':
        return {
          bg: 'bg-orange-50',
          border: 'border-orange-300',
          icon: AlertCircle,
          iconColor: 'text-orange-600',
          title: 'Job Update'
        };
      default:
        return {
          bg: 'bg-gray-50',
          border: 'border-gray-300',
          icon: AlertCircle,
          iconColor: 'text-gray-600',
          title: 'Notification'
        };
    }
  };

  if (activeNotifications.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 z-40 space-y-3 max-w-md" style={{ maxHeight: 'calc(100vh - 100px)', overflowY: 'auto' }}>
      <AnimatePresence>
        {activeNotifications.map((notification) => {
          const style = getAlertStyle(notification.type);
          const Icon = style.icon;

          return (
            <motion.div
              key={notification.id}
              initial={{ opacity: 0, x: 50, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 50, scale: 0.95 }}
              transition={{ duration: 0.3 }}
            >
              <Card className={`${style.bg} border-2 ${style.border} shadow-lg`}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className={`${style.iconColor} flex-shrink-0 mt-0.5`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h4 className="font-bold text-sm">{style.title}</h4>
                        <button
                          onClick={() => handleDismiss(notification.id)}
                          className="text-gray-400 hover:text-gray-600 flex-shrink-0"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      
                      <p className="text-sm text-gray-700 mb-3">
                        {notification.message}
                      </p>

                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleAction(notification)}
                          className="text-white hover:opacity-90"
                          style={{ backgroundColor: '#FF771D' }}
                        >
                          View Details
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDismiss(notification.id)}
                        >
                          Dismiss
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}