import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { MapPin, Plus, Trash2, Star } from 'lucide-react';
import { MapContainer, TileLayer, Circle, Marker } from 'react-leaflet';

export default function WorkZoneManager({ profile }) {
  const [zones, setZones] = useState(profile?.preferred_work_zones || []);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newZone, setNewZone] = useState({
    name: '',
    center_lat: profile?.current_lat || 0,
    center_lng: profile?.current_lng || 0,
    radius_miles: 10,
    priority: 1
  });
  const queryClient = useQueryClient();

  const saveZones = useMutation({
    mutationFn: async (updatedZones) => {
      return await base44.entities.TechnicianProfile.update(profile.id, {
        preferred_work_zones: updatedZones
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['tech-profile']);
    }
  });

  const handleAddZone = () => {
    const updatedZones = [...zones, { ...newZone, id: Date.now().toString() }];
    setZones(updatedZones);
    saveZones.mutate(updatedZones);
    setNewZone({
      name: '',
      center_lat: profile?.current_lat || 0,
      center_lng: profile?.current_lng || 0,
      radius_miles: 10,
      priority: 1
    });
    setShowAddForm(false);
  };

  const handleDeleteZone = (zoneId) => {
    const updatedZones = zones.filter(z => z.id !== zoneId);
    setZones(updatedZones);
    saveZones.mutate(updatedZones);
  };

  const handlePriorityChange = (zoneId, newPriority) => {
    const updatedZones = zones.map(z => 
      z.id === zoneId ? { ...z, priority: newPriority } : z
    );
    setZones(updatedZones);
    saveZones.mutate(updatedZones);
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        setNewZone({
          ...newZone,
          center_lat: position.coords.latitude,
          center_lng: position.coords.longitude
        });
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" style={{ color: '#FF771D' }} />
            Preferred Work Zones
          </CardTitle>
          <Button
            onClick={() => setShowAddForm(!showAddForm)}
            style={{ backgroundColor: '#3D692B' }}
            className="text-white"
            size="sm"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Zone
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {showAddForm && (
          <div className="border rounded-lg p-4 bg-gray-50 space-y-3">
            <h4 className="font-semibold text-sm">Add New Work Zone</h4>
            <div>
              <Label>Zone Name</Label>
              <Input
                value={newZone.name}
                onChange={(e) => setNewZone({ ...newZone, name: e.target.value })}
                placeholder="e.g., Downtown Area"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Latitude</Label>
                <Input
                  type="number"
                  step="0.000001"
                  value={newZone.center_lat}
                  onChange={(e) => setNewZone({ ...newZone, center_lat: parseFloat(e.target.value) })}
                />
              </div>
              <div>
                <Label>Longitude</Label>
                <Input
                  type="number"
                  step="0.000001"
                  value={newZone.center_lng}
                  onChange={(e) => setNewZone({ ...newZone, center_lng: parseFloat(e.target.value) })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Radius (miles)</Label>
                <Input
                  type="number"
                  value={newZone.radius_miles}
                  onChange={(e) => setNewZone({ ...newZone, radius_miles: parseInt(e.target.value) })}
                />
              </div>
              <div>
                <Label>Priority (1-5)</Label>
                <Input
                  type="number"
                  min="1"
                  max="5"
                  value={newZone.priority}
                  onChange={(e) => setNewZone({ ...newZone, priority: parseInt(e.target.value) })}
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={getCurrentLocation}
                className="flex-1"
              >
                Use Current Location
              </Button>
              <Button
                onClick={handleAddZone}
                disabled={!newZone.name || !newZone.center_lat}
                style={{ backgroundColor: '#3D692B' }}
                className="text-white flex-1"
              >
                Add Zone
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowAddForm(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        )}

        {zones.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <MapPin className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No work zones defined</p>
            <p className="text-xs mt-1">Add zones to prioritize jobs in your preferred areas</p>
          </div>
        ) : (
          <>
            {/* Map View */}
            {profile?.current_lat && (
              <div className="h-64 rounded-lg overflow-hidden border">
                <MapContainer
                  center={[profile.current_lat, profile.current_lng]}
                  zoom={10}
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                  {zones.map((zone) => (
                    <Circle
                      key={zone.id}
                      center={[zone.center_lat, zone.center_lng]}
                      radius={zone.radius_miles * 1609.34}
                      pathOptions={{
                        color: zone.priority >= 4 ? '#3D692B' : zone.priority >= 2 ? '#FF771D' : '#999',
                        fillOpacity: 0.2
                      }}
                    />
                  ))}
                  {profile?.current_lat && (
                    <Marker position={[profile.current_lat, profile.current_lng]} />
                  )}
                </MapContainer>
              </div>
            )}

            {/* Zone List */}
            <div className="space-y-2">
              {zones.sort((a, b) => b.priority - a.priority).map((zone) => (
                <div key={zone.id} className="border rounded-lg p-3 flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h5 className="font-semibold">{zone.name}</h5>
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-3 h-3 cursor-pointer ${
                              star <= zone.priority ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                            }`}
                            onClick={() => handlePriorityChange(zone.id, star)}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-xs text-gray-600">
                      {zone.radius_miles} mile radius • Priority {zone.priority}/5
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDeleteZone(zone.id)}
                    className="text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}