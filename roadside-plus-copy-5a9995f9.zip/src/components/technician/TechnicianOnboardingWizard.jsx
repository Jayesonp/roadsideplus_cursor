import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  CheckCircle, Car, MapPin, Wrench, Award, FileText,
  ArrowRight, ArrowLeft, Loader2, Upload, Sparkles,
  CircleDot, TrendingUp
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

const STEPS = [
  { id: 'welcome', title: 'Welcome', icon: Sparkles },
  { id: 'profile', title: 'Profile', icon: Car },
  { id: 'skills', title: 'Skills', icon: Wrench },
  { id: 'service_area', title: 'Service Area', icon: MapPin },
  { id: 'documents', title: 'Documents', icon: FileText },
  { id: 'tutorial', title: 'Tutorial', icon: TrendingUp },
  { id: 'complete', title: 'Complete', icon: CheckCircle }
];

const AVAILABLE_SKILLS = [
  'Brake Repair', 'Engine Diagnostics', 'Electrical Systems', 'Transmission Repair',
  'Air Conditioning', 'Oil Change', 'Tire Service', 'Battery Service',
  'Suspension Repair', 'Exhaust Systems', 'Fuel Systems', 'Cooling Systems',
  'Steering Systems', 'Hybrid/Electric Vehicles', 'Diesel Engines'
];

const SERVICE_TYPES = [
  { value: 'tire_change', label: 'Tire Change' },
  { value: 'battery_jump', label: 'Battery Jump Start' },
  { value: 'fuel_delivery', label: 'Fuel Delivery' },
  { value: 'lockout', label: 'Lockout Service' },
  { value: 'towing', label: 'Towing' },
  { value: 'other', label: 'Other Services' }
];

export default function TechnicianOnboardingWizard({ user, onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const queryClient = useQueryClient();

  const [wizardData, setWizardData] = useState({
    phone: '',
    bio: '',
    vehicle_type: '',
    license_plate: '',
    skills: [],
    preferred_service_types: [],
    service_area_center_lat: null,
    service_area_center_lng: null,
    service_area_radius_miles: 25,
    drivers_license_url: '',
    insurance_url: '',
    certifications: [],
    address: ''
  });

  const [uploadingDoc, setUploadingDoc] = useState(false);

  const saveOnboarding = useMutation({
    mutationFn: async () => {
      // Create or update technician profile
      const profiles = await base44.entities.TechnicianProfile.filter({ user_id: user.id });
      
      const profileData = {
        user_id: user.id,
        phone: wizardData.phone,
        bio: wizardData.bio,
        vehicle_type: wizardData.vehicle_type,
        license_plate: wizardData.license_plate,
        skills: wizardData.skills,
        preferred_service_types: wizardData.preferred_service_types,
        service_area_center_lat: wizardData.service_area_center_lat,
        service_area_center_lng: wizardData.service_area_center_lng,
        service_area_radius_miles: wizardData.service_area_radius_miles,
        drivers_license_url: wizardData.drivers_license_url,
        insurance_url: wizardData.insurance_url,
        certifications: wizardData.certifications,
        onboarding_completed: true,
        is_available: false,
        availability_status: 'offline'
      };

      if (profiles.length > 0) {
        await base44.entities.TechnicianProfile.update(profiles[0].id, profileData);
      } else {
        await base44.entities.TechnicianProfile.create(profileData);
      }

      // Update user
      await base44.auth.updateMe({
        onboarding_completed: true,
        user_type: 'technician'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
      onComplete();
    }
  });

  const handleFileUpload = async (event, type) => {
    const file = event.target.files[0];
    if (!file) return;

    setUploadingDoc(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      if (type === 'license') {
        setWizardData({...wizardData, drivers_license_url: file_url});
      } else if (type === 'insurance') {
        setWizardData({...wizardData, insurance_url: file_url});
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload file. Please try again.');
    } finally {
      setUploadingDoc(false);
      event.target.value = '';
    }
  };

  const getLocation = () => {
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setWizardData({
          ...wizardData,
          service_area_center_lat: position.coords.latitude,
          service_area_center_lng: position.coords.longitude
        });
        setLoading(false);
      },
      (error) => {
        console.error('Location error:', error);
        alert('Could not get your location. Please enter it manually or enable location services.');
        setLoading(false);
      }
    );
  };

  const handleNext = async () => {
    if (currentStep === STEPS.length - 2) {
      await saveOnboarding.mutateAsync();
    }
    
    setCurrentStep(prev => Math.min(prev + 1, STEPS.length - 1));
  };

  const handleBack = () => {
    setCurrentStep(prev => Math.max(prev - 1, 0));
  };

  const renderStepContent = () => {
    switch (STEPS[currentStep].id) {
      case 'welcome':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center"
                   style={{ backgroundColor: '#FF771D' }}>
                <Sparkles className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold mb-3">Welcome to the Team!</h2>
              <p className="text-lg text-gray-600 mb-6">
                Let's get you set up to start earning as a technician
              </p>
            </div>

            <Card className="bg-gradient-to-br from-orange-50 to-red-50">
              <CardContent className="pt-6">
                <h3 className="font-semibold mb-3">What we'll cover:</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Complete your profile and vehicle info
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Select your skills and service types
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Define your service area and radius
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Upload required documents
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Learn how to accept and manage jobs
                  </li>
                </ul>
              </CardContent>
            </Card>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900">
                ⏱️ <strong>This will take about 5-10 minutes</strong> to complete. You can save and come back anytime!
              </p>
            </div>
          </div>
        );

      case 'profile':
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <Car className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
              <h2 className="text-2xl font-bold mb-2">Your Profile & Vehicle</h2>
              <p className="text-gray-600">Tell us about yourself and your service vehicle</p>
            </div>

            <div>
              <Label>Phone Number *</Label>
              <Input
                placeholder="+1 (868) 123-4567"
                value={wizardData.phone}
                onChange={(e) => setWizardData({...wizardData, phone: e.target.value})}
              />
            </div>

            <div>
              <Label>Professional Bio *</Label>
              <Textarea
                placeholder="Tell customers about your experience, specialties, and what makes you a great technician..."
                value={wizardData.bio}
                onChange={(e) => setWizardData({...wizardData, bio: e.target.value})}
                className="h-24"
              />
              <p className="text-xs text-gray-500 mt-1">This will be shown to customers</p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Service Vehicle Type *</Label>
                <Input
                  placeholder="Pickup Truck, Van, SUV..."
                  value={wizardData.vehicle_type}
                  onChange={(e) => setWizardData({...wizardData, vehicle_type: e.target.value})}
                />
              </div>
              <div>
                <Label>License Plate *</Label>
                <Input
                  placeholder="ABC-1234"
                  value={wizardData.license_plate}
                  onChange={(e) => setWizardData({...wizardData, license_plate: e.target.value})}
                />
              </div>
            </div>
          </div>
        );

      case 'skills':
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <Wrench className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
              <h2 className="text-2xl font-bold mb-2">Your Skills & Services</h2>
              <p className="text-gray-600">Select what you're qualified to do</p>
            </div>

            <div>
              <Label className="mb-3 block">Technical Skills (Select all that apply)</Label>
              <div className="grid md:grid-cols-2 gap-3 max-h-64 overflow-y-auto border rounded-lg p-4">
                {AVAILABLE_SKILLS.map((skill) => (
                  <div key={skill} className="flex items-center gap-2">
                    <Checkbox
                      checked={wizardData.skills.includes(skill)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setWizardData({...wizardData, skills: [...wizardData.skills, skill]});
                        } else {
                          setWizardData({...wizardData, skills: wizardData.skills.filter(s => s !== skill)});
                        }
                      }}
                    />
                    <Label className="cursor-pointer">{skill}</Label>
                  </div>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Selected: {wizardData.skills.length} skills
              </p>
            </div>

            <div>
              <Label className="mb-3 block">Preferred Service Types</Label>
              <div className="grid md:grid-cols-2 gap-3">
                {SERVICE_TYPES.map((service) => (
                  <div key={service.value} className="flex items-center gap-2">
                    <Checkbox
                      checked={wizardData.preferred_service_types.includes(service.value)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setWizardData({
                            ...wizardData, 
                            preferred_service_types: [...wizardData.preferred_service_types, service.value]
                          });
                        } else {
                          setWizardData({
                            ...wizardData, 
                            preferred_service_types: wizardData.preferred_service_types.filter(s => s !== service.value)
                          });
                        }
                      }}
                    />
                    <Label className="cursor-pointer">{service.label}</Label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'service_area':
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <MapPin className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
              <h2 className="text-2xl font-bold mb-2">Your Service Area</h2>
              <p className="text-gray-600">Define where you want to work</p>
            </div>

            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-6">
                <p className="text-sm text-blue-900 mb-3">
                  📍 This is the center of your service area. You'll receive job requests within your specified radius.
                </p>
                <Button
                  variant="outline"
                  onClick={getLocation}
                  disabled={loading}
                  className="w-full"
                  style={{ borderColor: '#FF771D', color: '#FF771D' }}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Getting Location...
                    </>
                  ) : (
                    <>
                      <CircleDot className="w-4 h-4 mr-2" />
                      Use My Current Location
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {wizardData.service_area_center_lat && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-sm text-green-900">
                  ✓ Location set: {wizardData.service_area_center_lat.toFixed(4)}, {wizardData.service_area_center_lng.toFixed(4)}
                </p>
              </div>
            )}

            <div>
              <Label>Service Radius (miles)</Label>
              <Input
                type="number"
                value={wizardData.service_area_radius_miles}
                onChange={(e) => setWizardData({...wizardData, service_area_radius_miles: parseInt(e.target.value)})}
                min="5"
                max="100"
              />
              <p className="text-xs text-gray-500 mt-1">
                You'll receive jobs within {wizardData.service_area_radius_miles} miles of your service area center
              </p>
            </div>

            <div>
              <Label>Base Address (Optional)</Label>
              <Input
                placeholder="Your home or garage address"
                value={wizardData.address}
                onChange={(e) => setWizardData({...wizardData, address: e.target.value})}
              />
            </div>
          </div>
        );

      case 'documents':
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <FileText className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
              <h2 className="text-2xl font-bold mb-2">Required Documents</h2>
              <p className="text-gray-600">Upload your credentials to verify your account</p>
            </div>

            <Card>
              <CardContent className="pt-6 space-y-4">
                <div>
                  <Label className="mb-2 block">Driver's License *</Label>
                  <input
                    type="file"
                    id="license-upload"
                    className="hidden"
                    accept="image/*,.pdf"
                    onChange={(e) => handleFileUpload(e, 'license')}
                    disabled={uploadingDoc}
                  />
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => document.getElementById('license-upload').click()}
                    disabled={uploadingDoc}
                  >
                    {uploadingDoc ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : wizardData.drivers_license_url ? (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                        Uploaded ✓
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Upload Driver's License
                      </>
                    )}
                  </Button>
                </div>

                <div>
                  <Label className="mb-2 block">Vehicle Insurance *</Label>
                  <input
                    type="file"
                    id="insurance-upload"
                    className="hidden"
                    accept="image/*,.pdf"
                    onChange={(e) => handleFileUpload(e, 'insurance')}
                    disabled={uploadingDoc}
                  />
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => document.getElementById('insurance-upload').click()}
                    disabled={uploadingDoc}
                  >
                    {uploadingDoc ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : wizardData.insurance_url ? (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                        Uploaded ✓
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Upload Insurance Document
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <p className="text-sm text-yellow-900">
                ⚠️ Your documents will be reviewed by our team. You'll be notified once approved.
              </p>
            </div>
          </div>
        );

      case 'tutorial':
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <TrendingUp className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
              <h2 className="text-2xl font-bold mb-2">How It Works</h2>
              <p className="text-gray-600">Quick guide to getting started</p>
            </div>

            <div className="space-y-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                         style={{ backgroundColor: '#FF771D' }}>
                      <span className="text-white font-bold">1</span>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">Toggle Your Availability ON</h3>
                      <p className="text-sm text-gray-600">
                        When you're ready to work, turn on your availability in the dashboard. You'll start receiving job offers nearby.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                         style={{ backgroundColor: '#E52C2D' }}>
                      <span className="text-white font-bold">2</span>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">Accept Job Offers</h3>
                      <p className="text-sm text-gray-600">
                        You'll get real-time notifications for jobs. Review details and accept within the time limit (typically 30-60 seconds).
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                         style={{ backgroundColor: '#3D692B' }}>
                      <span className="text-white font-bold">3</span>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">Navigate & Complete</h3>
                      <p className="text-sm text-gray-600">
                        Use the built-in navigation to reach the customer. Update job status (En Route → Arrived → In Progress → Complete).
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                         style={{ backgroundColor: '#FF771D' }}>
                      <span className="text-white font-bold">4</span>
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">Get Paid & Rated</h3>
                      <p className="text-sm text-gray-600">
                        After completion, rate the customer. Payment is processed automatically. Build your reputation with great service!
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <p className="text-sm text-green-900">
                💡 <strong>Pro Tip:</strong> Respond quickly to job offers and maintain high ratings to get priority access to better jobs!
              </p>
            </div>
          </div>
        );

      case 'complete':
        return (
          <div className="text-center space-y-6">
            <div className="w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center bg-green-100">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-3xl font-bold mb-3">You're All Set!</h2>
            <p className="text-lg text-gray-600 mb-6">
              Welcome to the ROADSIDE+ technician network
            </p>

            <Card className="bg-gradient-to-br from-orange-50 to-red-50">
              <CardContent className="pt-6">
                <h3 className="font-semibold mb-3">What happens next?</h3>
                <ul className="space-y-2 text-sm text-left">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Your documents will be reviewed (usually within 24 hours)
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Once approved, you can toggle your availability ON
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Start receiving and accepting job requests
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Earn money helping customers in need
                  </li>
                </ul>
              </CardContent>
            </Card>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900">
                📧 We'll send you an email once your account is approved. Check your dashboard for your approval status.
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const canProceed = () => {
    switch (STEPS[currentStep].id) {
      case 'welcome':
        return true;
      case 'profile':
        return wizardData.phone && wizardData.bio && wizardData.vehicle_type && wizardData.license_plate;
      case 'skills':
        return wizardData.skills.length > 0 && wizardData.preferred_service_types.length > 0;
      case 'service_area':
        return wizardData.service_area_center_lat && wizardData.service_area_center_lng;
      case 'documents':
        return wizardData.drivers_license_url && wizardData.insurance_url;
      case 'tutorial':
        return true;
      case 'complete':
        return true;
      default:
        return false;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center overflow-y-auto"
         style={{
           paddingTop: 'calc(env(safe-area-inset-top) + 1rem)',
           paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)',
           paddingLeft: 'calc(env(safe-area-inset-left) + 1rem)',
           paddingRight: 'calc(env(safe-area-inset-right) + 1rem)'
         }}>
      <Card className="max-w-3xl w-full mx-auto my-8 shadow-2xl">
        <CardHeader>
          <div className="flex items-center justify-between mb-4">
            {STEPS.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 transition-colors ${
                  index < currentStep ? 'bg-green-500 border-green-500 text-white' :
                  index === currentStep ? 'border-orange-500 text-orange-500' :
                  'border-gray-300 text-gray-400'
                }`}>
                  {index < currentStep ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    React.createElement(step.icon, { className: 'w-5 h-5' })
                  )}
                </div>
                {index < STEPS.length - 1 && (
                  <div className={`hidden md:block w-12 h-1 mx-2 ${
                    index < currentStep ? 'bg-green-500' : 'bg-gray-300'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-500">
              Step {currentStep + 1} of {STEPS.length}
            </p>
          </div>
        </CardHeader>

        <CardContent>
          {renderStepContent()}

          <div className="flex justify-between mt-8 pt-6 border-t gap-3">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentStep === 0 || loading || saveOnboarding.isLoading}
              className="min-w-[100px]"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>

            <Button
              onClick={handleNext}
              disabled={!canProceed() || loading || saveOnboarding.isLoading || uploadingDoc}
              className="text-white min-w-[120px]"
              style={{ backgroundColor: '#FF771D' }}
            >
              {saveOnboarding.isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : currentStep === STEPS.length - 1 ? (
                'Go to Dashboard'
              ) : (
                <>
                  Next
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}