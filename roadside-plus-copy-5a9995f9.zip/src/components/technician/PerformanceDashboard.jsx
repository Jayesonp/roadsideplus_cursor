import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, Clock, Star, CheckCircle, DollarSign, Award, Target, Zap } from 'lucide-react';
import { format, subDays, differenceInMinutes } from 'date-fns';

export default function PerformanceDashboard({ technicianId, profile }) {
  const { data: completedJobs = [] } = useQuery({
    queryKey: ['completed-jobs', technicianId],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter(
        { technician_id: technicianId, status: 'completed' },
        '-completed_at',
        100
      );
    },
    enabled: !!technicianId
  });

  const { data: ratings = [] } = useQuery({
    queryKey: ['tech-ratings', technicianId],
    queryFn: async () => {
      return await base44.entities.Rating.filter(
        { technician_id: technicianId },
        '-created_date',
        100
      );
    },
    enabled: !!technicianId
  });

  // Calculate metrics
  const last7Days = completedJobs.filter(j => 
    new Date(j.completed_at) >= subDays(new Date(), 7)
  );

  const last30Days = completedJobs.filter(j => 
    new Date(j.completed_at) >= subDays(new Date(), 30)
  );

  const avgResponseTime = completedJobs.reduce((sum, job) => {
    if (job.created_date && job.completed_at) {
      return sum + differenceInMinutes(new Date(job.completed_at), new Date(job.created_date));
    }
    return sum;
  }, 0) / (completedJobs.length || 1);

  const totalEarnings = completedJobs.reduce((sum, job) => sum + (job.payment_amount || job.price || 0), 0);

  const last7DaysEarnings = last7Days.reduce((sum, job) => sum + (job.payment_amount || job.price || 0), 0);

  const avgRating = ratings.reduce((sum, r) => sum + r.rating, 0) / (ratings.length || 1);

  const fiveStarCount = ratings.filter(r => r.rating === 5).length;
  const fiveStarPercentage = (fiveStarCount / (ratings.length || 1)) * 100;

  const completionRate = profile?.total_jobs ? 
    ((completedJobs.length / profile.total_jobs) * 100).toFixed(1) : 100;

  const metrics = [
    {
      title: 'Jobs Completed',
      value: completedJobs.length,
      subtitle: `${last7Days.length} this week`,
      icon: CheckCircle,
      color: '#3D692B',
      trend: last7Days.length > 0 ? '+' + last7Days.length : '0'
    },
    {
      title: 'Avg Response Time',
      value: `${Math.round(avgResponseTime)} min`,
      subtitle: 'From request to completion',
      icon: Clock,
      color: '#FF771D',
      trend: avgResponseTime < 60 ? 'Excellent' : 'Good'
    },
    {
      title: 'Customer Rating',
      value: avgRating.toFixed(1),
      subtitle: `${ratings.length} total reviews`,
      icon: Star,
      color: '#FFD700',
      trend: `${fiveStarPercentage.toFixed(0)}% 5-star`
    },
    {
      title: 'Total Earnings',
      value: `$${totalEarnings.toFixed(0)}`,
      subtitle: `$${last7DaysEarnings.toFixed(0)} this week`,
      icon: DollarSign,
      color: '#3D692B',
      trend: last7DaysEarnings > 0 ? `+$${last7DaysEarnings.toFixed(0)}` : '$0'
    }
  ];

  const achievements = [
    {
      title: 'Fast Responder',
      description: 'Average response under 1 hour',
      achieved: avgResponseTime < 60,
      icon: Zap
    },
    {
      title: 'Top Rated',
      description: '4.5+ star rating',
      achieved: avgRating >= 4.5,
      icon: Award
    },
    {
      title: 'Consistent Performer',
      description: '95%+ completion rate',
      achieved: parseFloat(completionRate) >= 95,
      icon: Target
    },
    {
      title: 'Week Champion',
      description: '10+ jobs this week',
      achieved: last7Days.length >= 10,
      icon: TrendingUp
    }
  ];

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map((metric, idx) => {
          const Icon = metric.icon;
          return (
            <Card key={idx} className="border-l-4" style={{ borderLeftColor: metric.color }}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: metric.color + '20' }}>
                    <Icon className="w-5 h-5" style={{ color: metric.color }} />
                  </div>
                  <span className="text-xs font-semibold px-2 py-1 rounded-full bg-green-100 text-green-800">
                    {metric.trend}
                  </span>
                </div>
                <div className="text-2xl font-bold mb-1 dark:text-white">{metric.value}</div>
                <div className="text-xs text-gray-600 dark:text-gray-300">{metric.title}</div>
                <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">{metric.subtitle}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Performance Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" style={{ color: '#FF771D' }} />
            Performance Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            {/* Recent Activity */}
            <div>
              <h4 className="font-semibold mb-3 dark:text-white">Recent Activity</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                  <span className="text-sm dark:text-gray-300">Last 7 Days</span>
                  <span className="font-semibold dark:text-white">{last7Days.length} jobs</span>
                </div>
                <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                  <span className="text-sm dark:text-gray-300">Last 30 Days</span>
                  <span className="font-semibold dark:text-white">{last30Days.length} jobs</span>
                </div>
                <div className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                  <span className="text-sm dark:text-gray-300">All Time</span>
                  <span className="font-semibold dark:text-white">{completedJobs.length} jobs</span>
                </div>
              </div>
            </div>

            {/* Achievements */}
            <div>
              <h4 className="font-semibold mb-3 dark:text-white">Achievements</h4>
              <div className="space-y-2">
                {achievements.map((achievement, idx) => {
                  const Icon = achievement.icon;
                  return (
                    <div
                      key={idx}
                      className={`flex items-center gap-3 p-2 rounded transition-colors ${
                        achievement.achieved ? 'bg-green-50 dark:bg-green-900/30' : 'bg-gray-50 dark:bg-gray-700'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        achievement.achieved ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-600'
                      }`}>
                        <Icon className="w-4 h-4 text-white" />
                      </div>
                      <div className="flex-1">
                        <p className={`text-sm font-semibold ${
                          achievement.achieved ? 'text-green-900 dark:text-green-300' : 'text-gray-600 dark:text-gray-300'
                        }`}>
                          {achievement.title}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{achievement.description}</p>
                      </div>
                      {achievement.achieved && (
                        <CheckCircle className="w-4 h-4 text-green-600 dark:text-green-400" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}