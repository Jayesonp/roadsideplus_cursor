import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DollarSign, CheckCircle2, Clock, XCircle, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';

export default function PaymentSummary({ request }) {
  if (!request) return null;

  const amount = request.payment_amount || request.price || 0;
  const status = request.payment_status || 'pending';

  const statusConfig = {
    pending: {
      label: 'Payment Pending',
      color: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      icon: Clock,
      iconColor: '#FF771D'
    },
    initiated: {
      label: 'Payment Processing',
      color: 'bg-blue-100 text-blue-800 border-blue-300',
      icon: RefreshCw,
      iconColor: '#3B82F6'
    },
    paid: {
      label: 'Payment Received',
      color: 'bg-green-100 text-green-800 border-green-300',
      icon: CheckCircle2,
      iconColor: '#3D692B'
    },
    failed: {
      label: 'Payment Failed',
      color: 'bg-red-100 text-red-800 border-red-300',
      icon: XCircle,
      iconColor: '#E52C2D'
    },
    refunded: {
      label: 'Payment Refunded',
      color: 'bg-gray-100 text-gray-800 border-gray-300',
      icon: RefreshCw,
      iconColor: '#6B7280'
    }
  };

  const config = statusConfig[status] || statusConfig.pending;
  const Icon = config.icon;

  return (
    <Card className="border-2" style={{ borderColor: config.iconColor }}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5" style={{ color: config.iconColor }} />
            Payment Information
          </CardTitle>
          <Badge className={`${config.color} border flex items-center gap-1.5 px-3 py-1`}>
            <Icon className="w-3.5 h-3.5" style={{ color: config.iconColor }} />
            {config.label}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Amount */}
        <div className="bg-gray-50 rounded-lg p-4">
          <p className="text-sm text-gray-600 mb-1">Payment Amount</p>
          <p className="text-3xl font-bold" style={{ color: config.iconColor }}>
            ${amount.toFixed(2)}
          </p>
        </div>

        {/* Payment Details */}
        <div className="space-y-2">
          {request.payment_reference && (
            <div className="flex justify-between text-sm border-b pb-2">
              <span className="text-gray-600">Reference</span>
              <span className="font-mono text-gray-900">{request.payment_reference}</span>
            </div>
          )}
          
          {request.paid_at && (
            <div className="flex justify-between text-sm border-b pb-2">
              <span className="text-gray-600">Paid At</span>
              <span className="font-semibold text-gray-900">
                {format(new Date(request.paid_at), 'MMM d, yyyy h:mm a')}
              </span>
            </div>
          )}

          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Service Type</span>
            <span className="font-semibold text-gray-900 capitalize">
              {request.service_type.replace(/_/g, ' ')}
            </span>
          </div>
        </div>

        {/* Status Messages */}
        {status === 'pending' && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
            <p className="text-sm text-yellow-800">
              ⏳ Waiting for customer to complete payment
            </p>
          </div>
        )}

        {status === 'paid' && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
            <p className="text-sm text-green-800">
              ✅ Payment has been successfully received
            </p>
          </div>
        )}

        {status === 'failed' && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <p className="text-sm text-red-800">
              ❌ Payment attempt failed. Customer may retry.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}