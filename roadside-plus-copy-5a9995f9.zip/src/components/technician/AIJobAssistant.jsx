import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Sparkles, Loader2, AlertTriangle, CheckCircle, 
  Wrench, Clock, Lightbulb, FileText, TrendingUp, History 
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function AIJobAssistant({ serviceRequest, onSummaryGenerated }) {
  const [diagnostics, setDiagnostics] = useState(null);
  const [loadingDiagnostics, setLoadingDiagnostics] = useState(false);
  const [repairSummary, setRepairSummary] = useState(null);
  const [generatingSummary, setGeneratingSummary] = useState(false);
  const [repairGuide, setRepairGuide] = useState(null);
  const [loadingGuide, setLoadingGuide] = useState(false);
  const [predictions, setPredictions] = useState(null);
  const [loadingPredictions, setLoadingPredictions] = useState(false);
  const [vehicleHistory, setVehicleHistory] = useState([]);
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    // Auto-load diagnostics when job is accepted
    if (serviceRequest && ['assigned', 'en_route'].includes(serviceRequest.status)) {
      loadDiagnostics();
      loadVehicleHistory();
    }
  }, [serviceRequest?.id, serviceRequest?.status]);

  const loadVehicleHistory = async () => {
    try {
      // Get all completed service requests for this vehicle
      const history = await base44.entities.ServiceRequest.filter({
        customer_id: serviceRequest.customer_id,
        status: 'completed'
      }, '-completed_at', 20);
      
      setVehicleHistory(history);
      
      // Auto-load predictions if there's history
      if (history.length > 0) {
        loadPredictions(history);
      }
    } catch (error) {
      console.error('Error loading vehicle history:', error);
    }
  };

  const loadPredictions = async (history = vehicleHistory) => {
    if (history.length === 0) return;
    
    setLoadingPredictions(true);
    try {
      const historyText = history.map((h, i) => 
        `${i + 1}. ${(h.service_type || 'service').replace(/_/g, ' ')} - ${h.description || 'Standard service'} (${new Date(h.completed_at).toLocaleDateString()})`
      ).join('\n');

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a predictive maintenance AI for automotive service.

CURRENT VEHICLE:
- ${serviceRequest.vehicle_year || ''} ${serviceRequest.vehicle_make || ''} ${serviceRequest.vehicle_model || ''}
- VIN: ${serviceRequest.vehicle_vin || 'N/A'}

RECENT SERVICE HISTORY:
${historyText}

CURRENT ISSUE:
${(serviceRequest.service_type || 'service').replace(/_/g, ' ')} - ${serviceRequest.description || 'Standard service'}

Based on the service history and current issue, predict:
1. Potential future problems likely to occur (within 3-6 months)
2. Recommended preventive maintenance
3. Parts that may need attention soon
4. Wear patterns or recurring issues
5. Cost-saving opportunities through bundled maintenance
6. Safety-critical items that need monitoring

Be specific and practical. Consider vehicle age, service patterns, and common failure points.`,
        response_json_schema: {
          type: 'object',
          properties: {
            predicted_issues: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  issue: { type: 'string' },
                  timeframe: { type: 'string' },
                  probability: { type: 'string' },
                  estimated_cost: { type: 'string' }
                }
              }
            },
            preventive_maintenance: {
              type: 'array',
              items: { type: 'string' }
            },
            parts_to_monitor: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  part: { type: 'string' },
                  condition: { type: 'string' },
                  action: { type: 'string' }
                }
              }
            },
            recurring_patterns: {
              type: 'array',
              items: { type: 'string' }
            },
            bundled_services: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  service: { type: 'string' },
                  benefit: { type: 'string' },
                  savings: { type: 'string' }
                }
              }
            },
            safety_alerts: {
              type: 'array',
              items: { type: 'string' }
            }
          }
        }
      });
      setPredictions(response);
    } catch (error) {
      console.error('Predictions error:', error);
    } finally {
      setLoadingPredictions(false);
    }
  };

  const loadRepairGuide = async () => {
    setLoadingGuide(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert technician trainer providing step-by-step repair guidance.

SERVICE REQUEST:
- Type: ${(serviceRequest.service_type || 'service').replace(/_/g, ' ')}
- Vehicle: ${serviceRequest.vehicle_year || ''} ${serviceRequest.vehicle_make || ''} ${serviceRequest.vehicle_model || ''}
- Description: ${serviceRequest.description || 'Standard service'}
- Location: Roadside service

Provide detailed, sequential repair steps that are:
1. Clear and actionable
2. Include safety checks at each step
3. Specify exact tools/parts needed per step
4. Include quality checks and testing
5. Mention common pitfalls for each step
6. Provide troubleshooting if step fails
7. Include time estimate per step

Format as a professional repair guide suitable for a certified technician performing roadside service.`,
        response_json_schema: {
          type: 'object',
          properties: {
            procedure_name: { type: 'string' },
            overview: { type: 'string' },
            preparation: {
              type: 'array',
              items: { type: 'string' }
            },
            steps: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  step_number: { type: 'number' },
                  title: { type: 'string' },
                  instruction: { type: 'string' },
                  tools_needed: {
                    type: 'array',
                    items: { type: 'string' }
                  },
                  safety_note: { type: 'string' },
                  estimated_time: { type: 'string' },
                  quality_check: { type: 'string' },
                  troubleshooting: { type: 'string' }
                }
              }
            },
            final_checks: {
              type: 'array',
              items: { type: 'string' }
            },
            tips: {
              type: 'array',
              items: { type: 'string' }
            }
          }
        }
      });
      setRepairGuide(response);
    } catch (error) {
      console.error('Repair guide error:', error);
    } finally {
      setLoadingGuide(false);
    }
  };

  const loadDiagnostics = async () => {
    setLoadingDiagnostics(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert automotive diagnostics AI assistant for roadside technicians.

SERVICE REQUEST DETAILS:
- Type: ${(serviceRequest.service_type || 'service').replace(/_/g, ' ')}
- Description: ${serviceRequest.description || 'No additional details provided'}
- Vehicle: ${serviceRequest.vehicle_year || ''} ${serviceRequest.vehicle_make || ''} ${serviceRequest.vehicle_model || ''}
- Priority: ${serviceRequest.priority || 'normal'}

Provide comprehensive diagnostic assistance including:
1. Most likely root causes (ranked by probability)
2. Quick diagnostic checks the technician should perform on-site
3. Required tools and parts they should have ready
4. Safety precautions specific to this situation
5. Estimated repair time
6. Alternative solutions if primary fix isn't possible
7. Common mistakes to avoid

Be specific, practical, and focused on roadside repair scenarios.`,
        response_json_schema: {
          type: 'object',
          properties: {
            likely_causes: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  cause: { type: 'string' },
                  probability: { type: 'string' }
                }
              }
            },
            diagnostic_steps: {
              type: 'array',
              items: { type: 'string' }
            },
            required_tools: {
              type: 'array',
              items: { type: 'string' }
            },
            safety_precautions: {
              type: 'array',
              items: { type: 'string' }
            },
            estimated_time: { type: 'string' },
            alternative_solutions: {
              type: 'array',
              items: { type: 'string' }
            },
            common_mistakes: {
              type: 'array',
              items: { type: 'string' }
            },
            difficulty_level: {
              type: 'string',
              enum: ['Easy', 'Medium', 'Hard', 'Expert']
            },
            recommended_price_range: { type: 'string' }
          }
        }
      });
      setDiagnostics(response);
    } catch (error) {
      console.error('AI diagnostics error:', error);
    } finally {
      setLoadingDiagnostics(false);
    }
  };

  const generateCompletionSummary = async () => {
    setGeneratingSummary(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a professional, customer-friendly service completion summary.

SERVICE DETAILS:
- Service Type: ${(serviceRequest.service_type || 'service').replace(/_/g, ' ')}
- Vehicle: ${serviceRequest.vehicle_year || ''} ${serviceRequest.vehicle_make || ''} ${serviceRequest.vehicle_model || ''}
- Customer Description: ${serviceRequest.description || 'Standard service'}
- Final Price: $${serviceRequest.price || 'TBD'}

Create a comprehensive yet friendly summary that includes:
1. What service was performed
2. What was found/diagnosed
3. What was fixed/completed
4. Any recommendations for future maintenance
5. Safety notes or follow-up advice
6. Next steps (if any)

Make it professional but warm, suitable for sending to the customer. Be specific about what was done.`,
        response_json_schema: {
          type: 'object',
          properties: {
            summary_title: { type: 'string' },
            work_performed: {
              type: 'array',
              items: { type: 'string' }
            },
            findings: {
              type: 'array',
              items: { type: 'string' }
            },
            recommendations: {
              type: 'array',
              items: { type: 'string' }
            },
            customer_message: { type: 'string' },
            follow_up_timeline: { type: 'string' }
          }
        }
      });
      setRepairSummary(response);
      if (onSummaryGenerated) {
        onSummaryGenerated(response);
      }
    } catch (error) {
      console.error('Summary generation error:', error);
    } finally {
      setGeneratingSummary(false);
    }
  };

  if (!serviceRequest) return null;

  return (
    <div className="space-y-4">
      <Tabs defaultValue="diagnostics" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="diagnostics">Diagnostics</TabsTrigger>
          <TabsTrigger value="guide">Repair Guide</TabsTrigger>
          <TabsTrigger value="predictions">Predictions</TabsTrigger>
          <TabsTrigger value="summary">Summary</TabsTrigger>
        </TabsList>

        {/* Diagnostics Tab */}
        <TabsContent value="diagnostics">
      {/* AI Diagnostics */}
      <Card className="border-2" style={{ borderColor: '#FF771D' }}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5" style={{ color: '#FF771D' }} />
              AI Diagnostic Assistant
            </CardTitle>
            {!diagnostics && !loadingDiagnostics && (
              <Button
                size="sm"
                onClick={loadDiagnostics}
                style={{ backgroundColor: '#FF771D' }}
                className="text-white"
              >
                Get AI Analysis
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {loadingDiagnostics ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin" style={{ color: '#FF771D' }} />
              <span className="ml-2">Analyzing issue...</span>
            </div>
          ) : diagnostics ? (
            <div className="space-y-4">
              {/* Difficulty & Time */}
              <div className="flex gap-2">
                <Badge className={
                  diagnostics.difficulty_level === 'Easy' ? 'bg-green-600' :
                  diagnostics.difficulty_level === 'Medium' ? 'bg-yellow-600' :
                  diagnostics.difficulty_level === 'Hard' ? 'bg-orange-600' :
                  'bg-red-600'
                }>
                  {diagnostics.difficulty_level}
                </Badge>
                <Badge variant="outline">
                  <Clock className="w-3 h-3 mr-1" />
                  {diagnostics.estimated_time}
                </Badge>
                {diagnostics.recommended_price_range && (
                  <Badge variant="outline" style={{ borderColor: '#3D692B', color: '#3D692B' }}>
                    💰 {diagnostics.recommended_price_range}
                  </Badge>
                )}
              </div>

              {/* Likely Causes */}
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  Most Likely Causes
                </h4>
                <div className="space-y-2">
                  {diagnostics.likely_causes?.map((item, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <span className="font-bold text-red-600">{i + 1}.</span>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{item.cause}</p>
                        <p className="text-xs text-gray-600">{item.probability} probability</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Diagnostic Steps */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-blue-600" />
                  Diagnostic Checklist
                </h4>
                <ol className="space-y-1">
                  {diagnostics.diagnostic_steps?.map((step, i) => (
                    <li key={i} className="text-sm flex items-start gap-2">
                      <span className="font-bold text-blue-600">{i + 1}.</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              </div>

              {/* Required Tools */}
              {diagnostics.required_tools?.length > 0 && (
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-purple-600" />
                    Required Tools & Parts
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {diagnostics.required_tools.map((tool, i) => (
                      <Badge key={i} variant="outline" className="bg-white">
                        {tool}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Safety Precautions */}
              {diagnostics.safety_precautions?.length > 0 && (
                <div className="bg-yellow-50 border-2 border-yellow-400 rounded-lg p-4">
                  <h4 className="font-semibold mb-2 flex items-center gap-2 text-yellow-900">
                    ⚠️ Safety Precautions
                  </h4>
                  <ul className="space-y-1">
                    {diagnostics.safety_precautions.map((precaution, i) => (
                      <li key={i} className="text-sm text-yellow-900">• {precaution}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Alternative Solutions */}
              {diagnostics.alternative_solutions?.length > 0 && (
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <Lightbulb className="w-4 h-4 text-gray-600" />
                    Alternative Solutions
                  </h4>
                  <ul className="space-y-1 text-sm">
                    {diagnostics.alternative_solutions.map((alt, i) => (
                      <li key={i}>• {alt}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Common Mistakes */}
              {diagnostics.common_mistakes?.length > 0 && (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                  <h4 className="font-semibold mb-2 text-orange-900">⚡ Avoid These Mistakes</h4>
                  <ul className="space-y-1 text-sm text-orange-900">
                    {diagnostics.common_mistakes.map((mistake, i) => (
                      <li key={i}>• {mistake}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-6 text-gray-500">
              <Sparkles className="w-12 h-12 mx-auto mb-2 text-gray-300" />
              <p className="text-sm">Click to get AI-powered diagnostics for this job</p>
            </div>
          )}
        </CardContent>
      </Card>
        </TabsContent>

        {/* Step-by-Step Repair Guide Tab */}
        <TabsContent value="guide">
      <Card className="border-2" style={{ borderColor: '#3D692B' }}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Wrench className="w-5 h-5" style={{ color: '#3D692B' }} />
              Step-by-Step Repair Guide
            </CardTitle>
            {!repairGuide && !loadingGuide && (
              <Button
                size="sm"
                onClick={loadRepairGuide}
                style={{ backgroundColor: '#3D692B' }}
                className="text-white"
              >
                Get Repair Steps
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {loadingGuide ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin" style={{ color: '#3D692B' }} />
              <span className="ml-2">Generating repair guide...</span>
            </div>
          ) : repairGuide ? (
            <div className="space-y-4">
              <div className="bg-green-50 border-2 border-green-500 rounded-lg p-4">
                <h4 className="font-bold text-lg mb-2">{repairGuide.procedure_name}</h4>
                <p className="text-sm text-gray-700">{repairGuide.overview}</p>
              </div>

              {/* Preparation */}
              {repairGuide.preparation?.length > 0 && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h5 className="font-semibold mb-2 text-blue-900">📋 Preparation</h5>
                  <ul className="space-y-1 text-sm">
                    {repairGuide.preparation.map((prep, i) => (
                      <li key={i}>• {prep}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Step-by-step instructions */}
              <div className="space-y-3">
                {repairGuide.steps?.map((step, i) => (
                  <Card 
                    key={i} 
                    className={`border-2 transition-all ${currentStep === i ? 'border-green-500 shadow-lg' : 'border-gray-200'}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div 
                          className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0"
                          style={{ backgroundColor: currentStep === i ? '#3D692B' : '#9CA3AF' }}
                        >
                          {step.step_number}
                        </div>
                        <div className="flex-1">
                          <h5 className="font-bold text-lg mb-2">{step.title}</h5>
                          <p className="text-sm mb-3 text-gray-700">{step.instruction}</p>
                          
                          {step.tools_needed?.length > 0 && (
                            <div className="mb-2">
                              <p className="text-xs font-semibold text-gray-600 mb-1">Tools needed:</p>
                              <div className="flex flex-wrap gap-1">
                                {step.tools_needed.map((tool, ti) => (
                                  <Badge key={ti} variant="outline" className="text-xs">
                                    🔧 {tool}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          {step.safety_note && (
                            <div className="bg-yellow-50 border border-yellow-300 rounded p-2 mb-2">
                              <p className="text-xs text-yellow-900">
                                <strong>⚠️ Safety:</strong> {step.safety_note}
                              </p>
                            </div>
                          )}

                          <div className="flex gap-2 text-xs text-gray-600 mb-2">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {step.estimated_time}
                            </span>
                          </div>

                          {step.quality_check && (
                            <div className="bg-green-50 border border-green-200 rounded p-2 mb-2">
                              <p className="text-xs text-green-900">
                                <strong>✓ Quality Check:</strong> {step.quality_check}
                              </p>
                            </div>
                          )}

                          {step.troubleshooting && (
                            <details className="text-xs">
                              <summary className="cursor-pointer text-orange-600 font-semibold">
                                Troubleshooting
                              </summary>
                              <p className="mt-1 text-gray-700">{step.troubleshooting}</p>
                            </details>
                          )}

                          <div className="flex gap-2 mt-3">
                            {currentStep === i && (
                              <Button
                                size="sm"
                                onClick={() => setCurrentStep(i + 1)}
                                disabled={i === repairGuide.steps.length - 1}
                                style={{ backgroundColor: '#3D692B' }}
                                className="text-white"
                              >
                                <CheckCircle className="w-3 h-3 mr-1" />
                                Complete Step
                              </Button>
                            )}
                            {currentStep !== i && i < currentStep && (
                              <Badge className="bg-green-600">Completed</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Final Checks */}
              {repairGuide.final_checks?.length > 0 && (
                <div className="bg-purple-50 border-2 border-purple-400 rounded-lg p-4">
                  <h5 className="font-semibold mb-2 text-purple-900">✓ Final Verification</h5>
                  <ul className="space-y-1 text-sm">
                    {repairGuide.final_checks.map((check, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                        <span>{check}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Pro Tips */}
              {repairGuide.tips?.length > 0 && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h5 className="font-semibold mb-2 text-blue-900">💡 Pro Tips</h5>
                  <ul className="space-y-1 text-sm text-blue-900">
                    {repairGuide.tips.map((tip, i) => (
                      <li key={i}>• {tip}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-6 text-gray-500">
              <Wrench className="w-12 h-12 mx-auto mb-2 text-gray-300" />
              <p className="text-sm">Get detailed step-by-step repair instructions</p>
            </div>
          )}
        </CardContent>
      </Card>
        </TabsContent>

        {/* Vehicle History Predictions Tab */}
        <TabsContent value="predictions">
      <Card className="border-2" style={{ borderColor: '#FF771D' }}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" style={{ color: '#FF771D' }} />
              Predictive Maintenance
            </CardTitle>
            {vehicleHistory.length > 0 && !predictions && !loadingPredictions && (
              <Button
                size="sm"
                onClick={() => loadPredictions()}
                style={{ backgroundColor: '#FF771D' }}
                className="text-white"
              >
                Analyze Vehicle
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {vehicleHistory.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <History className="w-12 h-12 mx-auto mb-2 text-gray-300" />
              <p className="text-sm">No service history available for this vehicle</p>
              <p className="text-xs text-gray-400 mt-1">Predictions will be available after first service</p>
            </div>
          ) : loadingPredictions ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin" style={{ color: '#FF771D' }} />
              <span className="ml-2">Analyzing vehicle history...</span>
            </div>
          ) : predictions ? (
            <div className="space-y-4">
              {/* Service History Summary */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <h5 className="font-semibold mb-2 flex items-center gap-2">
                  <History className="w-4 h-4" />
                  Service History ({vehicleHistory.length} services)
                </h5>
                <div className="text-xs text-gray-600 space-y-1">
                  {vehicleHistory.slice(0, 3).map((h, i) => (
                    <p key={i}>
                      • {h.service_type.replace(/_/g, ' ')} - {new Date(h.completed_at).toLocaleDateString()}
                    </p>
                  ))}
                  {vehicleHistory.length > 3 && (
                    <p className="text-gray-400">+ {vehicleHistory.length - 3} more services</p>
                  )}
                </div>
              </div>

              {/* Predicted Issues */}
              {predictions.predicted_issues?.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h5 className="font-semibold mb-3 text-red-900">⚠️ Predicted Issues</h5>
                  <div className="space-y-3">
                    {predictions.predicted_issues.map((pred, i) => (
                      <div key={i} className="bg-white rounded p-3 border border-red-100">
                        <div className="flex justify-between items-start mb-1">
                          <p className="font-semibold text-sm">{pred.issue}</p>
                          <Badge variant="outline" className="text-xs">
                            {pred.probability}
                          </Badge>
                        </div>
                        <div className="flex gap-3 text-xs text-gray-600">
                          <span>📅 {pred.timeframe}</span>
                          <span>💰 {pred.estimated_cost}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Preventive Maintenance */}
              {predictions.preventive_maintenance?.length > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h5 className="font-semibold mb-2 text-green-900">✓ Recommended Preventive Maintenance</h5>
                  <ul className="space-y-1 text-sm">
                    {predictions.preventive_maintenance.map((item, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Parts to Monitor */}
              {predictions.parts_to_monitor?.length > 0 && (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                  <h5 className="font-semibold mb-3 text-orange-900">🔍 Parts Requiring Attention</h5>
                  <div className="space-y-2">
                    {predictions.parts_to_monitor.map((part, i) => (
                      <div key={i} className="bg-white rounded p-2 text-sm border border-orange-100">
                        <p className="font-semibold">{part.part}</p>
                        <p className="text-xs text-gray-600">
                          <span className="font-medium">Condition:</span> {part.condition}
                        </p>
                        <p className="text-xs text-orange-700">
                          <strong>Action:</strong> {part.action}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recurring Patterns */}
              {predictions.recurring_patterns?.length > 0 && (
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                  <h5 className="font-semibold mb-2 text-purple-900">🔄 Recurring Patterns</h5>
                  <ul className="space-y-1 text-sm text-purple-900">
                    {predictions.recurring_patterns.map((pattern, i) => (
                      <li key={i}>• {pattern}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Bundled Services */}
              {predictions.bundled_services?.length > 0 && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h5 className="font-semibold mb-3 text-blue-900">💰 Cost-Saving Opportunities</h5>
                  <div className="space-y-2">
                    {predictions.bundled_services.map((bundle, i) => (
                      <div key={i} className="bg-white rounded p-2 text-sm border border-blue-100">
                        <p className="font-semibold">{bundle.service}</p>
                        <p className="text-xs text-gray-600 mb-1">{bundle.benefit}</p>
                        <Badge className="bg-green-600 text-xs">{bundle.savings}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Safety Alerts */}
              {predictions.safety_alerts?.length > 0 && (
                <div className="bg-red-50 border-2 border-red-400 rounded-lg p-4">
                  <h5 className="font-semibold mb-2 text-red-900">🚨 Safety Alerts</h5>
                  <ul className="space-y-1 text-sm text-red-900">
                    {predictions.safety_alerts.map((alert, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                        <span className="font-medium">{alert}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-6 text-gray-500">
              <TrendingUp className="w-12 h-12 mx-auto mb-2 text-gray-300" />
              <p className="text-sm">Analyze vehicle history to predict future issues</p>
            </div>
          )}
        </CardContent>
      </Card>
        </TabsContent>

        {/* Summary Tab */}
        <TabsContent value="summary">
      {/* AI Completion Summary */}
      {['in_progress', 'completed'].includes(serviceRequest.status) && (
        <Card className="border-2" style={{ borderColor: '#3D692B' }}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" style={{ color: '#3D692B' }} />
                Job Completion Summary
              </CardTitle>
              <Button
                size="sm"
                onClick={generateCompletionSummary}
                disabled={generatingSummary}
                style={{ backgroundColor: '#3D692B' }}
                className="text-white"
              >
                {generatingSummary ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-1" />
                    Generate Summary
                  </>
                )}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {repairSummary ? (
              <div className="space-y-4">
                <div>
                  <h4 className="font-bold text-lg mb-2">{repairSummary.summary_title}</h4>
                </div>

                {repairSummary.work_performed?.length > 0 && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h5 className="font-semibold mb-2 text-green-900">✓ Work Performed</h5>
                    <ul className="space-y-1 text-sm">
                      {repairSummary.work_performed.map((work, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                          <span>{work}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {repairSummary.findings?.length > 0 && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h5 className="font-semibold mb-2 text-blue-900">🔍 Findings</h5>
                    <ul className="space-y-1 text-sm text-blue-900">
                      {repairSummary.findings.map((finding, i) => (
                        <li key={i}>• {finding}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {repairSummary.recommendations?.length > 0 && (
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <h5 className="font-semibold mb-2 text-yellow-900">💡 Recommendations</h5>
                    <ul className="space-y-1 text-sm text-yellow-900">
                      {repairSummary.recommendations.map((rec, i) => (
                        <li key={i}>• {rec}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <h5 className="font-semibold mb-2">Customer Message</h5>
                  <p className="text-sm text-gray-700 leading-relaxed">
                    {repairSummary.customer_message}
                  </p>
                  {repairSummary.follow_up_timeline && (
                    <p className="text-xs text-gray-600 mt-2">
                      Follow-up: {repairSummary.follow_up_timeline}
                    </p>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500">
                <FileText className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                <p className="text-sm">Generate a professional summary to send to the customer</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
        </TabsContent>
      </Tabs>
    </div>
  );
}