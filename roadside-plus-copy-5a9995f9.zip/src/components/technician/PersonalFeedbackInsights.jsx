import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Star, TrendingUp, MessageSquare, Sparkles, Loader2 } from 'lucide-react';

export default function PersonalFeedbackInsights({ technicianId }) {
  const [insights, setInsights] = useState(null);
  const [loading, setLoading] = useState(false);

  const { data: ratings = [] } = useQuery({
    queryKey: ['tech-ratings', technicianId],
    queryFn: () => base44.entities.Rating.filter({ technician_id: technicianId }, '-created_date', 50),
    enabled: !!technicianId
  });

  const { data: myJobs = [] } = useQuery({
    queryKey: ['tech-jobs', technicianId],
    queryFn: () => base44.entities.ServiceRequest.filter({ technician_id: technicianId }, '-created_date', 50),
    enabled: !!technicianId
  });

  useEffect(() => {
    if (ratings.length > 0) {
      generateInsights();
    }
  }, [ratings.length]);

  const generateInsights = async () => {
    setLoading(true);
    try {
      const feedbackData = ratings.map(r => ({
        rating: r.rating,
        comment: r.comment
      }));

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this technician's customer feedback and provide personalized insights.

Ratings: ${JSON.stringify(feedbackData)}
Total Jobs: ${myJobs.length}

Provide:
1. Overall performance summary
2. Top 3 strengths highlighted by customers
3. Top 3 areas for improvement
4. Specific actionable tips to improve ratings
5. Customer satisfaction trends`,
        response_json_schema: {
          type: 'object',
          properties: {
            summary: { type: 'string' },
            strengths: {
              type: 'array',
              items: { type: 'string' }
            },
            improvements: {
              type: 'array',
              items: { type: 'string' }
            },
            actionable_tips: {
              type: 'array',
              items: { type: 'string' }
            },
            trend: { type: 'string' }
          }
        }
      });

      setInsights(result);
    } catch (error) {
      console.error('Error generating insights:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!technicianId || ratings.length === 0) return null;

  const avgRating = ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length;

  return (
    <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-indigo-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-600" />
          Your Feedback Insights
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading && !insights ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
          </div>
        ) : insights ? (
          <div className="space-y-4">
            {/* Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-4 border border-purple-200">
                <div className="flex items-center gap-2 mb-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm text-gray-600">Avg Rating</span>
                </div>
                <div className="text-2xl font-bold text-purple-900">{avgRating.toFixed(2)}</div>
              </div>
              <div className="bg-white rounded-lg p-4 border border-purple-200">
                <div className="flex items-center gap-2 mb-1">
                  <MessageSquare className="w-4 h-4 text-purple-600" />
                  <span className="text-sm text-gray-600">Reviews</span>
                </div>
                <div className="text-2xl font-bold text-purple-900">{ratings.length}</div>
              </div>
            </div>

            {/* Summary */}
            <div className="bg-white rounded-lg p-4 border border-purple-200">
              <p className="text-sm text-gray-700">{insights.summary}</p>
            </div>

            {/* Strengths */}
            <div className="bg-white rounded-lg p-4 border border-green-200">
              <h4 className="font-semibold text-green-900 mb-2 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Your Strengths
              </h4>
              <ul className="space-y-1">
                {insights.strengths?.map((strength, idx) => (
                  <li key={idx} className="text-sm text-green-800">✓ {strength}</li>
                ))}
              </ul>
            </div>

            {/* Improvements */}
            <div className="bg-white rounded-lg p-4 border border-orange-200">
              <h4 className="font-semibold text-orange-900 mb-2">Growth Opportunities</h4>
              <ul className="space-y-1">
                {insights.improvements?.map((improvement, idx) => (
                  <li key={idx} className="text-sm text-orange-800">• {improvement}</li>
                ))}
              </ul>
            </div>

            {/* Actionable Tips */}
            <div className="bg-white rounded-lg p-4 border border-blue-200">
              <h4 className="font-semibold text-blue-900 mb-2">💡 Tips to Improve</h4>
              <ul className="space-y-2">
                {insights.actionable_tips?.map((tip, idx) => (
                  <li key={idx} className="text-sm text-blue-800">{tip}</li>
                ))}
              </ul>
            </div>

            {/* Trend */}
            <div className="bg-gradient-to-r from-purple-100 to-indigo-100 rounded-lg p-4 border border-purple-300">
              <h4 className="font-semibold text-purple-900 mb-1">Trend Analysis</h4>
              <p className="text-sm text-purple-800">{insights.trend}</p>
            </div>

            <Button
              onClick={generateInsights}
              variant="outline"
              className="w-full"
              disabled={loading}
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Refresh Insights'}
            </Button>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}