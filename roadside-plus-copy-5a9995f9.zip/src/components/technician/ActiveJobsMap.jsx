import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import { Navigation, MapPin, Clock, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { createPageUrl } from '@/utils';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { MAPBOX_TOKEN, MAPBOX_TILE_URL, MAPBOX_TILE_CONFIG } from '../map/mapboxConfig';

// Fix default marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom icons
let technicianIcon;
let activeJobIcon;
let pendingJobIcon;

try {
  technicianIcon = new L.Icon({
    iconUrl: 'data:image/svg+xml;base64,' + btoa(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#3D692B" width="32" height="32">
        <circle cx="12" cy="12" r="10" fill="#3D692B"/>
        <path d="M12 2L14.5 9L22 9.5L16 15L18 22L12 18L6 22L8 15L2 9.5L9.5 9Z" fill="white"/>
      </svg>
    `),
    iconSize: [32, 32],
    iconAnchor: [16, 32],
  });

  activeJobIcon = new L.Icon({
    iconUrl: 'data:image/svg+xml;base64,' + btoa(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#E52C2D" width="32" height="32">
        <path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z" fill="#E52C2D"/>
        <circle cx="12" cy="12" r="4" fill="white"/>
      </svg>
    `),
    iconSize: [32, 32],
    iconAnchor: [16, 32],
  });

  pendingJobIcon = new L.Icon({
    iconUrl: 'data:image/svg+xml;base64,' + btoa(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#FF771D" width="28" height="28">
        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" fill="#FF771D"/>
        <circle cx="12" cy="9" r="3" fill="white"/>
      </svg>
    `),
    iconSize: [28, 28],
    iconAnchor: [14, 28],
  });
} catch (e) {
  console.warn('Leaflet Icon constructor failed (Despia Runtime):', e);
}

const ActiveJobsMap = React.memo(function ActiveJobsMap({ technicianLocation, activeJobs, pendingRequests, serviceRadius = 25 }) {
  const [selectedJob, setSelectedJob] = useState(null);

  const isValidLocation = (loc) => 
    loc && typeof loc.lat === 'number' && typeof loc.lng === 'number';

  const center = isValidLocation(technicianLocation)
    ? [technicianLocation.lat, technicianLocation.lng]
    : [40.7128, -74.0060];

  const openNavigation = (lat, lng) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  return (
    <div className="relative h-full">
      <MapContainer
        center={center}
        zoom={12}
        style={{ height: '100%', width: '100%', borderRadius: '8px' }}
      >
        <TileLayer
          url={MAPBOX_TILE_URL(MAPBOX_TOKEN)}
          {...MAPBOX_TILE_CONFIG}
        />

        {/* Technician location */}
        {technicianLocation && (
          <>
            <Marker position={[technicianLocation.lat, technicianLocation.lng]} icon={technicianIcon}>
              <Popup>
                <div className="text-center font-semibold">
                  Your Location
                </div>
              </Popup>
            </Marker>
            <Circle
              center={[technicianLocation.lat, technicianLocation.lng]}
              radius={serviceRadius * 1609.34}
              pathOptions={{ color: '#3D692B', fillColor: '#3D692B', fillOpacity: 0.1 }}
            />
          </>
        )}

        {/* Active jobs */}
        {activeJobs?.filter(job => job.location_lat && job.location_lng).map((job) => (
          <Marker
            key={job.id}
            position={[job.location_lat, job.location_lng]}
            icon={activeJobIcon}
          >
            <Popup maxWidth={250}>
              <div className="p-2">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                  <h4 className="font-bold text-red-900">ACTIVE JOB</h4>
                </div>
                <p className="text-sm font-semibold mb-1">
                  {job.service_type.replace(/_/g, ' ').toUpperCase()}
                </p>
                <p className="text-xs text-gray-600 mb-2">
                  <MapPin className="w-3 h-3 inline mr-1" />
                  {job.location_address}
                </p>
                {job.vehicle_make && (
                  <p className="text-xs text-gray-600 mb-2">
                    {job.vehicle_year} {job.vehicle_make} {job.vehicle_model}
                  </p>
                )}
                <div className="flex gap-2 mt-3">
                  <Button
                    size="sm"
                    onClick={() => openNavigation(job.location_lat, job.location_lng)}
                    className="flex-1 text-white"
                    style={{ backgroundColor: '#3D692B' }}
                  >
                    <Navigation className="w-3 h-3 mr-1" />
                    Navigate
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => window.location.href = createPageUrl(`JobDetails?id=${job.id}`)}
                    className="flex-1 text-white"
                    style={{ backgroundColor: '#E52C2D' }}
                  >
                    Details
                  </Button>
                </div>
              </div>
            </Popup>
          </Marker>
        ))}

        {/* Pending requests */}
        {pendingRequests?.filter(req => req.location_lat && req.location_lng).map((request) => (
          <Marker
            key={request.id}
            position={[request.location_lat, request.location_lng]}
            icon={pendingJobIcon}
          >
            <Popup maxWidth={250}>
              <div className="p-2">
                <h4 className="font-bold text-orange-900 mb-2">
                  {request.service_type.replace(/_/g, ' ').toUpperCase()}
                </h4>
                <p className="text-xs text-gray-600 mb-2">
                  <MapPin className="w-3 h-3 inline mr-1" />
                  {request.location_address}
                </p>
                {request.price && (
                  <p className="text-sm font-semibold text-green-700 mb-2">
                    <DollarSign className="w-3 h-3 inline" />
                    {request.price.toFixed(2)}
                  </p>
                )}
                <Button
                  size="sm"
                  onClick={() => window.location.href = createPageUrl('TechnicianDashboard')}
                  className="w-full text-white"
                  style={{ backgroundColor: '#FF771D' }}
                >
                  View Request
                </Button>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* Map Legend */}
      <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-3 text-xs z-[1000]">
        <h5 className="font-semibold mb-2">Map Legend</h5>
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-700"></div>
            <span>Your Location</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-600"></div>
            <span>Active Jobs ({activeJobs?.length || 0})</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-orange-500"></div>
            <span>Available ({pendingRequests?.length || 0})</span>
          </div>
        </div>
      </div>
    </div>
  );
});

export default ActiveJobsMap;