import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, Bell, X, MapPin, Clock, DollarSign } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { createPageUrl } from '@/utils';

export default function UrgentJobAlerts({ technicianId, technicianLocation, isAvailable }) {
  const [dismissedAlerts, setDismissedAlerts] = useState([]);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const queryClient = useQueryClient();

  const { data: urgentRequests = [] } = useQuery({
    queryKey: ['urgent-requests', technicianLocation],
    queryFn: async () => {
      if (!technicianLocation) return [];
      
      const allPending = await base44.entities.ServiceRequest.filter(
        { status: 'pending_dispatch' },
        '-created_date',
        50
      );

      // Calculate distance and filter urgent ones (within 10 miles, older than 5 min)
      const now = Date.now();
      return allPending
        .filter(req => {
          const age = now - new Date(req.created_date).getTime();
          const distance = calculateDistance(
            technicianLocation.lat,
            technicianLocation.lng,
            req.location_lat,
            req.location_lng
          );
          return distance < 10 && age > 5 * 60 * 1000 && !dismissedAlerts.includes(req.id);
        })
        .slice(0, 3);
    },
    enabled: !!technicianLocation && isAvailable,
    refetchInterval: 30000,
    retry: 1,
    retryDelay: 10000,
    staleTime: 25000
  });

  const acceptJob = useMutation({
    mutationFn: async (requestId) => {
      return await base44.entities.ServiceRequest.update(requestId, {
        technician_id: technicianId,
        status: 'assigned',
        estimated_arrival: new Date(Date.now() + 20 * 60000).toISOString()
      });
    },
    onSuccess: async (updatedRequest) => {
      queryClient.invalidateQueries(['urgent-requests']);
      queryClient.invalidateQueries(['my-jobs']);
      
      if (updatedRequest.customer_id) {
        await base44.entities.Notification.create({
          user_id: updatedRequest.customer_id,
          type: 'technician_assigned',
          title: 'Technician Assigned',
          message: 'A technician has accepted your request!',
          related_id: updatedRequest.id
        });
      }
      
      window.location.href = createPageUrl(`JobDetails?id=${updatedRequest.id}`);
    }
  });

  useEffect(() => {
    if (urgentRequests.length > 0 && audioEnabled) {
      // Play notification sound
      try {
        // Check if Audio is available and constructible
        if (typeof window.Audio !== 'undefined') {
          const audio = new window.Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjGH0fPTgjMGHm7A7+OZUQ8MTKXh8bllHAU7k9nyyoUsBS18zPDckTsHGGe58OaZUQ8NTqff8Ldq');
          audio.volume = 0.3;
          audio.play().catch(() => {}); // Catch play promise errors
        }
      } catch (e) {
        // Catch constructor errors ("Illegal constructor")
        console.warn('Audio playback failed safe:', e);
      }
    }
  }, [urgentRequests.length]);

  const calculateDistance = (lat1, lng1, lat2, lng2) => {
    const R = 3959;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return (R * c).toFixed(1);
  };

  const dismissAlert = (requestId) => {
    setDismissedAlerts([...dismissedAlerts, requestId]);
  };

  if (!isAvailable || urgentRequests.length === 0) return null;

  return (
    <div className="space-y-3 mb-6">
      {urgentRequests.map((request) => (
        <Card
          key={request.id}
          className="border-2 border-red-500 bg-red-50 animate-pulse shadow-lg"
        >
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0 animate-bounce">
                <AlertCircle className="w-6 h-6 text-white" />
              </div>
              
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h4 className="font-bold text-red-900">URGENT REQUEST</h4>
                  <span className="text-xs px-2 py-1 bg-red-600 text-white rounded-full font-semibold">
                    HIGH PRIORITY
                  </span>
                </div>
                
                <p className="font-semibold text-red-800 mb-2">
                  {request.service_type.replace(/_/g, ' ').toUpperCase()}
                </p>
                
                <div className="space-y-1 text-sm text-red-700 mb-3">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    <span>{request.location_address}</span>
                    <span className="font-semibold">
                      ({calculateDistance(
                        technicianLocation.lat,
                        technicianLocation.lng,
                        request.location_lat,
                        request.location_lng
                      )} mi away)
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>Requested {formatDistanceToNow(new Date(request.created_date), { addSuffix: true })}</span>
                  </div>
                  
                  {request.price && (
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      <span className="font-semibold">${request.price.toFixed(2)}</span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => acceptJob.mutate(request.id)}
                    disabled={acceptJob.isLoading}
                    className="flex-1 text-white font-semibold"
                    style={{ backgroundColor: '#3D692B' }}
                  >
                    <Bell className="w-4 h-4 mr-2" />
                    Accept Now
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => dismissAlert(request.id)}
                    className="border-red-300 text-red-700 hover:bg-red-100"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}