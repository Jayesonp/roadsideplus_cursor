import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Play, ChevronRight, CheckCircle } from 'lucide-react';

export default function OnboardingTutorial({ onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);

  const tutorialSteps = [
    {
      title: 'Dashboard Overview',
      description: 'Your command center for managing jobs',
      points: [
        'View available service requests in real-time',
        'Track your active jobs and their status',
        'Monitor your earnings and performance stats',
        'Toggle your availability on/off as needed'
      ],
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop'
    },
    {
      title: 'Accepting Jobs',
      description: 'How to review and accept service requests',
      points: [
        'Check job details: type, location, and distance',
        'Estimate arrival time before accepting',
        'Accept jobs that match your skills',
        'Update your status as "En Route" immediately'
      ],
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop'
    },
    {
      title: 'Navigation & Tracking',
      description: 'Getting to the service location',
      points: [
        'Use the built-in navigation to reach customers',
        'Your location is shared with customers in real-time',
        'Update your status when you arrive',
        'Contact customer through the app if needed'
      ],
      image: 'https://images.unsplash.com/photo-1524661135-423995f22d0b?w=400&h=300&fit=crop'
    },
    {
      title: 'Completing Jobs',
      description: 'Finalizing service and documentation',
      points: [
        'Take before and after photos',
        'Upload any relevant documents',
        'Mark the job as complete in the app',
        'Customer will rate your service'
      ],
      image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=400&h=300&fit=crop'
    },
    {
      title: 'Customer Communication',
      description: 'Professional interaction guidelines',
      points: [
        'Use in-app chat for updates',
        'Be professional and courteous',
        'Explain the service process clearly',
        'Respect customer property and time'
      ],
      image: 'https://images.unsplash.com/photo-1577563908411-5077b6dc7624?w=400&h=300&fit=crop'
    }
  ];

  const handleNext = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const step = tutorialSteps[currentStep];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Play className="w-5 h-5" style={{ color: '#FF771D' }} />
          App Tutorial
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Progress */}
          <div className="flex gap-2">
            {tutorialSteps.map((_, index) => (
              <div
                key={index}
                className={`flex-1 h-2 rounded-full ${
                  index < currentStep
                    ? 'bg-green-500'
                    : index === currentStep
                    ? 'bg-orange-500'
                    : 'bg-gray-200'
                }`}
              />
            ))}
          </div>

          {/* Step Content */}
          <div>
            <div className="mb-4">
              <span className="text-sm text-gray-600">
                Step {currentStep + 1} of {tutorialSteps.length}
              </span>
              <h3 className="text-xl font-bold mt-1">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>

            <img
              src={step.image}
              alt={step.title}
              className="w-full h-48 object-cover rounded-lg mb-4"
            />

            <div className="space-y-3">
              {step.points.map((point, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: '#3D692B' }} />
                  <span className="text-gray-700">{point}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between pt-4">
            <Button
              variant="outline"
              onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
              disabled={currentStep === 0}
            >
              Previous
            </Button>

            <Button
              onClick={handleNext}
              className="text-white"
              style={{ backgroundColor: currentStep === tutorialSteps.length - 1 ? '#3D692B' : '#FF771D' }}
            >
              {currentStep === tutorialSteps.length - 1 ? (
                'Complete Tutorial'
              ) : (
                <>
                  Next
                  <ChevronRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}