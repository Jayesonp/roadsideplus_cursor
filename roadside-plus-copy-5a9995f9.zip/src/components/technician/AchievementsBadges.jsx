import React, { useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Award, Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

const BADGE_DEFINITIONS = {
  first_job: { title: 'First Steps', description: 'Complete your first job', icon: '🎯', threshold: 1 },
  'jobs_10': { title: 'Getting Started', description: 'Complete 10 jobs', icon: '⚡', threshold: 10 },
  'jobs_50': { title: 'Experienced', description: 'Complete 50 jobs', icon: '🔥', threshold: 50 },
  'jobs_100': { title: 'Century Club', description: 'Complete 100 jobs', icon: '💯', threshold: 100 },
  'jobs_500': { title: 'Elite Technician', description: 'Complete 500 jobs', icon: '👑', threshold: 500 },
  'star_streak_5': { title: '5-Star Streak', description: 'Get 5 consecutive 5-star ratings', icon: '⭐', checkFn: async (techId) => {
    const ratings = await base44.entities.Rating.filter({ technician_id: techId }, '-created_date', 5);
    return ratings.length >= 5 && ratings.every(r => r.rating === 5);
  }},
  speed_demon: { title: 'Speed Demon', description: 'Complete 10 jobs with avg response time < 15 min', icon: '⚡', checkFn: async (techId) => {
    const jobs = await base44.entities.ServiceRequest.filter({ technician_id: techId, status: 'completed' }, '-completed_at', 50);
    if (jobs.length < 10) return false;
    const times = jobs.slice(0, 10).map(j => (new Date(j.updated_date) - new Date(j.created_date)) / (1000 * 60));
    const avg = times.reduce((a, b) => a + b, 0) / times.length;
    return avg < 15;
  }},
  customer_favorite: { title: 'Customer Favorite', description: 'Maintain 4.8+ rating with 20+ jobs', icon: '❤️', checkFn: async (techId, profile) => {
    return profile.total_jobs >= 20 && profile.rating >= 4.8;
  }},
  early_bird: { title: 'Early Bird', description: 'Complete 5 jobs before 8 AM', icon: '🌅', checkFn: async (techId) => {
    const jobs = await base44.entities.ServiceRequest.filter({ technician_id: techId, status: 'completed' }, '-completed_at', 100);
    const earlyJobs = jobs.filter(j => {
      const hour = new Date(j.completed_at).getHours();
      return hour < 8;
    });
    return earlyJobs.length >= 5;
  }},
  night_owl: { title: 'Night Owl', description: 'Complete 5 jobs after 8 PM', icon: '🦉', checkFn: async (techId) => {
    const jobs = await base44.entities.ServiceRequest.filter({ technician_id: techId, status: 'completed' }, '-completed_at', 100);
    const lateJobs = jobs.filter(j => {
      const hour = new Date(j.completed_at).getHours();
      return hour >= 20;
    });
    return lateJobs.length >= 5;
  }},
  perfect_week: { title: 'Perfect Week', description: 'Complete 20+ jobs in one week', icon: '📅', checkFn: async (techId) => {
    const jobs = await base44.entities.ServiceRequest.filter({ technician_id: techId, status: 'completed' }, '-completed_at', 100);
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const weekJobs = jobs.filter(j => new Date(j.completed_at) >= weekAgo);
    return weekJobs.length >= 20;
  }}
};

export default function AchievementsBadges({ technicianId, profile }) {
  const queryClient = useQueryClient();

  const { data: achievements = [] } = useQuery({
    queryKey: ['achievements', technicianId],
    queryFn: async () => {
      return await base44.entities.Achievement.filter({ technician_id: technicianId }, '-earned_date');
    },
    enabled: !!technicianId
  });

  const checkAndAwardBadge = useMutation({
    mutationFn: async (badgeType) => {
      // Check if already earned
      if (achievements.some(a => a.badge_type === badgeType)) return null;

      const badge = BADGE_DEFINITIONS[badgeType];
      let earned = false;

      if (badge.threshold) {
        earned = profile?.total_jobs >= badge.threshold;
      } else if (badge.checkFn) {
        earned = await badge.checkFn(technicianId, profile);
      }

      if (earned) {
        const newAchievement = await base44.entities.Achievement.create({
          technician_id: technicianId,
          badge_type: badgeType,
          title: badge.title,
          description: badge.description,
          icon: badge.icon,
          earned_date: new Date().toISOString()
        });

        // Notify
        await base44.entities.Notification.create({
          user_id: technicianId,
          type: 'job_status_update',
          title: '🏆 New Achievement!',
          message: `You've earned "${badge.title}" badge!`,
          related_id: newAchievement.id
        });

        return newAchievement;
      }
      return null;
    },
    onSuccess: (newAchievement) => {
      if (newAchievement) {
        queryClient.invalidateQueries(['achievements', technicianId]);
        toast.success(`🏆 Achievement Unlocked: ${newAchievement.title}!`);
      }
    }
  });

  // Check for new achievements on load
  useEffect(() => {
    if (technicianId && profile) {
      Object.keys(BADGE_DEFINITIONS).forEach(badgeType => {
        setTimeout(() => checkAndAwardBadge.mutate(badgeType), 100);
      });
    }
  }, [technicianId, profile?.total_jobs]);

  const earnedBadges = Object.keys(BADGE_DEFINITIONS).filter(key => 
    achievements.some(a => a.badge_type === key)
  );
  const lockedBadges = Object.keys(BADGE_DEFINITIONS).filter(key => 
    !achievements.some(a => a.badge_type === key)
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Award className="w-5 h-5" style={{ color: '#FF771D' }} />
          Achievements ({achievements.length}/{Object.keys(BADGE_DEFINITIONS).length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          <AnimatePresence>
            {earnedBadges.map(key => {
              const badge = BADGE_DEFINITIONS[key];
              return (
                <motion.div
                  key={key}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="relative"
                >
                  <div className="aspect-square rounded-lg border-2 border-green-500 bg-gradient-to-br from-green-50 to-yellow-50 p-3 flex flex-col items-center justify-center text-center hover:shadow-lg transition-all cursor-pointer">
                    <div className="text-4xl mb-2">{badge.icon}</div>
                    <p className="text-xs font-bold text-gray-900">{badge.title}</p>
                    <p className="text-xs text-gray-600 mt-1">{badge.description}</p>
                  </div>
                </motion.div>
              );
            })}
            {lockedBadges.map(key => {
              const badge = BADGE_DEFINITIONS[key];
              return (
                <motion.div
                  key={key}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <div className="aspect-square rounded-lg border-2 border-gray-300 bg-gray-100 p-3 flex flex-col items-center justify-center text-center relative">
                    <Lock className="absolute top-2 right-2 w-3 h-3 text-gray-400" />
                    <div className="text-3xl mb-2 grayscale opacity-40">{badge.icon}</div>
                    <p className="text-xs font-bold text-gray-500">{badge.title}</p>
                    <p className="text-xs text-gray-400 mt-1">{badge.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </CardContent>
    </Card>
  );
}