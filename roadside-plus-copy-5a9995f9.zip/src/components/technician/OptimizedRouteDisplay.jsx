import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Navigation, Clock, MapPin, AlertCircle, TrendingUp, MapIcon, ChevronDown, ChevronUp, Route, Edit } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import ServiceTypeIcon from '../common/ServiceTypeIcon';
import { MapContainer, TileLayer, Marker, Polyline, Popup } from 'react-leaflet';
import ManualRouteAdjuster from './ManualRouteAdjuster';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix Leaflet icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const createColoredIcon = (color, number) => {
  return L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="
        width: 32px;
        height: 32px;
        background-color: ${color};
        border: 3px solid white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 14px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      ">
        ${number}
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 16],
  });
};

const createStartIcon = () => {
  return L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="
        width: 36px;
        height: 36px;
        background-color: #3D692B;
        border: 3px solid white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 18px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      ">
        🚗
      </div>
    `,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
  });
};

export default function OptimizedRouteDisplay({ route, onNavigate, currentLocation }) {
  const [expandedStop, setExpandedStop] = useState(null);
  const [showMap, setShowMap] = useState(true);
  const [showManualAdjust, setShowManualAdjust] = useState(false);

  const handleSaveManualRoute = (updatedRoute) => {
    setShowManualAdjust(false);
  };

  const handleResetRoute = () => {
    setShowManualAdjust(false);
  };

  if (!route || !route.stops) return null;

  const totalDistance = route.total_distance || 0;
  const totalTime = route.total_time || 0;
  const timeSaved = route.time_saved || 0;

  // Build polyline coordinates: start -> stop1 -> stop2 -> ... -> stopN
  const routeCoordinates = [
    [currentLocation.lat, currentLocation.lng],
    ...route.stops.map(stop => [stop.location.lat, stop.location.lng])
  ];

  // Calculate map bounds
  const allLats = routeCoordinates.map(coord => coord[0]);
  const allLngs = routeCoordinates.map(coord => coord[1]);
  const centerLat = (Math.min(...allLats) + Math.max(...allLats)) / 2;
  const centerLng = (Math.min(...allLngs) + Math.max(...allLngs)) / 2;

  return (
    <>
      {showManualAdjust ? (
        <ManualRouteAdjuster
          route={route}
          onSave={handleSaveManualRoute}
          onReset={handleResetRoute}
        />
      ) : (
        <Card className="border-2 border-green-500">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Navigation className="w-5 h-5 text-green-600" />
                Optimized Multi-Stop Route
              </CardTitle>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowManualAdjust(true)}
                  style={{ borderColor: '#FF771D', color: '#FF771D' }}
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Adjust
                </Button>
                <Badge className="bg-green-100 text-green-800">
                  {route.stops.length} Stops
                </Badge>
              </div>
            </div>
          </CardHeader>
      <CardContent className="space-y-4">
        {/* Route Summary */}
        <div className="grid grid-cols-3 gap-2 p-3 bg-green-50 rounded-lg">
          <div className="text-center">
            <p className="text-xs text-gray-600">Distance</p>
            <p className="font-bold text-green-800">{totalDistance.toFixed(1)} mi</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-600">Time</p>
            <p className="font-bold text-green-800">{totalTime} min</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-gray-600">Saved</p>
            <p className="font-bold text-green-600 flex items-center justify-center gap-1">
              <TrendingUp className="w-3 h-3" />
              {timeSaved} min
            </p>
          </div>
        </div>

        {/* Toggle Map Button */}
        <Button
          variant="outline"
          className="w-full"
          onClick={() => setShowMap(!showMap)}
        >
          <MapIcon className="w-4 h-4 mr-2" />
          {showMap ? 'Hide' : 'Show'} Route Map
          {showMap ? <ChevronUp className="w-4 h-4 ml-2" /> : <ChevronDown className="w-4 h-4 ml-2" />}
        </Button>

        {/* Map */}
        {showMap && currentLocation && (
          <div className="rounded-lg overflow-hidden border-2 border-gray-200">
            <MapContainer
              center={[centerLat, centerLng]}
              zoom={11}
              style={{ height: '400px', width: '100%' }}
              scrollWheelZoom={false}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              
              {/* Starting point */}
              <Marker 
                position={[currentLocation.lat, currentLocation.lng]}
                icon={createStartIcon()}
              >
                <Popup>
                  <div className="text-center">
                    <p className="font-bold">Your Location</p>
                    <p className="text-xs">Starting Point</p>
                  </div>
                </Popup>
              </Marker>

              {/* Route stops */}
              {route.stops.map((stop, index) => (
                <Marker
                  key={stop.id}
                  position={[stop.location.lat, stop.location.lng]}
                  icon={createColoredIcon(
                    stop.priority === 'critical' ? '#E52C2D' : 
                    stop.priority === 'high' ? '#FF771D' : '#3D692B',
                    index + 1
                  )}
                >
                  <Popup>
                    <div className="min-w-[180px]">
                      <p className="font-bold mb-1">Stop {index + 1}</p>
                      <p className="text-sm mb-1">{stop.service_type.replace(/_/g, ' ')}</p>
                      <p className="text-xs text-gray-600 mb-1">{stop.address}</p>
                      <p className="text-xs text-gray-600">ETA: {stop.eta}</p>
                      {stop.is_available && (
                        <Badge className="bg-blue-100 text-blue-800 text-xs mt-1">Available</Badge>
                      )}
                    </div>
                  </Popup>
                </Marker>
              ))}

              {/* Route polyline */}
              <Polyline
                positions={routeCoordinates}
                pathOptions={{
                  color: '#3D692B',
                  weight: 4,
                  opacity: 0.7,
                  dashArray: '10, 10'
                }}
              />
            </MapContainer>
          </div>
        )}

        {/* Route Steps */}
        <div className="space-y-2">
          {route.stops.map((stop, index) => (
            <div
              key={stop.id}
              className={`border rounded-lg p-3 cursor-pointer transition-all ${
                expandedStop === index ? 'bg-blue-50 border-blue-300' : 'hover:bg-gray-50'
              }`}
              onClick={() => setExpandedStop(expandedStop === index ? null : index)}
            >
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0">
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm"
                    style={{ 
                      backgroundColor: stop.priority === 'critical' ? '#E52C2D' : 
                                      stop.priority === 'high' ? '#FF771D' : '#3D692B' 
                    }}
                  >
                    {index + 1}
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <ServiceTypeIcon type={stop.service_type} className="w-4 h-4" />
                    <span className="font-semibold text-sm">
                      {stop.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </span>
                    {stop.priority === 'critical' && (
                      <Badge className="bg-red-600 text-white text-xs">Critical</Badge>
                    )}
                    {stop.priority === 'high' && (
                      <Badge className="bg-orange-100 text-orange-800 text-xs">High Priority</Badge>
                    )}
                    {stop.is_available && (
                      <Badge className="bg-blue-100 text-blue-800 text-xs">Available</Badge>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-3 text-xs text-gray-600 flex-wrap">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      ETA: {stop.eta}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {stop.distance_from_previous?.toFixed(1) || stop.distance?.toFixed(1)} mi
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      Service: {stop.service_duration} min
                    </span>
                  </div>

                  {expandedStop === index && (
                    <div className="mt-3 pt-3 border-t space-y-3">
                      <div>
                        <p className="text-xs font-semibold text-gray-700 mb-1">Address:</p>
                        <p className="text-xs text-gray-600">{stop.address}</p>
                      </div>
                      
                      {stop.vehicle && (
                        <div>
                          <p className="text-xs font-semibold text-gray-700 mb-1">Vehicle:</p>
                          <p className="text-xs text-gray-600">{stop.vehicle}</p>
                        </div>
                      )}
                      
                      {stop.traffic_delay > 0 && (
                        <div className="flex items-center gap-1 text-xs text-orange-600">
                          <AlertCircle className="w-3 h-3" />
                          +{stop.traffic_delay} min traffic delay expected
                        </div>
                      )}

                      {/* Turn-by-Turn Directions */}
                      {stop.turn_by_turn && stop.turn_by_turn.length > 0 && (
                        <div className="bg-gray-50 rounded p-2">
                          <div className="flex items-center gap-1 text-xs font-semibold text-gray-700 mb-2">
                            <Route className="w-3 h-3" />
                            Turn-by-Turn Directions:
                          </div>
                          <ol className="space-y-1 ml-4 list-decimal">
                            {stop.turn_by_turn.map((instruction, i) => (
                              <li key={i} className="text-xs text-gray-600">
                                {instruction}
                              </li>
                            ))}
                          </ol>
                        </div>
                      )}

                      <Button
                        size="sm"
                        className="w-full mt-2"
                        style={{ backgroundColor: '#FF771D' }}
                        onClick={(e) => {
                          e.stopPropagation();
                          onNavigate(stop);
                        }}
                      >
                        <Navigation className="w-3 h-3 mr-1" />
                        Navigate to This Stop
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Navigation Button */}
        <Button
          className="w-full text-white py-6 text-lg font-semibold"
          style={{ backgroundColor: '#3D692B' }}
          onClick={() => onNavigate('all')}
        >
          <Navigation className="w-5 h-5 mr-2" />
          Start Complete Route in Maps
        </Button>

        {/* Optimization Notes & Recommendations */}
        {route.optimization_notes && (
          <div className="text-xs text-gray-600 p-3 bg-blue-50 rounded border border-blue-200">
            <p className="font-semibold mb-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              Route Analysis:
            </p>
            <p>{route.optimization_notes}</p>
          </div>
        )}

        {route.recommendations && route.recommendations.length > 0 && (
          <div className="text-xs text-gray-600 p-3 bg-yellow-50 rounded border border-yellow-200">
            <p className="font-semibold mb-2">💡 Smart Recommendations:</p>
            <ul className="space-y-1 ml-4 list-disc">
              {route.recommendations.map((rec, i) => (
                <li key={i}>{rec}</li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
      )}
    </>
  );
}