import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MapPin, Loader2 } from 'lucide-react';

export default function OnboardingServiceArea({ profile, onComplete }) {
  const [serviceRadius, setServiceRadius] = useState(profile.service_radius || 25);
  const [location, setLocation] = useState(null);
  const [gettingLocation, setGettingLocation] = useState(false);

  useEffect(() => {
    getCurrentLocation();
  }, []);

  const getCurrentLocation = () => {
    setGettingLocation(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
          setGettingLocation(false);
        },
        (error) => {
          console.error('Location error:', error);
          setGettingLocation(false);
        }
      );
    }
  };

  const saveServiceArea = useMutation({
    mutationFn: async () => {
      await base44.entities.TechnicianProfile.update(profile.id, {
        service_radius: serviceRadius,
        current_lat: location?.lat,
        current_lng: location?.lng,
        service_area: `${serviceRadius} miles radius`
      });
    },
    onSuccess: () => {
      onComplete();
    }
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="w-5 h-5" style={{ color: '#FF771D' }} />
          Service Area
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <h4 className="font-semibold mb-2">Your Current Location</h4>
            {gettingLocation ? (
              <div className="flex items-center gap-2 text-gray-600">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Getting location...</span>
              </div>
            ) : location ? (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                <p className="text-sm text-green-800">
                  ✓ Location detected: {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
                </p>
              </div>
            ) : (
              <Button variant="outline" onClick={getCurrentLocation}>
                <MapPin className="w-4 h-4 mr-2" />
                Enable Location
              </Button>
            )}
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">
              Service Radius (miles)
            </label>
            <Input
              type="number"
              min="5"
              max="100"
              value={serviceRadius}
              onChange={(e) => setServiceRadius(parseInt(e.target.value))}
            />
            <p className="text-xs text-gray-600 mt-1">
              You'll receive job requests within this radius from your location
            </p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-gray-700">
              <strong>Coverage Area:</strong> {serviceRadius} miles
            </p>
            <p className="text-xs text-gray-600 mt-1">
              You can update this later in your profile settings
            </p>
          </div>

          <Button
            onClick={() => saveServiceArea.mutate()}
            disabled={!location || saveServiceArea.isLoading}
            className="w-full text-white"
            style={{ backgroundColor: '#FF771D' }}
          >
            {saveServiceArea.isLoading ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
            ) : (
              'Save & Continue'
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}