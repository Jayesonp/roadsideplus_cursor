import React from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Settings, Zap, Shield, Navigation } from 'lucide-react';

export default function RoutePreferencesPanel({ profile }) {
  const queryClient = useQueryClient();
  const preferences = profile?.route_preferences || {
    avoid_tolls: false,
    avoid_highways: false,
    prefer_faster_routes: true
  };

  const updatePreferences = useMutation({
    mutationFn: async (newPreferences) => {
      return await base44.entities.TechnicianProfile.update(profile.id, {
        route_preferences: newPreferences
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['tech-profile']);
    }
  });

  const updateTrafficAwareness = useMutation({
    mutationFn: async (enabled) => {
      return await base44.entities.TechnicianProfile.update(profile.id, {
        traffic_awareness_enabled: enabled
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['tech-profile']);
    }
  });

  const handleToggle = (key) => {
    const updated = { ...preferences, [key]: !preferences[key] };
    updatePreferences.mutate(updated);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="w-5 h-5" style={{ color: '#FF771D' }} />
          Route Preferences
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between py-3 border-b">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
              <Navigation className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <Label className="text-sm font-semibold">Real-Time Traffic</Label>
              <p className="text-xs text-gray-500">Use live traffic data for routing</p>
            </div>
          </div>
          <Switch
            checked={profile?.traffic_awareness_enabled !== false}
            onCheckedChange={updateTrafficAwareness.mutate}
          />
        </div>

        <div className="flex items-center justify-between py-3 border-b">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
              <Zap className="w-5 h-5" style={{ color: '#3D692B' }} />
            </div>
            <div>
              <Label className="text-sm font-semibold">Prefer Faster Routes</Label>
              <p className="text-xs text-gray-500">Optimize for speed over distance</p>
            </div>
          </div>
          <Switch
            checked={preferences.prefer_faster_routes}
            onCheckedChange={() => handleToggle('prefer_faster_routes')}
          />
        </div>

        <div className="flex items-center justify-between py-3 border-b">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
              <Shield className="w-5 h-5" style={{ color: '#FF771D' }} />
            </div>
            <div>
              <Label className="text-sm font-semibold">Avoid Toll Roads</Label>
              <p className="text-xs text-gray-500">Skip routes with tolls</p>
            </div>
          </div>
          <Switch
            checked={preferences.avoid_tolls}
            onCheckedChange={() => handleToggle('avoid_tolls')}
          />
        </div>

        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
              <Navigation className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <Label className="text-sm font-semibold">Avoid Highways</Label>
              <p className="text-xs text-gray-500">Use local roads when possible</p>
            </div>
          </div>
          <Switch
            checked={preferences.avoid_highways}
            onCheckedChange={() => handleToggle('avoid_highways')}
          />
        </div>

        <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <p className="text-xs text-blue-800">
            💡 These preferences will be applied to all route optimizations and navigation suggestions.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}