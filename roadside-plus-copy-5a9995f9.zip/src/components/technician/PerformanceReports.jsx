import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Calendar, TrendingUp, Activity } from 'lucide-react';
import { format, startOfWeek, endOfWeek, eachDayOfInterval, subDays } from 'date-fns';

export default function PerformanceReports({ technicianId }) {
  const [days, setDays] = useState(30);

  const { data: jobs = [] } = useQuery({
    queryKey: ['performance-jobs', technicianId, days],
    queryFn: async () => {
      const cutoffDate = subDays(new Date(), days);
      const allJobs = await base44.entities.ServiceRequest.filter(
        { technician_id: technicianId },
        '-completed_at',
        200
      );
      return allJobs.filter(j => j.completed_at && new Date(j.completed_at) >= cutoffDate);
    },
    enabled: !!technicianId
  });

  const { data: ratings = [] } = useQuery({
    queryKey: ['performance-ratings', technicianId, days],
    queryFn: async () => {
      const cutoffDate = subDays(new Date(), days);
      const allRatings = await base44.entities.Rating.filter(
        { technician_id: technicianId },
        '-created_date',
        100
      );
      return allRatings.filter(r => new Date(r.created_date) >= cutoffDate);
    },
    enabled: !!technicianId
  });

  // Jobs over time
  const jobsOverTime = jobs.reduce((acc, job) => {
    const date = format(new Date(job.completed_at), 'MMM dd');
    const existing = acc.find(item => item.date === date);
    if (existing) {
      existing.jobs += 1;
      existing.earnings += (job.payment_amount || job.price || 0);
    } else {
      acc.push({ 
        date, 
        jobs: 1, 
        earnings: (job.payment_amount || job.price || 0) 
      });
    }
    return acc;
  }, []).sort((a, b) => new Date(a.date) - new Date(b.date));

  // Service type distribution
  const serviceTypes = jobs.reduce((acc, job) => {
    const type = job.service_type.replace(/_/g, ' ');
    acc[type] = (acc[type] || 0) + 1;
    return acc;
  }, {});

  const serviceTypeData = Object.entries(serviceTypes).map(([name, value]) => ({
    name,
    value
  }));

  // Rating distribution
  const ratingDist = ratings.reduce((acc, r) => {
    acc[r.rating] = (acc[r.rating] || 0) + 1;
    return acc;
  }, {});

  const ratingData = [1, 2, 3, 4, 5].map(rating => ({
    rating: `${rating} ⭐`,
    count: ratingDist[rating] || 0
  }));

  // Weekly earnings
  const weeklyData = [];
  for (let i = 0; i < Math.min(4, Math.floor(days / 7)); i++) {
    const weekStart = startOfWeek(subDays(new Date(), i * 7));
    const weekEnd = endOfWeek(weekStart);
    const weekJobs = jobs.filter(j => {
      const date = new Date(j.completed_at);
      return date >= weekStart && date <= weekEnd;
    });
    const earnings = weekJobs.reduce((sum, j) => sum + (j.payment_amount || j.price || 0), 0);
    weeklyData.unshift({
      week: format(weekStart, 'MMM dd'),
      jobs: weekJobs.length,
      earnings: earnings
    });
  }

  const COLORS = ['#FF771D', '#E52C2D', '#3D692B', '#6366F1', '#F59E0B', '#10B981'];

  return (
    <div className="space-y-6">
      {/* Period Selector */}
      <div className="flex items-center gap-2">
        <Calendar className="w-5 h-5 text-gray-500" />
        <div className="flex gap-2">
          {[7, 14, 30, 90].map(d => (
            <button
              key={d}
              onClick={() => setDays(d)}
              className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                days === d 
                  ? 'bg-orange-600 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {d} days
            </button>
          ))}
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Jobs & Earnings Over Time */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Jobs & Earnings Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={jobsOverTime}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis yAxisId="left" tick={{ fontSize: 12 }} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Line yAxisId="left" type="monotone" dataKey="jobs" stroke="#FF771D" strokeWidth={2} name="Jobs" />
                <Line yAxisId="right" type="monotone" dataKey="earnings" stroke="#10B981" strokeWidth={2} name="Earnings ($)" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Service Type Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Service Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={serviceTypeData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {serviceTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Rating Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Rating Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={ratingData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="rating" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="count" fill="#FFB800" name="Count" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Weekly Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Weekly Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" tick={{ fontSize: 12 }} />
                <YAxis yAxisId="left" tick={{ fontSize: 12 }} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left" dataKey="jobs" fill="#FF771D" name="Jobs" />
                <Bar yAxisId="right" dataKey="earnings" fill="#10B981" name="Earnings ($)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}