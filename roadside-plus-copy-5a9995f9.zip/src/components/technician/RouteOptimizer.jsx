import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Navigation, Clock, MapPin, Loader2, Sparkles, ExternalLink } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Polyline, Popup } from 'react-leaflet';
import L from 'leaflet';

// Custom marker icons
const technicianIcon = L.divIcon({
  html: `<div style="background: #FF771D; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
      <path d="M5 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-1"/>
      <polygon points="12 15 17 21 7 21 12 15"/>
    </svg>
  </div>`,
  className: '',
  iconSize: [30, 30],
  iconAnchor: [15, 15]
});

const jobIcon = (number) => L.divIcon({
  html: `<div style="background: #3D692B; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3); color: white; font-weight: bold; font-size: 14px;">${number}</div>`,
  className: '',
  iconSize: [32, 32],
  iconAnchor: [16, 16]
});

export default function RouteOptimizer({ technicianId, currentLocation }) {
  const [optimizedRoute, setOptimizedRoute] = useState(null);
  const [loading, setLoading] = useState(false);

  const { data: activeJobs = [] } = useQuery({
    queryKey: ['active-jobs', technicianId],
    queryFn: async () => {
      const jobs = await base44.entities.ServiceRequest.filter(
        { technician_id: technicianId, status: ['assigned', 'en_route'] },
        'created_date',
        20
      );
      return jobs;
    },
    enabled: !!technicianId
  });

  const optimizeRoute = async () => {
    if (activeJobs.length === 0) return;
    
    setLoading(true);
    try {
      const jobsData = activeJobs.map(job => ({
        id: job.id,
        service_type: job.service_type,
        location: {
          lat: job.location_lat,
          lng: job.location_lng,
          address: job.location_address
        },
        status: job.status,
        created_at: job.created_date,
        estimated_service_time: getEstimatedServiceTime(job.service_type)
      }));

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an AI route optimizer for roadside assistance technicians. Analyze the following data and provide an optimized route.

Current Technician Location: ${currentLocation?.lat}, ${currentLocation?.lng}

Active Jobs to Complete:
${jobsData.map((j, i) => `
Job ${i + 1}:
- ID: ${j.id}
- Service Type: ${j.service_type}
- Location: ${j.location.address || `${j.location.lat}, ${j.location.lng}`}
- Estimated Service Time: ${j.estimated_service_time} minutes
- Current Status: ${j.status}
- Created: ${new Date(j.created_at).toLocaleTimeString()}
`).join('\n')}

Consider:
1. Distance between locations (prioritize closer jobs)
2. Job urgency (older requests should be prioritized)
3. Estimated service times
4. Current job status (en_route jobs should be first)
5. Minimize backtracking
6. Traffic patterns (current time: ${new Date().toLocaleTimeString()})

Provide:
1. Optimized order of job IDs
2. Estimated total time (travel + service)
3. Estimated total distance
4. Brief reasoning for the route
5. Time estimate for each leg of journey
6. Recommendations to maximize efficiency`,
        response_json_schema: {
          type: 'object',
          properties: {
            optimized_order: {
              type: 'array',
              items: { type: 'string' },
              description: 'Job IDs in optimal order'
            },
            total_time_minutes: {
              type: 'number',
              description: 'Total estimated time in minutes'
            },
            total_distance_miles: {
              type: 'number',
              description: 'Total estimated distance in miles'
            },
            reasoning: {
              type: 'string',
              description: 'Explanation of route optimization'
            },
            leg_details: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  from: { type: 'string' },
                  to: { type: 'string' },
                  travel_time_minutes: { type: 'number' },
                  distance_miles: { type: 'number' }
                }
              }
            },
            recommendations: {
              type: 'array',
              items: { type: 'string' }
            }
          }
        }
      });

      // Build optimized job list
      const orderedJobs = response.optimized_order.map(jobId => 
        activeJobs.find(j => j.id === jobId)
      ).filter(Boolean);

      setOptimizedRoute({
        ...response,
        jobs: orderedJobs
      });
    } catch (error) {
      console.error('Route optimization error:', error);
      alert('Failed to optimize route. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getEstimatedServiceTime = (serviceType) => {
    const times = {
      tire_change: 30,
      battery_jump: 15,
      fuel_delivery: 10,
      lockout: 20,
      towing: 45,
      other: 25
    };
    return times[serviceType] || 20;
  };

  const openInMaps = (lat, lng) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
    window.open(url, '_blank');
  };

  if (activeJobs.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Navigation className="w-5 h-5" style={{ color: '#3D692B' }} />
            Route Optimizer
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8 text-gray-500">
          No active jobs to optimize
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Navigation className="w-5 h-5" style={{ color: '#3D692B' }} />
            AI Route Optimizer
          </CardTitle>
          <Button
            onClick={optimizeRoute}
            disabled={loading}
            className="text-white hover:opacity-90"
            style={{ backgroundColor: '#3D692B' }}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Optimizing...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Optimize Route
              </>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {!optimizedRoute && (
          <div className="text-center py-4">
            <p className="text-gray-600 text-sm mb-2">
              You have {activeJobs.length} active job{activeJobs.length > 1 ? 's' : ''}
            </p>
            <p className="text-gray-500 text-xs">
              Click "Optimize Route" to get AI-powered route suggestions
            </p>
          </div>
        )}

        {optimizedRoute && (
          <>
            {/* Summary */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
                <div className="flex items-center gap-2 mb-1">
                  <Clock className="w-4 h-4 text-blue-600" />
                  <span className="text-xs font-semibold text-blue-800">Total Time</span>
                </div>
                <p className="text-xl font-bold text-blue-900">
                  {Math.floor(optimizedRoute.total_time_minutes / 60)}h {optimizedRoute.total_time_minutes % 60}m
                </p>
              </div>
              <div className="bg-green-50 rounded-lg p-3 border border-green-200">
                <div className="flex items-center gap-2 mb-1">
                  <MapPin className="w-4 h-4 text-green-600" />
                  <span className="text-xs font-semibold text-green-800">Total Distance</span>
                </div>
                <p className="text-xl font-bold text-green-900">
                  {optimizedRoute.total_distance_miles.toFixed(1)} mi
                </p>
              </div>
            </div>

            {/* Reasoning */}
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
              <h4 className="font-semibold text-sm mb-2 text-purple-900">Route Strategy</h4>
              <p className="text-sm text-purple-800">{optimizedRoute.reasoning}</p>
            </div>

            {/* Map */}
            {currentLocation && (
              <div className="h-64 rounded-lg overflow-hidden border-2 border-gray-200">
                <MapContainer
                  center={[currentLocation.lat, currentLocation.lng]}
                  zoom={11}
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                  />
                  
                  {/* Technician location */}
                  <Marker position={[currentLocation.lat, currentLocation.lng]} icon={technicianIcon}>
                    <Popup>Your Location</Popup>
                  </Marker>
                  
                  {/* Job markers */}
                  {optimizedRoute.jobs.map((job, idx) => (
                    <Marker 
                      key={job.id} 
                      position={[job.location_lat, job.location_lng]}
                      icon={jobIcon(idx + 1)}
                    >
                      <Popup>
                        <strong>Stop {idx + 1}</strong><br/>
                        {job.service_type.replace(/_/g, ' ')}
                      </Popup>
                    </Marker>
                  ))}
                  
                  {/* Route line */}
                  <Polyline
                    positions={[
                      [currentLocation.lat, currentLocation.lng],
                      ...optimizedRoute.jobs.map(j => [j.location_lat, j.location_lng])
                    ]}
                    color="#3D692B"
                    weight={3}
                    opacity={0.7}
                  />
                </MapContainer>
              </div>
            )}

            {/* Optimized Job List */}
            <div>
              <h4 className="font-semibold text-sm mb-2">Optimized Route ({optimizedRoute.jobs.length} stops)</h4>
              <div className="space-y-2">
                {optimizedRoute.jobs.map((job, idx) => (
                  <div key={job.id} className="border rounded-lg p-3 bg-white">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ backgroundColor: '#3D692B' }}>
                          {idx + 1}
                        </span>
                        <div>
                          <h5 className="font-semibold text-sm">
                            {job.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                          </h5>
                          <p className="text-xs text-gray-500">{job.location_address}</p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => openInMaps(job.location_lat, job.location_lng)}
                      >
                        <ExternalLink className="w-3 h-3" />
                      </Button>
                    </div>
                    {optimizedRoute.leg_details[idx] && (
                      <div className="flex gap-4 text-xs text-gray-600 mt-2">
                        <span>🚗 {optimizedRoute.leg_details[idx].distance_miles.toFixed(1)} mi</span>
                        <span>⏱️ {optimizedRoute.leg_details[idx].travel_time_minutes} min travel</span>
                        <span>🔧 {getEstimatedServiceTime(job.service_type)} min service</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendations */}
            {optimizedRoute.recommendations?.length > 0 && (
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                <h4 className="font-semibold text-sm mb-2 text-orange-900">💡 Efficiency Tips</h4>
                <ul className="space-y-1">
                  {optimizedRoute.recommendations.map((rec, idx) => (
                    <li key={idx} className="text-sm text-orange-800">• {rec}</li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}