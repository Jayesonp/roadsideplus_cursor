import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Clock, Loader2 } from 'lucide-react';

export default function OnboardingAvailability({ profile, onComplete }) {
  const [isAvailable, setIsAvailable] = useState(true);
  const [schedule, setSchedule] = useState({
    monday: true,
    tuesday: true,
    wednesday: true,
    thursday: true,
    friday: true,
    saturday: true,
    sunday: false
  });

  const saveAvailability = useMutation({
    mutationFn: async () => {
      await base44.entities.TechnicianProfile.update(profile.id, {
        is_available: isAvailable,
        availability_status: isAvailable ? 'available' : 'offline',
        schedule: schedule
      });
    },
    onSuccess: () => {
      onComplete();
    }
  });

  const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5" style={{ color: '#FF771D' }} />
          Availability Settings
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <Label className="font-semibold">Start as Available</Label>
              <p className="text-sm text-gray-600">Begin accepting jobs immediately</p>
            </div>
            <Switch
              checked={isAvailable}
              onCheckedChange={setIsAvailable}
              style={{
                backgroundColor: isAvailable ? '#3D692B' : '#ccc'
              }}
            />
          </div>

          <div>
            <h4 className="font-semibold mb-3">Preferred Working Days</h4>
            <div className="space-y-2">
              {days.map((day) => (
                <div key={day} className="flex items-center justify-between p-3 border rounded-lg">
                  <Label className="capitalize">{day}</Label>
                  <Switch
                    checked={schedule[day]}
                    onCheckedChange={(checked) =>
                      setSchedule({ ...schedule, [day]: checked })
                    }
                  />
                </div>
              ))}
            </div>
            <p className="text-xs text-gray-600 mt-2">
              You can change these settings anytime in your profile
            </p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-gray-700">
              <strong>Note:</strong> You have full control over your availability. 
              You can toggle online/offline anytime from your dashboard.
            </p>
          </div>

          <Button
            onClick={() => saveAvailability.mutate()}
            disabled={saveAvailability.isLoading}
            className="w-full text-white"
            style={{ backgroundColor: '#FF771D' }}
          >
            {saveAvailability.isLoading ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
            ) : (
              'Save & Continue'
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}