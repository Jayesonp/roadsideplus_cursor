import React, { useEffect, useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { MapPin, Clock, DollarSign, X, Car, User } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';

export default function UberStyleJobAlert({ technicianId, isAvailable }) {
  const [currentOffer, setCurrentOffer] = useState(null);
  const [customerData, setCustomerData] = useState(null);
  const [distance, setDistance] = useState(null);
  const [timeRemaining, setTimeRemaining] = useState(60);
  const [isExpired, setIsExpired] = useState(false);
  const audioRef = useRef(null);
  const timerRef = useRef(null);
  const queryClient = useQueryClient();

  // Fetch offers directed at this technician
  const { data: offers = [] } = useQuery({
    queryKey: ['technician-offers', technicianId],
    queryFn: async () => {
      const requests = await base44.entities.ServiceRequest.filter({
        current_offered_technician_id: technicianId,
        status: 'pending_dispatch'
      });
      if (requests.length > 0) {
        console.log('UberStyleJobAlert: Found offers:', requests.length);
      }
      return requests;
    },
    enabled: !!technicianId && isAvailable,
    refetchInterval: 5000,
    retry: 1,
    retryDelay: 2000,
    staleTime: 4000
  });

  const calculateDistance = (lat1, lng1, lat2, lng2) => {
    const R = 3959;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const acceptJob = useMutation({
    mutationFn: async (requestId) => {
      // Check if technician already has an active job
      const activeStatuses = ['assigned', 'en_route', 'in_progress', 'awaiting_review'];
      const myJobs = await base44.entities.ServiceRequest.filter({ technician_id: technicianId });
      const hasActiveJob = myJobs.some(job => activeStatuses.includes(job.status));
      
      if (hasActiveJob) {
        throw new Error('You already have an active job. Complete it before accepting another.');
      }

      const offerDuration = 60 - timeRemaining;
      
      // Log technician activity
      await base44.entities.TechnicianJobActivity.create({
        service_request_id: requestId,
        technician_id: technicianId,
        activity_type: 'offer_accepted',
        offer_duration_seconds: offerDuration
      });
      
      return await base44.entities.ServiceRequest.update(requestId, {
        technician_id: technicianId,
        status: 'assigned',
        current_offered_technician_id: null,
        offer_expires_at: null,
        estimated_arrival: new Date(Date.now() + 20 * 60000).toISOString()
      });
    },
    onSuccess: async (updatedRequest) => {
      stopAlert();
      queryClient.invalidateQueries(['technician-offers']);
      queryClient.invalidateQueries(['my-jobs']);
      
      if (updatedRequest.customer_id) {
        await base44.entities.Notification.create({
          user_id: updatedRequest.customer_id,
          type: 'technician_assigned',
          title: 'Technician Assigned',
          message: 'A technician has accepted your request!',
          related_id: updatedRequest.id
        });
      }
      
      window.location.href = createPageUrl(`JobDetails?id=${updatedRequest.id}`);
    }
  });

  const rejectJob = useMutation({
    mutationFn: async (requestId) => {
      const offerDuration = 60 - timeRemaining;
      
      // Log technician activity
      await base44.entities.TechnicianJobActivity.create({
        service_request_id: requestId,
        technician_id: technicianId,
        activity_type: 'offer_rejected',
        offer_duration_seconds: offerDuration,
        reason: 'Manually rejected by technician'
      });
      
      // Clear the offer so dispatch can find next technician
      await base44.entities.ServiceRequest.update(requestId, {
        current_offered_technician_id: null,
        offer_expires_at: null
      });

      // Trigger dispatch to resume search for next technician
      await base44.functions.invoke('dispatchServiceRequest', {
        requestId: requestId
      });
    },
    onSuccess: () => {
      stopAlert();
      queryClient.invalidateQueries(['technician-offers']);
    }
  });

  useEffect(() => {
    if (offers.length > 0 && !currentOffer) {
      const offer = offers[0];
      setCurrentOffer(offer);
      setTimeRemaining(60);
      setIsExpired(false);
      startAlert();
      
      // Load customer data and calculate distance
      loadCustomerData(offer.customer_id);
      if (offer.location_lat && offer.location_lng) {
        base44.entities.TechnicianProfile.filter({ user_id: technicianId })
          .then(profiles => {
            if (profiles[0]?.current_lat && profiles[0]?.current_lng) {
              const dist = calculateDistance(
                profiles[0].current_lat,
                profiles[0].current_lng,
                offer.location_lat,
                offer.location_lng
              );
              setDistance(dist);
            }
          });
      }
    } else if (offers.length === 0 && currentOffer) {
      stopAlert();
    }
  }, [offers]);

  const loadCustomerData = async (customerId) => {
    try {
      const customers = await base44.entities.User.filter({ id: customerId });
      if (customers[0]) {
        setCustomerData(customers[0]);
      }
    } catch (error) {
      console.error('Failed to load customer data:', error);
    }
  };

  useEffect(() => {
    if (!currentOffer) return;

    timerRef.current = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          handleExpiration();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentOffer]);

  const startAlert = () => {
    // Vibrate device
    if ('vibrate' in navigator) {
      navigator.vibrate([200, 100, 200, 100, 200]);
    }

    // Ensure Audio constructor exists before usage
    try {
      if (typeof window.Audio !== 'undefined') {
        // Despia environment safe audio construction
        const alertSound = new window.Audio('/alert.mp3');

        if (!audioRef.current) {
          audioRef.current = alertSound;
          audioRef.current.loop = true;
          audioRef.current.volume = 0.3;
          audioRef.current.play().catch(() => {});
        }
      }
    } catch (e) {
      console.warn('Audio blocked or illegal constructor:', e);
    }

    // Gradually increase volume over 10 seconds
    let volumeStep = 0;
    const volumeInterval = setInterval(() => {
      volumeStep++;
      if (audioRef.current && volumeStep <= 10) {
        audioRef.current.volume = Math.min(0.3 + (volumeStep * 0.07), 1.0);
      } else {
        clearInterval(volumeInterval);
      }
    }, 1000);

    // Repeat vibration every 5 seconds
    const vibrateInterval = setInterval(() => {
      if ('vibrate' in navigator) {
        navigator.vibrate([200, 100, 200]);
      }
    }, 5000);

    // Store interval for cleanup
    audioRef.current.vibrateInterval = vibrateInterval;
  };

  const stopAlert = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      if (audioRef.current.vibrateInterval) {
        clearInterval(audioRef.current.vibrateInterval);
      }
    }
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    if ('vibrate' in navigator) {
      navigator.vibrate(0);
    }
    setCurrentOffer(null);
    setCustomerData(null);
    setDistance(null);
    setTimeRemaining(60);
    setIsExpired(false);
  };

  const handleExpiration = async () => {
    setIsExpired(true);
    if (currentOffer) {
      // Log timeout activity
      await base44.entities.TechnicianJobActivity.create({
        service_request_id: currentOffer.id,
        technician_id: technicianId,
        activity_type: 'offer_timeout',
        offer_duration_seconds: 60,
        reason: 'Offer expired without response'
      });
      
      // Clear offer and resume search
      await base44.entities.ServiceRequest.update(currentOffer.id, {
        current_offered_technician_id: null,
        offer_expires_at: null
      });

      // Trigger dispatch to find next technician
      await base44.functions.invoke('dispatchServiceRequest', {
        requestId: currentOffer.id
      }).catch(err => console.error('Dispatch error:', err));

      stopAlert();
      queryClient.invalidateQueries(['technician-offers']);
    }
  };

  const handleAccept = () => {
    if (currentOffer && !isExpired) {
      acceptJob.mutate(currentOffer.id, {
        onError: (error) => {
          alert(error.message || 'Failed to accept job. Please try again.');
          stopAlert();
          queryClient.invalidateQueries(['technician-offers']);
        }
      });
    }
  };

  const handleReject = () => {
    if (currentOffer) {
      rejectJob.mutate(currentOffer.id);
    }
  };

  if (!currentOffer) return null;

  const progressPercent = (timeRemaining / 60) * 100;
  const urgencyColor = timeRemaining > 40 ? '#10B981' : timeRemaining > 20 ? '#F59E0B' : '#EF4444'; // Green -> Orange -> Red

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/95 backdrop-blur-sm"
        style={{
          paddingTop: 'var(--safe-area-top)',
          paddingLeft: 'env(safe-area-inset-left)',
          paddingRight: 'env(safe-area-inset-right)',
          paddingBottom: 'var(--safe-area-bottom)'
        }}
      >
        <div className="w-full max-w-md px-4 relative">
          {/* Animated Background Pulse */}
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.1, 0.3, 0.1],
            }}
            transition={{
              repeat: Infinity,
              duration: 2,
              ease: "easeInOut"
            }}
            className="absolute inset-0 bg-white rounded-full blur-3xl -z-10"
          />

          <motion.div
            animate={{
              scale: timeRemaining < 10 ? [1, 1.02, 1] : 1,
              borderColor: urgencyColor
            }}
            transition={{
              repeat: timeRemaining < 10 ? Infinity : 0,
              duration: 0.5
            }}
            className="bg-[#1C1C1C] rounded-3xl overflow-hidden border-4 shadow-2xl relative"
            style={{ borderColor: urgencyColor }}
          >
            {/* Top Progress Bar */}
            <div className="h-2 bg-gray-800 w-full">
              <motion.div
                className="h-full"
                style={{ backgroundColor: urgencyColor }}
                initial={{ width: '100%' }}
                animate={{ width: `${progressPercent}%` }}
                transition={{ duration: 1, ease: "linear" }}
              />
            </div>

            <div className="p-6 text-white">
              {/* Timer & Header */}
              <div className="text-center mb-8 relative">
                <motion.div
                  animate={{
                    scale: [1, 1.1, 1],
                    boxShadow: [`0 0 0 0px ${urgencyColor}40`, `0 0 0 20px ${urgencyColor}00`]
                  }}
                  transition={{
                    repeat: Infinity,
                    duration: 1.5
                  }}
                  className="w-24 h-24 rounded-full mx-auto mb-4 flex items-center justify-center border-4"
                  style={{ borderColor: urgencyColor, backgroundColor: '#2D2D2D' }}
                >
                  <div className="text-center">
                    <span className="block text-3xl font-bold leading-none">{timeRemaining}</span>
                    <span className="text-[10px] uppercase tracking-wider opacity-70">Seconds</span>
                  </div>
                </motion.div>
                
                <h2 className="text-2xl font-black uppercase tracking-wide mb-1">
                  New Job Request
                </h2>
                <p className="text-gray-400 text-sm">Accept quickly to secure this job</p>
              </div>

              {/* Job Details Card */}
              <div className="bg-[#2D2D2D] rounded-2xl p-5 mb-6 border border-gray-700">
                <div className="flex justify-between items-start mb-4 pb-4 border-b border-gray-700">
                  <div>
                    <p className="text-xs text-gray-400 uppercase font-bold mb-1">Service</p>
                    <h3 className="text-xl font-bold text-white flex items-center gap-2">
                      <Car className="w-5 h-5 text-blue-400" />
                      {currentOffer.service_type.replace(/_/g, ' ')}
                    </h3>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-400 uppercase font-bold mb-1">Payout</p>
                    <div className="text-2xl font-black text-green-400 flex items-center justify-end gap-1">
                      <span>${currentOffer.price?.toFixed(2) || '0.00'}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-xs text-gray-400 uppercase font-bold mb-1">Distance</p>
                    <div className="flex items-center gap-2 text-white font-semibold">
                      <MapPin className="w-4 h-4 text-orange-500" />
                      {distance ? `${distance.toFixed(1)} mi` : 'Calculating...'}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 uppercase font-bold mb-1">Vehicle</p>
                    <div className="text-white font-medium truncate">
                      {currentOffer.vehicle_make ? `${currentOffer.vehicle_year || ''} ${currentOffer.vehicle_make}` : 'Not specified'}
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 pt-3 border-t border-gray-700">
                  <p className="text-xs text-gray-400 uppercase font-bold mb-1">Location</p>
                  <p className="text-white text-sm line-clamp-2">{currentOffer.location_address}</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-1 gap-3">
                <Button
                  onClick={handleAccept}
                  disabled={isExpired || acceptJob.isLoading}
                  className="w-full h-16 text-xl font-black tracking-wide rounded-xl shadow-lg transform transition-transform active:scale-95"
                  style={{ 
                    backgroundColor: urgencyColor,
                    boxShadow: `0 4px 20px ${urgencyColor}40`
                  }}
                >
                  {isExpired ? 'OFFER EXPIRED' : 'TAP TO ACCEPT'}
                </Button>
                
                <Button
                  onClick={handleReject}
                  disabled={rejectJob.isLoading}
                  variant="ghost"
                  className="w-full h-12 text-gray-400 hover:text-white hover:bg-white/10 font-semibold rounded-xl"
                >
                  No Thanks
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}