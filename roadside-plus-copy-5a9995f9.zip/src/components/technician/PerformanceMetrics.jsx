import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Star, Clock, DollarSign, CheckCircle, Zap } from 'lucide-react';
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';

export default function PerformanceMetrics({ technicianId, profile }) {
  const { data: thisMonthJobs = [] } = useQuery({
    queryKey: ['monthly-jobs', technicianId],
    queryFn: async () => {
      const start = startOfMonth(new Date()).toISOString();
      const end = endOfMonth(new Date()).toISOString();
      
      const jobs = await base44.entities.ServiceRequest.filter(
        { technician_id: technicianId },
        '-completed_at',
        200
      );
      
      return jobs.filter(j => 
        j.completed_at && 
        new Date(j.completed_at) >= new Date(start) &&
        new Date(j.completed_at) <= new Date(end)
      );
    },
    enabled: !!technicianId
  });

  const { data: lastMonthJobs = [] } = useQuery({
    queryKey: ['last-month-jobs', technicianId],
    queryFn: async () => {
      const start = startOfMonth(subMonths(new Date(), 1)).toISOString();
      const end = endOfMonth(subMonths(new Date(), 1)).toISOString();
      
      const jobs = await base44.entities.ServiceRequest.filter(
        { technician_id: technicianId },
        '-completed_at',
        200
      );
      
      return jobs.filter(j => 
        j.completed_at && 
        new Date(j.completed_at) >= new Date(start) &&
        new Date(j.completed_at) <= new Date(end)
      );
    },
    enabled: !!technicianId
  });

  const { data: ratings = [] } = useQuery({
    queryKey: ['technician-ratings', technicianId],
    queryFn: async () => {
      return await base44.entities.Rating.filter(
        { technician_id: technicianId },
        '-created_date',
        100
      );
    },
    enabled: !!technicianId
  });

  // Calculate metrics
  const thisMonthEarnings = thisMonthJobs.reduce((sum, job) => sum + (job.payment_amount || job.price || 0), 0);
  const lastMonthEarnings = lastMonthJobs.reduce((sum, job) => sum + (job.payment_amount || job.price || 0), 0);
  const earningsGrowth = lastMonthEarnings > 0 ? ((thisMonthEarnings - lastMonthEarnings) / lastMonthEarnings * 100) : 0;

  const jobsGrowth = lastMonthJobs.length > 0 ? ((thisMonthJobs.length - lastMonthJobs.length) / lastMonthJobs.length * 100) : 0;

  // Calculate average response time (from assigned to en_route)
  const responseTimes = thisMonthJobs
    .filter(j => j.created_date && j.updated_date)
    .map(j => (new Date(j.updated_date) - new Date(j.created_date)) / (1000 * 60)); // minutes
  const avgResponseTime = responseTimes.length > 0 ? responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length : 0;

  const metrics = [
    {
      title: 'Jobs This Month',
      value: thisMonthJobs.length,
      change: jobsGrowth.toFixed(1),
      icon: CheckCircle,
      color: '#3D692B',
      suffix: ''
    },
    {
      title: 'Average Rating',
      value: profile?.rating?.toFixed(1) || '5.0',
      icon: Star,
      color: '#FFB800',
      suffix: '/5.0'
    },
    {
      title: 'Earnings This Month',
      value: `$${thisMonthEarnings.toFixed(0)}`,
      change: earningsGrowth.toFixed(1),
      icon: DollarSign,
      color: '#10B981',
      suffix: ''
    },
    {
      title: 'Avg Response Time',
      value: avgResponseTime.toFixed(0),
      icon: Clock,
      color: '#FF771D',
      suffix: ' min'
    },
    {
      title: 'Total Completed',
      value: profile?.total_jobs || 0,
      icon: Zap,
      color: '#6366F1',
      suffix: ' jobs'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
      {metrics.map((metric, idx) => (
        <Card key={idx}>
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">{metric.title}</p>
                <p className="text-2xl font-bold">
                  {metric.value}
                  <span className="text-sm font-normal text-gray-500">{metric.suffix}</span>
                </p>
                {metric.change && (
                  <div className={`flex items-center gap-1 mt-1 text-xs ${
                    parseFloat(metric.change) >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {parseFloat(metric.change) >= 0 ? (
                      <TrendingUp className="w-3 h-3" />
                    ) : (
                      <TrendingDown className="w-3 h-3" />
                    )}
                    <span>{Math.abs(parseFloat(metric.change))}% vs last month</span>
                  </div>
                )}
              </div>
              <div 
                className="w-10 h-10 rounded-full flex items-center justify-center"
                style={{ backgroundColor: `${metric.color}20` }}
              >
                <metric.icon className="w-5 h-5" style={{ color: metric.color }} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}