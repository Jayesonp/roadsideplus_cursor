// 🛡️ DESPIA RUNTIME SAFETY PATCHES
// This file must be imported as early as possible in the app lifecycle.
// It fixes specific crashes related to the Despia Native Runtime environment (Webview/Native bridges).

(function() {
  if (typeof window === 'undefined') return;

  console.log('🛡️ Applying Despia Runtime Safety Patches (Strong Mode)...');

  // --- 1. MessageChannel Polyfill ---
  // React Scheduler uses MessageChannel. If the native one is broken (Illegal constructor),
  // we MUST replace it with a working polyfill based on setTimeout.
  
  let needsPolyfill = false;
  try {
    if (typeof MessageChannel === 'undefined') {
      needsPolyfill = true;
    } else {
      const mc = new MessageChannel();
      mc.port1.close(); // Test basic functionality
    }
  } catch (e) {
    console.warn('⚠️ [Despia Patch] Native MessageChannel is broken. Activating Polyfill.');
    needsPolyfill = true;
  }

  if (needsPolyfill) {
    class MessagePortPolyfill {
      constructor() {
        this.onmessage = null;
        this._otherPort = null;
      }
      postMessage(message) {
        if (this._otherPort && this._otherPort.onmessage) {
          setTimeout(() => {
            if (this._otherPort.onmessage) {
              this._otherPort.onmessage({ data: message });
            }
          }, 0);
        }
      }
      start() {}
      close() {}
    }

    class MessageChannelPolyfill {
      constructor() {
        this.port1 = new MessagePortPolyfill();
        this.port2 = new MessagePortPolyfill();
        this.port1._otherPort = this.port2;
        this.port2._otherPort = this.port1;
      }
    }

    try {
      // Overwrite global
      window.MessageChannel = MessageChannelPolyfill;
      console.log('✅ [Despia Patch] MessageChannel polyfilled.');
    } catch (e) {
      console.error('❌ [Despia Patch] Failed to overwrite MessageChannel:', e);
    }
  }

  // --- 2. Monkey-Patch Native MessagePort (Late Binding Safety) ---
  // If React already captured the native MessageChannel reference before we could polyfill it,
  // we try to patch the native prototype methods to suppress the "Illegal constructor" crash.
  if (typeof MessagePort !== 'undefined' && MessagePort.prototype) {
    const safeWrap = (methodName) => {
      const original = MessagePort.prototype[methodName];
      if (!original) return;
      
      MessagePort.prototype[methodName] = function(...args) {
        try {
          return original.apply(this, args);
        } catch (e) {
          if (e.name === 'TypeError' && (e.message.includes('Illegal constructor') || e.message.includes('invocation'))) {
            console.warn(`🛡️ [Despia Patch] Suppressed crash in MessagePort.${methodName}`);
            return; // Suppress crash
          }
          throw e;
        }
      };
    };

    // Patch potentially dangerous methods
    safeWrap('postMessage');
    safeWrap('start');
    safeWrap('close');
  }

  // --- 3. Global Error Suppression ---
  // Catch any bubbling "Illegal constructor" errors to prevent white screens.
  const originalOnError = window.onerror;
  window.onerror = function(msg, url, line, col, error) {
    if (typeof msg === 'string' && (msg.includes('Illegal constructor') || msg.includes('MessagePort'))) {
      console.warn('🛡️ [Despia Patch] Caught global crash:', msg);
      return true; // Prevent default (crash)
    }
    if (originalOnError) return originalOnError.apply(this, arguments);
    return false;
  };

  // --- 4. Safe Audio Constructor ---
  if (typeof window.Audio !== 'undefined') {
    try {
      new window.Audio();
    } catch (e) {
      console.warn('⚠️ [Despia Patch] Audio constructor is restricted. Polyfilling.');
      const OriginalAudio = window.Audio;
      window.Audio = function() {
        try {
          return new OriginalAudio();
        } catch (e) {
          return {
            play: () => Promise.resolve(),
            pause: () => {},
            addEventListener: () => {},
            removeEventListener: () => {},
            setAttribute: () => {},
            src: ''
          };
        }
      };
    }
  }

})();

export default true;