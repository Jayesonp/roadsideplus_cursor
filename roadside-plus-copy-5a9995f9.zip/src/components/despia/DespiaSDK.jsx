/**
 * Despia Native SDK Helper
 * Provides utility functions for Despia native features
 */

import despia from '../despia';

/**
 * Send a local push notification
 * @param {number} seconds - Delay in seconds before showing notification
 * @param {string} title - Notification title
 * @param {string} message - Notification message
 * @param {string} url - Deep link URL to open when notification is tapped
 */
export function sendLocalPushNotification(seconds, title, message, url = '') {
  despia(`sendlocalpushmsg://push.send?s=${seconds}=msg!${message}&!#${title}&!#${url}`);
}

/**
 * Check if Despia native runtime is available
 * @returns {boolean}
 */
export function isDespiaAvailable() {
  return typeof window !== 'undefined' && typeof window.despia === 'function';
}

/**
 * Schedule a reminder notification
 * @param {number} delayMinutes - Minutes until reminder
 * @param {string} reminderText - Reminder message
 * @param {string} redirectUrl - Optional URL to open
 */
export function scheduleReminder(delayMinutes, reminderText, redirectUrl = '') {
  const seconds = delayMinutes * 60;
  sendLocalPushNotification(seconds, 'Reminder', reminderText, redirectUrl);
}

/**
 * Trigger biometric authentication (Face ID / Touch ID / Passcode)
 * Note: Define callback functions onBioAuthSuccess(), onBioAuthFailure(), and onBioAuthUnavailable()
 * The Despia Native Runtime will invoke these callbacks automatically
 */
export function triggerBiometricAuth() {
  despia('bioauth://');
}

export default {
  sendLocalPushNotification,
  isDespiaAvailable,
  scheduleReminder,
  triggerBiometricAuth,
  launchRevenueCatPaywall
};

/**
 * Launch RevenueCat Paywall
 * @param {string} userId - Current user ID
 * @param {string} offering - Offering identifier (default, premium, annual_sale)
 */
export function launchRevenueCatPaywall(userId, offering = 'default') {
  despia(`revenuecat://launchPaywall?external_id=${userId}&offering=${offering}`);
}