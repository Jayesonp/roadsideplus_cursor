import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar } from '@/components/ui/avatar';
import { Send, CheckCheck, Check, WifiOff, Paperclip, X, FileText, Image as ImageIcon, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { sendPushNotification } from '../pwa/PushNotificationManager';
import { useNetworkStatus } from '../offline/NetworkMonitor';
import { cacheMessages } from '../offline/cacheMessages';

export default function ChatInterface({ serviceRequestId, currentUserId, currentUserRole, otherUserId, otherUserName }) {
  const [newMessage, setNewMessage] = useState('');
  const [attachments, setAttachments] = useState([]);
  const [uploading, setUploading] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const queryClient = useQueryClient();
  const { isOnline } = useNetworkStatus();

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ['messages', serviceRequestId],
    queryFn: async () => {
      if (!isOnline) {
        return await cacheMessages.getMessages(serviceRequestId);
      }
      const freshMessages = await base44.entities.Message.filter(
        { service_request_id: serviceRequestId },
        'created_date',
        100
      );
      for (const msg of freshMessages) {
        await cacheMessages.saveMessage(msg);
      }
      return freshMessages;
    },
    enabled: !!serviceRequestId,
    refetchInterval: isOnline ? 3000 : false, // Real-time: poll every 3 seconds
    retry: 1,
    retryDelay: 5000,
    staleTime: 2000
  });

  // Mark messages as read when viewing
  useEffect(() => {
    if (messages.length > 0) {
      const unreadMessages = messages.filter(
        m => !m.is_read && m.sender_id !== currentUserId
      );
      
      if (unreadMessages.length > 0) {
        unreadMessages.forEach(async (msg) => {
          await base44.entities.Message.update(msg.id, { is_read: true });
        });
        queryClient.invalidateQueries(['messages', serviceRequestId]);
      }
    }
  }, [messages, currentUserId]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setUploading(true);
    try {
      const uploadedFiles = await Promise.all(
        files.map(async (file) => {
          const { file_url } = await base44.integrations.Core.UploadFile({ file });
          return {
            url: file_url,
            name: file.name,
            type: file.type.startsWith('image/') ? 'image' : 'file'
          };
        })
      );
      setAttachments([...attachments, ...uploadedFiles]);
    } catch (error) {
      console.error('Upload failed:', error);
    } finally {
      setUploading(false);
    }
  };

  const removeAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const sendMessageMutation = useMutation({
    mutationFn: async (messageText) => {
      const messageData = {
        service_request_id: serviceRequestId,
        sender_id: currentUserId,
        sender_role: currentUserRole,
        message: messageText,
        attachments: attachments.length > 0 ? JSON.stringify(attachments) : null,
        is_read: false,
        created_date: new Date().toISOString()
      };

      if (!isOnline) {
        return await cacheMessages.queueOfflineMessage(messageData);
      }

      const newMsg = await base44.entities.Message.create(messageData);
      await cacheMessages.saveMessage(newMsg);

      // Create notification for the other user
      await base44.entities.Notification.create({
        user_id: otherUserId,
        type: 'new_message',
        title: 'New Message',
        message: `You have a new message from ${currentUserRole === 'customer' ? 'customer' : 'technician'}`,
        related_id: serviceRequestId
      });

      // Send push notification
      sendPushNotification(
        'New Message',
        messageText.substring(0, 50) + (messageText.length > 50 ? '...' : ''),
        `/ServiceDetails?id=${serviceRequestId}`,
        otherUserId
      );

      return newMsg;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['messages', serviceRequestId]);
      setNewMessage('');
      setAttachments([]);
    }
  });

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (newMessage.trim()) {
      sendMessageMutation.mutate(newMessage.trim());
    }
  };

  const groupMessagesByDate = (messages) => {
    const groups = {};
    messages.forEach(msg => {
      const date = format(new Date(msg.created_date), 'yyyy-MM-dd');
      if (!groups[date]) groups[date] = [];
      groups[date].push(msg);
    });
    return groups;
  };

  const messageGroups = groupMessagesByDate(messages);

  return (
    <Card className="h-full md:h-[500px] flex flex-col">
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">
            Chat with {otherUserName || (currentUserRole === 'customer' ? 'Technician' : 'Customer')}
          </CardTitle>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-xs text-gray-500">Live</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
        {isLoading ? (
          <div className="text-center py-8 text-gray-500">Loading messages...</div>
        ) : messages.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <p className="mb-2">No messages yet</p>
            <p className="text-sm">Start the conversation!</p>
          </div>
        ) : (
          Object.entries(messageGroups).map(([date, msgs]) => (
            <div key={date}>
              <div className="text-center my-4">
                <span className="text-xs text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                  {format(new Date(date), 'MMM d, yyyy')}
                </span>
              </div>
              {msgs.map((msg) => {
                const isOwn = msg.sender_id === currentUserId;
                return (
                  <div key={msg.id} className={`flex mb-3 ${isOwn ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[70%] ${isOwn ? 'order-2' : 'order-1'}`}>
                      {!isOwn && (
                        <div className="flex items-center gap-2 mb-1">
                          <Avatar className="w-6 h-6 bg-gray-200" />
                          <span className="text-xs text-gray-500 font-medium">
                            {msg.sender_role === 'technician' ? 'Technician' : 'Customer'}
                          </span>
                        </div>
                      )}
                      <div
                        className={`rounded-2xl px-4 py-2 ${
                          isOwn
                            ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white'
                            : 'bg-gray-100 text-gray-900'
                        }`}
                      >
                        <p className="text-sm whitespace-pre-wrap break-words">{msg.message}</p>
                        {msg.attachments && (() => {
                          try {
                            const files = JSON.parse(msg.attachments);
                            return (
                              <div className="mt-2 space-y-2">
                                {files.map((file, idx) => (
                                  <div key={idx}>
                                   {file.type === 'image' ? (
                                     <a
                                       href={file.url}
                                       target="_blank"
                                       rel="noopener noreferrer"
                                       className="block"
                                     >
                                       <img
                                         src={file.url}
                                         alt={file.name}
                                         className="max-w-[200px] max-h-[200px] rounded-lg object-cover cursor-pointer hover:opacity-90 transition-opacity"
                                       />
                                     </a>
                                   ) : (
                                     <a
                                       href={file.url}
                                       target="_blank"
                                       rel="noopener noreferrer"
                                       className={`flex items-center gap-2 p-2 rounded-lg ${
                                         isOwn ? 'bg-white/20 hover:bg-white/30' : 'bg-gray-200 hover:bg-gray-300'
                                       } transition-colors`}
                                     >
                                       <FileText className="w-4 h-4" />
                                       <span className="text-xs truncate">{file.name}</span>
                                     </a>
                                   )}
                                  </div>
                                ))}
                              </div>
                            );
                          } catch {
                            return null;
                          }
                        })()}
                      </div>
                      <div className={`flex items-center gap-1 mt-1 ${isOwn ? 'justify-end' : 'justify-start'}`}>
                        <span className="text-xs text-gray-400">
                          {format(new Date(msg.created_date), 'h:mm a')}
                        </span>
                        {isOwn && msg.status === 'pending' && (
                          <WifiOff className="w-3 h-3 text-yellow-500" title="Sending when online..." />
                        )}
                        {isOwn && msg.status !== 'pending' && (
                          msg.is_read ? (
                            <CheckCheck className="w-3 h-3 text-blue-500" />
                          ) : (
                            <Check className="w-3 h-3 text-gray-400" />
                          )
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </CardContent>
      <div className="border-t p-4">
        {attachments.length > 0 && (
          <div className="mb-3 flex flex-wrap gap-2">
            {attachments.map((file, idx) => (
              <div
                key={idx}
                className="flex items-center gap-2 bg-gray-100 rounded-lg px-3 py-2 text-sm"
              >
                {file.type === 'image' ? (
                  <ImageIcon className="w-4 h-4 text-blue-600" />
                ) : (
                  <FileText className="w-4 h-4 text-gray-600" />
                )}
                <span className="truncate max-w-[150px]">{file.name}</span>
                <button
                  onClick={() => removeAttachment(idx)}
                  className="text-gray-500 hover:text-red-600"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileUpload}
            className="hidden"
            accept="image/jpeg,image/jpg,image/png,image/gif,image/webp,.pdf,.doc,.docx"
          />
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="self-end"
          >
            {uploading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Paperclip className="w-4 h-4" />
            )}
          </Button>
          <Textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 min-h-[60px] max-h-[120px] resize-none"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage(e);
              }
            }}
          />
          <Button
            type="submit"
            disabled={(!newMessage.trim() && attachments.length === 0) || sendMessageMutation.isLoading}
            className="self-end text-white hover:opacity-90"
            style={{ backgroundColor: '#FF771D' }}
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>
        <p className="text-xs text-gray-400 mt-2">Press Enter to send, Shift+Enter for new line</p>
      </div>
    </Card>
  );
}