import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MessageSquare, Clock, User, Wrench } from 'lucide-react';
import { format } from 'date-fns';

export default function ArchivedChatHistory({ serviceRequestId, currentUserId, currentUserRole }) {
  const { data: messages = [] } = useQuery({
    queryKey: ['archived-messages', serviceRequestId],
    queryFn: async () => {
      return await base44.entities.Message.filter(
        { service_request_id: serviceRequestId },
        'created_date'
      );
    },
    enabled: !!serviceRequestId
  });

  if (messages.length === 0) {
    return (
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 dark:text-white">
            <MessageSquare className="w-5 h-5" style={{ color: '#FF771D' }} />
            Chat History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No messages in this conversation</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="dark:bg-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 dark:text-white">
          <MessageSquare className="w-5 h-5" style={{ color: '#FF771D' }} />
          Chat History ({messages.length} messages)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-[500px] overflow-y-auto">
          {messages.map((message, idx) => {
            const isCurrentUser = message.sender_id === currentUserId;
            const isCustomer = message.sender_role === 'customer';
            
            return (
              <div
                key={message.id}
                className={`flex gap-3 ${isCurrentUser ? 'flex-row-reverse' : 'flex-row'}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  isCustomer ? 'bg-blue-100 dark:bg-blue-900' : 'bg-orange-100 dark:bg-orange-900'
                }`}>
                  {isCustomer ? (
                    <User className="w-4 h-4 text-blue-600 dark:text-blue-300" />
                  ) : (
                    <Wrench className="w-4 h-4 text-orange-600 dark:text-orange-300" />
                  )}
                </div>
                
                <div className={`flex-1 max-w-[70%] ${isCurrentUser ? 'items-end' : 'items-start'} flex flex-col`}>
                  <div className={`rounded-lg px-4 py-2 ${
                    isCurrentUser 
                      ? 'bg-orange-500 text-white' 
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white'
                  }`}>
                    <p className="text-sm">{message.message}</p>
                  </div>
                  <div className="flex items-center gap-1 mt-1 text-xs text-gray-500 dark:text-gray-400">
                    <Clock className="w-3 h-3" />
                    {format(new Date(message.created_date), 'MMM d, h:mm a')}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}