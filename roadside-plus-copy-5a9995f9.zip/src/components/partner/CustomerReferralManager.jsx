import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Users, Copy, CheckCircle, TrendingUp, 
  DollarSign, Share2, Search, Filter
} from 'lucide-react';
import { format } from 'date-fns';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function CustomerReferralManager({ partnerId, partnerCode, primaryColor = '#FF771D' }) {
  const [copied, setCopied] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const queryClient = useQueryClient();

  // Fetch customer referrals
  const { data: customerReferrals = [] } = useQuery({
    queryKey: ['customer-referrals', partnerId],
    queryFn: async () => {
      return await base44.entities.CustomerReferral.filter(
        { partner_id: partnerId },
        '-created_date'
      );
    },
    enabled: !!partnerId
  });

  // Fetch referred customers with service data
  const { data: referredCustomers = [] } = useQuery({
    queryKey: ['referred-customers', customerReferrals],
    queryFn: async () => {
      const customerIds = customerReferrals.map(r => r.customer_id);
      if (customerIds.length === 0) return [];
      
      // Get customer details
      const allUsers = await base44.entities.User.list();
      const customers = allUsers.filter(u => customerIds.includes(u.id));
      
      // Get service requests for each customer
      const customersWithServices = await Promise.all(
        customers.map(async (customer) => {
          const services = await base44.entities.ServiceRequest.filter({
            customer_id: customer.id,
            status: 'completed'
          });
          
          const referral = customerReferrals.find(r => r.customer_id === customer.id);
          
          return {
            ...customer,
            referral_id: referral?.id,
            referral_code: referral?.referral_code,
            referral_status: referral?.status,
            reward_earned: referral?.reward_earned || 0,
            reward_paid: referral?.reward_paid || false,
            services_count: services.length,
            total_spent: services.reduce((sum, s) => sum + (s.payment_amount || 0), 0),
            first_service_date: services.length > 0 ? services[0].created_date : null,
            last_service_date: services.length > 0 ? services[services.length - 1].created_date : null
          };
        })
      );
      
      return customersWithServices;
    },
    enabled: customerReferrals.length > 0
  });

  // Generate customer referral code
  const generateCustomerCode = useMutation({
    mutationFn: async () => {
      const code = `${partnerCode}-CUST-${Date.now().toString(36).toUpperCase()}`;
      return code;
    }
  });

  const copyReferralLink = (code) => {
    const referralLink = `${window.location.origin}/register?ref=${code}`;
    navigator.clipboard.writeText(referralLink);
    setCopied(code);
    setTimeout(() => setCopied(false), 2000);
  };

  // Filter customers
  const filteredCustomers = referredCustomers.filter(customer => {
    const matchesSearch = customer.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customer.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || customer.referral_status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Calculate stats
  const stats = {
    total: customerReferrals.length,
    signedUp: customerReferrals.filter(r => r.status === 'signed_up' || r.status === 'active').length,
    firstService: referredCustomers.filter(c => c.services_count > 0).length,
    totalEarned: customerReferrals.reduce((sum, r) => sum + (r.reward_earned || 0), 0),
    totalPaid: customerReferrals.filter(r => r.reward_paid).reduce((sum, r) => sum + (r.reward_earned || 0), 0)
  };

  const getStatusBadge = (customer) => {
    if (customer.services_count >= 5) {
      return <Badge className="bg-purple-100 text-purple-800">Loyal Customer</Badge>;
    } else if (customer.services_count > 0) {
      return <Badge className="bg-green-100 text-green-800">Active</Badge>;
    } else {
      return <Badge className="bg-yellow-100 text-yellow-800">Signed Up</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Customers</p>
                <p className="text-3xl font-bold mt-1">{stats.total}</p>
              </div>
              <Users className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">First Service Done</p>
                <p className="text-3xl font-bold mt-1" style={{ color: '#3D692B' }}>
                  {stats.firstService}
                </p>
              </div>
              <CheckCircle className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Earned</p>
                <p className="text-3xl font-bold mt-1" style={{ color: primaryColor }}>
                  ${stats.totalEarned.toFixed(0)}
                </p>
              </div>
              <TrendingUp className="w-10 h-10 opacity-20" style={{ color: primaryColor }} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Paid Out</p>
                <p className="text-3xl font-bold mt-1" style={{ color: '#3D692B' }}>
                  ${stats.totalPaid.toFixed(0)}
                </p>
              </div>
              <DollarSign className="w-10 h-10 opacity-20" style={{ color: '#3D692B' }} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Referral Code Generator */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5" style={{ color: primaryColor }} />
            Customer Referral Link
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 mb-3">
            Share this link with customers to earn rewards when they sign up and complete their first service
          </p>
          <div className="flex gap-2">
            <input
              type="text"
              readOnly
              value={`${window.location.origin}/register?ref=${partnerCode}`}
              className="flex-1 px-4 py-3 border rounded-lg bg-gray-50 text-sm"
            />
            <Button
              onClick={() => copyReferralLink(partnerCode)}
              className="text-white"
              style={{ backgroundColor: copied === partnerCode ? '#3D692B' : primaryColor }}
            >
              {copied === partnerCode ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="signed_up">Signed Up</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Customers List */}
      <Card>
        <CardHeader>
          <CardTitle>Referred Customers ({filteredCustomers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredCustomers.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-gray-600 mb-2">No customers yet</p>
              <p className="text-sm text-gray-500">Start sharing your referral link to grow your customer base!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredCustomers.map((customer) => (
                <Card key={customer.id} className="border hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4 flex-1">
                        <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0" 
                             style={{ backgroundColor: primaryColor }}>
                          {customer.full_name?.[0]?.toUpperCase() || 'C'}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-semibold truncate">{customer.full_name}</p>
                            {getStatusBadge(customer)}
                          </div>
                          <p className="text-sm text-gray-600 truncate mb-2">{customer.email}</p>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                            <div>
                              <p className="text-gray-500">Services</p>
                              <p className="font-semibold">{customer.services_count}</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Total Spent</p>
                              <p className="font-semibold">${customer.total_spent.toFixed(0)}</p>
                            </div>
                            {customer.first_service_date && (
                              <div>
                                <p className="text-gray-500">First Service</p>
                                <p className="font-semibold">{format(new Date(customer.first_service_date), 'MMM d, yyyy')}</p>
                              </div>
                            )}
                            {customer.last_service_date && (
                              <div>
                                <p className="text-gray-500">Last Service</p>
                                <p className="font-semibold">{format(new Date(customer.last_service_date), 'MMM d, yyyy')}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="text-right ml-4 flex-shrink-0">
                        {customer.reward_earned > 0 && (
                          <div>
                            <p className="text-2xl font-bold" style={{ color: '#3D692B' }}>
                              ${customer.reward_earned}
                            </p>
                            <Badge className={customer.reward_paid ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                              {customer.reward_paid ? 'Paid' : 'Pending'}
                            </Badge>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}