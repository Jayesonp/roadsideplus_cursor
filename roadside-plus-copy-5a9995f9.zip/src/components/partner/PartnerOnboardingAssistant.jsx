import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Bot, Send, Loader2, X, Minimize2, Maximize2, HelpCircle } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export default function PartnerOnboardingAssistant({ partner, onboardingStage = 'initial' }) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      initializeChat();
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const initializeChat = () => {
    const greetings = {
      registration: "👋 Welcome to ROADSIDE+! I'm your partner onboarding assistant. I'm here to help you through the registration process. What questions do you have about becoming a partner?",
      pending: "Hi there! I see your application is under review. While you wait, I can answer questions about our partnership program, commission structure, white-label features, and what to expect next!",
      active: "Welcome aboard! 🎉 Congratulations on becoming a ROADSIDE+ partner. I'm here to help you get started. Would you like to learn about client management, analytics, branding options, or how to maximize your referrals?"
    };

    setMessages([{
      role: 'assistant',
      content: greetings[onboardingStage] || greetings.registration
    }]);
  };

  const quickQuestions = [
    "How does the commission structure work?",
    "What are white-label features?",
    "How do I add clients?",
    "What's the approval process?",
    "How do I track my earnings?"
  ];

  const buildSystemPrompt = () => {
    return `You are an AI assistant for ROADSIDE+, a roadside assistance platform. You're helping a new partner understand the platform and complete their onboarding.

Key Information about the Partner Program:
- Partners can refer customers and earn commissions on completed services
- Commission rates are typically 10% but can be customized
- White-label features allow partners (especially insurance companies) to brand the platform
- Partners can manage their own client database
- Full analytics dashboard to track referrals and earnings
- Monthly automated payouts via Stripe Connect
- Partners can add staff members with different permission levels

White-Label Features:
- Custom domain support
- Custom logo and brand colors
- Branded customer portal
- Client database management
- Dedicated analytics

Onboarding Process:
1. Submit application with company details
2. Upload required documents (business license, insurance)
3. AI-powered review of application
4. Admin approval
5. Setup account and start referring customers

Your role:
- Be friendly, helpful, and encouraging
- Provide clear, concise answers
- Guide partners through setup steps
- Explain features in simple terms
- Encourage them to complete their profile

Current partner stage: ${onboardingStage}
${partner ? `Partner company: ${partner.company_name}, Status: ${partner.status}` : 'New partner (not yet registered)'}

Keep responses brief but informative. Use emojis occasionally to be friendly.`;
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const conversationHistory = messages.map(m => 
        `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`
      ).join('\n\n');

      const prompt = `${buildSystemPrompt()}

Conversation History:
${conversationHistory}

User: ${input}

Provide a helpful, friendly response:`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: false
      });

      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: "I apologize, but I'm having trouble right now. Please try again or contact support if the issue persists." 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickQuestion = (question) => {
    setInput(question);
    setTimeout(() => handleSend(), 100);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-20 right-6 w-14 h-14 rounded-full shadow-lg flex items-center justify-center text-white z-40 hover:scale-110 transition-transform"
        style={{ backgroundColor: '#FF771D' }}
        title="Partner Assistant"
      >
        <HelpCircle className="w-6 h-6" />
      </button>
    );
  }

  return (
    <Card 
      className={`fixed shadow-2xl z-40 flex flex-col ${
        isMaximized 
          ? 'inset-4' 
          : 'bottom-20 right-6 w-96 h-[600px]'
      } transition-all`}
    >
      <CardHeader 
        className="flex flex-row items-center justify-between p-4 border-b text-white"
        style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}
      >
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5" />
          <span className="font-semibold">Partner Assistant</span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMaximized(!isMaximized)}
            className="text-white hover:bg-white/20"
          >
            {isMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsOpen(false)}
            className="text-white hover:bg-white/20"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.role === 'user'
                    ? 'text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}
                style={message.role === 'user' ? { backgroundColor: '#FF771D' } : {}}
              >
                <ReactMarkdown className="text-sm prose prose-sm max-w-none">
                  {message.content}
                </ReactMarkdown>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-gray-100 rounded-lg p-3">
                <Loader2 className="w-5 h-5 animate-spin text-gray-600" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Questions */}
        {messages.length <= 2 && (
          <div className="p-3 border-t bg-gray-50">
            <p className="text-xs text-gray-600 mb-2">Quick questions:</p>
            <div className="flex flex-wrap gap-2">
              {quickQuestions.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleQuickQuestion(q)}
                  className="text-xs px-3 py-1 rounded-full border hover:bg-gray-100 transition-colors"
                  disabled={isLoading}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="p-4 border-t">
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask me anything..."
              disabled={isLoading}
              className="flex-1"
            />
            <Button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="text-white"
              style={{ backgroundColor: '#FF771D' }}
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}