import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, Navigation, Wrench, Clock, Zap } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export default function LiveStatusUpdates({ currentStatus, previousStatus }) {
  const [showUpdate, setShowUpdate] = useState(false);
  const [updateMessage, setUpdateMessage] = useState('');
  const prevStatusRef = useRef(previousStatus);

  const statusMessages = {
    assigned: {
      icon: CheckCircle,
      message: '✅ Technician assigned to your job',
      color: '#3D692B'
    },
    en_route: {
      icon: Navigation,
      message: '🚗 Technician is on the way',
      color: '#FF771D'
    },
    arrived: {
      icon: Clock,
      message: '📍 Technician has arrived',
      color: '#E52C2D'
    },
    in_progress: {
      icon: Wrench,
      message: '🔧 Work in progress',
      color: '#FF771D'
    },
    completed: {
      icon: CheckCircle,
      message: '✨ Job completed!',
      color: '#3D692B'
    }
  };

  useEffect(() => {
    if (currentStatus && prevStatusRef.current !== currentStatus) {
      const statusInfo = statusMessages[currentStatus];
      if (statusInfo) {
        setUpdateMessage(statusInfo.message);
        setShowUpdate(true);

        // Auto-hide after 5 seconds
        const timer = setTimeout(() => {
          setShowUpdate(false);
        }, 5000);

        prevStatusRef.current = currentStatus;

        return () => clearTimeout(timer);
      }
    }
  }, [currentStatus]);

  return (
    <AnimatePresence>
      {showUpdate && (
        <motion.div
          initial={{ opacity: 0, y: -50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -50, scale: 0.9 }}
          className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 max-w-md w-full px-4"
        >
          <Card className="border-2 shadow-2xl" style={{ borderColor: statusMessages[currentStatus]?.color }}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: 'spring' }}
                >
                  <Zap className="w-6 h-6" style={{ color: statusMessages[currentStatus]?.color }} />
                </motion.div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900">{updateMessage}</p>
                  <p className="text-xs text-gray-500">Just now • Live update</p>
                </div>
                <button
                  onClick={() => setShowUpdate(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}