const DB_NAME = 'roadsideplus_offline';
const DB_VERSION = 1;

export class OfflineStorage {
  static async init() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
      
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        
        if (!db.objectStoreNames.contains('jobs')) {
          db.createObjectStore('jobs', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('messages')) {
          db.createObjectStore('messages', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('cache')) {
          db.createObjectStore('cache', { keyPath: 'key' });
        }
      };
    });
  }

  static async saveJob(job) {
    const db = await this.init();
    const transaction = db.transaction(['jobs'], 'readwrite');
    const store = transaction.objectStore('jobs');
    await store.put(job);
  }

  static async getJob(id) {
    const db = await this.init();
    const transaction = db.transaction(['jobs'], 'readonly');
    const store = transaction.objectStore('jobs');
    return new Promise((resolve) => {
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result);
    });
  }

  static async saveMessages(messages) {
    const db = await this.init();
    const transaction = db.transaction(['messages'], 'readwrite');
    const store = transaction.objectStore('messages');
    messages.forEach(msg => store.put(msg));
  }

  static async getMessages() {
    const db = await this.init();
    const transaction = db.transaction(['messages'], 'readonly');
    const store = transaction.objectStore('messages');
    return new Promise((resolve) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
    });
  }

  static async saveCache(key, data) {
    const db = await this.init();
    const transaction = db.transaction(['cache'], 'readwrite');
    const store = transaction.objectStore('cache');
    await store.put({ key, data, timestamp: Date.now() });
  }

  static async getCache(key) {
    const db = await this.init();
    const transaction = db.transaction(['cache'], 'readonly');
    const store = transaction.objectStore('cache');
    return new Promise((resolve) => {
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result?.data);
    });
  }
}