import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';

export default function PushNotificationManager({ userId, userRole }) {
  const [lastCheck, setLastCheck] = useState(Date.now());

  useEffect(() => {
    if (!userId) return;
    
    // Service Worker registration disabled to prevent MIME errors
    // registerServiceWorker();
    requestNotificationPermission();
    
    // Poll intervals: technicians/officers 20s, others 60s to reduce rate limits
    const pollInterval = userRole === 'technician' ? 20000 : userRole === 'officer' ? 20000 : 60000;
    const interval = setInterval(() => {
      checkForNotifications();
    }, pollInterval);
    
    return () => clearInterval(interval);
  }, [userId, userRole]);

  const registerServiceWorker = async () => {
    // Service Worker registration completely disabled
    console.log('Service Worker registration disabled by policy');
  };

  const requestNotificationPermission = async () => {
    if ('Notification' in window && Notification.permission === 'default') {
      try {
        await Notification.requestPermission();
      } catch (e) {
        console.warn('Notification permission request failed (Despia Runtime):', e);
      }
    }
  };

  const checkForNotifications = async () => {
    try {
      const notifications = await base44.entities.Notification.filter(
        { user_id: userId, is_read: false },
        '-created_date',
        10
      );
      
      notifications.forEach(notif => {
        if (new Date(notif.created_date).getTime() > lastCheck) {
          showNotification(notif);
        }
      });
      
      setLastCheck(Date.now());
    } catch (error) {
      console.error('Notification check failed:', error);
    }
  };

  const showNotification = (notification) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      // Critical priority for technician job offers, officer assignments and broadcasts
      const isCritical = notification.type === 'new_service_request' ||
                         notification.type === 'new_message' || 
                         notification.title?.includes('BROADCAST') ||
                         notification.title?.includes('Assignment') ||
                         notification.title?.includes('Job Offer');
      
      try {
        const notif = new Notification(notification.title, {
          body: notification.message,
          icon: '/icon-192x192.png',
          badge: '/icon-192x192.png',
          tag: notification.id,
          requireInteraction: isCritical,
          vibrate: isCritical ? [300, 100, 300, 100, 300] : [200, 100, 200],
          silent: false,
          data: {
            url: notification.related_id ? `/JobDetails?id=${notification.related_id}` : null
          }
        });
        
        notif.onclick = () => {
          window.focus();
          if (notification.related_id) {
            if (userRole === 'officer') {
              window.location.href = `/SecurityIncidentDetail?id=${notification.related_id}`;
            } else if (userRole === 'technician' && notification.type === 'new_service_request') {
              window.location.href = `/JobDetails?id=${notification.related_id}`;
            }
          }
          notif.close();
        };
      } catch (e) {
        console.warn('Notification constructor failed (Despia Runtime):', e);
      }
    }
  };

  return null;
}

export function sendPushNotification(title, body, url, userId) {
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: '/icon-192.png',
        badge: '/badge-72.png',
        vibrate: [200, 100, 200],
        data: { url }
      });
    } catch (e) {
      console.warn('Notification constructor failed (Despia Runtime):', e);
    }
  }
}