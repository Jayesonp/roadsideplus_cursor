import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { RefreshCw, AlertTriangle } from 'lucide-react';
import { triggerJobReassignment } from '../dispatch/JobReassignmentMonitor';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function ManualReassignmentButton({ jobId, jobDetails }) {
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  const handleReassign = async () => {
    setLoading(true);
    try {
      const result = await triggerJobReassignment(
        jobId, 
        reason || 'manual reassignment by admin'
      );
      
      if (result.success) {
        alert('Job reassigned successfully!');
        window.location.reload();
      } else {
        alert(`Reassignment failed: ${result.error || result.reason}`);
      }
    } catch (error) {
      alert(`Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50">
          <RefreshCw className="w-4 h-4 mr-2" />
          Reassign Job
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            Reassign This Job?
          </AlertDialogTitle>
          <AlertDialogDescription>
            This will remove the current technician and automatically find a replacement.
            The customer and both technicians will be notified.
          </AlertDialogDescription>
        </AlertDialogHeader>
        
        <div className="space-y-3 py-4">
          {jobDetails && (
            <div className="bg-gray-50 p-3 rounded-lg text-sm">
              <p><strong>Job:</strong> {jobDetails.service_type?.replace(/_/g, ' ')}</p>
              <p><strong>Status:</strong> {jobDetails.status}</p>
            </div>
          )}
          
          <div>
            <Label htmlFor="reason">Reason for Reassignment (optional)</Label>
            <Input
              id="reason"
              placeholder="e.g., technician unable to reach location"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
          </div>
        </div>

        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleReassign}
            disabled={loading}
            className="bg-orange-600 hover:bg-orange-700"
          >
            {loading ? 'Reassigning...' : 'Reassign Job'}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}