import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { 
  Phone, MapPin, Car, CreditCard, CheckCircle, 
  ArrowRight, Bell, Sparkles 
} from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function CustomerOnboardingFlow({ userId, onComplete }) {
  const [step, setStep] = useState(1);
  const [profileData, setProfileData] = useState({
    phone: '',
    address: ''
  });
  const [vehicleData, setVehicleData] = useState({
    make: '',
    model: '',
    year: new Date().getFullYear().toString(),
    color: '',
    license_plate: ''
  });

  const totalSteps = 5;
  const progress = (step / totalSteps) * 100;

  const handleProfileSubmit = async () => {
    try {
      await base44.auth.updateMe({
        phone: profileData.phone,
        address: profileData.address
      });
      setStep(2);
    } catch (error) {
      console.error('Profile update error:', error);
    }
  };

  const handleVehicleSubmit = async () => {
    try {
      await base44.entities.Vehicle.create({
        customer_id: userId,
        ...vehicleData,
        is_default: true
      });
      setStep(3);
    } catch (error) {
      console.error('Vehicle creation error:', error);
    }
  };

  const handleNotificationSetup = async () => {
    try {
      if ('Notification' in window && Notification.permission !== 'granted') {
        await Notification.requestPermission();
      }
      
      await base44.entities.NotificationPreferences.create({
        user_id: userId,
        new_messages: true,
        job_status_updates: true,
        technician_arrival: true,
        payment_reminders: true,
        push_enabled: true
      });
      setStep(4);
    } catch (error) {
      console.error('Notification setup error:', error);
      setStep(4);
    }
  };

  const completeOnboarding = () => {
    setStep(5);
    setTimeout(() => {
      onComplete?.();
      window.location.href = createPageUrl('CustomerDashboard');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-semibold" style={{ color: '#FF771D' }}>
              Step {step} of {totalSteps}
            </span>
            <span className="text-sm text-gray-600">{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step 1: Welcome & Profile */}
        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-6 h-6" style={{ color: '#FF771D' }} />
                Welcome to ROADSIDE+!
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Let's get you set up for emergency roadside assistance
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <div className="relative mt-1">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={profileData.phone}
                    onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                    className="pl-10"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Used to contact you during emergencies
                </p>
              </div>

              <div>
                <Label htmlFor="address">Home Address</Label>
                <div className="relative mt-1">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="address"
                    type="text"
                    placeholder="123 Main St, City, State"
                    value={profileData.address}
                    onChange={(e) => setProfileData({ ...profileData, address: e.target.value })}
                    className="pl-10"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Helps us serve you better
                </p>
              </div>

              <Button
                onClick={handleProfileSubmit}
                className="w-full text-white"
                style={{ backgroundColor: '#FF771D' }}
                disabled={!profileData.phone}
              >
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>

              <button
                onClick={() => setStep(2)}
                className="w-full text-sm text-gray-500 hover:text-gray-700"
              >
                Skip for now
              </button>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Vehicle Information */}
        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Car className="w-6 h-6" style={{ color: '#FF771D' }} />
                Add Your Vehicle
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Help technicians identify your vehicle quickly
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="make">Make</Label>
                  <Input
                    id="make"
                    placeholder="Toyota"
                    value={vehicleData.make}
                    onChange={(e) => setVehicleData({ ...vehicleData, make: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="model">Model</Label>
                  <Input
                    id="model"
                    placeholder="Camry"
                    value={vehicleData.model}
                    onChange={(e) => setVehicleData({ ...vehicleData, model: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="year">Year</Label>
                  <Input
                    id="year"
                    type="number"
                    placeholder="2020"
                    value={vehicleData.year}
                    onChange={(e) => setVehicleData({ ...vehicleData, year: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="color">Color</Label>
                  <Input
                    id="color"
                    placeholder="Silver"
                    value={vehicleData.color}
                    onChange={(e) => setVehicleData({ ...vehicleData, color: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="license_plate">License Plate</Label>
                <Input
                  id="license_plate"
                  placeholder="ABC-1234"
                  value={vehicleData.license_plate}
                  onChange={(e) => setVehicleData({ ...vehicleData, license_plate: e.target.value })}
                />
              </div>

              <Button
                onClick={handleVehicleSubmit}
                className="w-full text-white"
                style={{ backgroundColor: '#FF771D' }}
                disabled={!vehicleData.make || !vehicleData.model}
              >
                Add Vehicle
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>

              <button
                onClick={() => setStep(3)}
                className="w-full text-sm text-gray-500 hover:text-gray-700"
              >
                Skip for now
              </button>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Notifications */}
        {step === 3 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-6 h-6" style={{ color: '#FF771D' }} />
                Enable Notifications
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Stay updated on your service requests
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-900 mb-3">
                  Get notified when:
                </p>
                <ul className="space-y-2 text-sm text-blue-800">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    A technician is assigned to your request
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    Your technician is on the way
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    Your service is completed
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    You receive messages from technicians
                  </li>
                </ul>
              </div>

              <Button
                onClick={handleNotificationSetup}
                className="w-full text-white"
                style={{ backgroundColor: '#FF771D' }}
              >
                Enable Notifications
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>

              <button
                onClick={() => setStep(4)}
                className="w-full text-sm text-gray-500 hover:text-gray-700"
              >
                Maybe later
              </button>
            </CardContent>
          </Card>
        )}

        {/* Step 4: Payment Method */}
        {step === 4 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-6 h-6" style={{ color: '#FF771D' }} />
                Payment Method
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Add a payment method for quick service requests
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-sm text-yellow-900 mb-2">
                  💳 Payment is required before service
                </p>
                <p className="text-xs text-yellow-800">
                  Add your payment method now or add it later when requesting service.
                </p>
              </div>

              <div className="space-y-3">
                <Button
                  onClick={() => {
                    window.location.href = createPageUrl('Settings') + '?addPayment=true';
                  }}
                  className="w-full text-white"
                  style={{ backgroundColor: '#FF771D' }}
                >
                  Add Payment Method Now
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>

                <Button
                  onClick={completeOnboarding}
                  variant="outline"
                  className="w-full"
                >
                  I'll Add It Later
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 5: Complete */}
        {step === 5 && (
          <Card className="text-center">
            <CardContent className="pt-6 pb-8">
              <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold mb-2">You're All Set!</h2>
              <p className="text-gray-600 mb-4">
                Welcome to ROADSIDE+. You're ready to request emergency assistance anytime.
              </p>
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 mx-auto" 
                   style={{ borderColor: '#FF771D' }}></div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}