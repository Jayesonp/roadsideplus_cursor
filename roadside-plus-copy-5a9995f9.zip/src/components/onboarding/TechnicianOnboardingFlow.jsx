import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Phone, MapPin, Wrench, FileText, CheckCircle, 
  ArrowRight, Bell, Upload, Car, Award
} from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function TechnicianOnboardingFlow({ userId, profileId, onComplete }) {
  const [step, setStep] = useState(1);
  const [profileData, setProfileData] = useState({
    phone: '',
    bio: '',
    vehicle_type: '',
    license_plate: ''
  });
  const [selectedSkills, setSelectedSkills] = useState([]);
  const [serviceTypes, setServiceTypes] = useState([]);

  const totalSteps = 6;
  const progress = (step / totalSteps) * 100;

  const availableSkills = [
    'Brake Repair', 'Engine Diagnostics', 'Electrical Systems',
    'Transmission Repair', 'Air Conditioning', 'Oil Change',
    'Tire Service', 'Battery Service', 'Suspension Repair'
  ];

  const availableServices = [
    { value: 'tire_change', label: 'Tire Change' },
    { value: 'battery_jump', label: 'Battery Jump Start' },
    { value: 'fuel_delivery', label: 'Fuel Delivery' },
    { value: 'lockout', label: 'Lockout Service' },
    { value: 'towing', label: 'Towing' }
  ];

  const handleProfileSubmit = async () => {
    try {
      await base44.entities.TechnicianProfile.update(profileId, {
        phone: profileData.phone,
        bio: profileData.bio,
        vehicle_type: profileData.vehicle_type,
        license_plate: profileData.license_plate
      });
      setStep(2);
    } catch (error) {
      console.error('Profile update error:', error);
    }
  };

  const handleSkillsSubmit = async () => {
    try {
      await base44.entities.TechnicianProfile.update(profileId, {
        skills: selectedSkills,
        preferred_service_types: serviceTypes
      });
      setStep(3);
    } catch (error) {
      console.error('Skills update error:', error);
    }
  };

  const handleServiceAreaSetup = () => {
    // Service area will be set via geolocation
    setStep(4);
  };

  const handleNotificationSetup = async () => {
    try {
      if ('Notification' in window && Notification.permission !== 'granted') {
        await Notification.requestPermission();
      }
      
      await base44.entities.NotificationPreferences.create({
        user_id: userId,
        new_messages: true,
        job_status_updates: true,
        new_job_assignments: true,
        payment_reminders: true,
        push_enabled: true
      });
      setStep(5);
    } catch (error) {
      console.error('Notification setup error:', error);
      setStep(5);
    }
  };

  const completeOnboarding = async () => {
    try {
      await base44.entities.TechnicianProfile.update(profileId, {
        onboarding_completed: true
      });
      setStep(6);
      setTimeout(() => {
        onComplete?.();
        window.location.href = createPageUrl('TechnicianDashboard');
      }, 2000);
    } catch (error) {
      console.error('Onboarding completion error:', error);
    }
  };

  const toggleSkill = (skill) => {
    setSelectedSkills(prev => 
      prev.includes(skill) 
        ? prev.filter(s => s !== skill)
        : [...prev, skill]
    );
  };

  const toggleServiceType = (type) => {
    setServiceTypes(prev => 
      prev.includes(type) 
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-semibold" style={{ color: '#FF771D' }}>
              Step {step} of {totalSteps}
            </span>
            <span className="text-sm text-gray-600">{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step 1: Profile Information */}
        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wrench className="w-6 h-6" style={{ color: '#FF771D' }} />
                Welcome, Technician!
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Let's set up your professional profile
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <div className="relative mt-1">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={profileData.phone}
                    onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="bio">Professional Bio</Label>
                <Textarea
                  id="bio"
                  placeholder="Tell customers about your experience and expertise..."
                  value={profileData.bio}
                  onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="vehicle_type">Your Vehicle</Label>
                  <div className="relative mt-1">
                    <Car className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      id="vehicle_type"
                      placeholder="Truck/Van"
                      value={profileData.vehicle_type}
                      onChange={(e) => setProfileData({ ...profileData, vehicle_type: e.target.value })}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="license_plate">License Plate</Label>
                  <Input
                    id="license_plate"
                    placeholder="ABC-1234"
                    value={profileData.license_plate}
                    onChange={(e) => setProfileData({ ...profileData, license_plate: e.target.value })}
                  />
                </div>
              </div>

              <Button
                onClick={handleProfileSubmit}
                className="w-full text-white"
                style={{ backgroundColor: '#FF771D' }}
                disabled={!profileData.phone}
              >
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Skills & Services */}
        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-6 h-6" style={{ color: '#FF771D' }} />
                Your Skills & Services
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Select the services you can provide
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="mb-3 block">Service Types</Label>
                <div className="grid grid-cols-2 gap-3">
                  {availableServices.map((service) => (
                    <div 
                      key={service.value}
                      className={`flex items-center gap-2 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                        serviceTypes.includes(service.value)
                          ? 'border-orange-500 bg-orange-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => toggleServiceType(service.value)}
                    >
                      <Checkbox checked={serviceTypes.includes(service.value)} />
                      <span className="text-sm font-medium">{service.label}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label className="mb-3 block">Technical Skills</Label>
                <div className="grid grid-cols-2 gap-2">
                  {availableSkills.map((skill) => (
                    <div 
                      key={skill}
                      className={`flex items-center gap-2 p-2 rounded-lg border cursor-pointer transition-all ${
                        selectedSkills.includes(skill)
                          ? 'border-orange-500 bg-orange-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => toggleSkill(skill)}
                    >
                      <Checkbox checked={selectedSkills.includes(skill)} />
                      <span className="text-xs">{skill}</span>
                    </div>
                  ))}
                </div>
              </div>

              <Button
                onClick={handleSkillsSubmit}
                className="w-full text-white"
                style={{ backgroundColor: '#FF771D' }}
                disabled={serviceTypes.length === 0}
              >
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Service Area */}
        {step === 3 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-6 h-6" style={{ color: '#FF771D' }} />
                Service Area
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Where do you provide services?
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-900 mb-2">
                  📍 Location-Based Service Area
                </p>
                <p className="text-xs text-blue-800">
                  Your service area will be determined by your current location. 
                  You can adjust this later in settings.
                </p>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm font-semibold mb-2">Default Service Radius:</p>
                <p className="text-2xl font-bold" style={{ color: '#FF771D' }}>25 miles</p>
                <p className="text-xs text-gray-600 mt-1">
                  From your current location
                </p>
              </div>

              <Button
                onClick={handleServiceAreaSetup}
                className="w-full text-white"
                style={{ backgroundColor: '#FF771D' }}
              >
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Step 4: Notifications */}
        {step === 4 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-6 h-6" style={{ color: '#FF771D' }} />
                Job Notifications
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Never miss a job opportunity
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <p className="text-sm text-orange-900 mb-3 font-semibold">
                  🔔 Critical for Technicians!
                </p>
                <ul className="space-y-2 text-sm text-orange-800">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 flex-shrink-0" />
                    Get instant alerts for new job assignments
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 flex-shrink-0" />
                    Receive urgent customer updates
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 flex-shrink-0" />
                    Payment and earnings notifications
                  </li>
                </ul>
              </div>

              <Button
                onClick={handleNotificationSetup}
                className="w-full text-white"
                style={{ backgroundColor: '#FF771D' }}
              >
                Enable Notifications
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>

              <button
                onClick={() => setStep(5)}
                className="w-full text-sm text-gray-500 hover:text-gray-700"
              >
                Skip for now
              </button>
            </CardContent>
          </Card>
        )}

        {/* Step 5: Documents */}
        {step === 5 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-6 h-6" style={{ color: '#FF771D' }} />
                Required Documents
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Upload your certifications and licenses
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-sm text-yellow-900 mb-2">
                  📄 Documents Needed:
                </p>
                <ul className="space-y-1 text-xs text-yellow-800">
                  <li>• Driver's License (Required)</li>
                  <li>• Insurance Documents (Required)</li>
                  <li>• Professional Certifications (Optional)</li>
                </ul>
              </div>

              <div className="space-y-3">
                <Button
                  onClick={() => window.location.href = createPageUrl('TechnicianProfile')}
                  className="w-full text-white"
                  style={{ backgroundColor: '#FF771D' }}
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Documents Now
                </Button>

                <Button
                  onClick={completeOnboarding}
                  variant="outline"
                  className="w-full"
                >
                  I'll Upload Later
                </Button>
              </div>

              <p className="text-xs text-gray-500 text-center">
                Note: You'll need to complete document verification before accepting jobs
              </p>
            </CardContent>
          </Card>
        )}

        {/* Step 6: Complete */}
        {step === 6 && (
          <Card className="text-center">
            <CardContent className="pt-6 pb-8">
              <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Welcome Aboard!</h2>
              <p className="text-gray-600 mb-4">
                You're ready to start accepting jobs and helping customers.
              </p>
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 mx-auto" 
                   style={{ borderColor: '#FF771D' }}></div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}