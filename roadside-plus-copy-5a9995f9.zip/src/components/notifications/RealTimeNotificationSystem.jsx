import { useEffect, useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { sendPushNotification } from '../pwa/PushNotificationManager';
import { createPageUrl } from '@/utils';

export default function RealTimeNotificationSystem({ userId, userRole }) {
  const queryClient = useQueryClient();
  const lastCheckRef = useRef(Date.now());
  const pollingIntervalRef = useRef(null);
  const errorCountRef = useRef(0);
  const [pollingInterval, setPollingInterval] = useState(30000); // Start with 30 seconds

  useEffect(() => {
    if (!userId) return;

    // Start polling for notifications
    startNotificationPolling();

    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
    };
  }, [userId, userRole]);

  const startNotificationPolling = () => {
    // Initial check after a short delay to avoid immediate rate limit
    setTimeout(() => {
      checkForNewNotifications();
    }, 2000);

    // Poll every 30-60 seconds based on error rate
    pollingIntervalRef.current = setInterval(() => {
      checkForNewNotifications();
    }, pollingInterval);
  };

  const checkForNewNotifications = async () => {
    try {
      const notifications = await base44.entities.Notification.filter(
        { 
          user_id: userId,
          created_date: { $gte: new Date(lastCheckRef.current).toISOString() }
        },
        '-created_date',
        50
      );

      if (notifications.length > 0) {
        // Update last check time
        lastCheckRef.current = Date.now();

        // Process each new notification
        notifications.forEach(notification => {
          handleNewNotification(notification);
        });

        // Invalidate notification queries to update UI
        queryClient.invalidateQueries(['notifications']);
      }

      // Reset error count on success
      errorCountRef.current = 0;
      
      // Restore normal polling interval if it was increased
      if (pollingInterval !== 30000) {
        setPollingInterval(30000);
        // Restart polling with new interval
        if (pollingIntervalRef.current) {
          clearInterval(pollingIntervalRef.current);
          pollingIntervalRef.current = setInterval(() => {
            checkForNewNotifications();
          }, 30000);
        }
      }
    } catch (error) {
      console.error('Error checking notifications:', error);
      
      // Handle rate limit errors with exponential backoff
      if (error.message?.includes('rate limit') || error.message?.includes('429')) {
        errorCountRef.current += 1;
        
        // Exponentially increase polling interval on rate limit errors
        const newInterval = Math.min(30000 * Math.pow(2, errorCountRef.current), 120000); // Max 2 minutes
        setPollingInterval(newInterval);
        
        // Restart polling with new interval
        if (pollingIntervalRef.current) {
          clearInterval(pollingIntervalRef.current);
          pollingIntervalRef.current = setInterval(() => {
            checkForNewNotifications();
          }, newInterval);
        }
      }
    }
  };

  const handleNewNotification = (notification) => {
    const notificationConfig = getNotificationConfig(notification, userRole);
    
    if (notificationConfig) {
      // Send push notification
      sendPushNotification(
        notificationConfig.title,
        notificationConfig.body,
        notificationConfig.url,
        userId
      );

      // Play notification sound
      playNotificationSound(notification.type);

      // Invalidate relevant queries
      invalidateRelevantQueries(notification);
    }
  };

  const getNotificationConfig = (notification, role) => {
    const configs = {
      technician: {
        'new_service_request': {
          title: '🚨 New Job Offer',
          body: notification.message,
          url: createPageUrl('TechnicianDashboard'),
          sound: 'urgent'
        },
        'job_assigned': {
          title: '✅ Job Assigned to You',
          body: notification.message,
          url: createPageUrl(`JobDetails?id=${notification.related_id}`),
          sound: 'success'
        },
        'job_cancelled': {
          title: '❌ Job Cancelled',
          body: notification.message,
          url: createPageUrl('TechnicianDashboard'),
          sound: 'alert'
        },
        'job_reassigned': {
          title: '⚠️ Job Reassigned',
          body: notification.message,
          url: createPageUrl('TechnicianDashboard'),
          sound: 'alert'
        },
        'urgent_job_update': {
          title: '⚠️ Urgent Job Update',
          body: notification.message,
          url: createPageUrl(`JobDetails?id=${notification.related_id}`),
          sound: 'urgent'
        },
        'customer_waiting': {
          title: '⏰ Customer Waiting',
          body: notification.message,
          url: createPageUrl(`JobDetails?id=${notification.related_id}`),
          sound: 'alert'
        },
        'new_message': {
          title: '💬 New Message',
          body: notification.message,
          url: createPageUrl(`JobDetails?id=${notification.related_id}`),
          sound: 'message'
        }
      },
      customer: {
        'technician_assigned': {
          title: '✅ Technician Assigned',
          body: notification.message,
          url: createPageUrl(`ServiceDetails?id=${notification.related_id}`),
          sound: 'success'
        },
        'technician_en_route': {
          title: '🚗 Technician En Route',
          body: notification.message,
          url: createPageUrl(`ServiceDetails?id=${notification.related_id}`),
          sound: 'alert'
        },
        'technician_arrived': {
          title: '📍 Technician Arrived',
          body: notification.message,
          url: createPageUrl(`ServiceDetails?id=${notification.related_id}`),
          sound: 'success'
        },
        'job_completed': {
          title: '🎉 Job Completed',
          body: notification.message,
          url: createPageUrl(`ServiceDetails?id=${notification.related_id}`),
          sound: 'success'
        },
        'new_message': {
          title: '💬 New Message',
          body: notification.message,
          url: createPageUrl(`ServiceDetails?id=${notification.related_id}`),
          sound: 'message'
        }
      }
    };

    const roleConfig = configs[role] || configs.customer;
    return roleConfig[notification.type];
  };

  const playNotificationSound = (type) => {
    try {
      // Ensure Audio constructor exists before usage
      if (typeof Audio === 'undefined' || typeof Audio !== 'function') {
        return;
      }
      
      let src = '';
      
      // Different sounds for different notification types
      switch (type) {
        case 'new_service_request':
          src = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTGM0fPTgjMGHWi56+OdTQwOUKvi8bllHAU2jdXxz3ksBS1+zPDaizsIG2S46+SVTAwMUKvj8blkHAU1i9Tx0X0wBSl9y/DZiToHGmG36+SXSwsKUK3j8bpmHAU0idPx0oE0BS1+y/HajDkHGV+16uaZTgsKUK3k8bxnHAU0iNLx04M2BTF+y/HbjjsHGF2z6+icUQsJUK7k8L5oHAU0htHx1IU4BTJ/zPHckTsHF1ux6uufUgsJUK7l8L9qHQU0hM/x1Yc6BTN/zfHek0wHF1qw6uygUwsJUK7l8MFqHQU0gc7x1oo7BTZ/zvHfljsHFlix6+2hVgsJUK/m8MJqHQU0f8zx14w8BTh/z/HgmjwHFVSv6++jWQsJUK/m8MRsHgUze8rx2I89BT1/z/HhmT0HFFKu6/ClWgsJULDm8MVsHgU1eMrx2JA+BT9/z/HimD4HE1Cs6/CoWgsIULHm8MZuHwU2dsjx2JI/BUF/0PHimT4HEk2p6/CqWgoIULHm8MhuHwU2eMjx2ZI/BUN/0PHjmj8HEUun6/GtWwoIULHm8MluHwU3e8nx2ZQ/BUV/0PHkmj8HEUqm6/GuWwoIULHm8MpwIAU4fMvx2ZY/BUZ/0PHlmz8HEUml6/KvWwoIULHm8MtwIAU5fc3x2pg/BUd/0PHmmz8HEUel6/KvXAoIULHm8M1xIAU6fs/x2ps/BUh/0PHom0AHEEWk6/OwXAoIULHm8M5xIAU7fs/x25s/BUp/0PHpm0AHEEOj6/KyXQoIULHm8M9yIQU8f9Hx3J0/BUt/0PHqnEEHEEKi6/K0XQoIULHm8NFzIQU9gNLx3Z8/BU1/0fHrnEEHD0Ch6/K1XgoIULHm8NJ0IgU+gtPx3qE/BU5/0fHsnUEHD0Ch6/O3XgoIULHm8NR1IgU/g9Xx4KI/BU9/0fHtnkIHDz+f6/O4XwoIULHm8NV1IgVAhNbx4aM/BVF/0fHtnkIHDz6e6/O5YAoIULHm8NZ2IwVBhdnx4qQ/BVJ/0fHunkIHDz2e6/O7YAoHULHm8Nd3IwVChtny46U/BVN/0fHvn0IHEEWR6/S8YQoHULHm8Nh3IwVDh9ny5Kg/BVR/0vHvoUMHD0OP6/S+YwoHULHn8Nl4IwVEidry5ao/BVV/0vHwo0QHEEOO6/S/YwoHULDn8Np5JAVFjdvy56w/BVd/0vHxpEQHEEON6/TCZAoHUK/n8Nt5JAVGj9zy6K4/BVh/0/HypkQHEEKM6/TDZAoHT6/n8Nx6JQVGkd7y6a8/BVl/0/HzpkQHEEKL6/TFZQoHT67n8N57JQVHk+Dy67E/BVp/0/H0p0UHEEGL6/THZgoHT67n8N97JQVIlebz7LM/BV1/1PH1qUUHEECK6/TIZgoHT63n8OB7JQVJle7z7rQ/BV5/1PH2q0YHEEGL6/TKZwoHT63n8OJ8JgVLl/Hz77Y/BV9/1PH3rEYHEECL6/TMaAoHT6zn8ON8JgVLmfH077c/BV9/1PH4rUYHEECL6/TOaAoHT6zn8OR9JwVMmvL077k/BV9/1PH4r0cHEECL6/TQaAoHTqvn8OV9JwVNnPT07rs/BV9/1PH5sEcHEECL6/TSaQoHTqvn8Oc+KAVOnvX077w/BWB/1fH6sUgHEECL6/TTaQoHTqvn8Oh+KAVPofb08L0/BWB/1fH7s0gHEECL6/TWagsHTqrn8Op/KQVQo/j08L4/BWB/1fH8tEkHEECL6/XXagsHTqrn8Ox/KQVR';
          break;
        case 'new_message':
          src = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=';
          break;
        default:
          src = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=';
      }
      
      const audio = new Audio(src);
      audio.volume = 0.3;
      audio.play().catch(() => {
        // Ignore errors if sound can't play
      });
    } catch (error) {
      console.warn('Audio constructor failed (Despia Runtime):', error);
    }
  };

  const invalidateRelevantQueries = (notification) => {
    // Invalidate queries based on notification type
    switch (notification.type) {
      case 'new_service_request':
      case 'job_reassigned':
        queryClient.invalidateQueries(['available-requests']);
        queryClient.invalidateQueries(['my-jobs']);
        break;
      case 'technician_assigned':
      case 'technician_en_route':
      case 'technician_arrived':
      case 'job_completed':
        queryClient.invalidateQueries(['service-request', notification.related_id]);
        queryClient.invalidateQueries(['customer-requests']);
        break;
      case 'new_message':
        queryClient.invalidateQueries(['messages', notification.related_id]);
        break;
    }
  };

  return null;
}