import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Bell, MessageSquare, Briefcase, CreditCard, MapPin, 
  CheckCircle, X, Trash2, Eye, EyeOff, Loader2 
} from 'lucide-react';
import { format, isToday, isYesterday } from 'date-fns';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const notificationIcons = {
  new_message: MessageSquare,
  technician_assigned: MapPin,
  technician_en_route: MapPin,
  technician_arrived: MapPin,
  job_completed: CheckCircle,
  new_service_request: Briefcase,
  payment_reminder: CreditCard,
  job_status_update: Briefcase,
  job_assigned: Briefcase,
  job_cancelled: X
};

const notificationColors = {
  new_message: '#3B82F6',
  technician_assigned: '#10B981',
  technician_en_route: '#F59E0B',
  technician_arrived: '#8B5CF6',
  job_completed: '#22C55E',
  new_service_request: '#FF771D',
  payment_reminder: '#EF4444',
  job_status_update: '#6366F1',
  job_assigned: '#FF771D',
  job_cancelled: '#EF4444'
};

function NotificationItem({ notification, onMarkRead, onDelete, onClick }) {
  const Icon = notificationIcons[notification.type] || Bell;
  const color = notificationColors[notification.type] || '#FF771D';
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    if (isToday(date)) return format(date, 'h:mm a');
    if (isYesterday(date)) return `Yesterday ${format(date, 'h:mm a')}`;
    return format(date, 'MMM d, h:mm a');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -100 }}
      layout
    >
      <Card 
        className={`mb-3 cursor-pointer transition-all hover:shadow-md ${
          !notification.is_read ? 'border-l-4 bg-orange-50' : 'bg-white'
        }`}
        style={!notification.is_read ? { borderLeftColor: color } : {}}
        onClick={() => onClick?.(notification)}
      >
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div 
              className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: `${color}20` }}
            >
              <Icon className="w-5 h-5" style={{ color }} />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2 mb-1">
                <h4 className={`font-semibold text-sm ${!notification.is_read ? 'text-gray-900' : 'text-gray-700'}`}>
                  {notification.title}
                </h4>
                {!notification.is_read && (
                  <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: color }} />
                )}
              </div>
              
              <p className={`text-sm mb-2 ${!notification.is_read ? 'text-gray-700' : 'text-gray-600'}`}>
                {notification.message}
              </p>
              
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">
                  {formatDate(notification.created_date)}
                </span>
                
                <div className="flex items-center gap-1">
                  {!notification.is_read ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        onMarkRead(notification.id);
                      }}
                      className="h-7 px-2 text-xs"
                    >
                      <Eye className="w-3 h-3 mr-1" />
                      Mark Read
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDelete(notification.id);
                      }}
                      className="h-7 px-2 text-xs text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function NotificationCenter({ userId, isOpen, onClose }) {
  const [activeTab, setActiveTab] = useState('all');
  const queryClient = useQueryClient();

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['notifications', userId],
    queryFn: async () => {
      return await base44.entities.Notification.filter(
        { user_id: userId },
        '-created_date',
        100
      );
    },
    enabled: !!userId && isOpen,
    refetchInterval: isOpen ? 10000 : false
  });

  const markAsRead = useMutation({
    mutationFn: async (notificationId) => {
      return await base44.entities.Notification.update(notificationId, { is_read: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['notifications', userId]);
      queryClient.invalidateQueries(['unread-count', userId]);
    }
  });

  const deleteNotification = useMutation({
    mutationFn: async (notificationId) => {
      await base44.entities.Notification.update(notificationId, { is_read: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['notifications', userId]);
      queryClient.invalidateQueries(['unread-count', userId]);
    }
  });

  const markAllAsRead = useMutation({
    mutationFn: async () => {
      const unreadNotifications = notifications.filter(n => !n.is_read);
      await Promise.all(
        unreadNotifications.map(n => 
          base44.entities.Notification.update(n.id, { is_read: true })
        )
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['notifications', userId]);
      queryClient.invalidateQueries(['unread-count', userId]);
    }
  });

  const handleNotificationClick = (notification) => {
    // Mark as read
    if (!notification.is_read) {
      markAsRead.mutate(notification.id);
    }

    // Navigate to related content
    if (notification.related_id) {
      onClose?.();
      if (notification.type === 'new_message' || notification.type.includes('job') || notification.type.includes('technician')) {
        window.location.href = createPageUrl(`ServiceDetails?id=${notification.related_id}`);
      }
    }
  };

  const filteredNotifications = notifications.filter(n => {
    if (activeTab === 'all') return true;
    if (activeTab === 'unread') return !n.is_read;
    if (activeTab === 'messages') return n.type === 'new_message';
    if (activeTab === 'jobs') return ['new_service_request', 'job_assigned', 'job_status_update', 'job_completed', 'job_cancelled'].includes(n.type);
    if (activeTab === 'payments') return n.type === 'payment_reminder';
    return true;
  });

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden p-0">
        <DialogHeader className="p-6 pb-4 border-b">
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" style={{ color: '#FF771D' }} />
              Notifications
              {unreadCount > 0 && (
                <Badge 
                  className="ml-2 text-white"
                  style={{ backgroundColor: '#FF771D' }}
                >
                  {unreadCount}
                </Badge>
              )}
            </DialogTitle>
            {unreadCount > 0 && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => markAllAsRead.mutate()}
                disabled={markAllAsRead.isPending}
              >
                {markAllAsRead.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Mark All Read
                  </>
                )}
              </Button>
            )}
          </div>
        </DialogHeader>

        <div className="px-6 py-4 border-b">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="all">
                All
                {notifications.length > 0 && (
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {notifications.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="unread">
                Unread
                {unreadCount > 0 && (
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {unreadCount}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="messages">
                <MessageSquare className="w-4 h-4" />
              </TabsTrigger>
              <TabsTrigger value="jobs">
                <Briefcase className="w-4 h-4" />
              </TabsTrigger>
              <TabsTrigger value="payments">
                <CreditCard className="w-4 h-4" />
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-200px)] px-6 py-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF771D' }} />
            </div>
          ) : filteredNotifications.length === 0 ? (
            <div className="text-center py-12">
              <Bell className="w-12 h-12 mx-auto mb-3 text-gray-400" />
              <p className="text-gray-600 font-semibold">No notifications</p>
              <p className="text-sm text-gray-500 mt-1">
                {activeTab === 'unread' 
                  ? "You're all caught up!" 
                  : "You'll see notifications here when you have activity"}
              </p>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              {filteredNotifications.map(notification => (
                <NotificationItem
                  key={notification.id}
                  notification={notification}
                  onMarkRead={markAsRead.mutate}
                  onDelete={deleteNotification.mutate}
                  onClick={handleNotificationClick}
                />
              ))}
            </AnimatePresence>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}