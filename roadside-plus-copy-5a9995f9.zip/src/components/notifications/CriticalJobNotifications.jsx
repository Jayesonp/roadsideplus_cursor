import { useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

// Send browser push notification
const sendBrowserNotification = (title, body, tag, requireInteraction = false) => {
  // Double check Notification API availability and constructor safety
  if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
    try {
      // Check if constructor throws illegal constructor immediately
      // by guarding the specific instantiation line
      const notification = new Notification(title, {
        body,
        icon: '/icon-192x192.png',
        badge: '/icon-192x192.png',
        tag,
        requireInteraction,
        vibrate: requireInteraction ? [300, 100, 300, 100, 300] : [200, 100, 200],
        silent: false,
        data: { timestamp: Date.now() }
      });
      
      notification.onclick = () => {
        window.focus();
        notification.close();
      };
    } catch (e) {
      // Suppress illegal constructor errors in restricted environments (Despia)
      console.warn('Notification constructor suppressed (Despia Runtime):', e);
    }
  }
};

// Track last notified status to avoid duplicates
const statusNotifications = new Map();

export default function CriticalJobNotifications({ serviceRequestId, userId, currentStatus }) {
  const lastStatusRef = useRef(currentStatus);
  const notifiedRef = useRef(new Set());

  // Monitor service request for status changes
  const { data: request } = useQuery({
    queryKey: ['service-request-notifications', serviceRequestId],
    queryFn: async () => {
      if (!serviceRequestId) return null;
      const requests = await base44.entities.ServiceRequest.filter({ id: serviceRequestId });
      return requests[0];
    },
    enabled: !!serviceRequestId,
    refetchInterval: 5000, // Check every 5 seconds
    retry: 2
  });

  useEffect(() => {
    if (!request || !userId) return;

    const newStatus = request.status;
    const hasStatusChanged = lastStatusRef.current !== newStatus;
    
    if (hasStatusChanged) {
      const notificationKey = `${serviceRequestId}-${newStatus}`;
      
      // Only notify once per status change
      if (!notifiedRef.current.has(notificationKey)) {
        handleStatusNotification(newStatus, request);
        notifiedRef.current.add(notificationKey);
      }
      
      lastStatusRef.current = newStatus;
    }
  }, [request, serviceRequestId, userId]);

  const handleStatusNotification = async (status, requestData) => {
    let title = '';
    let body = '';
    let requireInteraction = false;

    switch (status) {
      case 'dispatched':
        title = '🚗 Technician Dispatched!';
        body = 'We\'re finding the best technician for you. You\'ll be notified when one is assigned.';
        requireInteraction = false;
        break;

      case 'assigned':
        title = '✅ Technician Assigned!';
        body = 'A technician has been assigned to your service request. They will be on their way shortly.';
        requireInteraction = true;
        break;

      case 'en_route':
        title = '🚙 Technician En Route';
        body = `Your technician is on the way! ${requestData.estimated_arrival ? `ETA: ${new Date(requestData.estimated_arrival).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}` : 'Arriving soon'}`;
        requireInteraction = true;
        break;

      case 'arrived':
        title = '📍 Technician Arrived!';
        body = 'Your technician has arrived at your location. They will begin service shortly.';
        requireInteraction = true;
        break;

      case 'in_progress':
        title = '🔧 Service In Progress';
        body = 'Your technician is working on your vehicle. You\'ll be notified when service is complete.';
        requireInteraction = false;
        break;

      case 'completed':
        title = '✨ Service Complete!';
        body = 'Your service has been completed. Please rate your experience.';
        requireInteraction = true;
        break;

      case 'cancelled':
        title = '❌ Service Cancelled';
        body = 'Your service request has been cancelled.';
        requireInteraction = false;
        break;

      default:
        return; // Don't notify for other statuses
    }

    // Send browser notification
    sendBrowserNotification(title, body, `job-${serviceRequestId}-${status}`, requireInteraction);

    // Create in-app notification record
    try {
      await base44.entities.Notification.create({
        user_id: userId,
        type: 'job_status_updates',
        title,
        message: body,
        related_id: serviceRequestId,
        is_read: false
      });
    } catch (error) {
      console.error('Failed to create notification record:', error);
    }
  };

  return null; // This is a notification manager component
}

// Hook for easy integration
export function useCriticalJobNotifications(serviceRequestId, userId, currentStatus) {
  useEffect(() => {
    // Request notification permission on mount
    if ('Notification' in window && Notification.permission === 'default') {
      try {
        Notification.requestPermission();
      } catch (e) {
        console.warn('Notification permission request failed (Despia Runtime):', e);
      }
    }
  }, []);

  return { CriticalJobNotifications };
}