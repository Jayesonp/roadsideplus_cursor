import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, Check, X } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { format } from 'date-fns';
import { sendPushNotification } from '../pwa/PushNotificationManager';
import NotificationCenter from './NotificationCenter';

export default function NotificationBell({ userId }) {
  const [showCenter, setShowCenter] = useState(false);
  const queryClient = useQueryClient();

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications', userId],
    queryFn: async () => {
      if (!userId) return [];
      return await base44.entities.Notification.filter(
        { user_id: userId },
        '-created_date',
        50
      );
    },
    enabled: !!userId,
    refetchInterval: 30000,
    retry: 2,
    retryDelay: 5000,
    staleTime: 20000
  });

  const { data: unreadCount = 0 } = useQuery({
    queryKey: ['unread-count', userId],
    queryFn: async () => {
      if (!userId) return 0;
      const notifs = await base44.entities.Notification.filter(
        { user_id: userId, is_read: false },
        '-created_date',
        100
      );
      return notifs.length;
    },
    enabled: !!userId,
    refetchInterval: 30000
  });

  const { data: preferences } = useQuery({
    queryKey: ['notification-preferences', userId],
    queryFn: async () => {
      if (!userId) return null;
      const prefs = await base44.entities.NotificationPreferences.filter({ user_id: userId });
      return prefs[0] || null;
    },
    enabled: !!userId
  });

  useEffect(() => {
    if (notifications.length > 0 && preferences) {
      const latestUnread = notifications.find(n => !n.is_read);
      if (latestUnread) {
        // Check if this notification type is enabled
        const notificationTypeMap = {
          'technician_assigned': 'job_status_updates',
          'technician_en_route': 'technician_arrival',
          'technician_arrived': 'technician_arrival',
          'job_completed': 'job_status_updates',
          'new_service_request': 'new_job_assignments',
          'new_message': 'new_messages'
        };
        
        const prefKey = notificationTypeMap[latestUnread.type];
        const isEnabled = preferences[prefKey] !== false && preferences.push_enabled !== false;
        
        if (isEnabled) {
          const pageMap = {
            'technician_assigned': 'ServiceDetails',
            'technician_en_route': 'ServiceDetails',
            'technician_arrived': 'ServiceDetails',
            'job_completed': 'ServiceDetails',
            'new_service_request': 'JobDetails',
            'new_message': latestUnread.message.includes('customer') ? 'JobDetails' : 'ServiceDetails'
          };
          const page = pageMap[latestUnread.type];
          const url = page ? createPageUrl(`${page}?id=${latestUnread.related_id}`) : createPageUrl('CustomerDashboard');
          sendPushNotification(latestUnread.title, latestUnread.message, url, userId);
        }
      }
    }
  }, [notifications, preferences]);

  return (
    <>
      <Button 
        variant="outline" 
        className="relative bg-white/10 border-white/30 text-white hover:bg-white/20"
        onClick={() => setShowCenter(true)}
      >
        <Bell className="w-4 h-4" />
        {unreadCount > 0 && (
          <Badge 
            className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
            style={{ backgroundColor: '#E52C2D' }}
          >
            {unreadCount > 99 ? '99+' : unreadCount}
          </Badge>
        )}
      </Button>

      <NotificationCenter 
        userId={userId}
        isOpen={showCenter}
        onClose={() => setShowCenter(false)}
      />
    </>
  );
}