import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Info, ChevronDown, ChevronUp } from 'lucide-react';

export default function PriceBreakdown({ pricing }) {
  const [showDetails, setShowDetails] = useState(false);

  if (!pricing) return null;

  const { price, breakdown, explanation, factors } = pricing;

  return (
    <Card className="border-2" style={{ borderColor: '#FF771D' }}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="text-sm text-gray-600">Estimated Price</p>
            <p className="text-3xl font-bold" style={{ color: '#FF771D' }}>
              ${price}
            </p>
          </div>
          <Badge className="bg-green-100 text-green-800 border-green-300">
            AI-Optimized
          </Badge>
        </div>

        <p className="text-sm text-gray-600 mb-3">
          <Info className="w-4 h-4 inline mr-1" />
          {explanation}
        </p>

        <button
          onClick={() => setShowDetails(!showDetails)}
          className="text-sm text-gray-600 hover:text-gray-900 flex items-center gap-1"
        >
          {showDetails ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          {showDetails ? 'Hide' : 'View'} pricing breakdown
        </button>

        {showDetails && (
          <div className="mt-3 space-y-2 text-sm">
            <div className="pt-3 border-t">
              <p className="font-semibold mb-2">Price Breakdown:</p>
              <div className="space-y-1 text-gray-600">
                <div className="flex justify-between">
                  <span>Base Price</span>
                  <span>${breakdown.base_price?.toFixed(2)}</span>
                </div>
                {breakdown.demand_adjustment !== 0 && (
                  <div className="flex justify-between items-center">
                    <span>Demand Adjustment</span>
                    <span className={breakdown.demand_adjustment > 0 ? 'text-red-600' : 'text-green-600'}>
                      {breakdown.demand_adjustment > 0 ? '+' : ''}${breakdown.demand_adjustment?.toFixed(2)}
                      {breakdown.demand_adjustment > 0 ? <TrendingUp className="w-3 h-3 inline ml-1" /> : <TrendingDown className="w-3 h-3 inline ml-1" />}
                    </span>
                  </div>
                )}
                {breakdown.time_adjustment !== 0 && (
                  <div className="flex justify-between items-center">
                    <span>Time Premium</span>
                    <span className="text-red-600">
                      +${breakdown.time_adjustment?.toFixed(2)}
                      <TrendingUp className="w-3 h-3 inline ml-1" />
                    </span>
                  </div>
                )}
                {breakdown.distance_adjustment !== 0 && (
                  <div className="flex justify-between items-center">
                    <span>Distance Adjustment</span>
                    <span className="text-red-600">
                      +${breakdown.distance_adjustment?.toFixed(2)}
                      <TrendingUp className="w-3 h-3 inline ml-1" />
                    </span>
                  </div>
                )}
                {breakdown.complexity_adjustment !== 0 && (
                  <div className="flex justify-between">
                    <span>Service Complexity</span>
                    <span>+${breakdown.complexity_adjustment?.toFixed(2)}</span>
                  </div>
                )}
              </div>
            </div>

            {factors && Object.keys(factors).length > 0 && (
              <div className="pt-3 border-t">
                <p className="font-semibold mb-2">Market Factors:</p>
                <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                  {factors.demand !== undefined && (
                    <div>
                      <span className="font-medium">Recent Demand:</span> {factors.demand}
                    </div>
                  )}
                  {factors.availableTechs !== undefined && (
                    <div>
                      <span className="font-medium">Available:</span> {factors.availableTechs} techs
                    </div>
                  )}
                  {factors.avgDistance !== 'N/A' && (
                    <div>
                      <span className="font-medium">Avg Distance:</span> {factors.avgDistance}km
                    </div>
                  )}
                  {factors.isNightTime && (
                    <div className="col-span-2">
                      <Badge variant="outline" className="text-xs">Night Time Premium</Badge>
                    </div>
                  )}
                  {factors.isWeekend && (
                    <div className="col-span-2">
                      <Badge variant="outline" className="text-xs">Weekend Premium</Badge>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}