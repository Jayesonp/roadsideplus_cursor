import { base44 } from '@/api/base44Client';

// Base prices for each service type
const BASE_PRICES = {
  tire_change: 100,
  battery_jump: 75,
  fuel_delivery: 65,
  lockout: 90,
  towing: 150,
  other: 80
};

// Service complexity multipliers
const COMPLEXITY_FACTORS = {
  tire_change: 1.2,
  battery_jump: 1.0,
  fuel_delivery: 0.9,
  lockout: 1.1,
  towing: 1.5,
  other: 1.0
};

export const calculateDynamicPrice = async ({
  serviceType,
  location,
  timeOfDay = new Date(),
  description = ''
}) => {
  try {
    // Fetch data for pricing analysis
    const [
      recentRequests,
      availableTechnicians,
      historicalPricing
    ] = await Promise.all([
      // Recent requests for demand analysis (last 2 hours)
      base44.entities.ServiceRequest.filter({
        created_date: { $gte: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString() }
      }),
      // Available technicians
      base44.entities.TechnicianProfile.filter({
        onboarding_completed: true,
        availability_status: 'available'
      }),
      // Historical pricing (last 7 days)
      base44.entities.ServiceRequest.filter({
        status: 'completed',
        service_type: serviceType,
        completed_at: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString() }
      })
    ]);

    // Calculate demand metrics
    const demandCount = recentRequests.filter(r => 
      r.service_type === serviceType
    ).length;

    const techCount = availableTechnicians.filter(t => 
      t.specialties?.includes(serviceType.replace(/_/g, ' ')) || 
      t.current_lat && t.current_lng
    ).length;

    // Get time-based factors
    const hour = timeOfDay.getHours();
    const isWeekend = [0, 6].includes(timeOfDay.getDay());
    const isNightTime = hour >= 22 || hour <= 6;

    // Calculate average distance of available techs (if location provided)
    let avgDistance = null;
    if (location?.lat && location?.lng && availableTechnicians.length > 0) {
      const distances = availableTechnicians
        .filter(t => t.current_lat && t.current_lng)
        .map(t => {
          const R = 6371;
          const dLat = (t.current_lat - location.lat) * Math.PI / 180;
          const dLon = (t.current_lng - location.lng) * Math.PI / 180;
          const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                    Math.cos(location.lat * Math.PI / 180) * Math.cos(t.current_lat * Math.PI / 180) *
                    Math.sin(dLon/2) * Math.sin(dLon/2);
          const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
          return R * c;
        });
      
      avgDistance = distances.length > 0 
        ? distances.reduce((a, b) => a + b, 0) / distances.length 
        : null;
    }

    // Historical average price
    const avgHistoricalPrice = historicalPricing.length > 0
      ? historicalPricing.reduce((sum, r) => sum + (r.price || 0), 0) / historicalPricing.length
      : BASE_PRICES[serviceType];

    // Use AI to calculate optimal price
    const aiResponse = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a pricing optimization AI for a roadside assistance service. Calculate the optimal price for this service request.

SERVICE REQUEST:
- Service Type: ${serviceType.replace(/_/g, ' ').toUpperCase()}
- Base Price: $${BASE_PRICES[serviceType]}
- Complexity Factor: ${COMPLEXITY_FACTORS[serviceType]}x

MARKET CONDITIONS:
- Recent Demand (last 2h): ${demandCount} similar requests
- Available Technicians: ${techCount} technicians ${techCount > 0 ? 'with matching skills' : 'total'}
- Time: ${timeOfDay.toLocaleString()} (${isWeekend ? 'Weekend' : 'Weekday'}, ${isNightTime ? 'Night' : 'Day'})
- Average Technician Distance: ${avgDistance ? `${avgDistance.toFixed(1)}km` : 'Unknown'}

HISTORICAL DATA:
- Historical Average Price: $${avgHistoricalPrice.toFixed(2)}
- Completed Jobs (7 days): ${historicalPricing.length}

PRICING FACTORS TO CONSIDER:
1. Demand vs Supply: ${demandCount > techCount ? 'HIGH DEMAND (increase price)' : 'LOW DEMAND (standard price)'}
2. Time Premium: ${isNightTime ? 'Night time (+15-25%)' : isWeekend ? 'Weekend (+10-15%)' : 'Standard time'}
3. Distance: ${avgDistance > 20 ? 'Far distance (+10-20%)' : avgDistance > 10 ? 'Medium distance (+5-10%)' : 'Close distance (standard)'}
4. Service Complexity: ${COMPLEXITY_FACTORS[serviceType] > 1.2 ? 'High' : COMPLEXITY_FACTORS[serviceType] > 1.0 ? 'Medium' : 'Standard'}

RULES:
- Minimum price: $${Math.floor(BASE_PRICES[serviceType] * 0.8)}
- Maximum price: $${Math.ceil(BASE_PRICES[serviceType] * 2.0)}
- Stay within 20% of historical average if data available
- Consider competitive market rates
- Higher demand = higher price (up to 30% increase)
- Lower availability = higher price (up to 25% increase)
- Night/weekend premium: 10-25% increase
- Distance premium: up to 20% for >20km

Calculate the optimal price that balances profitability with market competitiveness. Provide the final price and a brief explanation of the key factors.`,
      response_json_schema: {
        type: "object",
        properties: {
          final_price: {
            type: "number",
            description: "The calculated price in dollars"
          },
          breakdown: {
            type: "object",
            properties: {
              base_price: { type: "number" },
              demand_adjustment: { type: "number" },
              time_adjustment: { type: "number" },
              distance_adjustment: { type: "number" },
              complexity_adjustment: { type: "number" }
            }
          },
          explanation: {
            type: "string",
            description: "Brief explanation of pricing factors"
          }
        },
        required: ["final_price", "explanation"]
      }
    });

    // Round to nearest $5
    const finalPrice = Math.round(aiResponse.final_price / 5) * 5;

    return {
      price: finalPrice,
      breakdown: aiResponse.breakdown || {
        base_price: BASE_PRICES[serviceType],
        demand_adjustment: 0,
        time_adjustment: 0,
        distance_adjustment: 0,
        complexity_adjustment: 0
      },
      explanation: aiResponse.explanation,
      factors: {
        demand: demandCount,
        availableTechs: techCount,
        isNightTime,
        isWeekend,
        avgDistance: avgDistance ? avgDistance.toFixed(1) : 'N/A',
        historicalAvg: avgHistoricalPrice.toFixed(2)
      }
    };

  } catch (error) {
    console.error('Dynamic pricing error:', error);
    
    // Fallback to base price with simple adjustments
    const basePrice = BASE_PRICES[serviceType] || 80;
    const hour = timeOfDay.getHours();
    const isNight = hour >= 22 || hour <= 6;
    const fallbackPrice = Math.round(basePrice * (isNight ? 1.2 : 1.0) / 5) * 5;
    
    return {
      price: fallbackPrice,
      breakdown: {
        base_price: basePrice,
        demand_adjustment: 0,
        time_adjustment: isNight ? basePrice * 0.2 : 0,
        distance_adjustment: 0,
        complexity_adjustment: 0
      },
      explanation: 'Standard pricing applied',
      factors: {}
    };
  }
};