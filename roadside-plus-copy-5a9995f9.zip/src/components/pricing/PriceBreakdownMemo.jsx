import React from 'react';
import PriceBreakdown from './PriceBreakdown';

export default React.memo(PriceBreakdown, (prevProps, nextProps) => {
  return JSON.stringify(prevProps.pricing) === JSON.stringify(nextProps.pricing);
});