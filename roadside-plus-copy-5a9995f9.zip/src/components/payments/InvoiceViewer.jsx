import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Download, Mail, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';

export default function InvoiceViewer({ serviceRequestId }) {
  const { data: invoice, isLoading } = useQuery({
    queryKey: ['invoice', serviceRequestId],
    queryFn: async () => {
      const invoices = await base44.entities.Invoice.filter({ service_request_id: serviceRequestId });
      return invoices[0];
    },
    enabled: !!serviceRequestId
  });

  const { data: serviceRequest } = useQuery({
    queryKey: ['service-request', serviceRequestId],
    queryFn: async () => {
      const requests = await base44.entities.ServiceRequest.filter({ id: serviceRequestId });
      return requests[0];
    },
    enabled: !!serviceRequestId
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto" style={{ color: '#FF771D' }} />
        </CardContent>
      </Card>
    );
  }

  if (!invoice) {
    return null;
  }

  const handleDownload = () => {
    if (invoice.invoice_pdf_url) {
      const link = document.createElement('a');
      link.href = invoice.invoice_pdf_url;
      link.download = `${invoice.invoice_number}.html`;
      link.click();
    }
  };

  const handleEmail = async () => {
    const customer = await base44.entities.User.filter({ id: invoice.customer_id }).then(u => u[0]);
    await base44.integrations.Core.SendEmail({
      to: customer.email,
      subject: `Invoice ${invoice.invoice_number} - RoadsidePlus`,
      body: `Your invoice ${invoice.invoice_number} is attached. Total: $${invoice.total_amount.toFixed(2)}`
    });
    alert('Invoice emailed successfully!');
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Invoice {invoice.invoice_number}
          </CardTitle>
          <Badge className={
            invoice.payment_status === 'paid' 
              ? 'bg-green-100 text-green-800'
              : 'bg-yellow-100 text-yellow-800'
          }>
            {invoice.payment_status.toUpperCase()}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-gray-600">Invoice Date</p>
            <p className="font-semibold">
              {format(new Date(invoice.service_date), 'MMM dd, yyyy')}
            </p>
          </div>
          <div>
            <p className="text-gray-600">Service Type</p>
            <p className="font-semibold">
              {invoice.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </p>
          </div>
        </div>

        <div className="border-t pt-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Subtotal</span>
            <span>${invoice.subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Tax</span>
            <span>${invoice.tax_amount.toFixed(2)}</span>
          </div>
          {invoice.tip_amount > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Tip</span>
              <span>${invoice.tip_amount.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between text-lg font-bold pt-2 border-t">
            <span>Total</span>
            <span style={{ color: '#FF771D' }}>${invoice.total_amount.toFixed(2)}</span>
          </div>
        </div>

        {invoice.notes && (
          <div className="bg-gray-50 rounded-lg p-3 text-sm">
            <p className="text-gray-600 mb-1">Notes</p>
            <p>{invoice.notes}</p>
          </div>
        )}

        <div className="flex gap-2 pt-4">
          <Button
            variant="outline"
            className="flex-1"
            onClick={handleDownload}
          >
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
          <Button
            variant="outline"
            className="flex-1"
            onClick={handleEmail}
          >
            <Mail className="w-4 h-4 mr-2" />
            Email
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}