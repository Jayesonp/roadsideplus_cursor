import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Link as LinkIcon, Copy, Mail, MessageSquare, Loader2, CheckCircle } from 'lucide-react';

export default function PaymentLinkOption({ amount, requestId }) {
  const [loading, setLoading] = useState(false);
  const [paymentLink, setPaymentLink] = useState('');
  const [copied, setCopied] = useState(false);

  const generatePaymentLink = async () => {
    setLoading(true);
    try {
      const { data } = await base44.functions.invoke('stripePayment', {
        action: 'create_payment_link',
        requestId: requestId,
        amount: amount,
        description: 'Roadside Assistance Service',
      });

      if (data.error) {
        throw new Error(data.error);
      }

      setPaymentLink(data.paymentLink);
    } catch (error) {
      console.error('Error generating payment link:', error);
      alert('Failed to generate payment link. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(paymentLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const sendViaEmail = () => {
    window.location.href = `mailto:?subject=Payment Link for Service&body=Please complete your payment using this link: ${paymentLink}`;
  };

  const sendViaSMS = () => {
    window.location.href = `sms:?body=Complete your payment here: ${paymentLink}`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <LinkIcon className="w-5 h-5" style={{ color: '#FF771D' }} />
          Payment Link
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert className="border-blue-200 bg-blue-50">
          <AlertDescription className="text-blue-800">
            Generate a secure payment link that can be shared via email, SMS, or any messaging app.
          </AlertDescription>
        </Alert>

        {!paymentLink ? (
          <Button
            onClick={generatePaymentLink}
            disabled={loading}
            className="w-full text-white"
            style={{ backgroundColor: '#FF771D' }}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Link...
              </>
            ) : (
              <>
                <LinkIcon className="w-4 h-4 mr-2" />
                Generate Payment Link
              </>
            )}
          </Button>
        ) : (
          <div className="space-y-4">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-start gap-2 mb-2">
                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <p className="font-semibold text-green-900">Payment Link Generated!</p>
                  <p className="text-sm text-green-700">Share this link to receive payment</p>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 border rounded-lg p-3">
              <p className="text-xs text-gray-500 mb-1">Payment Link</p>
              <p className="text-sm font-mono break-all">{paymentLink}</p>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <Button
                variant="outline"
                onClick={copyToClipboard}
                className="flex-col h-auto py-3"
              >
                {copied ? (
                  <>
                    <CheckCircle className="w-5 h-5 mb-1 text-green-600" />
                    <span className="text-xs">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-5 h-5 mb-1" />
                    <span className="text-xs">Copy</span>
                  </>
                )}
              </Button>

              <Button
                variant="outline"
                onClick={sendViaEmail}
                className="flex-col h-auto py-3"
              >
                <Mail className="w-5 h-5 mb-1" />
                <span className="text-xs">Email</span>
              </Button>

              <Button
                variant="outline"
                onClick={sendViaSMS}
                className="flex-col h-auto py-3"
              >
                <MessageSquare className="w-5 h-5 mb-1" />
                <span className="text-xs">SMS</span>
              </Button>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 border">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Amount to Collect</span>
                <span className="text-xl font-bold" style={{ color: '#E52C2D' }}>
                  ${amount.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}