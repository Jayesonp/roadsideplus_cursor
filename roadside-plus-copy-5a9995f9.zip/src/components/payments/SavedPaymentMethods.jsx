import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { CreditCard, CheckCircle } from 'lucide-react';

export default function SavedPaymentMethods({ userId, selectedMethodId, onSelectMethod }) {
  const { data: paymentMethods = [], isLoading } = useQuery({
    queryKey: ['payment-methods', userId],
    queryFn: async () => {
      return await base44.entities.PaymentMethod.filter({ user_id: userId }, '-created_date', 10);
    },
    enabled: !!userId,
    staleTime: 60000,
    retry: 1
  });

  if (isLoading) {
    return (
      <div className="space-y-3">
        <div className="h-20 bg-gray-200 animate-pulse rounded"></div>
        <div className="h-20 bg-gray-200 animate-pulse rounded"></div>
      </div>
    );
  }

  if (paymentMethods.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <CreditCard className="w-12 h-12 mx-auto mb-3 text-gray-400" />
        <p className="text-sm">No saved payment methods</p>
        <p className="text-xs">Add a card to get started</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {paymentMethods.map((method) => (
        <Card
          key={method.id}
          className={`cursor-pointer transition-all hover:shadow-md ${
            selectedMethodId === method.id ? 'border-2 border-orange-500 bg-orange-50' : 'border'
          }`}
          onClick={() => onSelectMethod(method)}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-gray-700 to-gray-900 rounded flex items-center justify-center">
                  <CreditCard className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-semibold">
                    {method.card_brand} •••• {method.last_four}
                  </p>
                  <p className="text-xs text-gray-500">
                    Expires {method.expiry_month}/{method.expiry_year}
                    {method.is_default && (
                      <span className="ml-2 text-orange-600 font-semibold">• Default</span>
                    )}
                  </p>
                </div>
              </div>
              {selectedMethodId === method.id && (
                <CheckCircle className="w-5 h-5 text-orange-600" />
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}