import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { CreditCard, Loader2, X, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function AddPaymentMethodForm({ userId, onClose, onSuccess }) {
  const [cardData, setCardData] = useState({
    cardNumber: '',
    cardholderName: '',
    expiryMonth: '',
    expiryYear: '',
    cvc: '',
    billingZip: '',
    isDefault: false
  });
  const [error, setError] = useState('');
  const queryClient = useQueryClient();

  const addPaymentMethod = useMutation({
    mutationFn: async () => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);
      
      try {
        const cardNumber = cardData.cardNumber.replace(/\s/g, '');
        if (cardNumber.length < 13 || cardNumber.length > 19) {
          throw new Error('Invalid card number');
        }

        const firstDigit = cardNumber[0];
        let cardBrand = 'Unknown';
        if (firstDigit === '4') cardBrand = 'Visa';
        else if (firstDigit === '5') cardBrand = 'Mastercard';
        else if (firstDigit === '3') cardBrand = 'Amex';
        else if (firstDigit === '6') cardBrand = 'Discover';

        const gatewayToken = `tok_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

        const result = await base44.entities.PaymentMethod.create({
          user_id: userId,
          payment_type: 'credit_card',
          card_brand: cardBrand,
          last_four: cardNumber.slice(-4),
          expiry_month: cardData.expiryMonth,
          expiry_year: cardData.expiryYear,
          cardholder_name: cardData.cardholderName,
          is_default: cardData.isDefault,
          gateway_token: gatewayToken,
          billing_zip: cardData.billingZip
        });
        
        clearTimeout(timeoutId);
        return result;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['payment-methods']);
      onSuccess?.();
    },
    onError: (error) => {
      setError(error.message || 'Failed to add payment method. Please try again.');
    }
  });

  const handleCardNumberChange = (e) => {
    let value = e.target.value.replace(/\s/g, '');
    value = value.replace(/(\d{4})/g, '$1 ').trim();
    setCardData({ ...cardData, cardNumber: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    addPaymentMethod.mutate();
  };

  const fillTestCard = () => {
    setCardData({
      cardNumber: '4242 4242 4242 4242',
      cardholderName: 'Test Customer',
      expiryMonth: '12',
      expiryYear: '2028',
      cvc: '123',
      billingZip: '12345',
      isDefault: true
    });
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold flex items-center gap-2">
            <CreditCard className="w-5 h-5" style={{ color: '#FF771D' }} />
            Add Payment Method
          </h3>
          {onClose && (
            <button onClick={onClose}>
              <X className="w-5 h-5 text-gray-400 hover:text-gray-600" />
            </button>
          )}
        </div>

        <Alert className="mb-4 border-blue-200 bg-blue-50">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800 text-sm">
            <strong>Test Mode:</strong> Use 4242 4242 4242 4242 for testing.
            <Button
              type="button"
              variant="link"
              className="p-0 h-auto ml-2 text-blue-600"
              onClick={fillTestCard}
            >
              Fill Test Card
            </Button>
          </AlertDescription>
        </Alert>

        {error && (
          <Alert className="mb-4 border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800 text-sm">{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="cardholderName">Cardholder Name</Label>
            <Input
              id="cardholderName"
              value={cardData.cardholderName}
              onChange={(e) => setCardData({ ...cardData, cardholderName: e.target.value })}
              placeholder="John Doe"
              required
            />
          </div>

          <div>
            <Label htmlFor="cardNumber">Card Number</Label>
            <Input
              id="cardNumber"
              value={cardData.cardNumber}
              onChange={handleCardNumberChange}
              placeholder="1234 5678 9012 3456"
              maxLength={19}
              required
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label htmlFor="expiryMonth">Month</Label>
              <Input
                id="expiryMonth"
                value={cardData.expiryMonth}
                onChange={(e) => setCardData({ ...cardData, expiryMonth: e.target.value })}
                placeholder="MM"
                maxLength={2}
                required
              />
            </div>
            <div>
              <Label htmlFor="expiryYear">Year</Label>
              <Input
                id="expiryYear"
                value={cardData.expiryYear}
                onChange={(e) => setCardData({ ...cardData, expiryYear: e.target.value })}
                placeholder="YYYY"
                maxLength={4}
                required
              />
            </div>
            <div>
              <Label htmlFor="cvc">CVC</Label>
              <Input
                id="cvc"
                type="text"
                value={cardData.cvc}
                onChange={(e) => setCardData({ ...cardData, cvc: e.target.value.replace(/\D/g, '') })}
                placeholder="123"
                maxLength={4}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="billingZip">Billing ZIP Code</Label>
            <Input
              id="billingZip"
              value={cardData.billingZip}
              onChange={(e) => setCardData({ ...cardData, billingZip: e.target.value })}
              placeholder="12345"
              maxLength={10}
              required
            />
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="isDefault"
              checked={cardData.isDefault}
              onCheckedChange={(checked) => setCardData({ ...cardData, isDefault: checked })}
            />
            <Label htmlFor="isDefault" className="text-sm cursor-pointer">
              Set as default payment method
            </Label>
          </div>

          <Button
            type="submit"
            disabled={addPaymentMethod.isPending}
            className="w-full text-white"
            style={{ backgroundColor: '#FF771D' }}
          >
            {addPaymentMethod.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Adding Card...
              </>
            ) : (
              'Add Card'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}