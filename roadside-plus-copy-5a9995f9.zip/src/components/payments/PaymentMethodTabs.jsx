import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { CreditCard, Link as LinkIcon } from 'lucide-react';
import StripeCardPayment from './StripeCardPayment';
import PaymentLinkOption from './PaymentLinkOption';

export default function PaymentMethodTabs({ amount, requestId, onSuccess }) {
  const [activeTab, setActiveTab] = useState('card');

  const tabs = [
    { id: 'card', label: 'Pay with Card', icon: CreditCard },
    { id: 'link', label: 'Payment Link', icon: LinkIcon },
  ];

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-2 gap-2 mb-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-all ${
                    activeTab === tab.id
                      ? 'border-orange-500 bg-orange-50 text-orange-700 font-semibold'
                      : 'border-gray-200 bg-white text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {activeTab === 'card' && (
        <StripeCardPayment
          amount={amount}
          requestId={requestId}
          onSuccess={onSuccess}
          onCancel={() => window.history.back()}
        />
      )}

      {activeTab === 'link' && (
        <PaymentLinkOption
          amount={amount}
          requestId={requestId}
        />
      )}
    </div>
  );
}