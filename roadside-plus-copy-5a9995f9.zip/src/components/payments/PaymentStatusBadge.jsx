import React from 'react';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Clock, XCircle, AlertCircle, DollarSign } from 'lucide-react';

export default function PaymentStatusBadge({ status, showIcon = true }) {
  const statusConfig = {
    pending: {
      label: 'Payment Pending',
      bgColor: 'bg-yellow-100',
      textColor: 'text-yellow-800',
      icon: Clock,
    },
    initiated: {
      label: 'Payment Initiated',
      bgColor: 'bg-blue-100',
      textColor: 'text-blue-800',
      icon: DollarSign,
    },
    paid: {
      label: 'Paid',
      bgColor: 'bg-green-100',
      textColor: 'text-green-800',
      icon: CheckCircle,
    },
    failed: {
      label: 'Payment Failed',
      bgColor: 'bg-red-100',
      textColor: 'text-red-800',
      icon: XCircle,
    },
    refunded: {
      label: 'Refunded',
      bgColor: 'bg-gray-100',
      textColor: 'text-gray-800',
      icon: AlertCircle,
    },
  };

  const config = statusConfig[status] || statusConfig.pending;
  const Icon = config.icon;

  return (
    <Badge className={`${config.bgColor} ${config.textColor} border-none`}>
      {showIcon && <Icon className="w-3 h-3 mr-1" />}
      {config.label}
    </Badge>
  );
}