import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { FileText, Download, Mail, Loader2, Link as LinkIcon } from 'lucide-react';
import { format } from 'date-fns';

export default function InvoiceGenerator({ serviceRequest, onInvoiceCreated }) {
  const [generatingLink, setGeneratingLink] = useState(false);
  const [paymentLink, setPaymentLink] = useState(null);
  const generateInvoiceMutation = useMutation({
    mutationFn: async () => {
      // Generate invoice number
      const invoiceNumber = `INV-${Date.now()}-${serviceRequest.id.slice(-6).toUpperCase()}`;
      
      // Calculate amounts
      const subtotal = serviceRequest.price || 0;
      const taxRate = 0.08; // 8% tax
      const taxAmount = subtotal * taxRate;
      const tipAmount = 0; // Can be added from rating
      const totalAmount = subtotal + taxAmount + tipAmount;

      // Get customer and technician details
      const [customer, technician] = await Promise.all([
        base44.entities.User.filter({ id: serviceRequest.customer_id }).then(u => u[0]),
        serviceRequest.technician_id 
          ? base44.entities.User.filter({ id: serviceRequest.technician_id }).then(u => u[0])
          : null
      ]);

      // Create invoice
      const invoice = await base44.entities.Invoice.create({
        service_request_id: serviceRequest.id,
        invoice_number: invoiceNumber,
        customer_id: serviceRequest.customer_id,
        technician_id: serviceRequest.technician_id,
        service_date: serviceRequest.completed_at || new Date().toISOString(),
        service_type: serviceRequest.service_type,
        subtotal,
        tax_amount: taxAmount,
        tip_amount: tipAmount,
        total_amount: totalAmount,
        payment_method: serviceRequest.payment_reference ? 'Card' : 'Pending',
        payment_status: serviceRequest.payment_status === 'paid' ? 'paid' : 'pending',
        notes: serviceRequest.description
      });

      // Generate PDF-like HTML content
      const invoiceHTML = generateInvoiceHTML(invoice, serviceRequest, customer, technician);
      
      // In production, use a service to convert HTML to PDF and store it
      // For now, we'll simulate this
      const pdfUrl = `data:text/html;base64,${btoa(invoiceHTML)}`;
      
      await base44.entities.Invoice.update(invoice.id, {
        invoice_pdf_url: pdfUrl
      });

      // Send email with invoice
      await base44.integrations.Core.SendEmail({
        to: customer.email,
        subject: `Invoice ${invoiceNumber} - RoadsidePlus Service`,
        body: `
          Hi ${customer.full_name},
          
          Thank you for using RoadsidePlus! Your invoice for the ${serviceRequest.service_type.replace(/_/g, ' ')} service is attached.
          
          Invoice Number: ${invoiceNumber}
          Service Date: ${format(new Date(serviceRequest.completed_at || new Date()), 'MMM dd, yyyy')}
          Total Amount: $${totalAmount.toFixed(2)}
          
          View your invoice: [View Invoice]
          
          Thank you for your business!
          
          Best regards,
          RoadsidePlus Team
        `
      });

      return invoice;
    },
    onSuccess: (invoice) => {
      onInvoiceCreated?.(invoice);
    }
  });

  const generateInvoiceHTML = (invoice, request, customer, technician) => {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; padding: 40px; }
          .header { text-align: center; margin-bottom: 40px; }
          .logo { font-size: 28px; font-weight: bold; color: #FF771D; }
          .invoice-info { margin: 30px 0; }
          .invoice-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
          .invoice-table th, .invoice-table td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
          .total-row { font-weight: bold; font-size: 18px; }
          .footer { margin-top: 40px; text-align: center; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo">ROADSIDEPLUS</div>
          <p>Roadside Assistance Service</p>
        </div>
        
        <div class="invoice-info">
          <h2>INVOICE ${invoice.invoice_number}</h2>
          <p><strong>Date:</strong> ${format(new Date(invoice.service_date), 'MMMM dd, yyyy')}</p>
          <p><strong>Customer:</strong> ${customer.full_name} (${customer.email})</p>
          ${technician ? `<p><strong>Technician:</strong> ${technician.full_name}</p>` : ''}
          <p><strong>Service Location:</strong> ${request.location_address || 'N/A'}</p>
        </div>
        
        <table class="invoice-table">
          <thead>
            <tr>
              <th>Service Description</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>${request.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</td>
              <td>$${invoice.subtotal.toFixed(2)}</td>
            </tr>
            ${request.vehicle_make ? `
            <tr>
              <td colspan="2" style="font-size: 12px; color: #666;">
                Vehicle: ${request.vehicle_year} ${request.vehicle_make} ${request.vehicle_model}
              </td>
            </tr>
            ` : ''}
            <tr>
              <td>Tax (8%)</td>
              <td>$${invoice.tax_amount.toFixed(2)}</td>
            </tr>
            ${invoice.tip_amount > 0 ? `
            <tr>
              <td>Tip</td>
              <td>$${invoice.tip_amount.toFixed(2)}</td>
            </tr>
            ` : ''}
            <tr class="total-row">
              <td>TOTAL</td>
              <td>$${invoice.total_amount.toFixed(2)}</td>
            </tr>
          </tbody>
        </table>
        
        <p><strong>Payment Status:</strong> ${invoice.payment_status.toUpperCase()}</p>
        ${invoice.payment_method ? `<p><strong>Payment Method:</strong> ${invoice.payment_method}</p>` : ''}
        
        ${invoice.notes ? `
        <div style="margin-top: 30px;">
          <p><strong>Notes:</strong></p>
          <p>${invoice.notes}</p>
        </div>
        ` : ''}
        
        <div class="footer">
          <p>Thank you for choosing RoadsidePlus!</p>
          <p>For questions about this invoice, please contact support@roadsideplus.com</p>
        </div>
      </body>
      </html>
    `;
  };

  const generatePaymentLink = async () => {
    setGeneratingLink(true);
    try {
      const { data } = await base44.functions.invoke('stripePayment', {
        action: 'create_payment_link',
        requestId: serviceRequest.id,
        amount: serviceRequest.payment_amount || serviceRequest.price,
        description: `${serviceRequest.service_type.replace(/_/g, ' ')} - Invoice`,
      });

      if (data.paymentLink) {
        setPaymentLink(data.paymentLink);
        navigator.clipboard.writeText(data.paymentLink);
        alert('Payment link copied to clipboard!');
      }
    } catch (error) {
      console.error('Error generating payment link:', error);
      alert('Failed to generate payment link.');
    } finally {
      setGeneratingLink(false);
    }
  };

  return (
    <div className="flex gap-2">
      <Button
        onClick={() => generateInvoiceMutation.mutate()}
        disabled={generateInvoiceMutation.isPending}
        variant="outline"
        className="flex items-center gap-2"
      >
        {generateInvoiceMutation.isPending ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            Generating...
          </>
        ) : (
          <>
            <FileText className="w-4 h-4" />
            Generate & Email Invoice
          </>
        )}
      </Button>

      <Button
        onClick={generatePaymentLink}
        disabled={generatingLink}
        variant="outline"
        style={{ borderColor: '#FF771D', color: '#FF771D' }}
      >
        {generatingLink ? (
          <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
        ) : (
          <><LinkIcon className="w-4 h-4 mr-2" /> Payment Link</>
        )}
      </Button>
    </div>
  );
}