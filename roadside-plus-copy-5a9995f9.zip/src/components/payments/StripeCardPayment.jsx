import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CreditCard, Lock, AlertCircle, Loader2 } from 'lucide-react';

export default function StripeCardPayment({ amount, requestId, onSuccess, onCancel }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [testMode, setTestMode] = useState(true);
  const [cardData, setCardData] = useState({
    cardNumber: '',
    expiry: '',
    cvc: '',
    name: '',
  });

  const handleCardNumberChange = (e) => {
    let value = e.target.value.replace(/\s/g, '');
    value = value.replace(/(\d{4})/g, '$1 ').trim();
    setCardData({ ...cardData, cardNumber: value });
  };

  const handleExpiryChange = (e) => {
    let value = e.target.value.replace(/\s/g, '');
    if (value.length >= 2 && !value.includes('/')) {
      value = value.slice(0, 2) + '/' + value.slice(2);
    }
    setCardData({ ...cardData, expiry: value });
  };

  const fillTestData = () => {
    setCardData({
      cardNumber: '4242 4242 4242 4242',
      expiry: '12/25',
      cvc: '123',
      name: 'Test Customer',
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // Step 1: Create payment intent
      const { data: intentData } = await base44.functions.invoke('stripePayment', {
        action: 'create_payment_intent',
        amount: amount,
        metadata: {
          request_id: requestId,
        },
      });

      if (intentData.error) {
        throw new Error(intentData.error);
      }

      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      // In real implementation, you would use Stripe.js here
      // For now, we'll simulate a successful payment
      const mockPaymentIntentId = `pi_test_${Date.now()}`;

      // Step 2: Confirm payment
      const { data: confirmData } = await base44.functions.invoke('stripePayment', {
        action: 'confirm_payment',
        requestId: requestId,
        paymentIntentId: mockPaymentIntentId,
        tipAmount: 0,
      });

      if (confirmData.error) {
        throw new Error(confirmData.error);
      }

      onSuccess(confirmData);
    } catch (err) {
      console.error('Payment error:', err);
      setError(err.message || 'Payment failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="w-5 h-5" style={{ color: '#FF771D' }} />
          Pay with Card
        </CardTitle>
      </CardHeader>
      <CardContent>
        {testMode && (
          <Alert className="mb-4 border-blue-200 bg-blue-50">
            <AlertCircle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              <strong>Test Mode:</strong> Use test card 4242 4242 4242 4242 with any future date and CVC.
              <Button
                type="button"
                variant="link"
                className="p-0 h-auto ml-2 text-blue-600"
                onClick={fillTestData}
              >
                Fill Test Data
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert className="mb-4 border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Cardholder Name</Label>
            <Input
              id="name"
              value={cardData.name}
              onChange={(e) => setCardData({ ...cardData, name: e.target.value })}
              placeholder="John Doe"
              required
            />
          </div>

          <div>
            <Label htmlFor="cardNumber">Card Number</Label>
            <div className="relative">
              <Input
                id="cardNumber"
                value={cardData.cardNumber}
                onChange={handleCardNumberChange}
                placeholder="1234 5678 9012 3456"
                maxLength={19}
                required
              />
              <CreditCard className="absolute right-3 top-3 w-5 h-5 text-gray-400" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="expiry">Expiry Date</Label>
              <Input
                id="expiry"
                value={cardData.expiry}
                onChange={handleExpiryChange}
                placeholder="MM/YY"
                maxLength={5}
                required
              />
            </div>
            <div>
              <Label htmlFor="cvc">CVC</Label>
              <Input
                id="cvc"
                type="text"
                value={cardData.cvc}
                onChange={(e) => setCardData({ ...cardData, cvc: e.target.value.replace(/\D/g, '') })}
                placeholder="123"
                maxLength={4}
                required
              />
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-4 border">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-600">Service Fee</span>
              <span className="font-semibold">${amount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center text-lg font-bold pt-2 border-t">
              <span>Total Amount</span>
              <span style={{ color: '#E52C2D' }}>${amount.toFixed(2)}</span>
            </div>
          </div>

          <div className="flex items-center justify-center gap-2 text-xs text-gray-500 mb-4">
            <Lock className="w-3 h-3" />
            <span>Secured by Stripe • Your payment information is encrypted</span>
          </div>

          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              disabled={loading}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="flex-1 text-white"
              style={{ backgroundColor: '#3D692B' }}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                `Pay $${amount.toFixed(2)}`
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}