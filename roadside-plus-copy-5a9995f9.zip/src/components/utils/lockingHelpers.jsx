import { base44 } from '@/api/base44Client';

// Check if customer has an active service request
export const checkCustomerActiveJob = async (customerId) => {
  const activeStatuses = [
    'pending_payment',
    'pending_dispatch',
    'dispatched',
    'assigned',
    'en_route',
    'arrived',
    'in_progress',
    'awaiting_review'
  ];

  const requests = await base44.entities.ServiceRequest.filter({
    customer_id: customerId
  });

  const activeJobs = requests.filter(req => activeStatuses.includes(req.status));
  
  return {
    hasActiveJob: activeJobs.length > 0,
    activeJob: activeJobs[0] || null
  };
};

// Check if technician has an active service request
export const checkTechnicianActiveJob = async (technicianId) => {
  const activeStatuses = [
    'assigned',
    'en_route',
    'arrived',
    'in_progress',
    'awaiting_review'
  ];

  const requests = await base44.entities.ServiceRequest.filter({
    technician_id: technicianId
  });

  const dispatchedRequests = await base44.entities.ServiceRequest.filter({
    current_offered_technician_id: technicianId,
    status: 'dispatched'
  });

  const activeJobs = [
    ...requests.filter(req => activeStatuses.includes(req.status)),
    ...dispatchedRequests
  ];

  return {
    hasActiveJob: activeJobs.length > 0,
    activeJob: activeJobs[0] || null
  };
};

// Validate and lock customer for new request
export const lockCustomerForNewRequest = async (customerId) => {
  const { hasActiveJob, activeJob } = await checkCustomerActiveJob(customerId);
  
  if (hasActiveJob) {
    return {
      allowed: false,
      message: 'You already have an active service in progress.',
      activeJob
    };
  }

  return { allowed: true };
};

// Validate and lock technician for accepting job
export const lockTechnicianForAcceptJob = async (technicianId) => {
  const { hasActiveJob, activeJob } = await checkTechnicianActiveJob(technicianId);
  
  if (hasActiveJob) {
    return {
      allowed: false,
      message: 'You must complete your current job before accepting a new one.',
      activeJob
    };
  }

  return { allowed: true };
};