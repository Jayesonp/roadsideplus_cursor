import { base44 } from '@/api/base44Client';

let userPromise = null;
let lastFetchTime = 0;
const CACHE_DURATION = 30000; // 30 seconds cache

export const getCachedUser = async () => {
  const now = Date.now();
  
  if (userPromise && (now - lastFetchTime < CACHE_DURATION)) {
    return userPromise;
  }

  // Deduplicate simultaneous calls
  userPromise = base44.auth.me().then(user => {
    lastFetchTime = Date.now();
    return user;
  }).catch(err => {
    userPromise = null;
    throw err;
  });

  return userPromise;
};

export const invalidateUserCache = () => {
  userPromise = null;
  lastFetchTime = 0;
};