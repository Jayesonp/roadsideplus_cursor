import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, Navigation, MapPin, TrendingDown, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const calculateDistance = (lat1, lng1, lat2, lng2) => {
  const R = 3959;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

const calculateETA = (distanceMiles, currentTraffic = 'normal') => {
  const trafficMultipliers = {
    light: 0.85,
    normal: 1.0,
    heavy: 1.4
  };
  
  const baseSpeed = 35; // mph
  const multiplier = trafficMultipliers[currentTraffic] || 1.0;
  const adjustedSpeed = baseSpeed / multiplier;
  const responseTime = 3; // minutes
  const travelMinutes = (distanceMiles / adjustedSpeed) * 60;
  
  return Math.round(travelMinutes + responseTime);
};

export default function ETADisplay({ serviceRequest, className = '' }) {
  const [currentETA, setCurrentETA] = useState(null);
  const [previousDistance, setPreviousDistance] = useState(null);
  const [showImprovement, setShowImprovement] = useState(false);

  // Get technician's real-time location if assigned
  const { data: techProfile } = useQuery({
    queryKey: ['tech-location', serviceRequest?.technician_id],
    queryFn: async () => {
      if (!serviceRequest?.technician_id) return null;
      const profiles = await base44.entities.TechnicianProfile.filter({
        user_id: serviceRequest.technician_id
      });
      return profiles[0];
    },
    enabled: !!serviceRequest?.technician_id && ['assigned', 'en_route', 'arrived'].includes(serviceRequest?.status),
    refetchInterval: 8000, // Update every 8 seconds
    retry: 2
  });

  useEffect(() => {
    if (!serviceRequest || !techProfile?.current_lat || !serviceRequest.location_lat) {
      // Use estimated arrival if no live tracking
      if (serviceRequest?.estimated_arrival) {
        const now = new Date();
        const eta = new Date(serviceRequest.estimated_arrival);
        const minutesRemaining = Math.max(0, Math.round((eta - now) / 60000));
        setCurrentETA(minutesRemaining);
      }
      return;
    }

    // Calculate live distance and ETA
    const distance = calculateDistance(
      techProfile.current_lat,
      techProfile.current_lng,
      serviceRequest.location_lat,
      serviceRequest.location_lng
    );

    const eta = calculateETA(distance);
    
    // Check if distance is decreasing (technician getting closer)
    if (previousDistance !== null && distance < previousDistance) {
      setShowImprovement(true);
      setTimeout(() => setShowImprovement(false), 2000);
    }
    
    setPreviousDistance(distance);
    setCurrentETA(eta);
  }, [techProfile, serviceRequest]);

  if (!serviceRequest || !['assigned', 'en_route', 'arrived'].includes(serviceRequest.status)) {
    return null;
  }

  if (serviceRequest.status === 'arrived') {
    return (
      <Card className={`border-2 border-green-500 bg-green-50 ${className}`}>
        <CardContent className="p-4">
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-lg font-bold text-green-900">Technician Arrived!</p>
              <p className="text-sm text-green-700">Service will begin shortly</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (currentETA === null) {
    return (
      <Card className={className}>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <Loader2 className="w-5 h-5 animate-spin" style={{ color: '#FF771D' }} />
            <p className="text-sm text-gray-600">Calculating ETA...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const isUrgent = currentETA <= 5;
  const borderColor = isUrgent ? '#3D692B' : '#FF771D';
  const bgColor = isUrgent ? 'bg-green-50' : 'bg-orange-50';

  return (
    <Card className={`border-2 ${bgColor} ${className}`} style={{ borderColor }}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-full flex items-center justify-center"
              style={{ backgroundColor: borderColor }}
            >
              <Clock className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <p className="text-sm text-gray-600 font-medium">
                  {serviceRequest.status === 'en_route' ? 'Arriving in' : 'Estimated arrival'}
                </p>
                {showImprovement && (
                  <Badge className="bg-green-100 text-green-800 text-xs animate-bounce">
                    <TrendingDown className="w-3 h-3 mr-1" />
                    Getting closer!
                  </Badge>
                )}
              </div>
              <p className="text-2xl font-bold" style={{ color: borderColor }}>
                {currentETA} minutes
              </p>
            </div>
          </div>
          
          {serviceRequest.status === 'en_route' && (
            <div className="text-right">
              <Badge 
                className="text-white mb-1"
                style={{ backgroundColor: '#E52C2D' }}
              >
                <Navigation className="w-3 h-3 mr-1" />
                En Route
              </Badge>
              <p className="text-xs text-gray-500">Live tracking active</p>
            </div>
          )}
        </div>
        
        {techProfile && previousDistance !== null && (
          <div className="mt-3 pt-3 border-t border-gray-200">
            <div className="flex items-center justify-between text-xs text-gray-600">
              <span>Distance remaining:</span>
              <span className="font-semibold">{previousDistance.toFixed(1)} miles</span>
            </div>
          </div>
        )}
        
        <p className="text-xs text-gray-500 mt-2 text-center">
          {serviceRequest.status === 'en_route' ? '🔄 Updating every 8 seconds' : '⏱️ Based on current traffic'}
        </p>
      </CardContent>
    </Card>
  );
}