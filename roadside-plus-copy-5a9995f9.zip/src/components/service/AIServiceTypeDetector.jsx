import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, Camera, Sparkles, CheckCircle, AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function AIServiceTypeDetector({ 
  description, 
  imageUrl = null,
  onDetectionComplete,
  autoDetect = false 
}) {
  const [detecting, setDetecting] = useState(false);
  const [result, setResult] = useState(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [uploadedImageUrl, setUploadedImageUrl] = useState(imageUrl);

  const handleImageUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setUploadingImage(true);
    try {
      // Compress image if large
      const compressedFile = file.size > 1024 * 1024 ? await compressImage(file) : file;
      
      const { file_url } = await base44.integrations.Core.UploadFile({ file: compressedFile });
      setUploadedImageUrl(file_url);
      
      // Auto-detect immediately without delay
      detectServiceType(null, file_url);
    } catch (error) {
      console.error('Error uploading image:', error);
      alert('Failed to upload image');
    } finally {
      setUploadingImage(false);
    }
  };

  const compressImage = (file) => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          const maxDimension = 1200;
          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height = (height / width) * maxDimension;
              width = maxDimension;
            } else {
              width = (width / height) * maxDimension;
              height = maxDimension;
            }
          }
          
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          
          canvas.toBlob((blob) => {
            resolve(new File([blob], file.name, { type: 'image/jpeg' }));
          }, 'image/jpeg', 0.85);
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(file);
    });
  };

  const detectServiceType = async (textDescription = description, imgUrl = uploadedImageUrl) => {
    if (!textDescription?.trim() && !imgUrl) {
      alert('Please provide a description or upload an image');
      return;
    }

    setDetecting(true);
    setResult(null);

    try {
      // Prepare context for AI
      const hasImage = !!imgUrl;
      const hasText = !!textDescription?.trim();

      let prompt = `You are an expert roadside assistance service classifier. Analyze the provided information and determine the most appropriate service type.

Available Service Types:
1. tire_change - Flat tire, tire puncture, blown tire, nail in tire, tire damage
2. battery_jump - Dead battery, car won't start, battery issues, needs jump start, electrical problems
3. fuel_delivery - Out of gas, fuel empty, need gas/diesel, ran out of fuel
4. lockout - Keys locked inside car, lost keys, can't access vehicle, key issues
5. towing - Major breakdown, engine failure, transmission problems, accident, vehicle immobile, severe mechanical issues
6. other - Any service not clearly matching the above categories

`;

      if (hasText) {
        prompt += `Customer Description: "${textDescription}"\n\n`;
      }

      if (hasImage) {
        prompt += `An image has been provided showing the vehicle or issue.\n\n`;
      }

      prompt += `Analyze ${hasImage && hasText ? 'both the description and image' : hasImage ? 'the image' : 'the description'} carefully.

Classification Guidelines:
- Look for specific keywords and visual cues
- Consider the severity and nature of the problem
- If unsure between two types, choose the more specific one
- Use "other" only if it clearly doesn't fit any category
- For images: identify visible damage, flat tires, warning lights, empty fuel gauge, etc.

Provide:
1. The most appropriate service_type
2. Your confidence level (high/medium/low)
3. A clear reasoning explaining your choice
4. Any additional observations that might help the technician`;

      const aiResponse = await base44.integrations.Core.InvokeLLM({
        prompt,
        file_urls: imgUrl ? [imgUrl] : undefined,
        response_json_schema: {
          type: 'object',
          properties: {
            service_type: {
              type: 'string',
              enum: ['tire_change', 'battery_jump', 'fuel_delivery', 'lockout', 'towing', 'other']
            },
            confidence: {
              type: 'string',
              enum: ['high', 'medium', 'low']
            },
            reasoning: {
              type: 'string',
              description: 'Detailed explanation of why this service type was chosen'
            },
            additional_observations: {
              type: 'string',
              description: 'Any other relevant details noticed'
            },
            suggested_priority: {
              type: 'string',
              enum: ['low', 'normal', 'high', 'critical'],
              description: 'Suggested priority based on urgency'
            }
          },
          required: ['service_type', 'confidence', 'reasoning']
        }
      });

      setResult(aiResponse);

      // Call the callback with results
      if (onDetectionComplete) {
        onDetectionComplete({
          serviceType: aiResponse.service_type,
          confidence: aiResponse.confidence,
          reasoning: aiResponse.reasoning,
          priority: aiResponse.suggested_priority || 'normal',
          observations: aiResponse.additional_observations
        });
      }

    } catch (error) {
      console.error('Error detecting service type:', error);
      alert('Failed to analyze. Please try again or select service type manually.');
    } finally {
      setDetecting(false);
    }
  };

  // Auto-detect on mount if enabled
  React.useEffect(() => {
    if (autoDetect && (description?.trim() || uploadedImageUrl)) {
      detectServiceType();
    }
  }, [autoDetect]);

  const getConfidenceColor = (confidence) => {
    switch (confidence) {
      case 'high': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-orange-600';
      default: return 'text-gray-600';
    }
  };

  const getServiceTypeLabel = (type) => {
    const labels = {
      tire_change: 'Tire Change',
      battery_jump: 'Battery Jump Start',
      fuel_delivery: 'Fuel Delivery',
      lockout: 'Lockout Service',
      towing: 'Towing',
      other: 'Other Service'
    };
    return labels[type] || type;
  };

  return (
    <div className="space-y-3">
      {/* Image Upload */}
      <div className="flex gap-2">
        <label className="flex-1">
          <Button
            type="button"
            variant="outline"
            className="w-full"
            disabled={uploadingImage || detecting}
            onClick={() => document.getElementById('service-image-upload').click()}
          >
            {uploadingImage ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Uploading Image...
              </>
            ) : (
              <>
                <Camera className="w-4 h-4 mr-2" />
                {uploadedImageUrl ? 'Change Image' : 'Upload Image'}
              </>
            )}
          </Button>
          <input
            id="service-image-upload"
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
          />
        </label>

        <Button
          type="button"
          onClick={() => detectServiceType()}
          disabled={detecting || (!description?.trim() && !uploadedImageUrl)}
          className="flex-1 text-white"
          style={{ backgroundColor: '#FF771D' }}
        >
          {detecting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              AI Detect Service
            </>
          )}
        </Button>
      </div>

      {/* Image Preview */}
      {uploadedImageUrl && (
        <div className="relative">
          <img 
            src={uploadedImageUrl} 
            alt="Service issue" 
            className="w-full h-48 object-cover rounded-lg border-2 border-gray-200"
          />
          <Button
            type="button"
            variant="destructive"
            size="sm"
            className="absolute top-2 right-2"
            onClick={() => setUploadedImageUrl(null)}
          >
            Remove
          </Button>
        </div>
      )}

      {/* Detection Result */}
      {result && (
        <Card className="border-2" style={{ borderColor: result.confidence === 'high' ? '#3D692B' : '#FF771D' }}>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              {result.confidence === 'high' ? (
                <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
              ) : (
                <AlertTriangle className={`w-6 h-6 flex-shrink-0 mt-1 ${getConfidenceColor(result.confidence)}`} />
              )}
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <h4 className="font-bold text-lg">{getServiceTypeLabel(result.service_type)}</h4>
                  <span className={`text-xs font-semibold uppercase px-2 py-1 rounded ${getConfidenceColor(result.confidence)}`}>
                    {result.confidence} confidence
                  </span>
                </div>
                
                <p className="text-sm text-gray-700 mb-2">
                  <strong>Analysis:</strong> {result.reasoning}
                </p>

                {result.additional_observations && (
                  <p className="text-sm text-gray-600 mb-2">
                    <strong>Notes:</strong> {result.additional_observations}
                  </p>
                )}

                {result.suggested_priority && (
                  <div className="flex items-center gap-2 text-sm">
                    <strong>Suggested Priority:</strong>
                    <span className={`font-semibold capitalize ${
                      result.suggested_priority === 'critical' ? 'text-red-600' :
                      result.suggested_priority === 'high' ? 'text-orange-600' :
                      'text-gray-600'
                    }`}>
                      {result.suggested_priority}
                    </span>
                  </div>
                )}

                {result.confidence === 'low' && (
                  <Alert className="mt-3 bg-yellow-50 border-yellow-200">
                    <AlertTriangle className="w-4 h-4 text-yellow-600" />
                    <AlertDescription className="text-sm text-yellow-800">
                      AI confidence is low. Please verify the suggested service type or provide more details.
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Help Text */}
      {!result && !detecting && (
        <p className="text-xs text-gray-500 text-center">
          💡 Upload a photo of your vehicle issue or provide a description for automatic service type detection
        </p>
      )}
    </div>
  );
}