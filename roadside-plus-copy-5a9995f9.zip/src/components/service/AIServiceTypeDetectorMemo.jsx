import React from 'react';
import AIServiceTypeDetector from './AIServiceTypeDetector';

export default React.memo(AIServiceTypeDetector, (prevProps, nextProps) => {
  return prevProps.description === nextProps.description;
});