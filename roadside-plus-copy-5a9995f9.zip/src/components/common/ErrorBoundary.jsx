import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    // Suppress Illegal constructor errors from crashing the UI if possible
    if (error.message && error.message.includes('Illegal constructor')) {
      console.warn("Suppressed Illegal constructor error in ErrorBoundary:", error);
      return;
    }
    console.error("ErrorBoundary caught an error", error, errorInfo);
    this.setState({ errorInfo });
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
    if (this.props.onRetry) {
      this.props.onRetry();
    } else {
      window.location.reload();
    }
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="p-6 border border-red-200 bg-red-50 rounded-lg flex flex-col items-center justify-center text-center h-full min-h-[200px]">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <AlertTriangle className="w-6 h-6 text-red-600" />
          </div>
          <h3 className="text-lg font-semibold text-red-900 mb-2">Something went wrong</h3>
          <p className="text-sm text-red-700 mb-4 max-w-md">
            {this.props.message || "We couldn't load this section. Please try again."}
          </p>
          <Button 
            variant="outline" 
            onClick={this.handleRetry}
            className="border-red-300 text-red-700 hover:bg-red-100"
          >
            Retry
          </Button>
          {process.env.NODE_ENV === 'development' && this.state.error && (
            <details className="mt-4 text-left text-xs text-red-800 bg-red-100 p-2 rounded w-full overflow-auto max-h-40">
              <summary>Error Details</summary>
              <pre className="mt-2">{this.state.error.toString()}</pre>
              <pre>{this.state.errorInfo?.componentStack}</pre>
            </details>
          )}
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;