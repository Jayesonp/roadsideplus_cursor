import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Clock, CheckCircle, Loader, Navigation, Wrench, XCircle } from 'lucide-react';

const statusConfig = {
  pending: {
    label: 'Pending',
    color: 'bg-gray-100 text-gray-800 border-gray-300',
    icon: Clock
  },
  assigned: {
    label: 'Assigned',
    color: 'bg-blue-100 text-blue-800 border-blue-300',
    icon: CheckCircle
  },
  en_route: {
    label: 'En Route',
    color: 'bg-yellow-100 text-yellow-800 border-yellow-300',
    icon: Navigation,
    iconColor: '#FF771D'
  },
  in_progress: {
    label: 'In Progress',
    color: 'bg-orange-100 text-orange-800 border-orange-300',
    icon: Wrench,
    iconColor: '#FF771D'
  },
  completed: {
    label: 'Completed',
    color: 'bg-green-100 text-green-800 border-green-300',
    icon: CheckCircle,
    iconColor: '#3D692B'
  },
  cancelled: {
    label: 'Cancelled',
    color: 'bg-red-100 text-red-800 border-red-300',
    icon: XCircle,
    iconColor: '#E52C2D'
  }
};

export default function StatusBadge({ status, showIcon = true }) {
  const config = statusConfig[status] || statusConfig.pending;
  const Icon = config.icon;
  
  return (
    <Badge className={`${config.color} border flex items-center gap-1.5 px-3 py-1`}>
      {showIcon && <Icon className="w-3.5 h-3.5" style={config.iconColor ? { color: config.iconColor } : {}} />}
      <span className="font-medium">{config.label}</span>
    </Badge>
  );
}