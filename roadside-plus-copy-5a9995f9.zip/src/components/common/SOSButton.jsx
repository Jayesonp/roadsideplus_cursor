import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';

export default function SOSButton({ userId }) {
  const [triggering, setTriggering] = useState(false);

  const triggerSOS = useMutation({
    mutationFn: async () => {
      // Get user location
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 5000
        });
      });

      const { latitude, longitude } = position.coords;

      // Get battery level if available
      const battery = await navigator.getBattery?.() || {};

      // Get current user details
      const currentUser = await base44.auth.me();

      // Check if user has a partner
      let partnerId = null;
      const userRequests = await base44.entities.ServiceRequest.filter({ customer_id: userId });
      if (userRequests.length > 0 && userRequests[0].partner_id) {
        partnerId = userRequests[0].partner_id;
      }

      // Create SOS incident
      const incident = await base44.entities.SOSIncident.create({
        customer_id: userId,
        location_lat: latitude,
        location_lng: longitude,
        severity: 'critical',
        status: 'pending',
        customer_device_battery: battery.level ? Math.round(battery.level * 100) : null,
        description: 'Emergency SOS triggered by customer'
      });

      // Log event
      await base44.entities.SecurityEvent.create({
        incident_id: incident.id,
        event_type: 'sos_triggered',
        location_lat: latitude,
        location_lng: longitude
      });

      // Notify admins
      const admins = await base44.entities.User.filter({ role: 'admin' });
      for (const admin of admins) {
        await base44.entities.Notification.create({
          user_id: admin.id,
          type: 'critical_sos',
          title: '🚨 EMERGENCY SOS ALERT',
          message: `Critical SOS triggered by ${currentUser.full_name}`,
          related_id: incident.id
        });
      }

      // Notify partner if exists
      if (partnerId) {
        const partner = await base44.entities.Partner.filter({ id: partnerId });
        if (partner.length > 0) {
          // Get partner staff with admin access
          const partnerStaff = await base44.entities.PartnerStaff.filter({ 
            partner_id: partnerId,
            role: 'admin'
          });
          for (const staff of partnerStaff) {
            await base44.entities.Notification.create({
              user_id: staff.user_id,
              type: 'critical_sos',
              title: '🚨 CLIENT EMERGENCY SOS',
              message: `Your client ${currentUser.full_name} has triggered an emergency SOS`,
              related_id: incident.id
            });
          }
        }
      }

      // Notify security companies
      const securityCompanies = await base44.entities.SecurityCompany.filter({ status: 'active' });
      for (const company of securityCompanies) {
        const officers = await base44.entities.SecurityOfficer.filter({ 
          company_id: company.id,
          status: 'available'
        });
        for (const officer of officers) {
          await base44.entities.Notification.create({
            user_id: officer.user_id,
            type: 'critical_sos',
            title: '🚨 EMERGENCY SOS ALERT',
            message: `Critical SOS at ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`,
            related_id: incident.id
          });
        }
      }

      return incident;
    },
    onSuccess: () => {
      alert('SOS Alert Sent! Security team has been notified.');
      setTriggering(false);
    },
    onError: (error) => {
      alert('Failed to send SOS: ' + error.message);
      setTriggering(false);
    }
  });

  const handleSOSClick = () => {
    if (window.confirm('⚠️ TRIGGER EMERGENCY SOS?\n\nThis will immediately alert security personnel to your location. Only use in genuine emergencies.')) {
      setTriggering(true);
      triggerSOS.mutate();
    }
  };

  return (
    <Button
      onClick={handleSOSClick}
      disabled={triggering}
      className="fixed z-[40] w-14 h-14 rounded-full shadow-2xl text-white animate-pulse hover:scale-110 transition-transform"
      style={{ 
        backgroundColor: '#E52C2D',
        bottom: 'calc(env(safe-area-inset-bottom) + 100px)',
        right: 'calc(env(safe-area-inset-right) + 20px)'
      }}
    >
      <AlertTriangle className="w-6 h-6" />
    </Button>
  );
}