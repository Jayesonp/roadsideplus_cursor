import React from 'react';
import { Wrench, Battery, Fuel, Key, Truck, HelpCircle } from 'lucide-react';

const serviceIcons = {
  tire_change: Wrench,
  battery_jump: Battery,
  fuel_delivery: Fuel,
  lockout: Key,
  towing: Truck,
  other: HelpCircle
};

const serviceLabels = {
  tire_change: 'Tire Change',
  battery_jump: 'Battery Jump',
  fuel_delivery: 'Fuel Delivery',
  lockout: 'Lockout Service',
  towing: 'Towing',
  other: 'Other Service'
};

export default function ServiceTypeIcon({ type, showLabel = false, className = "w-6 h-6" }) {
  const Icon = serviceIcons[type] || HelpCircle;
  
  if (showLabel) {
    return (
      <div className="flex items-center gap-2">
        <Icon className={className} style={{ color: '#FF771D' }} />
        <span className="font-medium">{serviceLabels[type] || 'Service'}</span>
      </div>
    );
  }
  
  return <Icon className={className} style={{ color: '#FF771D' }} />;
}