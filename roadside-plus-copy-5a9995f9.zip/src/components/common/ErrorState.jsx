import React from 'react';
import { AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function ErrorState({ 
  message = 'Something went wrong', 
  onRetry,
  showRetry = true,
  buttonText = 'Try Again'
}) {
  return (
    <Card className="m-6">
      <CardContent className="flex flex-col items-center justify-center p-8">
        <AlertCircle className="w-12 h-12 mb-4" style={{ color: '#E52C2D' }} />
        <h3 className="text-lg font-semibold mb-2">Oops!</h3>
        <p className="text-gray-600 text-center mb-4">{message}</p>
        {showRetry && onRetry && (
          <Button onClick={onRetry} className="text-white" style={{ backgroundColor: '#FF771D' }}>
            {buttonText}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}