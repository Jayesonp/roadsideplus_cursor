import { useQuery } from '@tanstack/react-query';
import { useState, useEffect, useRef } from 'react';

/**
 * Custom hook that wraps useQuery with automatic timeout handling
 * Optimization: Uses Promise.race to enforce timeout at the fetch level
 * @param {Object} queryOptions - React Query options
 * @param {Number} timeout - Timeout in milliseconds (default: 10000)
 */
export function useQueryWithTimeout(queryOptions, timeout = 10000) {
  // Wrap queryFn with timeout logic
  const originalFn = queryOptions.queryFn;
  
  const wrappedFn = async (context) => {
    const timeoutPromise = new Promise((_, reject) => {
      const id = setTimeout(() => {
        reject(new Error('Request timed out'));
      }, timeout);
    });

    try {
      // Race the original function against the timeout
      return await Promise.race([
        originalFn(context),
        timeoutPromise
      ]);
    } catch (error) {
      throw error;
    }
  };

  return useQuery({
    ...queryOptions,
    queryFn: wrappedFn,
    retry: queryOptions.retry ?? 1,
    retryDelay: queryOptions.retryDelay ?? 1000,
    // Increase cache time to reduce redundant fetches
    staleTime: queryOptions.staleTime ?? 60000, 
    gcTime: 300000, // 5 minutes (formerly cacheTime)
  });
}