import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Star, Loader2, DollarSign } from 'lucide-react';

const tipOptions = [
  { label: 'No Tip', value: 0 },
  { label: '$5', value: 5 },
  { label: '$10', value: 10 },
  { label: '$15', value: 15 },
  { label: '$20', value: 20 },
  { label: 'Custom', value: 'custom' }
];

export default function CustomerRatingModal({ serviceRequest, technicianName, onSubmit, isSubmitting }) {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [tipAmount, setTipAmount] = useState(0);
  const [customTip, setCustomTip] = useState('');
  const [showCustomTip, setShowCustomTip] = useState(false);

  const handleTipSelect = (value) => {
    if (value === 'custom') {
      setShowCustomTip(true);
      setTipAmount(0);
    } else {
      setShowCustomTip(false);
      setTipAmount(value);
    }
  };

  const handleCustomTipChange = (e) => {
    const value = e.target.value;
    setCustomTip(value);
    const parsed = parseFloat(value);
    setTipAmount(isNaN(parsed) ? 0 : parsed);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (rating > 0) {
      onSubmit({ rating, comment, tipAmount });
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80 overflow-y-auto py-4"
           style={{
             paddingTop: 'max(1rem, env(safe-area-inset-top))',
             paddingLeft: 'env(safe-area-inset-left)',
             paddingRight: 'env(safe-area-inset-right)',
             paddingBottom: 'max(1rem, env(safe-area-inset-bottom))'
           }}>
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl"
        >
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center"
                 style={{ backgroundColor: '#FF771D' }}>
              <Star className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Rate Your Experience</h2>
            <p className="text-gray-600">How was your service with {technicianName}?</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Star Rating */}
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-12 h-12 ${
                      star <= (hoverRating || rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>

            {rating > 0 && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="text-center"
              >
                <p className="text-lg font-semibold" style={{ color: '#FF771D' }}>
                  {rating === 5 ? 'Excellent!' : 
                   rating === 4 ? 'Very Good!' : 
                   rating === 3 ? 'Good' : 
                   rating === 2 ? 'Fair' : 
                   'Needs Improvement'}
                </p>
              </motion.div>
            )}

            {/* Tip Selection */}
            <div>
              <label className="block text-sm font-semibold mb-3 flex items-center gap-2">
                <DollarSign className="w-4 h-4" style={{ color: '#3D692B' }} />
                Add a Tip (Optional)
              </label>
              <div className="grid grid-cols-3 gap-2 mb-3">
                {tipOptions.map((option) => (
                  <button
                    key={option.label}
                    type="button"
                    onClick={() => handleTipSelect(option.value)}
                    className={`py-3 px-4 rounded-lg border-2 font-semibold transition-all ${
                      (option.value === 'custom' && showCustomTip) || 
                      (option.value !== 'custom' && tipAmount === option.value)
                        ? 'border-green-600 bg-green-50 text-green-700'
                        : 'border-gray-300 hover:border-green-400'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>

              {showCustomTip && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-bold text-gray-600">$</span>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={customTip}
                      onChange={handleCustomTipChange}
                      placeholder="Enter amount"
                      className="flex-1 px-4 py-2 border-2 border-green-300 rounded-lg text-lg focus:outline-none focus:border-green-500"
                    />
                  </div>
                </motion.div>
              )}

              {tipAmount > 0 && (
                <p className="text-sm mt-2 font-semibold" style={{ color: '#3D692B' }}>
                  ✓ Tip: ${tipAmount.toFixed(2)}
                </p>
              )}
            </div>

            {/* Optional Comment */}
            <div>
              <label className="block text-sm font-semibold mb-2">
                Add a comment (optional)
              </label>
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Share your experience..."
                rows={4}
                className="w-full"
              />
            </div>

            {/* Required Notice */}
            <div className="bg-orange-50 rounded-lg p-3 text-center border-2 border-orange-200">
              <p className="text-sm text-gray-700 font-medium">
                ⚠️ Rating is required to request new services
              </p>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={rating === 0 || isSubmitting}
              className="w-full text-white text-lg py-6"
              style={{ backgroundColor: rating > 0 ? '#FF771D' : '#9CA3AF' }}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>Submit Rating{tipAmount > 0 ? ` & Tip ($${tipAmount.toFixed(2)})` : ''}</>
              )}
            </Button>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}