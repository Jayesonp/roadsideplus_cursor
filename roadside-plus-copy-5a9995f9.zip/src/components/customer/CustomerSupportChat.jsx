import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { MessageCircle, Send, X, Plus, Clock, CheckCircle2, Circle, Paperclip, FileText, Image as ImageIcon, Loader2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function CustomerSupportChat({ userId }) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [showNewChat, setShowNewChat] = useState(false);
  const [newSubject, setNewSubject] = useState('');
  const [attachments, setAttachments] = useState([]);
  const [uploading, setUploading] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const queryClient = useQueryClient();

  // Fetch conversations
  const { data: conversations = [] } = useQuery({
    queryKey: ['support-conversations', userId],
    queryFn: async () => {
      return await base44.entities.SupportConversation.filter(
        { customer_id: userId },
        '-last_message_at'
      );
    },
    enabled: !!userId && isOpen,
    refetchInterval: 3000
  });

  // Fetch online agents
  const { data: onlineAgents = [] } = useQuery({
    queryKey: ['online-agents'],
    queryFn: async () => {
      const allUsers = await base44.entities.User.list();
      return allUsers.filter(u => u.role === 'admin');
    },
    refetchInterval: 30000
  });

  // Fetch messages for selected conversation
  const { data: messages = [] } = useQuery({
    queryKey: ['support-messages', selectedConversation?.id],
    queryFn: async () => {
      return await base44.entities.SupportMessage.filter(
        { conversation_id: selectedConversation.id },
        'created_date'
      );
    },
    enabled: !!selectedConversation,
    refetchInterval: 2000
  });

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Mark messages as read
  useEffect(() => {
    if (selectedConversation && messages.length > 0) {
      const unreadMessages = messages.filter(
        msg => msg.sender_role === 'agent' && !msg.is_read
      );
      
      unreadMessages.forEach(async (msg) => {
        await base44.entities.SupportMessage.update(msg.id, { is_read: true });
      });

      if (unreadMessages.length > 0) {
        base44.entities.SupportConversation.update(selectedConversation.id, {
          customer_unread_count: 0
        });
        queryClient.invalidateQueries(['support-conversations']);
      }
    }
  }, [messages, selectedConversation]);

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setUploading(true);
    try {
      const uploadedFiles = await Promise.all(
        files.map(async (file) => {
          const { file_url } = await base44.integrations.Core.UploadFile({ file });
          return {
            url: file_url,
            name: file.name,
            type: file.type.startsWith('image/') ? 'image' : 'file'
          };
        })
      );
      setAttachments([...attachments, ...uploadedFiles]);
    } catch (error) {
      console.error('Upload failed:', error);
    } finally {
      setUploading(false);
    }
  };

  const removeAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  // Create new conversation
  const createConversation = useMutation({
    mutationFn: async () => {
      return await base44.entities.SupportConversation.create({
        customer_id: userId,
        subject: newSubject,
        status: 'open',
        last_message_at: new Date().toISOString()
      });
    },
    onSuccess: (newConv) => {
      queryClient.invalidateQueries(['support-conversations']);
      setSelectedConversation(newConv);
      setShowNewChat(false);
      setNewSubject('');
    }
  });

  // Send message
  const sendMessage = useMutation({
    mutationFn: async () => {
      const msg = await base44.entities.SupportMessage.create({
        conversation_id: selectedConversation.id,
        sender_id: userId,
        sender_role: 'customer',
        message: newMessage,
        attachment_url: attachments.length > 0 ? JSON.stringify(attachments) : null
      });

      // Update conversation
      await base44.entities.SupportConversation.update(selectedConversation.id, {
        last_message_at: new Date().toISOString(),
        agent_unread_count: (selectedConversation.agent_unread_count || 0) + 1
      });

      // Notify agent if assigned
      if (selectedConversation.assigned_agent_id) {
        await base44.entities.Notification.create({
          user_id: selectedConversation.assigned_agent_id,
          type: 'new_message',
          title: 'New Support Message',
          message: `Customer replied: "${newMessage.substring(0, 50)}..."`,
          related_id: selectedConversation.id
        });
      }

      return msg;
    },
    onSuccess: () => {
      setNewMessage('');
      setAttachments([]);
      queryClient.invalidateQueries(['support-messages']);
      queryClient.invalidateQueries(['support-conversations']);
    }
  });

  const totalUnread = conversations.reduce((sum, conv) => sum + (conv.customer_unread_count || 0), 0);

  const statusConfig = {
    open: { label: 'Open', color: 'bg-blue-100 text-blue-800' },
    in_progress: { label: 'In Progress', color: 'bg-yellow-100 text-yellow-800' },
    resolved: { label: 'Resolved', color: 'bg-green-100 text-green-800' },
    closed: { label: 'Closed', color: 'bg-gray-100 text-gray-800' }
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed z-[40] w-14 h-14 rounded-full flex items-center justify-center text-white hover:scale-110 transition-transform"
        style={{ 
          backgroundColor: '#FF771D',
          bottom: 'calc(env(safe-area-inset-bottom) + 240px)',
          right: 'calc(env(safe-area-inset-right) + 20px)',
          boxShadow: '0px 4px 12px rgba(0,0,0,0.3)'
        }}
      >
        <MessageCircle className="w-6 h-6" />
        {totalUnread > 0 && (
          <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold">
            {totalUnread}
          </div>
        )}
      </button>

      {/* Chat Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl h-[600px] p-0 z-[50]">
          <div className="flex h-full">
            {/* Conversations List */}
            <div className="w-1/3 border-r flex flex-col">
              <DialogHeader className="p-4 border-b text-white" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
                <div className="flex items-center justify-between">
                  <div>
                    <DialogTitle className="text-white">Support Chat</DialogTitle>
                    <div className="flex items-center gap-1 text-xs opacity-90 mt-1">
                      <Circle className={`w-2 h-2 ${onlineAgents.length > 0 ? 'fill-green-400 text-green-400' : 'fill-gray-400 text-gray-400'}`} />
                      <span>{onlineAgents.length > 0 ? `${onlineAgents.length} agent${onlineAgents.length > 1 ? 's' : ''} online` : 'Offline'}</span>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => setShowNewChat(true)}
                    className="bg-white/20 hover:bg-white/30 text-white border-0"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </DialogHeader>

              <div className="flex-1 overflow-y-auto p-2">
                {conversations.length === 0 ? (
                  <div className="text-center p-4 text-gray-500 text-sm">
                    No conversations yet
                  </div>
                ) : (
                  conversations.map(conv => (
                    <Card
                      key={conv.id}
                      className={`mb-2 cursor-pointer hover:bg-gray-50 transition-colors ${
                        selectedConversation?.id === conv.id ? 'border-orange-500' : ''
                      }`}
                      onClick={() => setSelectedConversation(conv)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-start justify-between mb-1">
                          <h4 className="font-semibold text-sm line-clamp-1">{conv.subject}</h4>
                          {conv.customer_unread_count > 0 && (
                            <div className="w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center flex-shrink-0 ml-2">
                              {conv.customer_unread_count}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center justify-between">
                          <Badge className={`text-xs ${statusConfig[conv.status].color}`}>
                            {statusConfig[conv.status].label}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            {formatDistanceToNow(new Date(conv.last_message_at || conv.created_date), { addSuffix: true })}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 flex flex-col">
              {showNewChat ? (
                <div className="flex-1 flex flex-col p-6">
                  <h3 className="font-semibold mb-4">Start New Conversation</h3>
                  <Input
                    placeholder="What do you need help with?"
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value)}
                    className="mb-4"
                  />
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={() => setShowNewChat(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button
                      onClick={() => createConversation.mutate()}
                      disabled={!newSubject.trim() || createConversation.isLoading}
                      className="flex-1 text-white"
                      style={{ backgroundColor: '#FF771D' }}
                    >
                      Start Chat
                    </Button>
                  </div>
                </div>
              ) : selectedConversation ? (
                <>
                  <div className="p-4 border-b">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold">{selectedConversation.subject}</h3>
                        <Badge className={`text-xs mt-1 ${statusConfig[selectedConversation.status].color}`}>
                          {statusConfig[selectedConversation.status].label}
                        </Badge>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setSelectedConversation(null)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    {messages.map(msg => (
                      <div
                        key={msg.id}
                        className={`flex ${msg.sender_role === 'customer' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[70%] rounded-lg px-4 py-2 ${
                            msg.sender_role === 'customer'
                              ? 'text-white'
                              : 'bg-gray-100 text-gray-900'
                          }`}
                          style={msg.sender_role === 'customer' ? { backgroundColor: '#FF771D' } : {}}
                        >
                          <p className="text-sm">{msg.message}</p>
                          {msg.attachment_url && (() => {
                            try {
                              const files = JSON.parse(msg.attachment_url);
                              return (
                                <div className="mt-2 space-y-1">
                                  {files.map((file, idx) => (
                                    <a
                                      key={idx}
                                      href={file.url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className={`flex items-center gap-2 p-2 rounded text-xs ${
                                        msg.sender_role === 'customer' ? 'bg-white/20 hover:bg-white/30' : 'bg-gray-200 hover:bg-gray-300'
                                      }`}
                                    >
                                      {file.type === 'image' ? <ImageIcon className="w-3 h-3" /> : <FileText className="w-3 h-3" />}
                                      <span className="truncate">{file.name}</span>
                                    </a>
                                  ))}
                                </div>
                              );
                            } catch {
                              return null;
                            }
                          })()}
                          <div className="flex items-center gap-1 mt-1 text-xs opacity-70">
                            <Clock className="w-3 h-3" />
                            {formatDistanceToNow(new Date(msg.created_date), { addSuffix: true })}
                          </div>
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>

                  <div className="p-4 border-t">
                    {attachments.length > 0 && (
                      <div className="mb-2 flex flex-wrap gap-2">
                        {attachments.map((file, idx) => (
                          <div key={idx} className="flex items-center gap-2 bg-gray-100 rounded px-2 py-1 text-xs">
                            {file.type === 'image' ? <ImageIcon className="w-3 h-3" /> : <FileText className="w-3 h-3" />}
                            <span className="truncate max-w-[100px]">{file.name}</span>
                            <button onClick={() => removeAttachment(idx)} className="text-gray-500 hover:text-red-600">
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="flex gap-2">
                      <input
                        ref={fileInputRef}
                        type="file"
                        multiple
                        onChange={handleFileUpload}
                        className="hidden"
                        accept="image/*,.pdf,.doc,.docx"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={uploading}
                      >
                        {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Paperclip className="w-4 h-4" />}
                      </Button>
                      <Textarea
                        placeholder="Type your message..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            if (newMessage.trim() || attachments.length > 0) sendMessage.mutate();
                          }
                        }}
                        className="flex-1 min-h-[60px] max-h-[120px]"
                      />
                      <Button
                        onClick={() => sendMessage.mutate()}
                        disabled={(!newMessage.trim() && attachments.length === 0) || sendMessage.isLoading}
                        className="text-white"
                        style={{ backgroundColor: '#FF771D' }}
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center text-gray-500">
                  Select a conversation or start a new one
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}