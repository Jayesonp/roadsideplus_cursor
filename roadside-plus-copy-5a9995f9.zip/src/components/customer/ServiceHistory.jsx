import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { 
  Calendar, MapPin, User, DollarSign, Clock, 
  Search, Filter, ChevronDown, ChevronUp, Star,
  FileText, Download
} from 'lucide-react';
import { format } from 'date-fns';
import ServiceTypeIcon from '../common/ServiceTypeIcon';
import StatusBadge from '../common/StatusBadge';
import { createPageUrl } from '@/utils';

export default function ServiceHistory({ userId }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [serviceTypeFilter, setServiceTypeFilter] = useState('all');
  const [expandedId, setExpandedId] = useState(null);

  // Fetch all service requests for the customer
  const { data: serviceRequests = [], isLoading } = useQuery({
    queryKey: ['customer-service-history', userId],
    queryFn: async () => {
      const requests = await base44.entities.ServiceRequest.filter(
        { customer_id: userId },
        '-created_date'
      );
      return requests;
    },
    enabled: !!userId
  });

  // Fetch ratings
  const { data: ratings = [] } = useQuery({
    queryKey: ['customer-ratings', userId],
    queryFn: async () => {
      return await base44.entities.Rating.filter(
        { customer_id: userId },
        '-created_date'
      );
    },
    enabled: !!userId
  });

  // Fetch technician profiles for display
  const { data: techProfiles = [] } = useQuery({
    queryKey: ['tech-profiles-for-history'],
    queryFn: async () => {
      return await base44.entities.TechnicianProfile.list();
    }
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2" style={{ borderColor: '#FF771D' }}></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Filter requests
  const filteredRequests = serviceRequests.filter(req => {
    const matchesSearch = searchTerm === '' || 
      req.service_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.location_address?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || req.status === statusFilter;
    const matchesServiceType = serviceTypeFilter === 'all' || req.service_type === serviceTypeFilter;
    
    return matchesSearch && matchesStatus && matchesServiceType;
  });

  const getTechProfile = (techId) => {
    return techProfiles.find(t => t.user_id === techId);
  };

  const getRatingForRequest = (requestId) => {
    return ratings.find(r => r.service_request_id === requestId);
  };

  const toggleExpand = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  // Calculate stats
  const stats = {
    total: serviceRequests.length,
    completed: serviceRequests.filter(r => r.status === 'completed').length,
    totalSpent: serviceRequests
      .filter(r => r.status === 'completed' && r.payment_amount)
      .reduce((sum, r) => sum + r.payment_amount, 0)
  };

  const exportHistory = () => {
    const csvContent = [
      ['Date', 'Service Type', 'Status', 'Location', 'Technician', 'Price', 'Rating'].join(','),
      ...filteredRequests.map(req => {
        const tech = getTechProfile(req.technician_id);
        const rating = getRatingForRequest(req.id);
        return [
          format(new Date(req.created_date), 'yyyy-MM-dd'),
          req.service_type.replace(/_/g, ' '),
          req.status,
          req.location_address || 'N/A',
          tech ? `Tech ${tech.user_id.substring(0, 8)}` : 'N/A',
          req.price ? `$${req.price}` : 'N/A',
          rating ? rating.rating : 'N/A'
        ].join(',');
      })
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `service-history-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
  };

  return (
    <div className="space-y-6">
      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Services</p>
                <p className="text-2xl font-bold mt-1">{stats.total}</p>
              </div>
              <FileText className="w-8 h-8" style={{ color: '#FF771D' }} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Completed</p>
                <p className="text-2xl font-bold mt-1">{stats.completed}</p>
              </div>
              <Clock className="w-8 h-8" style={{ color: '#3D692B' }} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Spent</p>
                <p className="text-2xl font-bold mt-1">${stats.totalSpent.toFixed(2)}</p>
              </div>
              <DollarSign className="w-8 h-8" style={{ color: '#3D692B' }} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search by service type, location, or description..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button 
                onClick={exportHistory}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Export
              </Button>
            </div>

            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="awaiting_review">Awaiting Review</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex-1">
                <Select value={serviceTypeFilter} onValueChange={setServiceTypeFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filter by service type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Service Types</SelectItem>
                    <SelectItem value="tire_change">Tire Change</SelectItem>
                    <SelectItem value="battery_jump">Battery Jump</SelectItem>
                    <SelectItem value="fuel_delivery">Fuel Delivery</SelectItem>
                    <SelectItem value="lockout">Lockout</SelectItem>
                    <SelectItem value="towing">Towing</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Service History List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" style={{ color: '#FF771D' }} />
            Service History ({filteredRequests.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredRequests.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-gray-500">No service requests found</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredRequests.map((request) => {
                const tech = getTechProfile(request.technician_id);
                const rating = getRatingForRequest(request.id);
                const isExpanded = expandedId === request.id;

                return (
                  <Card key={request.id} className="border hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div 
                        className="flex items-start justify-between cursor-pointer"
                        onClick={() => toggleExpand(request.id)}
                      >
                        <div className="flex items-start gap-3 flex-1">
                          <ServiceTypeIcon type={request.service_type} className="w-6 h-6 mt-1" />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h4 className="font-semibold">
                                {request.service_type.replace(/_/g, ' ').toUpperCase()}
                              </h4>
                              <StatusBadge status={request.status} />
                            </div>
                            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                              <div className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                {format(new Date(request.created_date), 'MMM d, yyyy')}
                              </div>
                              {request.price && (
                                <div className="flex items-center gap-1 font-semibold" style={{ color: '#3D692B' }}>
                                  <DollarSign className="w-4 h-4" />
                                  ${request.price.toFixed(2)}
                                </div>
                              )}
                              {rating && (
                                <div className="flex items-center gap-1" style={{ color: '#FF771D' }}>
                                  <Star className="w-4 h-4 fill-current" />
                                  {rating.rating}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </Button>
                      </div>

                      {isExpanded && (
                        <div className="mt-4 pt-4 border-t space-y-3">
                          {request.location_address && (
                            <div className="flex items-start gap-2 text-sm">
                              <MapPin className="w-4 h-4 mt-0.5" style={{ color: '#FF771D' }} />
                              <span className="text-gray-700">{request.location_address}</span>
                            </div>
                          )}

                          {tech && (
                            <div className="flex items-center gap-2 text-sm">
                              <User className="w-4 h-4" style={{ color: '#FF771D' }} />
                              <span className="text-gray-700">
                                Technician: {tech.user_id.substring(0, 12)}...
                                {tech.rating && (
                                  <span className="ml-2 text-yellow-600">
                                    ⭐ {tech.rating.toFixed(1)}
                                  </span>
                                )}
                              </span>
                            </div>
                          )}

                          {request.description && (
                            <div className="text-sm">
                              <p className="text-gray-500 mb-1">Description:</p>
                              <p className="text-gray-700">{request.description}</p>
                            </div>
                          )}

                          {request.vehicle_make && (
                            <div className="text-sm">
                              <p className="text-gray-500 mb-1">Vehicle:</p>
                              <p className="text-gray-700">
                                {request.vehicle_year} {request.vehicle_make} {request.vehicle_model}
                                {request.vehicle_color && ` (${request.vehicle_color})`}
                              </p>
                            </div>
                          )}

                          {request.completed_at && (
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <Clock className="w-4 h-4" />
                              Completed: {format(new Date(request.completed_at), 'MMM d, yyyy h:mm a')}
                            </div>
                          )}

                          {rating?.comment && (
                            <div className="p-3 bg-gray-50 rounded-lg">
                              <p className="text-sm text-gray-500 mb-1">Your Review:</p>
                              <p className="text-sm text-gray-700">"{rating.comment}"</p>
                            </div>
                          )}

                          <div className="flex gap-2 pt-2">
                            <Button
                              size="sm"
                              variant="outline"
                              asChild
                            >
                              <a href={createPageUrl(`ServiceDetails?id=${request.id}`)}>
                                View Details
                              </a>
                            </Button>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}