import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Heart, Star, Wrench, Phone, Mail, Trash2 } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function PreferredTechniciansList({ customerId }) {
  const queryClient = useQueryClient();

  const { data: preferredTechs = [], isLoading } = useQuery({
    queryKey: ['preferred-technicians', customerId],
    queryFn: async () => {
      return await base44.entities.PreferredTechnician.filter(
        { customer_id: customerId },
        '-created_date'
      );
    },
    enabled: !!customerId
  });

  const { data: techUsers = [] } = useQuery({
    queryKey: ['tech-users', preferredTechs.map(p => p.technician_id)],
    queryFn: async () => {
      if (preferredTechs.length === 0) return [];
      const users = await Promise.all(
        preferredTechs.map(async (pref) => {
          const userList = await base44.entities.User.filter({ id: pref.technician_id });
          return userList[0];
        })
      );
      return users.filter(Boolean);
    },
    enabled: preferredTechs.length > 0
  });

  const { data: techProfiles = [] } = useQuery({
    queryKey: ['tech-profiles', preferredTechs.map(p => p.technician_id)],
    queryFn: async () => {
      if (preferredTechs.length === 0) return [];
      const profiles = await Promise.all(
        preferredTechs.map(async (pref) => {
          const profileList = await base44.entities.TechnicianProfile.filter({ user_id: pref.technician_id });
          return profileList[0];
        })
      );
      return profiles.filter(Boolean);
    },
    enabled: preferredTechs.length > 0
  });

  const removePreferred = useMutation({
    mutationFn: async (preferredId) => {
      await base44.entities.PreferredTechnician.delete(preferredId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['preferred-technicians', customerId]);
    }
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2" style={{ borderColor: '#FF771D' }}></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (preferredTechs.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5" style={{ color: '#FF771D' }} />
            Preferred Technicians
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <Heart className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <p className="text-gray-500 mb-2">No preferred technicians yet</p>
            <p className="text-sm text-gray-400">
              Save your favorite technicians for quick access next time
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getTechUser = (techId) => techUsers.find(u => u?.id === techId);
  const getTechProfile = (techId) => techProfiles.find(p => p?.user_id === techId);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Heart className="w-5 h-5" style={{ color: '#FF771D' }} />
          Preferred Technicians ({preferredTechs.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {preferredTechs.map((pref) => {
            const user = getTechUser(pref.technician_id);
            const profile = getTechProfile(pref.technician_id);
            
            if (!user || !profile) return null;

            return (
              <Card key={pref.id} className="border-2" style={{ borderColor: '#FF771D' }}>
                <CardContent className="pt-4">
                  <div className="flex items-start gap-4">
                    <Avatar className="w-14 h-14">
                      <AvatarFallback style={{ backgroundColor: '#FF771D' }} className="text-white">
                        {user.full_name?.charAt(0) || 'T'}
                      </AvatarFallback>
                    </Avatar>

                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-bold text-lg">{user.full_name}</h4>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                              <span className="font-semibold">{profile.rating?.toFixed(1) || '5.0'}</span>
                            </div>
                            <span className="text-sm text-gray-500">
                              {profile.total_jobs || 0} jobs
                            </span>
                          </div>
                        </div>

                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Remove Preferred Technician?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to remove {user.full_name} from your preferred technicians list?
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => removePreferred.mutate(pref.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Remove
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>

                      {pref.notes && (
                        <div className="mt-2 p-2 bg-orange-50 rounded text-sm">
                          <p className="text-xs text-gray-600 mb-1">Your notes:</p>
                          <p className="text-gray-700">"{pref.notes}"</p>
                        </div>
                      )}

                      {profile.skills && profile.skills.length > 0 && (
                        <div className="mt-3">
                          <div className="flex flex-wrap gap-1">
                            {profile.skills.slice(0, 3).map((skill) => (
                              <Badge key={skill} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                            {profile.skills.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{profile.skills.length - 3}
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}

                      <div className="mt-3 flex gap-2">
                        {profile.phone && (
                          <Button
                            size="sm"
                            variant="outline"
                            asChild
                          >
                            <a href={`tel:${profile.phone}`}>
                              <Phone className="w-3 h-3 mr-1" />
                              Call
                            </a>
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          asChild
                        >
                          <a href={`mailto:${user.email}`}>
                            <Mail className="w-3 h-3 mr-1" />
                            Email
                          </a>
                        </Button>
                      </div>

                      {pref.times_used > 0 && (
                        <p className="text-xs text-gray-500 mt-2">
                          Used {pref.times_used} time{pref.times_used > 1 ? 's' : ''}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}