import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { History, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import ServiceTypeIcon from '../common/ServiceTypeIcon';
import StatusBadge from '../common/StatusBadge';

export default function VehicleServiceHistory({ vehicleId, vehicleInfo }) {
  const { data: requests = [] } = useQuery({
    queryKey: ['vehicle-history', vehicleId],
    queryFn: async () => {
      // Find requests matching this vehicle's details
      const allRequests = await base44.entities.ServiceRequest.filter(
        { customer_id: vehicleInfo.customer_id },
        '-created_date',
        100
      );
      
      // Match by make, model, year (since old requests might not have vehicle_id)
      return allRequests.filter(r => 
        r.vehicle_make === vehicleInfo.make &&
        r.vehicle_model === vehicleInfo.model &&
        (r.vehicle_year === vehicleInfo.year || !r.vehicle_year)
      );
    },
    enabled: !!vehicleInfo
  });

  if (requests.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-gray-500">
          <History className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No service history for this vehicle</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <History className="w-5 h-5" />
          Service History ({requests.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {requests.map(request => (
            <div key={request.id} className="border-l-4 border-orange-300 pl-4 py-2">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <ServiceTypeIcon type={request.service_type} className="w-4 h-4" />
                  <span className="font-medium">
                    {request.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </span>
                </div>
                <StatusBadge status={request.status} showIcon={false} />
              </div>
              <div className="text-sm text-gray-600 space-y-1">
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {format(new Date(request.created_date), 'MMM d, yyyy')}
                </div>
                {request.description && (
                  <p className="text-xs">{request.description}</p>
                )}
                {request.price && (
                  <p className="font-semibold text-gray-900">${request.price}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}