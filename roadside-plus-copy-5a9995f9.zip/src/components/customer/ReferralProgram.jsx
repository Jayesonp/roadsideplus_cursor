import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Gift, Copy, Share2, Users, DollarSign, 
  CheckCircle, Clock, TrendingUp, Sparkles 
} from 'lucide-react';
import { toast } from 'sonner';

export default function ReferralProgram({ userId }) {
  const [copied, setCopied] = useState(false);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['user', userId],
    queryFn: async () => {
      const users = await base44.entities.User.filter({ id: userId });
      return users[0];
    },
    enabled: !!userId
  });

  const { data: referrals = [] } = useQuery({
    queryKey: ['my-referrals', userId],
    queryFn: async () => {
      return await base44.entities.CustomerReferral.filter(
        { referrer_id: userId },
        '-created_date'
      );
    },
    enabled: !!userId
  });

  const { data: activeReward } = useQuery({
    queryKey: ['active-referral-reward'],
    queryFn: async () => {
      const rewards = await base44.entities.ReferralReward.filter(
        { is_active: true },
        '-created_date',
        1
      );
      return rewards[0];
    }
  });

  const generateReferralCode = useMutation({
    mutationFn: async () => {
      const code = `${user.full_name.replace(/\s+/g, '').toUpperCase().substring(0, 6)}${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      await base44.auth.updateMe({ referral_code: code });
      return code;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['user', userId]);
      toast.success('Referral code generated!');
    }
  });

  const referralCode = user?.referral_code;
  const referralUrl = referralCode ? `${window.location.origin}?ref=${referralCode}` : '';

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success('Copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const shareReferral = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join ROADSIDE+ with my referral code!',
          text: `Get ${activeReward?.referred_reward_value ? `$${activeReward.referred_reward_value} off` : 'a discount'} your first service with ROADSIDE+. Use my referral code: ${referralCode}`,
          url: referralUrl
        });
      } catch (error) {
        console.log('Share cancelled');
      }
    } else {
      copyToClipboard(referralUrl);
    }
  };

  const stats = {
    total: referrals.length,
    completed: referrals.filter(r => r.status === 'completed').length,
    rewarded: referrals.filter(r => r.reward_issued).length,
    totalEarned: referrals
      .filter(r => r.reward_issued)
      .reduce((sum, r) => sum + (r.reward_amount || 0), 0)
  };

  return (
    <div className="space-y-6">
      {/* Referral Program Header */}
      <Card className="border-2" style={{ borderColor: '#FF771D' }}>
        <CardContent className="pt-6">
          <div className="text-center">
            <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center"
                 style={{ backgroundColor: '#FF771D' }}>
              <Gift className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Refer Friends, Earn Rewards!</h2>
            <p className="text-gray-600 mb-4">
              {activeReward ? (
                <>
                  Give ${activeReward.referred_reward_value} off, get ${activeReward.referrer_reward_value} credit
                  {activeReward.description && (
                    <span className="block text-sm mt-1">{activeReward.description}</span>
                  )}
                </>
              ) : (
                'Share your referral code and earn rewards when friends sign up'
              )}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Referral Code Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" style={{ color: '#FF771D' }} />
            Your Referral Code
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!referralCode ? (
            <div className="text-center py-6">
              <p className="text-gray-600 mb-4">Generate your unique referral code to start earning</p>
              <Button
                onClick={() => generateReferralCode.mutate()}
                disabled={generateReferralCode.isLoading}
                style={{ backgroundColor: '#FF771D' }}
                className="text-white"
              >
                {generateReferralCode.isLoading ? 'Generating...' : 'Generate Referral Code'}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex gap-2">
                <Input
                  value={referralCode}
                  readOnly
                  className="text-lg font-bold text-center"
                  style={{ color: '#FF771D' }}
                />
                <Button
                  onClick={() => copyToClipboard(referralCode)}
                  variant="outline"
                >
                  {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>

              <div className="flex gap-2">
                <Input
                  value={referralUrl}
                  readOnly
                  className="text-sm"
                />
                <Button
                  onClick={() => copyToClipboard(referralUrl)}
                  variant="outline"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>

              <Button
                onClick={shareReferral}
                className="w-full text-white"
                style={{ backgroundColor: '#3D692B' }}
              >
                <Share2 className="w-4 h-4 mr-2" />
                Share Your Code
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Stats */}
      {referralCode && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6 text-center">
              <Users className="w-8 h-8 mx-auto mb-2" style={{ color: '#FF771D' }} />
              <p className="text-2xl font-bold">{stats.total}</p>
              <p className="text-sm text-gray-600">Total Referrals</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6 text-center">
              <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <p className="text-2xl font-bold">{stats.completed}</p>
              <p className="text-sm text-gray-600">Completed</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6 text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <p className="text-2xl font-bold">{stats.rewarded}</p>
              <p className="text-sm text-gray-600">Rewarded</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6 text-center">
              <DollarSign className="w-8 h-8 mx-auto mb-2" style={{ color: '#3D692B' }} />
              <p className="text-2xl font-bold">${stats.totalEarned.toFixed(2)}</p>
              <p className="text-sm text-gray-600">Total Earned</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Referral History */}
      {referrals.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Referral History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {referrals.map((referral) => (
                <div key={referral.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center"
                         style={{ backgroundColor: referral.reward_issued ? '#3D692B' : '#e5e7eb' }}>
                      {referral.reward_issued ? (
                        <CheckCircle className="w-5 h-5 text-white" />
                      ) : (
                        <Clock className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                    <div>
                      <p className="font-semibold">Referral #{referral.id.substring(0, 8)}</p>
                      <p className="text-sm text-gray-600">
                        {new Date(referral.created_date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge
                      variant={referral.status === 'completed' ? 'default' : 'secondary'}
                      style={referral.status === 'completed' ? { backgroundColor: '#3D692B' } : {}}
                    >
                      {referral.status}
                    </Badge>
                    {referral.reward_issued && (
                      <p className="text-sm font-bold mt-1" style={{ color: '#3D692B' }}>
                        +${referral.reward_amount?.toFixed(2)}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* How It Works */}
      {activeReward && (
        <Card className="bg-gradient-to-br from-blue-50 to-purple-50">
          <CardHeader>
            <CardTitle>How It Works</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                     style={{ backgroundColor: '#FF771D' }}>
                  <span className="text-white font-bold">1</span>
                </div>
                <div>
                  <p className="font-semibold">Share Your Code</p>
                  <p className="text-sm text-gray-600">
                    Send your referral code to friends and family
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                     style={{ backgroundColor: '#E52C2D' }}>
                  <span className="text-white font-bold">2</span>
                </div>
                <div>
                  <p className="font-semibold">They Sign Up</p>
                  <p className="text-sm text-gray-600">
                    Your friend signs up using your code and gets ${activeReward.referred_reward_value} off
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                     style={{ backgroundColor: '#3D692B' }}>
                  <span className="text-white font-bold">3</span>
                </div>
                <div>
                  <p className="font-semibold">You Get Rewarded</p>
                  <p className="text-sm text-gray-600">
                    Once they complete their first service, you get ${activeReward.referrer_reward_value} credit
                  </p>
                </div>
              </div>
            </div>

            {activeReward.terms && (
              <div className="mt-4 pt-4 border-t">
                <p className="text-xs text-gray-600">{activeReward.terms}</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}