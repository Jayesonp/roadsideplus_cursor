import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Star, DollarSign, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function RateAndTipScreen({ request, onComplete }) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState('');
  const [tipAmount, setTipAmount] = useState('');
  const [customTip, setCustomTip] = useState('');
  const queryClient = useQueryClient();

  const submitMutation = useMutation({
    mutationFn: async () => {
      // Create rating
      const newRating = await base44.entities.Rating.create({
        service_request_id: request.id,
        technician_id: request.technician_id,
        customer_id: request.customer_id,
        rating: rating,
        comment: comment || ''
      });

      // Update technician's average rating
      const allRatings = await base44.entities.Rating.filter({ 
        technician_id: request.technician_id 
      });
      const avgRating = allRatings.reduce((sum, r) => sum + r.rating, 0) / allRatings.length;
      
      const techProfiles = await base44.entities.TechnicianProfile.filter({ 
        user_id: request.technician_id 
      });
      if (techProfiles[0]) {
        await base44.entities.TechnicianProfile.update(techProfiles[0].id, {
          rating: avgRating,
          total_jobs: (techProfiles[0].total_jobs || 0) + 1
        });
      }

      // Add tip if provided
      const finalTipAmount = parseFloat(customTip || tipAmount || 0);
      if (finalTipAmount > 0) {
        const payments = await base44.entities.Payment.filter({ 
          request_id: request.id 
        });
        if (payments[0]) {
          await base44.entities.Payment.update(payments[0].id, {
            tip_amount: finalTipAmount,
            amount: payments[0].amount + finalTipAmount
          });
        }

        // Log tip event
        await base44.entities.Event.create({
          type: 'TIP_ADDED',
          request_id: request.id,
          customer_id: request.customer_id,
          technician_id: request.technician_id,
          payload: { tip_amount: finalTipAmount }
        });
      }

      // Log rating event
      await base44.entities.Event.create({
        type: 'RATING_SUBMITTED',
        request_id: request.id,
        customer_id: request.customer_id,
        technician_id: request.technician_id,
        payload: { rating, comment, tip: finalTipAmount }
      });

      // Mark service as completed
      await base44.entities.ServiceRequest.update(request.id, {
        status: 'completed',
        completed_at: new Date().toISOString()
      });

      // Log completion event
      await base44.entities.Event.create({
        type: 'JOB_COMPLETED',
        request_id: request.id,
        customer_id: request.customer_id,
        technician_id: request.technician_id,
        payload: { 
          final_rating: rating, 
          tip_amount: finalTipAmount,
          total_paid: request.price + finalTipAmount
        }
      });

      // Notify technician
      await base44.entities.Notification.create({
        user_id: request.technician_id,
        type: 'job_completed',
        title: 'Job Completed',
        message: `Customer rated you ${rating} stars${finalTipAmount > 0 ? ` and added a $${finalTipAmount.toFixed(2)} tip!` : ''}`,
        related_id: request.id
      });

      return newRating;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['service-request']);
      onComplete?.();
    }
  });

  const quickTips = [5, 10, 15, 20];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
    >
      <Card className="w-full max-w-md">
        <CardHeader className="text-center text-white" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
          <CheckCircle className="w-16 h-16 mx-auto mb-2" />
          <CardTitle className="text-2xl">Service Complete!</CardTitle>
          <p className="text-sm opacity-90">How was your experience?</p>
        </CardHeader>

        <CardContent className="p-6 space-y-6">
          {/* Rating */}
          <div>
            <label className="block text-sm font-semibold mb-3 text-center">
              Rate Your Technician
            </label>
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-12 h-12 ${
                      star <= (hoveredRating || rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Comment */}
          <div>
            <label className="block text-sm font-semibold mb-2">
              Leave a Review (Optional)
            </label>
            <Textarea
              placeholder="Share your experience..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="h-20"
            />
          </div>

          {/* Tip */}
          <div>
            <label className="block text-sm font-semibold mb-3 flex items-center gap-2">
              <DollarSign className="w-4 h-4" style={{ color: '#3D692B' }} />
              Add a Tip (Optional)
            </label>
            
            <div className="grid grid-cols-4 gap-2 mb-3">
              {quickTips.map((amount) => (
                <Button
                  key={amount}
                  variant="outline"
                  className={`h-12 ${
                    tipAmount === amount.toString()
                      ? 'border-2 text-white'
                      : ''
                  }`}
                  style={
                    tipAmount === amount.toString()
                      ? { backgroundColor: '#3D692B', borderColor: '#3D692B' }
                      : {}
                  }
                  onClick={() => {
                    setTipAmount(amount.toString());
                    setCustomTip('');
                  }}
                >
                  ${amount}
                </Button>
              ))}
            </div>

            <Input
              type="number"
              placeholder="Custom amount"
              value={customTip}
              onChange={(e) => {
                setCustomTip(e.target.value);
                setTipAmount('');
              }}
              className="text-center"
            />
          </div>

          {/* Submit */}
          <Button
            className="w-full h-12 text-lg font-semibold text-white"
            style={{ backgroundColor: '#FF771D' }}
            onClick={() => submitMutation.mutate()}
            disabled={rating === 0 || submitMutation.isLoading}
          >
            {submitMutation.isLoading ? 'Submitting...' : 'Submit'}
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}