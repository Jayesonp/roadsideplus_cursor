import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Image, FileText, Star, Eye } from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import StatusBadge from '../common/StatusBadge';
import ServiceTypeIcon from '../common/ServiceTypeIcon';

export default function JobHistoryCard({ job, attachments, rating }) {
  const hasDocuments = attachments && attachments.length > 0;

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <ServiceTypeIcon type={job.service_type} />
            <div>
              <CardTitle className="text-base">
                {job.service_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </CardTitle>
              <p className="text-xs text-gray-500">
                {format(new Date(job.created_date), 'MMM d, yyyy h:mm a')}
              </p>
            </div>
          </div>
          <StatusBadge status={job.status} showIcon={false} />
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {job.location_address && (
          <p className="text-sm text-gray-600 line-clamp-1">{job.location_address}</p>
        )}

        {job.price && (
          <p className="text-lg font-bold" style={{ color: '#FF771D' }}>
            ${job.price.toFixed(2)}
          </p>
        )}

        {rating && (
          <div className="flex items-center gap-2 py-2 px-3 bg-yellow-50 rounded-lg">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="font-semibold">{rating.rating}</span>
            <span className="text-xs text-gray-500">
              {rating.comment && `"${rating.comment.substring(0, 50)}..."`}
            </span>
          </div>
        )}

        {hasDocuments && (
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="w-4 h-4 text-gray-600" />
              <span className="text-sm font-semibold">Service Documentation</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {attachments.slice(0, 3).map((att) => (
                <div key={att.id} className="relative aspect-square rounded overflow-hidden border">
                  {att.file_type.includes('photo') ? (
                    <img 
                      src={att.file_url} 
                      alt={att.file_name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gray-100">
                      <FileText className="w-6 h-6 text-gray-400" />
                    </div>
                  )}
                </div>
              ))}
            </div>
            {attachments.length > 3 && (
              <p className="text-xs text-gray-500 mt-2">+{attachments.length - 3} more files</p>
            )}
          </div>
        )}

        <Button
          onClick={() => window.location.href = createPageUrl(`ServiceDetails?id=${job.id}`)}
          variant="outline"
          className="w-full"
        >
          <Eye className="w-4 h-4 mr-2" />
          View Details
        </Button>
      </CardContent>
    </Card>
  );
}