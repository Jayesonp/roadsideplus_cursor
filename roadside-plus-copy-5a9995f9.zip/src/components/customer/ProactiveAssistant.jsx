import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Bell, Clock, Sparkles, Star, X, Send } from 'lucide-react';
import { format } from 'date-fns';

export default function ProactiveAssistant({ userId, activeRequest }) {
  const [updates, setUpdates] = useState([]);
  const [showFollowUp, setShowFollowUp] = useState(false);
  const [followUpMessage, setFollowUpMessage] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [submittingFeedback, setSubmittingFeedback] = useState(false);

  // Fetch recent completed service
  const { data: recentCompleted } = useQuery({
    queryKey: ['recent-completed', userId],
    queryFn: async () => {
      const completed = await base44.entities.ServiceRequest.filter(
        { customer_id: userId, status: 'completed' },
        '-completed_at',
        1
      );
      return completed[0];
    },
    enabled: !!userId
  });

  // Check if follow-up needed - ONLY after service completion
  useEffect(() => {
    if (recentCompleted && !activeRequest && recentCompleted.status === 'completed') {
      const completedTime = new Date(recentCompleted.completed_at);
      const now = new Date();
      const hoursSinceCompletion = (now - completedTime) / (1000 * 60 * 60);
      
      // Show follow-up if completed in last 24 hours and no rating yet
      if (hoursSinceCompletion <= 24 && hoursSinceCompletion >= 0.1) {
        checkForExistingRating();
      }
    }
  }, [recentCompleted, activeRequest]);

  const checkForExistingRating = async () => {
    const ratings = await base44.entities.Rating.filter({
      service_request_id: recentCompleted.id,
      customer_id: userId
    });
    
    if (ratings.length === 0) {
      generateFollowUp();
    }
  };

  const generateFollowUp = async () => {
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a warm, personalized follow-up message for a customer who recently completed a roadside assistance service.

Service Details:
- Service Type: ${recentCompleted.service_type.replace(/_/g, ' ')}
- Vehicle: ${recentCompleted.vehicle_year || ''} ${recentCompleted.vehicle_make || ''} ${recentCompleted.vehicle_model || ''}
- Completed: ${format(new Date(recentCompleted.completed_at), 'MMMM d, yyyy h:mm a')}

The message should:
1. Thank them for using the service
2. Ask how their experience was
3. Provide 2-3 relevant maintenance tips based on the service type
4. Be friendly, concise, and helpful

Keep it under 150 words.`,
        response_json_schema: {
          type: 'object',
          properties: {
            message: {
              type: 'string',
              description: 'The follow-up message'
            },
            maintenance_tips: {
              type: 'array',
              items: { type: 'string' },
              description: 'Maintenance tips'
            }
          }
        }
      });

      setFollowUpMessage(response);
      setShowFollowUp(true);
    } catch (error) {
      console.error('Error generating follow-up:', error);
    }
  };

  // Generate proactive status updates
  useEffect(() => {
    if (activeRequest && activeRequest.status !== 'pending') {
      generateProactiveUpdate();
      
      // Check every 5 minutes for updates
      const interval = setInterval(generateProactiveUpdate, 300000);
      return () => clearInterval(interval);
    }
  }, [activeRequest?.id, activeRequest?.status]);

  const generateProactiveUpdate = async () => {
    if (!activeRequest) return;

    try {
      const statusMessages = {
        assigned: 'Your technician has been assigned and will be contacting you shortly.',
        en_route: 'Your technician is on the way to your location.',
        in_progress: 'The technician has arrived and is working on your vehicle.',
      };

      const baseMessage = statusMessages[activeRequest.status];
      if (!baseMessage) return;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a helpful, personalized status update for a customer's roadside assistance request.

Current Status: ${activeRequest.status}
Service Type: ${activeRequest.service_type.replace(/_/g, ' ')}
Base Message: ${baseMessage}

${activeRequest.estimated_arrival ? `Estimated Arrival: ${format(new Date(activeRequest.estimated_arrival), 'h:mm a')}` : ''}

Enhance the message by:
1. Adding a friendly, reassuring tone
2. Including what they should expect next
3. Adding a helpful tip if relevant (e.g., have keys ready, stay safe distance)
4. Keeping it brief (2-3 sentences)

Also consider current time (${new Date().toLocaleTimeString()}) and suggest if traffic might affect arrival.`,
        response_json_schema: {
          type: 'object',
          properties: {
            message: {
              type: 'string',
              description: 'The enhanced status update'
            },
            eta_note: {
              type: 'string',
              description: 'Note about estimated arrival or delays'
            },
            helpful_tip: {
              type: 'string',
              description: 'A helpful tip for the customer'
            }
          }
        }
      });

      // Check if this is a new unique update
      const isDuplicate = updates.some(u => 
        u.message === response.message || 
        (Date.now() - u.timestamp < 300000) // Less than 5 min ago
      );

      if (!isDuplicate) {
        setUpdates(prev => [{
          ...response,
          status: activeRequest.status,
          timestamp: Date.now()
        }, ...prev].slice(0, 5)); // Keep last 5 updates
      }
    } catch (error) {
      console.error('Error generating update:', error);
    }
  };

  const submitFeedback = async () => {
    setSubmittingFeedback(true);
    try {
      await base44.entities.Message.create({
        service_request_id: recentCompleted.id,
        sender_id: userId,
        sender_role: 'customer',
        message: `Customer Feedback: ${feedback}`
      });

      setShowFollowUp(false);
      setFeedback('');
      alert('Thank you for your feedback!');
    } catch (error) {
      console.error('Error submitting feedback:', error);
      alert('Failed to submit feedback. Please try again.');
    } finally {
      setSubmittingFeedback(false);
    }
  };

  if (!activeRequest && !showFollowUp) return null;

  return (
    <>
      {/* Proactive Updates */}
      {updates.length > 0 && (
        <Card className="mb-6 border-2 border-blue-300 bg-gradient-to-r from-blue-50 to-indigo-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-900">
              <Sparkles className="w-5 h-5 text-blue-600" />
              AI Assistant Updates
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {updates.map((update, idx) => (
              <div key={idx} className="bg-white rounded-lg p-4 border border-blue-200 shadow-sm">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                    <Bell className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-gray-900 text-sm mb-2">{update.message}</p>
                    
                    {update.eta_note && (
                      <div className="flex items-center gap-2 text-xs text-gray-600 mb-1">
                        <Clock className="w-3 h-3" />
                        {update.eta_note}
                      </div>
                    )}
                    
                    {update.helpful_tip && (
                      <div className="bg-amber-50 border border-amber-200 rounded p-2 mt-2">
                        <p className="text-xs text-amber-900">
                          <strong>💡 Tip:</strong> {update.helpful_tip}
                        </p>
                      </div>
                    )}
                    
                    <p className="text-xs text-gray-400 mt-2">
                      {format(new Date(update.timestamp), 'h:mm a')}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Follow-Up Message */}
      {showFollowUp && followUpMessage && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
             style={{ 
               paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)',
               paddingTop: 'calc(env(safe-area-inset-top) + 1rem)'
             }}>
          <Card className="max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5" style={{ color: '#FF771D' }} />
                  How Was Your Experience?
                </CardTitle>
                <button onClick={() => setShowFollowUp(false)}>
                  <X className="w-5 h-5 text-gray-400 hover:text-gray-600" />
                </button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <p className="text-gray-800 text-sm whitespace-pre-line">
                  {followUpMessage.message}
                </p>
              </div>

              {followUpMessage.maintenance_tips?.length > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h4 className="font-semibold text-sm mb-2 text-green-900 flex items-center gap-2">
                    <Star className="w-4 h-4" />
                    Maintenance Tips
                  </h4>
                  <ul className="space-y-1">
                    {followUpMessage.maintenance_tips.map((tip, idx) => (
                      <li key={idx} className="text-sm text-green-800">• {tip}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div>
                <label className="text-sm font-semibold mb-2 block">Share Your Feedback</label>
                <Textarea
                  placeholder="Tell us about your experience..."
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setShowFollowUp(false)}
                >
                  Maybe Later
                </Button>
                <Button
                  className="flex-1 text-white hover:opacity-90"
                  style={{ backgroundColor: '#FF771D' }}
                  onClick={submitFeedback}
                  disabled={!feedback.trim() || submittingFeedback}
                >
                  <Send className="w-4 h-4 mr-2" />
                  {submittingFeedback ? 'Sending...' : 'Send Feedback'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
}