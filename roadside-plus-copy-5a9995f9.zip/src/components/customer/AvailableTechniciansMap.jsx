import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Users, Loader2 } from 'lucide-react';
import TechniciansMap from '../map/TechniciansMap';

export default function AvailableTechniciansMap({ customerLocation = null, showCustomer = false }) {
  const { data: availableTechs = [], isLoading } = useQuery({
    queryKey: ['available-technicians'],
    queryFn: async () => {
      // Get all available technician profiles with 'available' status (live broadcasting)
      const profiles = await base44.entities.TechnicianProfile.filter(
        { availability_status: 'available' },
        '-rating',
        50
      );
      return profiles.filter(p => p.current_lat && p.current_lng);
    },
    refetchInterval: 30000,
    retry: 2,
    retryDelay: 5000,
    staleTime: 25000
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2" style={{ color: '#FF771D' }} />
          <p className="text-gray-600">Loading technicians...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" style={{ color: '#FF771D' }} />
            Available Technicians Nearby
          </CardTitle>
          <Badge className="bg-green-100 text-green-800 border-green-300 flex items-center gap-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-1"></div>
            {availableTechs.length} Live Now
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {availableTechs.length === 0 ? (
          <div className="text-center py-8">
            <MapPin className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p className="text-gray-600">No technicians available right now</p>
            <p className="text-sm text-gray-500 mt-1">Please check back shortly</p>
          </div>
        ) : (
          <TechniciansMap 
            technicians={availableTechs}
            customerLocation={customerLocation}
            showCustomer={showCustomer}
            height="400px"
            zoom={12}
          />
        )}
      </CardContent>
    </Card>
  );
}