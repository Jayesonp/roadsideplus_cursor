import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  CheckCircle, Car, MapPin, Bell, Sparkles, 
  ArrowRight, ArrowLeft, Loader2 
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';

const STEPS = [
  { id: 'welcome', title: 'Welcome', icon: Sparkles },
  { id: 'vehicle', title: 'Add Vehicle', icon: Car },
  { id: 'location', title: 'Location', icon: MapPin },
  { id: 'preferences', title: 'Preferences', icon: Bell },
  { id: 'complete', title: 'Complete', icon: CheckCircle }
];

export default function OnboardingWizard({ user, onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [aiInsights, setAiInsights] = useState(null);
  const queryClient = useQueryClient();

  const [wizardData, setWizardData] = useState({
    // Vehicle info
    vehicleMake: '',
    vehicleModel: '',
    vehicleYear: '',
    vehicleColor: '',
    vehicleLicensePlate: '',
    vehicleNickname: '',
    
    // Location preferences
    homeAddress: '',
    workAddress: '',
    
    // User preferences
    preferredContactMethod: 'phone',
    notificationsEnabled: true,
    emergencyContact: '',
    
    // AI personalization
    drivingHabits: '',
    vehicleAge: '',
    mainConcerns: []
  });

  const saveOnboarding = useMutation({
    mutationFn: async () => {
      // Save vehicle
      if (wizardData.vehicleMake && wizardData.vehicleModel) {
        await base44.entities.Vehicle.create({
          customer_id: user.id,
          make: wizardData.vehicleMake,
          model: wizardData.vehicleModel,
          year: wizardData.vehicleYear,
          color: wizardData.vehicleColor,
          license_plate: wizardData.vehicleLicensePlate,
          nickname: wizardData.vehicleNickname || `My ${wizardData.vehicleMake}`,
          is_default: true
        });
      }

      // Update user preferences
      await base44.auth.updateMe({
        onboarding_completed: true,
        home_address: wizardData.homeAddress,
        work_address: wizardData.workAddress,
        emergency_contact: wizardData.emergencyContact,
        preferred_contact_method: wizardData.preferredContactMethod
      });

      // Save notification preferences
      const existingPrefs = await base44.entities.NotificationPreferences.filter({ user_id: user.id });
      if (existingPrefs.length > 0) {
        await base44.entities.NotificationPreferences.update(existingPrefs[0].id, {
          push_enabled: wizardData.notificationsEnabled,
          new_messages: wizardData.notificationsEnabled,
          job_status_updates: wizardData.notificationsEnabled
        });
      } else {
        await base44.entities.NotificationPreferences.create({
          user_id: user.id,
          push_enabled: wizardData.notificationsEnabled,
          new_messages: wizardData.notificationsEnabled,
          job_status_updates: wizardData.notificationsEnabled
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
      onComplete();
    }
  });

  const getAIPersonalization = async () => {
    if (!wizardData.vehicleMake || !wizardData.vehicleYear) return;

    setLoading(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a roadside assistance expert providing personalized recommendations for a new customer.

CUSTOMER PROFILE:
- Vehicle: ${wizardData.vehicleYear} ${wizardData.vehicleMake} ${wizardData.vehicleModel}
- Driving Habits: ${wizardData.drivingHabits || 'Not specified'}
- Main Concerns: ${wizardData.mainConcerns.join(', ') || 'General roadside assistance'}

Provide personalized insights and recommendations including:
1. Common issues for this vehicle type and age
2. Preventive maintenance tips
3. Which services they're most likely to need
4. Quick tips for this specific vehicle
5. Emergency preparedness recommendations

Be friendly, practical, and specific to their vehicle.`,
        response_json_schema: {
          type: 'object',
          properties: {
            common_issues: {
              type: 'array',
              items: { type: 'string' }
            },
            preventive_tips: {
              type: 'array',
              items: { type: 'string' }
            },
            likely_services: {
              type: 'array',
              items: { type: 'string' }
            },
            quick_tips: {
              type: 'array',
              items: { type: 'string' }
            },
            emergency_kit: {
              type: 'array',
              items: { type: 'string' }
            },
            welcome_message: { type: 'string' }
          }
        }
      });

      setAiInsights(response);
    } catch (error) {
      console.error('AI personalization error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleNext = async () => {
    if (currentStep === 1 && wizardData.vehicleMake && !aiInsights) {
      await getAIPersonalization();
    }
    
    if (currentStep === STEPS.length - 2) {
      await saveOnboarding.mutateAsync();
    }
    
    setCurrentStep(prev => Math.min(prev + 1, STEPS.length - 1));
  };

  const handleBack = () => {
    setCurrentStep(prev => Math.max(prev - 1, 0));
  };

  const renderStepContent = () => {
    switch (STEPS[currentStep].id) {
      case 'welcome':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center"
                   style={{ backgroundColor: '#FF771D' }}>
                <Sparkles className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold mb-3">Welcome to Roadside+</h2>
              <p className="text-lg text-gray-600 mb-6">
                Let's get you set up in just a few minutes
              </p>
            </div>

            <Card className="bg-gradient-to-br from-orange-50 to-red-50">
              <CardContent className="pt-6">
                <h3 className="font-semibold mb-3">What you'll set up:</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Add your vehicle information
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Set your location preferences
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Customize notification settings
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Get personalized AI recommendations
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        );

      case 'vehicle':
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <Car className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
              <h2 className="text-2xl font-bold mb-2">Add Your Vehicle</h2>
              <p className="text-gray-600">This helps us provide faster, better service</p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Make *</Label>
                <Input
                  placeholder="Toyota, Honda, Ford..."
                  value={wizardData.vehicleMake}
                  onChange={(e) => setWizardData({...wizardData, vehicleMake: e.target.value})}
                />
              </div>
              <div>
                <Label>Model *</Label>
                <Input
                  placeholder="Camry, Civic, F-150..."
                  value={wizardData.vehicleModel}
                  onChange={(e) => setWizardData({...wizardData, vehicleModel: e.target.value})}
                />
              </div>
              <div>
                <Label>Year *</Label>
                <Input
                  placeholder="2020"
                  value={wizardData.vehicleYear}
                  onChange={(e) => setWizardData({...wizardData, vehicleYear: e.target.value})}
                />
              </div>
              <div>
                <Label>Color</Label>
                <Input
                  placeholder="Black, White, Red..."
                  value={wizardData.vehicleColor}
                  onChange={(e) => setWizardData({...wizardData, vehicleColor: e.target.value})}
                />
              </div>
              <div>
                <Label>License Plate</Label>
                <Input
                  placeholder="ABC-1234"
                  value={wizardData.vehicleLicensePlate}
                  onChange={(e) => setWizardData({...wizardData, vehicleLicensePlate: e.target.value})}
                />
              </div>
              <div>
                <Label>Nickname (Optional)</Label>
                <Input
                  placeholder="My Car, Work Truck..."
                  value={wizardData.vehicleNickname}
                  onChange={(e) => setWizardData({...wizardData, vehicleNickname: e.target.value})}
                />
              </div>
            </div>

            <div>
              <Label>Tell us about your driving habits (helps AI personalize)</Label>
              <Textarea
                placeholder="I mostly drive in the city, long highway commutes, weekend trips..."
                value={wizardData.drivingHabits}
                onChange={(e) => setWizardData({...wizardData, drivingHabits: e.target.value})}
                className="h-20"
              />
            </div>
          </div>
        );

      case 'location':
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <MapPin className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
              <h2 className="text-2xl font-bold mb-2">Common Locations</h2>
              <p className="text-gray-600">Save time by storing frequent addresses</p>
            </div>

            <div>
              <Label>Home Address (Optional)</Label>
              <Input
                placeholder="123 Main St, City, State"
                value={wizardData.homeAddress}
                onChange={(e) => setWizardData({...wizardData, homeAddress: e.target.value})}
              />
              <p className="text-xs text-gray-500 mt-1">Quick access for service requests</p>
            </div>

            <div>
              <Label>Work Address (Optional)</Label>
              <Input
                placeholder="456 Business Blvd, City, State"
                value={wizardData.workAddress}
                onChange={(e) => setWizardData({...wizardData, workAddress: e.target.value})}
              />
              <p className="text-xs text-gray-500 mt-1">For work-related breakdowns</p>
            </div>

            <div>
              <Label>Emergency Contact (Optional)</Label>
              <Input
                placeholder="Phone number or name"
                value={wizardData.emergencyContact}
                onChange={(e) => setWizardData({...wizardData, emergencyContact: e.target.value})}
              />
              <p className="text-xs text-gray-500 mt-1">Someone to notify in emergencies</p>
            </div>
          </div>
        );

      case 'preferences':
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <Bell className="w-12 h-12 mx-auto mb-3" style={{ color: '#FF771D' }} />
              <h2 className="text-2xl font-bold mb-2">Notification Preferences</h2>
              <p className="text-gray-600">Stay updated on your service requests</p>
            </div>

            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <Label className="text-base font-semibold">Enable Notifications</Label>
                <p className="text-sm text-gray-600">Get updates on technician status</p>
              </div>
              <Switch
                checked={wizardData.notificationsEnabled}
                onCheckedChange={(checked) => setWizardData({...wizardData, notificationsEnabled: checked})}
              />
            </div>

            <div>
              <Label>Preferred Contact Method</Label>
              <Select
                value={wizardData.preferredContactMethod}
                onValueChange={(value) => setWizardData({...wizardData, preferredContactMethod: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="phone">Phone Call</SelectItem>
                  <SelectItem value="sms">Text Message</SelectItem>
                  <SelectItem value="app">In-App Only</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {aiInsights && (
              <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-2" style={{ borderColor: '#FF771D' }}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5" style={{ color: '#FF771D' }} />
                    AI Recommendations for You
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-sm mb-2">Welcome Message:</h4>
                    <p className="text-sm text-gray-700">{aiInsights.welcome_message}</p>
                  </div>
                  
                  {aiInsights.likely_services && (
                    <div>
                      <h4 className="font-semibold text-sm mb-2">Services You May Need:</h4>
                      <ul className="text-sm space-y-1">
                        {aiInsights.likely_services.slice(0, 3).map((service, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span style={{ color: '#FF771D' }}>•</span>
                            {service}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {aiInsights.quick_tips && (
                    <div>
                      <h4 className="font-semibold text-sm mb-2">Quick Tips:</h4>
                      <ul className="text-sm space-y-1">
                        {aiInsights.quick_tips.slice(0, 2).map((tip, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span>💡</span>
                            {tip}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        );

      case 'complete':
        return (
          <div className="text-center space-y-6">
            <div className="w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center bg-green-100">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-3xl font-bold mb-3">You're All Set!</h2>
            <p className="text-lg text-gray-600 mb-6">
              Your account is ready. Here's what you can do now:
            </p>

            <div className="grid md:grid-cols-2 gap-4 text-left">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-2">🚗 Request Service</h3>
                  <p className="text-sm text-gray-600">
                    Get roadside assistance in minutes with our network of technicians
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-2">📍 Track in Real-Time</h3>
                  <p className="text-sm text-gray-600">
                    See your technician's location and get live ETA updates
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-2">💬 Chat Support</h3>
                  <p className="text-sm text-gray-600">
                    Message your technician or our support team anytime
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-2">⭐ Rate & Review</h3>
                  <p className="text-sm text-gray-600">
                    Help improve service quality with your feedback
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const canProceed = () => {
    switch (STEPS[currentStep].id) {
      case 'welcome':
        return true;
      case 'vehicle':
        return wizardData.vehicleMake && wizardData.vehicleModel && wizardData.vehicleYear;
      case 'location':
        return true;
      case 'preferences':
        return true;
      case 'complete':
        return true;
      default:
        return false;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center overflow-y-auto"
         style={{
           paddingTop: 'calc(env(safe-area-inset-top) + 1rem)',
           paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)',
           paddingLeft: 'calc(env(safe-area-inset-left) + 1rem)',
           paddingRight: 'calc(env(safe-area-inset-right) + 1rem)'
         }}>
      <Card className="max-w-3xl w-full mx-auto my-8 shadow-2xl">
        <CardHeader>
          <div className="flex items-center justify-between mb-4">
            {STEPS.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 transition-colors ${
                  index < currentStep ? 'bg-green-500 border-green-500 text-white' :
                  index === currentStep ? 'border-orange-500 text-orange-500' :
                  'border-gray-300 text-gray-400'
                }`}>
                  {index < currentStep ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    React.createElement(step.icon, { className: 'w-5 h-5' })
                  )}
                </div>
                {index < STEPS.length - 1 && (
                  <div className={`hidden md:block w-12 h-1 mx-2 ${
                    index < currentStep ? 'bg-green-500' : 'bg-gray-300'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-500">
              Step {currentStep + 1} of {STEPS.length}
            </p>
          </div>
        </CardHeader>

        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#FF771D' }} />
              <span className="ml-3">Getting personalized insights...</span>
            </div>
          ) : (
            renderStepContent()
          )}

          <div className="flex justify-between mt-8 pt-6 border-t gap-3"
               style={{
                 paddingBottom: 'calc(env(safe-area-inset-bottom) + 0.5rem)'
               }}>
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentStep === 0 || loading}
              className="min-w-[100px]"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>

            <Button
              onClick={handleNext}
              disabled={!canProceed() || loading || saveOnboarding.isLoading}
              className="text-white min-w-[120px]"
              style={{ backgroundColor: '#FF771D' }}
            >
              {saveOnboarding.isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : currentStep === STEPS.length - 1 ? (
                'Get Started'
              ) : (
                <>
                  Next
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}