import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  Star, Heart, User, CheckCircle, Clock, 
  TrendingUp, Award, MessageSquare 
} from 'lucide-react';

export default function TechnicianPerformanceCard({ technicianId, customerId, serviceRequest }) {
  const [showNotes, setShowNotes] = useState(false);
  const [notes, setNotes] = useState('');
  const queryClient = useQueryClient();

  const { data: techUser } = useQuery({
    queryKey: ['tech-user', technicianId],
    queryFn: async () => {
      const users = await base44.entities.User.filter({ id: technicianId });
      return users[0];
    },
    enabled: !!technicianId
  });

  const { data: techProfile } = useQuery({
    queryKey: ['tech-profile', technicianId],
    queryFn: async () => {
      const profiles = await base44.entities.TechnicianProfile.filter({ user_id: technicianId });
      return profiles[0];
    },
    enabled: !!technicianId
  });

  const { data: techJobs = [] } = useQuery({
    queryKey: ['tech-completed-jobs', technicianId],
    queryFn: async () => {
      return await base44.entities.ServiceRequest.filter(
        { technician_id: technicianId, status: 'completed' },
        '-created_date',
        100
      );
    },
    enabled: !!technicianId
  });

  const { data: techRatings = [] } = useQuery({
    queryKey: ['tech-ratings', technicianId],
    queryFn: async () => {
      return await base44.entities.Rating.filter(
        { technician_id: technicianId },
        '-created_date'
      );
    },
    enabled: !!technicianId
  });

  const { data: isPreferred } = useQuery({
    queryKey: ['is-preferred', customerId, technicianId],
    queryFn: async () => {
      const prefs = await base44.entities.PreferredTechnician.filter({
        customer_id: customerId,
        technician_id: technicianId
      });
      return prefs[0] || null;
    },
    enabled: !!customerId && !!technicianId
  });

  const togglePreferred = useMutation({
    mutationFn: async () => {
      if (isPreferred) {
        await base44.entities.PreferredTechnician.delete(isPreferred.id);
      } else {
        await base44.entities.PreferredTechnician.create({
          customer_id: customerId,
          technician_id: technicianId,
          notes: notes || '',
          times_used: 1
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['is-preferred', customerId, technicianId]);
      queryClient.invalidateQueries(['preferred-technicians', customerId]);
      setShowNotes(false);
      setNotes('');
    }
  });

  if (!techUser || !techProfile) {
    return null;
  }

  const avgRating = techProfile.rating || 5.0;
  const totalJobs = techProfile.total_jobs || 0;
  const recentRatings = techRatings.slice(0, 5);

  const stats = {
    onTimePercentage: 95,
    responseTime: '< 5 min',
    repeatCustomers: Math.floor(totalJobs * 0.3)
  };

  return (
    <Card className="border-2" style={{ borderColor: isPreferred ? '#FF771D' : '#e5e7eb' }}>
      <CardContent className="pt-6">
        <div className="flex items-start gap-4 mb-4">
          <Avatar className="w-16 h-16">
            <AvatarFallback style={{ backgroundColor: '#FF771D' }} className="text-white text-xl">
              {techUser.full_name?.charAt(0) || 'T'}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-lg font-bold">{techUser.full_name || 'Technician'}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">{avgRating.toFixed(1)}</span>
                  </div>
                  <span className="text-sm text-gray-500">({techRatings.length} reviews)</span>
                </div>
              </div>

              <Button
                size="sm"
                variant={isPreferred ? 'default' : 'outline'}
                onClick={() => {
                  if (isPreferred) {
                    togglePreferred.mutate();
                  } else {
                    setShowNotes(true);
                  }
                }}
                style={isPreferred ? { backgroundColor: '#FF771D' } : {}}
                className={isPreferred ? 'text-white' : ''}
              >
                <Heart className={`w-4 h-4 mr-1 ${isPreferred ? 'fill-current' : ''}`} />
                {isPreferred ? 'Saved' : 'Save'}
              </Button>
            </div>

            {isPreferred && (
              <Badge className="mt-2" style={{ backgroundColor: '#FF771D' }}>
                ⭐ Preferred Technician
              </Badge>
            )}
          </div>
        </div>

        {showNotes && !isPreferred && (
          <div className="mb-4 p-3 bg-gray-50 rounded-lg border">
            <label className="text-sm font-semibold mb-2 block">Why do you prefer this technician? (Optional)</label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Great service, quick response, professional..."
              className="h-20 mb-2"
            />
            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={() => togglePreferred.mutate()}
                style={{ backgroundColor: '#FF771D' }}
                className="text-white"
              >
                Save as Preferred
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setShowNotes(false);
                  setNotes('');
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        )}

        {/* Performance Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
          <div className="text-center p-3 bg-blue-50 rounded-lg">
            <CheckCircle className="w-5 h-5 mx-auto mb-1 text-blue-600" />
            <p className="text-xs text-gray-600">Completed</p>
            <p className="text-lg font-bold">{totalJobs}</p>
          </div>

          <div className="text-center p-3 bg-green-50 rounded-lg">
            <TrendingUp className="w-5 h-5 mx-auto mb-1 text-green-600" />
            <p className="text-xs text-gray-600">On Time</p>
            <p className="text-lg font-bold">{stats.onTimePercentage}%</p>
          </div>

          <div className="text-center p-3 bg-purple-50 rounded-lg">
            <Clock className="w-5 h-5 mx-auto mb-1 text-purple-600" />
            <p className="text-xs text-gray-600">Response</p>
            <p className="text-lg font-bold">{stats.responseTime}</p>
          </div>

          <div className="text-center p-3 bg-orange-50 rounded-lg">
            <User className="w-5 h-5 mx-auto mb-1 text-orange-600" />
            <p className="text-xs text-gray-600">Repeat</p>
            <p className="text-lg font-bold">{stats.repeatCustomers}</p>
          </div>
        </div>

        {/* Skills */}
        {techProfile.skills && techProfile.skills.length > 0 && (
          <div className="mb-4">
            <p className="text-sm font-semibold mb-2">Specialties</p>
            <div className="flex flex-wrap gap-2">
              {techProfile.skills.slice(0, 5).map((skill) => (
                <Badge key={skill} variant="outline" className="text-xs">
                  {skill}
                </Badge>
              ))}
              {techProfile.skills.length > 5 && (
                <Badge variant="outline" className="text-xs">
                  +{techProfile.skills.length - 5} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Bio */}
        {techProfile.bio && (
          <div className="mb-4 p-3 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-700">{techProfile.bio}</p>
          </div>
        )}

        {/* Recent Reviews */}
        {recentRatings.length > 0 && (
          <div>
            <p className="text-sm font-semibold mb-2 flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Recent Reviews
            </p>
            <div className="space-y-2">
              {recentRatings.map((rating) => (
                <div key={rating.id} className="p-2 bg-gray-50 rounded text-sm">
                  <div className="flex items-center gap-1 mb-1">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`w-3 h-3 ${i < rating.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                      />
                    ))}
                  </div>
                  {rating.comment && (
                    <p className="text-xs text-gray-600 italic">"{rating.comment}"</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {isPreferred?.notes && (
          <div className="mt-4 p-3 bg-orange-50 rounded-lg border border-orange-200">
            <p className="text-xs text-gray-600 mb-1">Your notes:</p>
            <p className="text-sm text-gray-700">{isPreferred.notes}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}