import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, Clock, Navigation, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import ServiceMap from '../map/ServiceMap';
import StatusBadge from '../common/StatusBadge';
import ServiceTypeIcon from '../common/ServiceTypeIcon';
import { createPageUrl } from '@/utils';

export default function TrackJobCard({ request }) {
  // Fetch technician's real-time location - poll every 5 seconds for active jobs
  const { data: technicianLocation } = useQuery({
    queryKey: ['technician-location', request.technician_id],
    queryFn: async () => {
      if (!request.technician_id) return null;
      const locations = await base44.entities.TechnicianLocation.filter(
        { technician_id: request.technician_id },
        '-created_date',
        1
      );
      return locations[0] || null;
    },
    enabled: !!request.technician_id && ['assigned', 'en_route', 'in_progress'].includes(request.status),
    refetchInterval: 5000,
    retry: 2,
    retryDelay: 2000,
    staleTime: 3000
  });

  // Fetch technician profile for details
  const { data: technicianProfile } = useQuery({
    queryKey: ['technician-profile', request.technician_id],
    queryFn: async () => {
      if (!request.technician_id) return null;
      const profiles = await base44.entities.TechnicianProfile.filter(
        { user_id: request.technician_id }
      );
      return profiles[0] || null;
    },
    enabled: !!request.technician_id
  });

  // Fetch technician user details
  const { data: technicianUser } = useQuery({
    queryKey: ['technician-user', request.technician_id],
    queryFn: async () => {
      if (!request.technician_id) return null;
      const users = await base44.entities.User.filter(
        { id: request.technician_id }
      );
      return users[0] || null;
    },
    enabled: !!request.technician_id
  });

  const calculateDistance = (lat1, lng1, lat2, lng2) => {
    const R = 3959;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return (R * c).toFixed(1);
  };

  const distance = technicianLocation 
    ? calculateDistance(
        technicianLocation.latitude,
        technicianLocation.longitude,
        request.location_lat,
        request.location_lng
      )
    : null;

  // Dynamic ETA calculation with traffic simulation
  const calculateDynamicETA = () => {
    if (!distance) return null;
    
    const baseSpeed = 35; // mph average
    const now = new Date();
    const hour = now.getHours();
    
    // Traffic factor based on time of day
    let trafficMultiplier = 1.0;
    if (hour >= 7 && hour <= 9) trafficMultiplier = 1.5; // Morning rush
    else if (hour >= 16 && hour <= 18) trafficMultiplier = 1.6; // Evening rush
    else if (hour >= 22 || hour <= 5) trafficMultiplier = 0.8; // Night
    
    const adjustedSpeed = baseSpeed / trafficMultiplier;
    const timeInHours = parseFloat(distance) / adjustedSpeed;
    const timeInMinutes = Math.ceil(timeInHours * 60);
    
    return timeInMinutes;
  };

  const estimatedMinutes = calculateDynamicETA();

  return (
    <Card className="border-2" style={{ borderColor: '#FF771D' }}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <ServiceTypeIcon type={request.service_type} />
            Track Your Service
          </CardTitle>
          <StatusBadge status={request.status} />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Technician Info */}
        {technicianUser && (
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="font-semibold text-lg">{technicianUser.full_name}</p>
                <p className="text-sm text-gray-600">Your Technician</p>
                {technicianProfile && (
                  <p className="text-xs text-gray-500 mt-1">
                    {technicianProfile.vehicle_type} • {technicianProfile.license_plate}
                  </p>
                )}
              </div>
              {technicianProfile?.rating && (
                <div className="text-right">
                  <div className="flex items-center gap-1">
                    <span className="text-yellow-500">★</span>
                    <span className="font-semibold">{technicianProfile.rating.toFixed(1)}</span>
                  </div>
                  <p className="text-xs text-gray-500">{technicianProfile.total_jobs} jobs</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Real-time Map with route */}
        <div className="relative">
          <ServiceMap
            customerLocation={[request.location_lat, request.location_lng]}
            technicianLocation={
              technicianLocation 
                ? [technicianLocation.latitude, technicianLocation.longitude]
                : null
            }
            height="300px"
            zoom={13}
            showCustomer={true}
            showTechnician={!!technicianLocation}
            showRoute={true}
          />
          {technicianLocation && (
            <>
              <div className="absolute top-2 right-2 bg-white rounded-lg shadow-lg px-3 py-2 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                <span className="text-xs font-semibold">Live Tracking</span>
              </div>
              <div className="absolute top-2 left-2 bg-white rounded-lg shadow-lg px-3 py-2">
                <p className="text-xs text-gray-600">Real-time GPS • 5s refresh</p>
              </div>
            </>
          )}
        </div>

        {/* Status Info */}
        <div className="grid grid-cols-2 gap-3">
          {distance && (
            <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-4 h-4 text-blue-600" />
                <span className="text-xs font-semibold text-blue-800">Distance</span>
              </div>
              <p className="text-xl font-bold text-blue-900">{distance} mi</p>
            </div>
          )}

          {estimatedMinutes && (request.status === 'en_route' || request.status === 'assigned') && (
            <div className="rounded-lg p-3 border" style={{ backgroundColor: '#FFF5EE', borderColor: '#FF771D' }}>
              <div className="flex items-center gap-2 mb-1">
                <Clock className="w-4 h-4" style={{ color: '#FF771D' }} />
                <span className="text-xs font-semibold" style={{ color: '#FF771D' }}>
                  {request.status === 'en_route' ? 'Live ETA' : 'Est. Arrival'}
                </span>
              </div>
              <p className="text-xl font-bold" style={{ color: '#FF771D' }}>
                ~{estimatedMinutes} min
              </p>
              {request.status === 'en_route' && (
                <p className="text-xs text-gray-500 mt-1">Adjusting for traffic</p>
              )}
            </div>
          )}

          {request.estimated_arrival && request.status !== 'en_route' && (
            <div className="rounded-lg p-3 border" style={{ backgroundColor: '#FFF5EE', borderColor: '#FF771D' }}>
              <div className="flex items-center gap-2 mb-1">
                <Clock className="w-4 h-4" style={{ color: '#FF771D' }} />
                <span className="text-xs font-semibold" style={{ color: '#FF771D' }}>Estimated Arrival</span>
              </div>
              <p className="text-sm font-bold" style={{ color: '#FF771D' }}>
                {format(new Date(request.estimated_arrival), 'h:mm a')}
              </p>
            </div>
          )}
        </div>

        {/* Status Message with movement indicator */}
        <div className="bg-gray-50 rounded-lg p-3 text-center">
          <p className="text-sm text-gray-700 font-medium">
            {request.status === 'assigned' && '🎯 Technician has accepted your request'}
            {request.status === 'en_route' && (
              <span className="flex items-center justify-center gap-2">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                </span>
                Technician is moving toward your location
              </span>
            )}
            {request.status === 'arrived' && '✅ Technician has arrived'}
            {request.status === 'in_progress' && '🔧 Service in progress'}
          </p>
          {technicianLocation && distance && request.status === 'en_route' && (
            <p className="text-xs text-gray-500 mt-2">
              {parseFloat(distance) < 0.5 
                ? 'Less than half a mile away!' 
                : parseFloat(distance) < 1 
                ? 'Less than a mile away!' 
                : `${distance} miles away`}
            </p>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => window.location.href = createPageUrl(`ServiceDetails?id=${request.id}`)}
          >
            View Details
          </Button>
          {technicianLocation && (
            <Button
              className="flex-1 text-white hover:opacity-90"
              style={{ backgroundColor: '#FF771D' }}
              onClick={() => {
                const url = `https://www.google.com/maps/dir/?api=1&origin=${request.location_lat},${request.location_lng}&destination=${technicianLocation.latitude},${technicianLocation.longitude}`;
                window.open(url, '_blank');
              }}
            >
              <Navigation className="w-4 h-4 mr-2" />
              Track on Maps
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}