import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { MessageCircle, Send, Loader2, X, User, BookOpen } from 'lucide-react';
import KnowledgeBaseSearch from '../support/KnowledgeBaseSearch';

export default function SupportChatbot({ userId }) {
  const [isOpen, setIsOpen] = useState(false);
  const [showKnowledgeBase, setShowKnowledgeBase] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: 'Hi! I\'m your ROADSIDE+ AI assistant. I can help answer questions about our services, pricing, and common roadside issues. How can I help you today?'
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Fetch user's active service requests for context
      const activeRequests = await base44.entities.ServiceRequest.filter({ 
        customer_id: userId,
        status: ['pending_dispatch', 'dispatched', 'assigned', 'en_route', 'in_progress', 'arrived']
      });

      // Fetch recent support conversations for training context
      const recentSupport = await base44.entities.SupportConversation.filter({ 
        customer_id: userId 
      }, '-created_date', 5);

      const conversationHistory = messages.map(m => `${m.role === 'user' ? 'Customer' : 'Assistant'}: ${m.content}`).join('\n');
      
      // Build context from user's current situation
      let userContext = '';
      if (activeRequests.length > 0) {
        const req = activeRequests[0];
        userContext = `\n\nCUSTOMER'S CURRENT SERVICE REQUEST:
- Service Type: ${req.service_type.replace(/_/g, ' ')}
- Status: ${req.status}
- Created: ${new Date(req.created_date).toLocaleString()}
${req.estimated_arrival ? `- Estimated Arrival: ${new Date(req.estimated_arrival).toLocaleString()}` : ''}
${req.technician_id ? '- Technician: Assigned' : '- Technician: Searching...'}
${req.location_address ? `- Location: ${req.location_address}` : ''}`;
      }

      // Check knowledge base for relevant articles
      const kbArticles = await base44.entities.KnowledgeBaseArticle.filter({
        is_published: true,
        target_audience: ['customer', 'both']
      });
      
      const relevantArticles = kbArticles.filter(article => {
        const searchTerms = input.toLowerCase();
        return article.title.toLowerCase().includes(searchTerms) ||
               article.content.toLowerCase().includes(searchTerms) ||
               (article.tags && article.tags.some(tag => tag.toLowerCase().includes(searchTerms)));
      }).slice(0, 3);

      let kbContext = '';
      if (relevantArticles.length > 0) {
        kbContext = '\n\nRELEVANT KNOWLEDGE BASE ARTICLES:\n' + 
          relevantArticles.map(a => `- ${a.title}: ${a.content.substring(0, 200)}...`).join('\n');
      }

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a helpful customer support AI for ROADSIDE+, a roadside assistance service. 

Our Services:
- Tire Change: Flat tire repair and replacement ($75-$150)
- Battery Jump: Dead battery jump-start service ($60-$100)
- Fuel Delivery: Emergency fuel delivery ($50-$80 + fuel cost)
- Lockout Service: Vehicle lockout assistance ($80-$120)
- Towing: Vehicle towing to nearest facility ($100-$300 depending on distance)

Key Information:
- Average response time: 15-30 minutes
- 24/7 availability
- All technicians are certified and background-checked
- Real-time tracking available once technician is assigned
- Payment accepted after service completion

Refund Policy:
- Full refund if service not completed
- Partial refund for unsatisfactory service (case-by-case)
- Refund requests processed within 5-7 business days
- Contact support to initiate refund process
${userContext}
${kbContext}

Previous conversation:
${conversationHistory}

Customer's question: ${input}

Instructions:
- Use the customer's current service request context to answer specific questions like "Where is my technician?" or "What's my ETA?"
- Use knowledge base articles if available to provide accurate, detailed information
- For "Where is my technician?" questions: Check status. If dispatched/assigned, say technician is being notified. If en_route, say they're on the way. If no technician yet, explain we're finding one.
- For refund inquiries: Explain the refund policy and offer to escalate to human support for processing
- For complex billing, complaints, account issues, or technical problems: Suggest escalation to human support
- Answer questions about services, pricing, and common roadside issues
- Be friendly, concise, and helpful (2-3 sentences max unless detailed explanation needed)
- Don't make up information not provided above
- If you suggest an article or information from KB, mention it naturally

Escalation triggers:
- Billing disputes or complex payment issues
- Service complaints or quality issues
- Account access problems
- Legal or policy questions
- Emergency situations
- Customer explicitly requests human agent
- You cannot confidently answer with provided information

If escalation is needed, set needs_escalation to true and explain why human support would be better.

Provide your response:`,
        response_json_schema: {
          type: 'object',
          properties: {
            message: {
              type: 'string',
              description: 'Your response to the customer'
            },
            needs_escalation: {
              type: 'boolean',
              description: 'Whether this query should be escalated to human support'
            },
            confidence: {
              type: 'string',
              enum: ['high', 'medium', 'low'],
              description: 'Your confidence in this answer'
            }
          }
        }
      });

      const aiMessage = {
        role: 'assistant',
        content: response.message,
        needsEscalation: response.needs_escalation,
        confidence: response.confidence
      };

      setMessages(prev => [...prev, aiMessage]);

      // Auto-suggest escalation for low confidence answers
      if (response.confidence === 'low' && !response.needs_escalation) {
        setTimeout(() => {
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: 'Would you like me to connect you with a human agent for more personalized assistance?',
            needsEscalation: true
          }]);
        }, 1000);
      }
    } catch (error) {
      console.error('Chatbot error:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again or contact support directly.'
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const escalateToSupport = async () => {
    setIsLoading(true);
    try {
      const conversationLog = messages.map(m => 
        `${m.role === 'user' ? 'Customer' : 'AI'}: ${m.content}`
      ).join('\n\n');

      // Create support conversation in the system
      const conversation = await base44.entities.SupportConversation.create({
        customer_id: userId,
        subject: 'Escalated from AI Chatbot',
        status: 'open'
      });

      // Add initial message with chatbot context
      await base44.entities.SupportMessage.create({
        conversation_id: conversation.id,
        sender_id: userId,
        sender_role: 'customer',
        message: `[Escalated from AI Chatbot]\n\nCustomer conversation:\n${conversationLog}`
      });

      // Send notification to admin users
      const adminUsers = await base44.entities.User.filter({ role: 'admin' });
      
      for (const admin of adminUsers) {
        await base44.entities.Notification.create({
          user_id: admin.id,
          type: 'new_message',
          title: 'AI Support Escalation',
          message: `Customer escalated from chatbot. View in Support Chat.`,
          related_id: conversation.id
        });
      }

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: '✅ Connected to human support! A support agent will respond to you shortly. You can continue this conversation in the Support Chat section.'
      }]);
    } catch (error) {
      console.error('Escalation error:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Unable to escalate at this time. Please try using the Support Chat feature directly.'
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed bottom-6 right-6 w-96 h-[600px] shadow-2xl rounded-lg flex flex-col z-50 bg-white">
      {/* Header */}
      <div className="text-white p-4 rounded-t-lg flex items-center justify-between" style={{ background: 'linear-gradient(135deg, #FF771D 0%, #E52C2D 100%)' }}>
        <div className="flex items-center gap-2">
          <MessageCircle className="w-5 h-5" />
          <h3 className="font-semibold">ROADSIDE+ AI Support</h3>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowKnowledgeBase(!showKnowledgeBase)} 
            className="hover:opacity-70"
            title="Browse Knowledge Base"
          >
            <BookOpen className="w-5 h-5" />
          </button>
          <button onClick={() => setIsOpen(false)} className="hover:opacity-70">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Knowledge Base or Messages */}
      {showKnowledgeBase ? (
        <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
          <KnowledgeBaseSearch userRole="customer" />
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                msg.role === 'user'
                  ? 'text-white'
                  : 'bg-white border border-gray-200 text-gray-900'
              }`}
              style={msg.role === 'user' ? { backgroundColor: '#FF771D' } : {}}
            >
              <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
              {msg.needsEscalation && (
                <Button
                  size="sm"
                  variant="outline"
                  className="mt-2 w-full"
                  onClick={escalateToSupport}
                  disabled={isLoading}
                >
                  <User className="w-3 h-3 mr-1" />
                  Connect to Human Support
                </Button>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start flex-col items-start">
            <div className="bg-white border border-gray-200 rounded-2xl px-4 py-2 flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin" style={{ color: '#FF771D' }} />
              <span className="text-xs text-gray-500">AI is thinking...</span>
            </div>
          </div>
        )}
        </div>
      )}

      {/* Input */}
      {!showKnowledgeBase && (
        <div className="p-4 border-t bg-white rounded-b-lg">
          <div className="flex gap-2">
          <Textarea
            placeholder="Ask a question..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            className="flex-1 min-h-[60px] max-h-[100px] resize-none"
            disabled={isLoading}
          />
          <Button
            onClick={sendMessage}
            disabled={!input.trim() || isLoading}
            className="text-white hover:opacity-90"
            style={{ backgroundColor: '#FF771D' }}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-xs text-gray-400 mt-2 text-center">
          Powered by AI • Answers may not be 100% accurate
        </p>
      </div>
      )}
    </div>
  );
}