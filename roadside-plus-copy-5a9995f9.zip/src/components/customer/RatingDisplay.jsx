import React from 'react';
import { Star } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export default function RatingDisplay({ rating }) {
  if (!rating) return null;

  return (
    <Card className="border-2 border-yellow-200 bg-yellow-50">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <div className="flex">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                className={`w-5 h-5 ${
                  star <= rating.rating
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="font-bold text-lg">{rating.rating.toFixed(1)}</span>
        </div>
        {rating.comment && (
          <div>
            <p className="text-sm text-gray-700 italic">"{rating.comment}"</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}