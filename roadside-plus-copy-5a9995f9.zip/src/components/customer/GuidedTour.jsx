import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X, ArrowRight, ArrowLeft } from 'lucide-react';

const TOUR_STEPS = [
  {
    id: 'request-service',
    title: 'Request Roadside Assistance',
    description: 'Click here to request help. Our AI will find the best technician for your needs.',
    position: 'bottom',
    highlight: '.request-service-btn'
  },
  {
    id: 'track-job',
    title: 'Track Your Service',
    description: 'See your technician\'s location in real-time and get ETA updates.',
    position: 'top',
    highlight: '.track-job-card'
  },
  {
    id: 'history',
    title: 'Service History',
    description: 'View past services, photos, and invoices anytime.',
    position: 'right',
    highlight: '.history-tab'
  },
  {
    id: 'support',
    title: '24/7 Support',
    description: 'Chat with support or your technician directly from the app.',
    position: 'left',
    highlight: '.support-chat'
  }
];

export default function GuidedTour({ onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [position, setPosition] = useState({ top: 0, left: 0 });

  React.useEffect(() => {
    updatePosition();
    window.addEventListener('resize', updatePosition);
    return () => window.removeEventListener('resize', updatePosition);
  }, [currentStep]);

  const updatePosition = () => {
    const step = TOUR_STEPS[currentStep];
    const element = document.querySelector(step.highlight);
    
    if (element) {
      const rect = element.getBoundingClientRect();
      let top = 0;
      let left = 0;

      switch (step.position) {
        case 'bottom':
          top = rect.bottom + 20;
          left = rect.left + rect.width / 2;
          break;
        case 'top':
          top = rect.top - 150;
          left = rect.left + rect.width / 2;
          break;
        case 'right':
          top = rect.top + rect.height / 2;
          left = rect.right + 20;
          break;
        case 'left':
          top = rect.top + rect.height / 2;
          left = rect.left - 320;
          break;
      }

      setPosition({ top, left });
      
      // Highlight element
      element.classList.add('tour-highlight');
      
      return () => {
        element.classList.remove('tour-highlight');
      };
    }
  };

  const handleNext = () => {
    if (currentStep < TOUR_STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    localStorage.setItem('tour_completed', 'true');
    onComplete();
  };

  const step = TOUR_STEPS[currentStep];

  return (
    <>
      {/* Overlay */}
      <div className="fixed inset-0 bg-black/60 z-40" onClick={handleComplete} />

      {/* Tour Card */}
      <div
        className="fixed z-50 transition-all duration-300 max-w-[90vw]"
        style={{
          top: `${Math.max(position.top, 100)}px`,
          left: `${Math.min(Math.max(position.left, 160), window.innerWidth - 160)}px`,
          transform: 'translate(-50%, -50%)'
        }}
      >
        <Card className="w-80 max-w-full shadow-2xl border-2" style={{ borderColor: '#FF771D' }}>
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-start justify-between mb-3">
              <div className="text-sm font-semibold" style={{ color: '#FF771D' }}>
                {currentStep + 1} / {TOUR_STEPS.length}
              </div>
              <button onClick={handleComplete} className="text-gray-400 hover:text-gray-600 flex-shrink-0">
                <X className="w-4 h-4" />
              </button>
            </div>

            <h3 className="text-base sm:text-lg font-bold mb-2 text-gray-900">{step.title}</h3>
            <p className="text-sm text-gray-700 mb-6 leading-relaxed">{step.description}</p>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBack}
                disabled={currentStep === 0}
                className="w-full sm:w-auto"
              >
                <ArrowLeft className="w-4 h-4 mr-1" />
                Back
              </Button>

              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleComplete}
                  className="flex-1 sm:flex-none"
                >
                  Skip Tour
                </Button>
                <Button
                  size="sm"
                  onClick={handleNext}
                  className="text-white flex-1 sm:flex-none"
                  style={{ backgroundColor: '#FF771D' }}
                >
                  {currentStep === TOUR_STEPS.length - 1 ? 'Finish' : 'Next'}
                  <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <style jsx>{`
        .tour-highlight {
          position: relative;
          z-index: 45;
          box-shadow: 0 0 0 4px rgba(255, 119, 29, 0.5), 0 0 0 9999px rgba(0, 0, 0, 0.6);
          border-radius: 8px;
        }
      `}</style>
    </>
  );
}