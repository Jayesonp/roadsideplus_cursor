import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Plus, Car, Edit, Trash2, Star } from 'lucide-react';
import { useNetworkStatus } from '../offline/NetworkMonitor';
import { cacheVehicles } from '../offline/cacheVehicles';
import { syncManager } from '../offline/SyncManager';

export default function VehicleManager({ userId }) {
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    nickname: '',
    make: '',
    model: '',
    year: '',
    color: '',
    vin: '',
    license_plate: '',
    is_default: false
  });

  const queryClient = useQueryClient();
  const { isOnline } = useNetworkStatus();

  const { data: vehicles = [] } = useQuery({
    queryKey: ['vehicles', userId],
    queryFn: async () => {
      // Try cache first if offline
      if (!isOnline) {
        return await cacheVehicles.getCustomerVehicles(userId);
      }
      
      const fetchedVehicles = await base44.entities.Vehicle.filter({ customer_id: userId }, '-created_date');
      
      // Cache for offline use
      await cacheVehicles.saveMultipleVehicles(fetchedVehicles);
      
      return fetchedVehicles;
    }
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      // If offline, queue the action
      if (!isOnline) {
        const tempVehicle = {
          ...data,
          customer_id: userId,
          id: `temp_${Date.now()}`,
          created_date: new Date().toISOString()
        };
        await cacheVehicles.saveVehicle(tempVehicle);
        await syncManager.queueAction('create_vehicle', { vehicleData: { ...data, customer_id: userId } });
        return tempVehicle;
      }
      
      const vehicle = await base44.entities.Vehicle.create({ ...data, customer_id: userId });
      await cacheVehicles.saveVehicle(vehicle);
      return vehicle;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['vehicles']);
      resetForm();
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      // Update cache immediately
      const cached = await cacheVehicles.getVehicle(id);
      if (cached) {
        await cacheVehicles.saveVehicle({ ...cached, ...data });
      }
      
      // If offline, queue the action
      if (!isOnline) {
        await syncManager.queueAction('update_vehicle', { vehicleId: id, data });
        return { ...cached, ...data };
      }
      
      const updated = await base44.entities.Vehicle.update(id, data);
      await cacheVehicles.saveVehicle(updated);
      return updated;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['vehicles']);
      resetForm();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (vehicleId) => {
      // Remove from cache
      await cacheVehicles.removeVehicle(vehicleId);
      
      // If offline, queue the action
      if (!isOnline) {
        await syncManager.queueAction('delete_vehicle', { vehicleId });
        return { id: vehicleId };
      }
      
      return await base44.entities.Vehicle.delete(vehicleId);
    },
    onSuccess: () => queryClient.invalidateQueries(['vehicles'])
  });

  const setDefaultMutation = useMutation({
    mutationFn: async (vehicleId) => {
      // Update cache for all vehicles
      for (const v of vehicles) {
        const isDefault = v.id === vehicleId;
        await cacheVehicles.saveVehicle({ ...v, is_default: isDefault });
      }
      
      // If offline, queue the action
      if (!isOnline) {
        await syncManager.queueAction('set_default_vehicle', { vehicleId, customerId: userId });
        return { id: vehicleId, is_default: true };
      }
      
      // Unset all defaults first
      await Promise.all(
        vehicles.map(v => base44.entities.Vehicle.update(v.id, { is_default: false }))
      );
      // Set new default
      const updated = await base44.entities.Vehicle.update(vehicleId, { is_default: true });
      await cacheVehicles.saveVehicle(updated);
      return updated;
    },
    onSuccess: () => queryClient.invalidateQueries(['vehicles'])
  });

  const resetForm = () => {
    setFormData({
      nickname: '',
      make: '',
      model: '',
      year: '',
      color: '',
      vin: '',
      license_plate: '',
      is_default: false
    });
    setEditing(null);
    setShowForm(false);
  };

  const handleEdit = (vehicle) => {
    setFormData(vehicle);
    setEditing(vehicle.id);
    setShowForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editing) {
        await updateMutation.mutateAsync({ id: editing, data: formData });
      } else {
        await createMutation.mutateAsync(formData);
      }
    } catch (error) {
      console.error('Error saving vehicle:', error);
      alert('Failed to save vehicle. Please try again.');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">My Vehicles</h3>
        <Button
          onClick={() => setShowForm(!showForm)}
          style={{ backgroundColor: '#FF771D' }}
          className="text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Vehicle
        </Button>
      </div>

      {showForm && (
        <Card className="border-2" style={{ borderColor: '#FF771D' }}>
          <CardHeader>
            <CardTitle>{editing ? 'Edit Vehicle' : 'Add New Vehicle'}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Nickname (optional)</Label>
                  <Input
                    placeholder="e.g., My Truck"
                    value={formData.nickname}
                    onChange={(e) => setFormData({...formData, nickname: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Make *</Label>
                  <Input
                    placeholder="e.g., Toyota"
                    value={formData.make}
                    onChange={(e) => setFormData({...formData, make: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label>Model *</Label>
                  <Input
                    placeholder="e.g., Camry"
                    value={formData.model}
                    onChange={(e) => setFormData({...formData, model: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label>Year</Label>
                  <Input
                    placeholder="e.g., 2020"
                    value={formData.year}
                    onChange={(e) => setFormData({...formData, year: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Color</Label>
                  <Input
                    placeholder="e.g., Silver"
                    value={formData.color}
                    onChange={(e) => setFormData({...formData, color: e.target.value})}
                  />
                </div>
                <div>
                  <Label>License Plate</Label>
                  <Input
                    placeholder="e.g., ABC-1234"
                    value={formData.license_plate}
                    onChange={(e) => setFormData({...formData, license_plate: e.target.value})}
                  />
                </div>
                <div className="md:col-span-2">
                  <Label>VIN</Label>
                  <Input
                    placeholder="17-digit Vehicle Identification Number"
                    value={formData.vin}
                    onChange={(e) => setFormData({...formData, vin: e.target.value})}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button type="submit" style={{ backgroundColor: '#FF771D' }} className="text-white">
                  {editing ? 'Update' : 'Add'} Vehicle
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        {vehicles.map(vehicle => (
          <Card key={vehicle.id} className={vehicle.is_default ? 'border-2 border-green-500' : ''}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Car className="w-5 h-5" style={{ color: '#FF771D' }} />
                  <div>
                    {vehicle.nickname && (
                      <p className="font-semibold">{vehicle.nickname}</p>
                    )}
                    <p className="text-sm text-gray-600">
                      {vehicle.year} {vehicle.make} {vehicle.model}
                    </p>
                  </div>
                </div>
                {vehicle.is_default && (
                  <Badge className="bg-green-100 text-green-800">
                    <Star className="w-3 h-3 mr-1 fill-green-600" />
                    Default
                  </Badge>
                )}
              </div>

              <div className="space-y-1 text-sm text-gray-600 mb-3">
                {vehicle.color && <p>Color: {vehicle.color}</p>}
                {vehicle.license_plate && <p>Plate: {vehicle.license_plate}</p>}
                {vehicle.vin && <p className="text-xs">VIN: {vehicle.vin}</p>}
              </div>

              <div className="flex gap-2">
                {!vehicle.is_default && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setDefaultMutation.mutate(vehicle.id)}
                  >
                    <Star className="w-3 h-3 mr-1" />
                    Set Default
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleEdit(vehicle)}
                >
                  <Edit className="w-3 h-3 mr-1" />
                  Edit
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="text-red-600"
                  onClick={() => {
                    if (confirm('Delete this vehicle?')) {
                      deleteMutation.mutate(vehicle.id);
                    }
                  }}
                >
                  <Trash2 className="w-3 h-3 mr-1" />
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}

        {vehicles.length === 0 && !showForm && (
          <Card className="md:col-span-2">
            <CardContent className="p-8 text-center text-gray-500">
              <Car className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No vehicles added yet</p>
              <p className="text-sm">Add your vehicles for faster service requests</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}