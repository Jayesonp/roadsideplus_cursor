import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  CreditCard, Plus, Trash2, CheckCircle, X, 
  Loader2, Lock, Calendar
} from 'lucide-react';

export default function PaymentMethodsManager({ userId }) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newCard, setNewCard] = useState({
    payment_type: 'credit_card',
    card_brand: '',
    last_four: '',
    expiry_month: '',
    expiry_year: '',
    cardholder_name: '',
    billing_zip: ''
  });
  const queryClient = useQueryClient();

  const { data: paymentMethods = [], isLoading } = useQuery({
    queryKey: ['payment-methods', userId],
    queryFn: async () => {
      return await base44.entities.PaymentMethod.filter({ user_id: userId });
    },
    enabled: !!userId
  });

  const addPaymentMethod = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.PaymentMethod.create({
        ...data,
        user_id: userId,
        gateway_token: 'mock_token_' + Date.now() // In production, use real payment gateway
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['payment-methods', userId]);
      setShowAddForm(false);
      setNewCard({
        payment_type: 'credit_card',
        card_brand: '',
        last_four: '',
        expiry_month: '',
        expiry_year: '',
        cardholder_name: '',
        billing_zip: ''
      });
      alert('Payment method added successfully!');
    },
    onError: (error) => {
      alert('Failed to add payment method: ' + error.message);
    }
  });

  const deletePaymentMethod = useMutation({
    mutationFn: async (id) => {
      return await base44.entities.PaymentMethod.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['payment-methods', userId]);
      alert('Payment method removed');
    }
  });

  const setDefaultPaymentMethod = useMutation({
    mutationFn: async (id) => {
      // First, unset all defaults
      for (const method of paymentMethods) {
        if (method.is_default) {
          await base44.entities.PaymentMethod.update(method.id, { is_default: false });
        }
      }
      // Then set the new default
      return await base44.entities.PaymentMethod.update(id, { is_default: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['payment-methods', userId]);
    }
  });

  const getCardIcon = (brand) => {
    const icons = {
      'visa': '💳',
      'mastercard': '💳',
      'amex': '💳',
      'discover': '💳'
    };
    return icons[brand?.toLowerCase()] || '💳';
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Basic validation
    if (!newCard.last_four || newCard.last_four.length !== 4) {
      alert('Please enter the last 4 digits of your card');
      return;
    }
    
    if (!newCard.expiry_month || !newCard.expiry_year) {
      alert('Please enter expiry date');
      return;
    }

    addPaymentMethod.mutate(newCard);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto" style={{ color: '#FF771D' }} />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            Payment Methods
          </div>
          {!showAddForm && (
            <Button
              onClick={() => setShowAddForm(true)}
              size="sm"
              className="text-white"
              style={{ backgroundColor: '#FF771D' }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Card
            </Button>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add Payment Form */}
        {showAddForm && (
          <Card className="border-2" style={{ borderColor: '#FF771D' }}>
            <CardContent className="pt-4">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Add New Card</h3>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowAddForm(false)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>

                <div>
                  <Label htmlFor="cardholder_name">Cardholder Name</Label>
                  <Input
                    id="cardholder_name"
                    placeholder="John Doe"
                    value={newCard.cardholder_name}
                    onChange={(e) => setNewCard({ ...newCard, cardholder_name: e.target.value })}
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="card_brand">Card Brand</Label>
                    <select
                      id="card_brand"
                      className="w-full border rounded-md px-3 py-2"
                      value={newCard.card_brand}
                      onChange={(e) => setNewCard({ ...newCard, card_brand: e.target.value })}
                      required
                    >
                      <option value="">Select...</option>
                      <option value="Visa">Visa</option>
                      <option value="Mastercard">Mastercard</option>
                      <option value="Amex">American Express</option>
                      <option value="Discover">Discover</option>
                    </select>
                  </div>
                  <div>
                    <Label htmlFor="last_four">Last 4 Digits</Label>
                    <Input
                      id="last_four"
                      placeholder="1234"
                      maxLength={4}
                      value={newCard.last_four}
                      onChange={(e) => setNewCard({ ...newCard, last_four: e.target.value.replace(/\D/g, '') })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="expiry_month">Month</Label>
                    <Input
                      id="expiry_month"
                      placeholder="MM"
                      maxLength={2}
                      value={newCard.expiry_month}
                      onChange={(e) => setNewCard({ ...newCard, expiry_month: e.target.value.replace(/\D/g, '') })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="expiry_year">Year</Label>
                    <Input
                      id="expiry_year"
                      placeholder="YYYY"
                      maxLength={4}
                      value={newCard.expiry_year}
                      onChange={(e) => setNewCard({ ...newCard, expiry_year: e.target.value.replace(/\D/g, '') })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="billing_zip">ZIP Code</Label>
                    <Input
                      id="billing_zip"
                      placeholder="12345"
                      value={newCard.billing_zip}
                      onChange={(e) => setNewCard({ ...newCard, billing_zip: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-start gap-2">
                  <Lock className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-blue-800">
                    Your payment information is encrypted and secure
                  </p>
                </div>

                <Button
                  type="submit"
                  className="w-full text-white"
                  style={{ backgroundColor: '#FF771D' }}
                  disabled={addPaymentMethod.isLoading}
                >
                  {addPaymentMethod.isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Adding...
                    </>
                  ) : (
                    'Add Payment Method'
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* List of Payment Methods */}
        {paymentMethods.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <CreditCard className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No payment methods added yet</p>
            <p className="text-xs mt-1">Add a card to make payments faster</p>
          </div>
        ) : (
          <div className="space-y-3">
            {paymentMethods.map((method) => (
              <Card key={method.id} className="border-2 hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">
                        {getCardIcon(method.card_brand)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-semibold">
                            {method.card_brand} •••• {method.last_four}
                          </p>
                          {method.is_default && (
                            <Badge className="text-xs bg-green-100 text-green-800">
                              Default
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-3 text-xs text-gray-500 mt-1">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            Expires {method.expiry_month}/{method.expiry_year}
                          </span>
                          {method.cardholder_name && (
                            <span>{method.cardholder_name}</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {!method.is_default && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setDefaultPaymentMethod.mutate(method.id)}
                          disabled={setDefaultPaymentMethod.isLoading}
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Set Default
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          if (confirm('Remove this payment method?')) {
                            deletePaymentMethod.mutate(method.id);
                          }
                        }}
                        className="text-red-600 hover:bg-red-50"
                        disabled={deletePaymentMethod.isLoading}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}