import React, { useEffect, useState } from 'react';
import { WifiOff, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { useNetworkStatus } from './NetworkMonitor';
import { localDB } from './localDB';
import { Card, CardContent } from '@/components/ui/card';

export default function OfflineIndicator() {
  const { isOnline } = useNetworkStatus();
  const [pendingActions, setPendingActions] = useState(0);

  useEffect(() => {
    if (!isOnline) {
      checkPendingActions();
      const interval = setInterval(checkPendingActions, 5000);
      return () => clearInterval(interval);
    }
  }, [isOnline]);

  const checkPendingActions = async () => {
    try {
      const actionQueue = await localDB.getAllItems('actionQueue');
      const messageQueue = await localDB.getAllItems('messages');
      const pendingMessages = messageQueue.filter(m => m.status === 'pending');
      setPendingActions(actionQueue.length + pendingMessages.length);
    } catch (error) {
      console.error('Error checking pending actions:', error);
    }
  };

  if (isOnline && pendingActions === 0) return null;

  return (
    <>
      {/* Compact indicator */}
      <div className={`fixed top-20 md:top-4 right-4 z-50 px-4 py-2 rounded-lg shadow-lg border-2 flex items-center gap-2 ${
        isOnline 
          ? 'bg-blue-50 dark:bg-blue-900 border-blue-300 dark:border-blue-600' 
          : 'bg-yellow-50 dark:bg-yellow-900 border-yellow-300 dark:border-yellow-600'
      }`}>
        {isOnline ? (
          <>
            <Clock className="w-4 h-4 text-blue-600 dark:text-blue-300 animate-spin" />
            <span className="text-sm font-medium text-blue-900 dark:text-blue-100">
              Syncing {pendingActions} {pendingActions === 1 ? 'item' : 'items'}...
            </span>
          </>
        ) : (
          <>
            <WifiOff className="w-4 h-4 text-yellow-600 dark:text-yellow-300" />
            <div className="flex flex-col">
              <span className="text-sm font-bold text-yellow-900 dark:text-yellow-100">
                Offline Mode
              </span>
              {pendingActions > 0 && (
                <span className="text-xs text-yellow-700 dark:text-yellow-300">
                  {pendingActions} {pendingActions === 1 ? 'action' : 'actions'} will sync when online
                </span>
              )}
            </div>
          </>
        )}
      </div>

      {/* Full offline notice (only when offline) */}
      {!isOnline && (
        <div className="fixed bottom-24 left-4 right-4 md:left-auto md:right-4 md:w-96 z-40">
          <Card className="border-2 border-yellow-400 bg-yellow-50 dark:bg-yellow-900/20">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h4 className="font-semibold text-yellow-900 dark:text-yellow-100 mb-1">
                    Working Offline
                  </h4>
                  <p className="text-sm text-yellow-800 dark:text-yellow-200 mb-2">
                    You can view job details and make updates. All changes will sync automatically when you're back online.
                  </p>
                  {pendingActions > 0 && (
                    <div className="bg-yellow-100 dark:bg-yellow-800/30 rounded px-2 py-1 text-xs text-yellow-900 dark:text-yellow-100">
                      <strong>{pendingActions}</strong> {pendingActions === 1 ? 'action' : 'actions'} queued for sync
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
}