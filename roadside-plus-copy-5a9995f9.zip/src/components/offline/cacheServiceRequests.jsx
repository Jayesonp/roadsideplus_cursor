import { localDB } from './localDB';

export const cacheServiceRequests = {
  async saveRequest(request) {
    await localDB.setItem('serviceRequests', request);
  },

  async saveMultipleRequests(requests) {
    for (const request of requests) {
      await localDB.setItem('serviceRequests', request);
    }
  },

  async getRequest(id) {
    return await localDB.getItem('serviceRequests', id);
  },

  async getAllRequests() {
    return await localDB.getAllItems('serviceRequests');
  },

  async getMyJobs(technicianId) {
    const allRequests = await localDB.getAllItems('serviceRequests');
    return allRequests.filter(r => r.technician_id === technicianId);
  },

  async getMyCustomerRequests(customerId) {
    const allRequests = await localDB.getAllItems('serviceRequests');
    return allRequests.filter(r => r.customer_id === customerId);
  },

  async removeRequest(id) {
    await localDB.removeItem('serviceRequests', id);
  },

  async updateRequestStatus(requestId, status) {
    const request = await localDB.getItem('serviceRequests', requestId);
    if (request) {
      request.status = status;
      request.updated_date = new Date().toISOString();
      await localDB.setItem('serviceRequests', request);
    }
  },

  async saveActiveJob(request) {
    localStorage.setItem('activeJob', JSON.stringify(request));
  },

  async getActiveJob() {
    const data = localStorage.getItem('activeJob');
    return data ? JSON.parse(data) : null;
  },

  async clearActiveJob() {
    localStorage.removeItem('activeJob');
  }
};