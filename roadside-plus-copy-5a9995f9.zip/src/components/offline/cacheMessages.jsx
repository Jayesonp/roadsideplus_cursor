import { localDB } from './localDB';

export const cacheMessages = {
  async saveMessage(message) {
    await localDB.setItem('messages', message);
  },

  async getMessages(serviceRequestId) {
    return await localDB.queryByIndex('messages', 'service_request_id', serviceRequestId);
  },

  async queueOfflineMessage(message) {
    const queuedMessage = {
      ...message,
      status: 'pending',
      queued_at: new Date().toISOString()
    };
    await localDB.setItem('messages', queuedMessage);
    return queuedMessage;
  },

  async getPendingMessages() {
    const allMessages = await localDB.getAllItems('messages');
    return allMessages.filter(m => m.status === 'pending');
  },

  async markMessageSent(messageId) {
    const message = await localDB.getItem('messages', messageId);
    if (message) {
      message.status = 'sent';
      await localDB.setItem('messages', message);
    }
  },

  async clearMessages(serviceRequestId) {
    const messages = await this.getMessages(serviceRequestId);
    for (const msg of messages) {
      await localDB.removeItem('messages', msg.id);
    }
  }
};