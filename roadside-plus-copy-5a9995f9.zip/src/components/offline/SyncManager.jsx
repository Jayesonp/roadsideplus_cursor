import { base44 } from '@/api/base44Client';
import { localDB } from './localDB';
import { cacheMessages } from './cacheMessages';
import { cacheVehicles } from './cacheVehicles';
import { cacheServiceRequests } from './cacheServiceRequests';

class SyncManager {
  constructor() {
    this.isSyncing = false;
    this.setupListeners();
  }

  setupListeners() {
    window.addEventListener('app:online', () => this.syncAll());
  }

  async syncAll() {
    if (this.isSyncing) return;
    
    console.log('🔄 Starting sync...');
    this.isSyncing = true;

    try {
      await this.syncMessages();
      await this.syncLocationUpdates();
      await this.syncActionQueue();
      await this.syncVehicles();
      await this.syncServiceRequests();
      console.log('✅ Sync complete');
      window.dispatchEvent(new CustomEvent('sync:complete'));
    } catch (error) {
      console.error('❌ Sync error:', error);
    } finally {
      this.isSyncing = false;
    }
  }

  async syncVehicles() {
    try {
      const user = await base44.auth.me();
      if (!user) return;

      const vehicles = await base44.entities.Vehicle.filter({ customer_id: user.id });
      await cacheVehicles.saveMultipleVehicles(vehicles);
      console.log('🚗 Vehicles synced');
    } catch (error) {
      console.error('Error syncing vehicles:', error);
    }
  }

  async syncServiceRequests() {
    try {
      const user = await base44.auth.me();
      if (!user) return;

      const techProfiles = await base44.entities.TechnicianProfile.filter({ user_id: user.id });
      const isTechnician = techProfiles.length > 0;

      let requests = [];
      if (isTechnician) {
        requests = await base44.entities.ServiceRequest.filter({ technician_id: user.id }, '-created_date', 50);
      } else {
        requests = await base44.entities.ServiceRequest.filter({ customer_id: user.id }, '-created_date', 50);
      }

      await cacheServiceRequests.saveMultipleRequests(requests);
      console.log('📋 Service requests synced');
    } catch (error) {
      console.error('Error syncing service requests:', error);
    }
  }

  async syncMessages() {
    const pendingMessages = await cacheMessages.getPendingMessages();
    console.log(`📨 Syncing ${pendingMessages.length} messages...`);

    for (const message of pendingMessages) {
      try {
        const { id, status, queued_at, ...messageData } = message;
        
        const created = await base44.entities.Message.create(messageData);
        
        await cacheMessages.markMessageSent(id);
        
        // Notify recipient
        if (messageData.service_request_id) {
          const requests = await base44.entities.ServiceRequest.filter({ id: messageData.service_request_id });
          const request = requests[0];
          
          if (request) {
            const recipientId = messageData.sender_role === 'customer' 
              ? request.technician_id 
              : request.customer_id;
            
            if (recipientId) {
              await base44.entities.Notification.create({
                user_id: recipientId,
                type: 'new_message',
                title: 'New Message',
                message: 'You have a new message.',
                related_id: messageData.service_request_id
              });
            }
          }
        }
      } catch (error) {
        console.error('Failed to sync message:', error);
      }
    }
  }

  async syncLocationUpdates() {
    const queue = await localDB.getAllItems('locationQueue');
    console.log(`📍 Syncing ${queue.length} location updates...`);

    for (const update of queue) {
      try {
        const { id, ...locationData } = update;
        
        await base44.entities.TechnicianLocation.create(locationData);
        await localDB.removeItem('locationQueue', id);
      } catch (error) {
        console.error('Failed to sync location:', error);
      }
    }
  }

  async syncActionQueue() {
    const queue = await localDB.getAllItems('actionQueue');
    console.log(`⚡ Syncing ${queue.length} actions...`);

    for (const action of queue) {
      try {
        const { id, type, data } = action;

        switch (type) {
          case 'update_status':
            await base44.entities.ServiceRequest.update(data.requestId, { status: data.status });
            break;
          
          case 'set_price':
            await base44.entities.ServiceRequest.update(data.requestId, { 
              price: data.price,
              payment_amount: data.price 
            });
            break;
          
          case 'upload_attachment':
            const { file_url } = await base44.integrations.Core.UploadFile({ file: data.file });
            await base44.entities.ServiceAttachment.create({
              service_request_id: data.service_request_id,
              file_url,
              file_type: data.file_type,
              file_name: data.file_name,
              uploaded_by: data.uploaded_by
            });
            break;
          
          case 'create_request':
            await base44.entities.ServiceRequest.create(data);
            break;
          
          case 'update_technician_location':
            await base44.entities.TechnicianProfile.update(data.profileId, {
              current_lat: data.latitude,
              current_lng: data.longitude
            });
            break;

          case 'create_vehicle':
            const newVehicle = await base44.entities.Vehicle.create(data.vehicleData);
            await cacheVehicles.saveVehicle(newVehicle);
            break;

          case 'update_vehicle':
            const updatedVehicle = await base44.entities.Vehicle.update(data.vehicleId, data.data);
            await cacheVehicles.saveVehicle(updatedVehicle);
            break;

          case 'delete_vehicle':
            await base44.entities.Vehicle.delete(data.vehicleId);
            await cacheVehicles.removeVehicle(data.vehicleId);
            break;

          case 'set_default_vehicle':
            const allVehicles = await base44.entities.Vehicle.filter({ customer_id: data.customerId });
            for (const v of allVehicles) {
              if (v.id !== data.vehicleId && v.is_default) {
                await base44.entities.Vehicle.update(v.id, { is_default: false });
              }
            }
            const defaultVehicle = await base44.entities.Vehicle.update(data.vehicleId, { is_default: true });
            await cacheVehicles.saveVehicle(defaultVehicle);
            break;

          case 'create_notification':
            // Create status change notification
            const requests = await base44.entities.ServiceRequest.filter({ id: data.jobId });
            const request = requests[0];
            if (request && request.customer_id) {
              const statusLabels = {
                'en_route': 'on the way',
                'arrived': 'arrived at your location',
                'in_progress': 'working on your vehicle',
                'completed': 'completed the service'
              };
              
              await base44.entities.Notification.create({
                user_id: request.customer_id,
                type: 'job_status_update',
                title: 'Job Status Updated',
                message: `Your technician is ${statusLabels[data.newStatus] || data.newStatus}`,
                related_id: data.jobId
              });
            }
            break;
        }

        await localDB.removeItem('actionQueue', id);
      } catch (error) {
        console.error('Failed to sync action:', error);
      }
    }
  }

  async queueAction(type, data) {
    await localDB.setItem('actionQueue', {
      type,
      data,
      queued_at: new Date().toISOString()
    });
  }

  async queueLocationUpdate(technicianId, latitude, longitude) {
    await localDB.setItem('locationQueue', {
      technician_id: technicianId,
      latitude,
      longitude,
      timestamp: new Date().toISOString()
    });
  }
}

export const syncManager = new SyncManager();