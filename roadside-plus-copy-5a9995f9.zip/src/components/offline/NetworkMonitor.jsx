import React, { createContext, useContext, useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { WifiOff, Wifi } from 'lucide-react';

const NetworkContext = createContext({ isOnline: true, wasOffline: false });

export function useNetworkStatus() {
  return useContext(NetworkContext);
}

export function NetworkMonitor({ children }) {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [wasOffline, setWasOffline] = useState(false);
  const [showReconnected, setShowReconnected] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      if (wasOffline) {
        setShowReconnected(true);
        setTimeout(() => setShowReconnected(false), 3000);
        // Trigger sync
        window.dispatchEvent(new CustomEvent('app:online'));
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      setWasOffline(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [wasOffline]);

  return (
    <NetworkContext.Provider value={{ isOnline, wasOffline }}>
      {!isOnline && (
        <Alert className="fixed top-16 md:top-4 left-4 right-4 z-50 bg-yellow-50 border-yellow-200">
          <WifiOff className="w-4 h-4" />
          <AlertDescription>
            You are offline. Some features may be limited. Changes will sync when reconnected.
          </AlertDescription>
        </Alert>
      )}
      
      {showReconnected && (
        <Alert className="fixed top-16 md:top-4 left-4 right-4 z-50 bg-green-50 border-green-200">
          <Wifi className="w-4 h-4" />
          <AlertDescription>
            Back online! Syncing your data...
          </AlertDescription>
        </Alert>
      )}
      
      {children}
    </NetworkContext.Provider>
  );
}