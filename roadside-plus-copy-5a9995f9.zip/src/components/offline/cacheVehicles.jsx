import { localDB } from './localDB';

export const cacheVehicles = {
  // Save a single vehicle
  async saveVehicle(vehicle) {
    await localDB.setItem('vehicles', vehicle);
  },

  // Save multiple vehicles
  async saveMultipleVehicles(vehicles) {
    for (const vehicle of vehicles) {
      await this.saveVehicle(vehicle);
    }
  },

  // Get a vehicle by ID
  async getVehicle(vehicleId) {
    return await localDB.getItem('vehicles', vehicleId);
  },

  // Get all vehicles for a customer
  async getCustomerVehicles(customerId) {
    const allVehicles = await localDB.getAllItems('vehicles');
    return allVehicles.filter(vehicle => vehicle.customer_id === customerId);
  },

  // Get all vehicles
  async getAllVehicles() {
    return await localDB.getAllItems('vehicles');
  },

  // Remove a vehicle
  async removeVehicle(vehicleId) {
    await localDB.removeItem('vehicles', vehicleId);
  },

  // Clear all vehicles
  async clearAll() {
    await localDB.clearStore('vehicles');
  }
};