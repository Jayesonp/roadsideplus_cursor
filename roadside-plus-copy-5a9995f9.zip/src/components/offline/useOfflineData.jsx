import { useState, useEffect } from 'react';
import { useNetworkStatus } from './NetworkMonitor';
import { cacheServiceRequests } from './cacheServiceRequests';

/**
 * Custom hook for offline-first data fetching
 * Tries cache first, then fetches fresh data
 */
export function useOfflineData(fetchFn, cacheKey, dependencies = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [fromCache, setFromCache] = useState(false);
  const { isOnline } = useNetworkStatus();

  useEffect(() => {
    loadData();
  }, [...dependencies, isOnline]);

  const loadData = async () => {
    try {
      // Try cache first
      if (cacheKey) {
        const cached = await cacheServiceRequests.getRequest(cacheKey);
        if (cached) {
          setData(cached);
          setFromCache(true);
          setLoading(false);
        }
      }

      // Fetch fresh data if online
      if (isOnline) {
        const fresh = await fetchFn();
        setData(fresh);
        setFromCache(false);
        
        // Update cache
        if (cacheKey && fresh) {
          await cacheServiceRequests.saveRequest({ id: cacheKey, ...fresh });
        }
      }
    } catch (error) {
      console.error('Data fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  return { data, loading, fromCache, refetch: loadData };
}