import { localDB } from './localDB';
import { syncManager } from './SyncManager';
import { base44 } from '@/api/base44Client';

class OfflineJobManager {
  // Save job details for offline viewing
  async cacheJobDetails(jobId) {
    try {
      const requests = await base44.entities.ServiceRequest.filter({ id: jobId });
      const job = requests[0];
      
      if (job) {
        await localDB.setItem('serviceRequests', job);
        
        // Cache customer info
        if (job.customer_id) {
          const customers = await base44.entities.User.filter({ id: job.customer_id });
          if (customers[0]) {
            await localDB.setItem('customers', customers[0]);
          }
        }
        
        // Cache attachments
        const attachments = await base44.entities.ServiceAttachment.filter({ service_request_id: jobId });
        for (const attachment of attachments) {
          await localDB.setItem('attachments', attachment);
        }
      }
      
      return job;
    } catch (error) {
      console.error('Error caching job details:', error);
      return null;
    }
  }

  // Get job from cache
  async getCachedJob(jobId) {
    try {
      return await localDB.getItem('serviceRequests', jobId);
    } catch (error) {
      console.error('Error getting cached job:', error);
      return null;
    }
  }

  // Get customer from cache
  async getCachedCustomer(customerId) {
    try {
      return await localDB.getItem('customers', customerId);
    } catch (error) {
      console.error('Error getting cached customer:', error);
      return null;
    }
  }

  // Queue status update for offline
  async updateJobStatusOffline(jobId, newStatus, technicianId) {
    try {
      // Update local cache
      const job = await localDB.getItem('serviceRequests', jobId);
      if (job) {
        job.status = newStatus;
        job.updated_date = new Date().toISOString();
        await localDB.setItem('serviceRequests', job);
      }

      // Queue for sync
      await syncManager.queueAction('update_status', {
        requestId: jobId,
        status: newStatus,
        technicianId: technicianId
      });

      // Create notification action
      await syncManager.queueAction('create_notification', {
        jobId: jobId,
        newStatus: newStatus
      });

      return true;
    } catch (error) {
      console.error('Error updating job status offline:', error);
      return false;
    }
  }

  // Queue message for offline
  async sendMessageOffline(messageData) {
    try {
      // Store in messages with pending status
      const message = {
        ...messageData,
        status: 'pending',
        queued_at: new Date().toISOString(),
        created_date: new Date().toISOString()
      };
      
      await localDB.setItem('messages', message);
      return message;
    } catch (error) {
      console.error('Error queuing message offline:', error);
      return null;
    }
  }

  // Get cached messages for a job
  async getCachedMessages(serviceRequestId) {
    try {
      const allMessages = await localDB.getAllItems('messages');
      return allMessages
        .filter(m => m.service_request_id === serviceRequestId)
        .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    } catch (error) {
      console.error('Error getting cached messages:', error);
      return [];
    }
  }

  // Queue attachment upload for offline
  async uploadAttachmentOffline(attachmentData) {
    try {
      await syncManager.queueAction('upload_attachment', attachmentData);
      
      // Store attachment metadata locally
      const attachment = {
        ...attachmentData,
        id: `temp_${Date.now()}`,
        status: 'pending',
        created_date: new Date().toISOString()
      };
      
      await localDB.setItem('attachments', attachment);
      return attachment;
    } catch (error) {
      console.error('Error queuing attachment offline:', error);
      return null;
    }
  }

  // Get pending actions count
  async getPendingActionsCount() {
    try {
      const actionQueue = await localDB.getAllItems('actionQueue');
      const messages = await localDB.getAllItems('messages');
      const pendingMessages = messages.filter(m => m.status === 'pending');
      return actionQueue.length + pendingMessages.length;
    } catch (error) {
      return 0;
    }
  }

  // Check if job data is available offline
  async isJobAvailableOffline(jobId) {
    try {
      const job = await localDB.getItem('serviceRequests', jobId);
      return !!job;
    } catch (error) {
      return false;
    }
  }

  // Cache active jobs for technician
  async cacheActiveJobs(technicianId) {
    try {
      const jobs = await base44.entities.ServiceRequest.filter(
        { technician_id: technicianId },
        '-updated_date',
        50
      );

      for (const job of jobs) {
        await localDB.setItem('serviceRequests', job);
        
        // Cache customer info
        if (job.customer_id) {
          const customers = await base44.entities.User.filter({ id: job.customer_id });
          if (customers[0]) {
            await localDB.setItem('customers', customers[0]);
          }
        }
      }

      return jobs;
    } catch (error) {
      console.error('Error caching active jobs:', error);
      return [];
    }
  }

  // Queue price setting for offline
  async setPriceOffline(jobId, price) {
    try {
      // Update local cache
      const job = await localDB.getItem('serviceRequests', jobId);
      if (job) {
        job.price = price;
        job.payment_amount = price;
        await localDB.setItem('serviceRequests', job);
      }

      // Queue for sync
      await syncManager.queueAction('set_price', {
        requestId: jobId,
        price: price
      });

      return true;
    } catch (error) {
      console.error('Error setting price offline:', error);
      return false;
    }
  }
}

export const offlineJobManager = new OfflineJobManager();