import { localDB } from './localDB';

export const cacheCustomers = {
  async saveCustomer(customer) {
    await localDB.setItem('customers', customer);
  },

  async getCustomer(id) {
    return await localDB.getItem('customers', id);
  },

  async getAllCustomers() {
    return await localDB.getAllItems('customers');
  },

  async saveMultipleCustomers(customers) {
    for (const customer of customers) {
      await localDB.setItem('customers', customer);
    }
  }
};