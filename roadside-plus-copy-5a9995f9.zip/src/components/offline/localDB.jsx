/**
 * Local Database Layer using IndexedDB
 * Provides persistent offline storage for web apps
 */

const DB_NAME = 'roadsideplus_db';
const DB_VERSION = 2;

class LocalDB {
  constructor() {
    this.db = null;
  }

  async init() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve(this.db);
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        // Service Requests store
        if (!db.objectStoreNames.contains('serviceRequests')) {
          db.createObjectStore('serviceRequests', { keyPath: 'id' });
        }

        // Messages store
        if (!db.objectStoreNames.contains('messages')) {
          const msgStore = db.createObjectStore('messages', { keyPath: 'id', autoIncrement: true });
          msgStore.createIndex('service_request_id', 'service_request_id', { unique: false });
          msgStore.createIndex('status', 'status', { unique: false });
        }

        // User profile store
        if (!db.objectStoreNames.contains('profile')) {
          db.createObjectStore('profile', { keyPath: 'id' });
        }

        // Vehicles store
        if (!db.objectStoreNames.contains('vehicles')) {
          db.createObjectStore('vehicles', { keyPath: 'id' });
        }

        // Location queue
        if (!db.objectStoreNames.contains('locationQueue')) {
          db.createObjectStore('locationQueue', { keyPath: 'id', autoIncrement: true });
        }

        // Action queue
        if (!db.objectStoreNames.contains('actionQueue')) {
          db.createObjectStore('actionQueue', { keyPath: 'id', autoIncrement: true });
        }

        // Knowledge base cache
        if (!db.objectStoreNames.contains('knowledgeBase')) {
          db.createObjectStore('knowledgeBase', { keyPath: 'id' });
        }

        // Customers cache
        if (!db.objectStoreNames.contains('customers')) {
          db.createObjectStore('customers', { keyPath: 'id' });
        }

        // Ratings cache
        if (!db.objectStoreNames.contains('ratings')) {
          db.createObjectStore('ratings', { keyPath: 'id' });
        }

        // Attachments cache
        if (!db.objectStoreNames.contains('attachments')) {
          const attachStore = db.createObjectStore('attachments', { keyPath: 'id' });
          attachStore.createIndex('service_request_id', 'service_request_id', { unique: false });
          attachStore.createIndex('status', 'status', { unique: false });
        }

        // Tech profiles cache
        if (!db.objectStoreNames.contains('techProfiles')) {
          db.createObjectStore('techProfiles', { keyPath: 'id' });
        }
      };
    });
  }

  async setItem(storeName, value) {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.put(value);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async getItem(storeName, key) {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async getAllItems(storeName) {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async removeItem(storeName, key) {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.delete(key);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async clearStore(storeName) {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.clear();
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async queryByIndex(storeName, indexName, value) {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const index = store.index(indexName);
      const request = index.getAll(value);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
}

export const localDB = new LocalDB();