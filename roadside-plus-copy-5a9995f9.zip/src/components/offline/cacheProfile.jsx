import { localDB } from './localDB';

export const cacheProfile = {
  async saveUserProfile(profile) {
    await localDB.setItem('profile', { ...profile, type: 'user' });
  },

  async getUserProfile(userId) {
    return await localDB.getItem('profile', userId);
  },

  async saveTechnicianProfile(profile) {
    await localDB.setItem('profile', { ...profile, type: 'technician' });
  },

  async getTechnicianProfile(userId) {
    return await localDB.getItem('profile', userId);
  },

  async saveVehicle(vehicle) {
    await localDB.setItem('vehicles', vehicle);
  },

  async getVehicles() {
    return await localDB.getAllItems('vehicles');
  },

  async removeVehicle(id) {
    await localDB.removeItem('vehicles', id);
  }
};