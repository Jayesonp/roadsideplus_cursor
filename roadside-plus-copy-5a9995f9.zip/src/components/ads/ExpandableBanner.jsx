import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function ExpandableBanner({ ads, onImpression, onClick }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [autoHideTimer, setAutoHideTimer] = useState(null);

  useEffect(() => {
    if (ads.length === 0 || isDismissed) return;

    const currentAd = ads[currentIndex];
    onImpression(currentAd.id);

    // Auto-hide after 10 seconds
    const timer = setTimeout(() => {
      setIsDismissed(true);
    }, 10000);

    setAutoHideTimer(timer);
    return () => clearTimeout(timer);
  }, [currentIndex, ads, isDismissed]);

  if (ads.length === 0 || isDismissed) return null;

  const currentAd = ads[currentIndex];

  const handleAdClick = () => {
    onClick(currentAd.id);
    if (currentAd.link_url) {
      window.open(currentAd.link_url, '_blank');
    }
  };

  const toggleExpand = (e) => {
    e.stopPropagation();
    setIsExpanded(!isExpanded);
    if (autoHideTimer) clearTimeout(autoHideTimer);
  };

  return (
    <div 
      className="fixed bottom-20 left-0 right-0 z-30 px-4"
      style={{
        paddingLeft: 'env(safe-area-inset-left)',
        paddingRight: 'env(safe-area-inset-right)',
        paddingBottom: 'env(safe-area-inset-bottom)'
      }}
    >
      <AnimatePresence>
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
        >
          <Card 
            className="relative overflow-hidden shadow-xl border-2"
            style={{ borderColor: '#FF771D', borderRadius: '16px' }}
          >
            {/* Mini Banner */}
            {!isExpanded && (
              <div 
                className="flex items-center justify-between p-3 cursor-pointer"
                onClick={toggleExpand}
              >
                <div className="flex items-center gap-3 flex-1">
                  {currentAd.image_url && (
                    <img 
                      src={currentAd.image_url} 
                      alt={currentAd.title}
                      className="w-12 h-12 object-cover rounded"
                    />
                  )}
                  <div className="flex-1">
                    <p className="font-bold text-sm">{currentAd.title}</p>
                    <p className="text-xs text-gray-600">Tap to view offer</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsDismissed(true);
                  }}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            )}

            {/* Expanded View */}
            {isExpanded && (
              <div className="relative">
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 bg-white/90 hover:bg-white z-10"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsExpanded(false);
                  }}
                >
                  <ChevronUp className="w-4 h-4" />
                </Button>

                {currentAd.image_url && (
                  <img 
                    src={currentAd.image_url} 
                    alt={currentAd.title}
                    className="w-full h-32 object-cover"
                  />
                )}
                
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-2">{currentAd.title}</h3>
                  {currentAd.subtitle && (
                    <p className="text-sm text-gray-600 mb-3">{currentAd.subtitle}</p>
                  )}
                  <Button 
                    className="w-full text-white"
                    style={{ backgroundColor: '#FF771D' }}
                    onClick={handleAdClick}
                  >
                    {currentAd.cta_text || 'Learn More'}
                  </Button>
                </div>
              </div>
            )}
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}