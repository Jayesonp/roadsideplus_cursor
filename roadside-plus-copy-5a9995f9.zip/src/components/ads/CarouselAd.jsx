import React, { useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function CarouselAd({ ads, onImpression, onClick }) {
  useEffect(() => {
    ads.forEach(ad => onImpression(ad.id));
  }, [ads]);

  if (ads.length === 0) return null;

  const handleAdClick = (ad) => {
    onClick(ad.id);
    if (ad.link_url) {
      window.open(ad.link_url, '_blank');
    }
  };

  return (
    <div className="overflow-x-auto hide-scrollbar">
      <div className="flex gap-4 pb-2">
        {ads.map((ad) => (
          <Card
            key={ad.id}
            className="min-w-[280px] cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => handleAdClick(ad)}
            style={{ 
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
              borderRadius: '12px'
            }}
          >
            {ad.image_url && (
              <img 
                src={ad.image_url} 
                alt={ad.title}
                className="w-full h-40 object-cover rounded-t-lg"
              />
            )}
            <div className="p-4">
              <h3 className="font-bold mb-1">{ad.title}</h3>
              {ad.subtitle && (
                <p className="text-sm text-gray-600 mb-3">{ad.subtitle}</p>
              )}
              <Button 
                size="sm" 
                className="w-full text-white"
                style={{ backgroundColor: '#FF771D' }}
              >
                {ad.cta_text || 'Learn More'}
              </Button>
            </div>
          </Card>
        ))}
      </div>
      <style jsx>{`
        .hide-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .hide-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}