import React, { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function DashboardCardAd({ ads, onImpression, onClick }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [autoScroll, setAutoScroll] = useState(true);

  useEffect(() => {
    if (ads.length === 0) return;

    const currentAd = ads[currentIndex];
    onImpression(currentAd.id);

    if (!autoScroll) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % ads.length);
    }, (currentAd.rotation_duration || 10) * 1000);

    return () => clearInterval(timer);
  }, [currentIndex, ads, autoScroll]);

  if (ads.length === 0) return null;

  const currentAd = ads[currentIndex];

  const handleAdClick = () => {
    onClick(currentAd.id);
    if (currentAd.link_url) {
      window.open(currentAd.link_url, '_blank');
    }
  };

  const goToPrevious = (e) => {
    e.stopPropagation();
    setAutoScroll(false);
    setCurrentIndex((prev) => (prev - 1 + ads.length) % ads.length);
  };

  const goToNext = (e) => {
    e.stopPropagation();
    setAutoScroll(false);
    setCurrentIndex((prev) => (prev + 1) % ads.length);
  };

  return (
    <Card 
      className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow border-2"
      style={{ borderColor: '#FF771D' }}
      onClick={handleAdClick}
    >
      <CardContent className="p-0">
        <div className="relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.5 }}
            >
              {currentAd.image_url && (
                <img 
                  src={currentAd.image_url} 
                  alt={currentAd.title}
                  className="w-full h-48 object-cover"
                />
              )}
              
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{currentAd.title}</h3>
                {currentAd.subtitle && (
                  <p className="text-gray-600 mb-4">{currentAd.subtitle}</p>
                )}
                <Button 
                  className="w-full text-white font-semibold"
                  style={{ backgroundColor: '#FF771D' }}
                >
                  {currentAd.cta_text || 'Learn More'}
                </Button>
              </div>
            </motion.div>
          </AnimatePresence>

          {ads.length > 1 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-1/2 left-2 -translate-y-1/2 bg-white/80 hover:bg-white shadow-lg"
                onClick={goToPrevious}
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-1/2 right-2 -translate-y-1/2 bg-white/80 hover:bg-white shadow-lg"
                onClick={goToNext}
              >
                <ChevronRight className="w-5 h-5" />
              </Button>

              {/* Indicators */}
              <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
                {ads.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={(e) => {
                      e.stopPropagation();
                      setCurrentIndex(idx);
                      setAutoScroll(false);
                    }}
                    className={`w-2 h-2 rounded-full transition-all ${
                      idx === currentIndex 
                        ? 'bg-white w-6' 
                        : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}