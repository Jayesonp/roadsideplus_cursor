import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

export default function BannerAd({ ads, onImpression, onClick, position = 'bottom' }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDismissed, setIsDismissed] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (ads.length === 0 || isDismissed) return;

    setIsVisible(true);
    const currentAd = ads[currentIndex];
    onImpression(currentAd.id);

    const rotationTimer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % ads.length);
    }, (currentAd.rotation_duration || 15) * 1000);

    return () => clearInterval(rotationTimer);
  }, [currentIndex, ads, isDismissed]);

  if (ads.length === 0 || isDismissed || !isVisible) return null;

  const currentAd = ads[currentIndex];

  const handleAdClick = () => {
    onClick(currentAd.id);
    if (currentAd.link_url) {
      window.open(currentAd.link_url, '_blank');
    }
  };

  return (
    <div 
      className={`fixed ${position === 'top' ? 'top-16' : 'bottom-20'} left-0 right-0 z-30 px-4 animate-in fade-in slide-in-from-bottom-2`}
      style={{
        paddingLeft: 'env(safe-area-inset-left)',
        paddingRight: 'env(safe-area-inset-right)'
      }}
    >
      <Card 
        className="relative overflow-hidden cursor-pointer"
        onClick={handleAdClick}
        style={{ 
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
          borderRadius: '12px'
        }}
      >
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 bg-white/90 hover:bg-white z-10"
          onClick={(e) => {
            e.stopPropagation();
            setIsDismissed(true);
          }}
        >
          <X className="w-4 h-4" />
        </Button>
        
        <div className="flex items-center gap-4 p-4">
          {currentAd.image_url && (
            <img 
              src={currentAd.image_url} 
              alt={currentAd.title}
              className="w-20 h-20 object-cover rounded-lg"
            />
          )}
          <div className="flex-1">
            <h3 className="font-bold text-sm mb-1">{currentAd.title}</h3>
            {currentAd.subtitle && (
              <p className="text-xs text-gray-600 mb-2">{currentAd.subtitle}</p>
            )}
            <Button 
              size="sm" 
              className="text-white text-xs"
              style={{ backgroundColor: '#FF771D' }}
            >
              {currentAd.cta_text || 'Learn More'}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}