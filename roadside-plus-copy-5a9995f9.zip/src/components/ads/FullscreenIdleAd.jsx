import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function FullscreenIdleAd({ ads, onImpression, onClick }) {
  const [isVisible, setIsVisible] = useState(false);
  const [hasShown, setHasShown] = useState(false);

  useEffect(() => {
    if (ads.length === 0 || hasShown) return;

    // Show after 5 seconds of idle time
    const timer = setTimeout(() => {
      setIsVisible(true);
      setHasShown(true);
      onImpression(ads[0].id);
    }, 5000);

    return () => clearTimeout(timer);
  }, [ads, hasShown]);

  if (ads.length === 0 || !isVisible) return null;

  const ad = ads[0];

  const handleAdClick = () => {
    onClick(ad.id);
    if (ad.link_url) {
      window.open(ad.link_url, '_blank');
    }
    setIsVisible(false);
  };

  const handleSkip = () => {
    setIsVisible(false);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          style={{
            paddingTop: 'env(safe-area-inset-top)',
            paddingLeft: 'env(safe-area-inset-left)',
            paddingRight: 'env(safe-area-inset-right)',
            paddingBottom: 'env(safe-area-inset-bottom)'
          }}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            className="relative bg-white rounded-2xl overflow-hidden max-w-md w-full shadow-2xl"
          >
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-3 right-3 bg-white/80 hover:bg-white z-10 rounded-full"
              onClick={handleSkip}
            >
              <X className="w-5 h-5" />
            </Button>

            {ad.image_url && (
              <img 
                src={ad.image_url} 
                alt={ad.title}
                className="w-full h-64 object-cover"
              />
            )}

            <div className="p-6">
              <h2 className="text-2xl font-bold mb-3">{ad.title}</h2>
              {ad.subtitle && (
                <p className="text-gray-600 mb-6">{ad.subtitle}</p>
              )}
              <div className="space-y-2">
                <Button 
                  className="w-full text-white text-lg py-6"
                  style={{ backgroundColor: '#FF771D' }}
                  onClick={handleAdClick}
                >
                  {ad.cta_text || 'Learn More'}
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full"
                  onClick={handleSkip}
                >
                  Skip
                </Button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}