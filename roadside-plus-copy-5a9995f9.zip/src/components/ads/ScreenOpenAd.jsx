import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

export default function ScreenOpenAd({ ad, onImpression, onClick, onDismiss }) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (!ad) return;
    
    setIsVisible(true);
    onImpression(ad.id);
  }, [ad]);

  if (!ad || !isVisible) return null;

  const handleAdClick = () => {
    onClick(ad.id);
    if (ad.link_url) {
      window.open(ad.link_url, '_blank');
    }
    setIsVisible(false);
    onDismiss();
  };

  const handleDismiss = () => {
    setIsVisible(false);
    onDismiss();
  };

  return (
    <div 
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 animate-in fade-in"
      onClick={handleDismiss}
    >
      <Card 
        className="relative max-w-md w-full"
        onClick={(e) => e.stopPropagation()}
        style={{ 
          boxShadow: '0 8px 24px rgba(0, 0, 0, 0.2)',
          borderRadius: '16px'
        }}
      >
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 bg-white hover:bg-gray-100 z-10"
          onClick={handleDismiss}
        >
          <X className="w-5 h-5" />
        </Button>

        <div className="cursor-pointer" onClick={handleAdClick}>
          {ad.image_url && (
            <img 
              src={ad.image_url} 
              alt={ad.title}
              className="w-full h-48 object-cover rounded-t-2xl"
            />
          )}
          <div className="p-6">
            <h2 className="text-2xl font-bold mb-2">{ad.title}</h2>
            {ad.subtitle && (
              <p className="text-gray-600 mb-4">{ad.subtitle}</p>
            )}
            <Button 
              className="w-full text-white"
              style={{ backgroundColor: '#FF771D' }}
            >
              {ad.cta_text || 'Learn More'}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}