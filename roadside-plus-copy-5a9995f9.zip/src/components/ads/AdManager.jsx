import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export function useAdManager(placement, userId, userRole) {
  const [activeRequests, setActiveRequests] = useState([]);

  // Fetch active service requests to determine if ads should show
  const { data: requests = [] } = useQuery({
    queryKey: ['active-service-requests', userId],
    queryFn: async () => {
      if (userRole === 'technician') {
        return await base44.entities.ServiceRequest.filter({ technician_id: userId });
      } else {
        return await base44.entities.ServiceRequest.filter({ customer_id: userId });
      }
    },
    enabled: !!userId,
    refetchInterval: 60000, // Increased to 1m
    retry: 1,
    retryDelay: 10000,
    staleTime: 60000 // Increased to 1m
  });

  // Check if any requests are in active states
  const hasActiveJob = requests.some(r => 
    ['pending_dispatch', 'dispatched', 'assigned', 'en_route', 'arrived', 'in_progress', 'awaiting_review'].includes(r.status)
  );

  // Fetch active ads
  const { data: allAds = [] } = useQuery({
    queryKey: ['active-ads', placement],
    queryFn: async () => {
      const ads = await base44.entities.Advertisement.filter({ status: 'active' });
      const now = new Date();
      
      return ads.filter(ad => {
        // Check placement
        if (ad.placement !== placement && ad.placement !== 'both') return false;
        
        // Check dates
        if (ad.start_date && new Date(ad.start_date) > now) return false;
        if (ad.end_date && new Date(ad.end_date) < now) return false;
        
        return true;
      }).sort((a, b) => (b.priority || 1) - (a.priority || 1));
    },
    enabled: !hasActiveJob,
    refetchInterval: 300000, // Increased to 5m
    retry: 1,
    retryDelay: 15000,
    staleTime: 300000 // Increased to 5m
  });

  const recordImpression = async (adId) => {
    if (!adId) return;
    const ad = allAds.find(a => a.id === adId);
    if (ad) {
      await base44.entities.Advertisement.update(adId, {
        total_impressions: (ad.total_impressions || 0) + 1
      });
    }
  };

  const recordClick = async (adId) => {
    if (!adId) return;
    const ad = allAds.find(a => a.id === adId);
    if (ad) {
      await base44.entities.Advertisement.update(adId, {
        total_clicks: (ad.total_clicks || 0) + 1
      });
    }
  };

  return {
    adsEnabled: !hasActiveJob,
    ads: hasActiveJob ? [] : allAds,
    recordImpression,
    recordClick
  };
}