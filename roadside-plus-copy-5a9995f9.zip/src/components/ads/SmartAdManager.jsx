import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

export function useSmartAdManager(placement, userId, userRole) {
  const [userImpressions, setUserImpressions] = useState({});
  const [lastActivity, setLastActivity] = useState(Date.now());
  const [isIdle, setIsIdle] = useState(false);

  // Track user activity
  useEffect(() => {
    const handleActivity = () => {
      setLastActivity(Date.now());
      setIsIdle(false);
    };

    window.addEventListener('mousemove', handleActivity);
    window.addEventListener('keypress', handleActivity);
    window.addEventListener('scroll', handleActivity);
    window.addEventListener('click', handleActivity);

    // Check for idle state every second
    const idleInterval = setInterval(() => {
      const idleTime = Date.now() - lastActivity;
      setIsIdle(idleTime > 3000); // Idle after 3 seconds
    }, 1000);

    return () => {
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('keypress', handleActivity);
      window.removeEventListener('scroll', handleActivity);
      window.removeEventListener('click', handleActivity);
      clearInterval(idleInterval);
    };
  }, [lastActivity]);

  // Check for active jobs (safety-critical check)
  const { data: requests = [] } = useQuery({
    queryKey: ['active-service-requests', userId],
    queryFn: async () => {
      if (userRole === 'technician') {
        return await base44.entities.ServiceRequest.filter({ technician_id: userId });
      } else {
        return await base44.entities.ServiceRequest.filter({ customer_id: userId });
      }
    },
    enabled: !!userId,
    refetchInterval: 60000,
    retry: 1,
    retryDelay: 10000,
    staleTime: 45000
  });

  const hasActiveJob = requests.some(r => 
    ['pending_dispatch', 'dispatched', 'assigned', 'en_route', 'arrived', 'in_progress', 'awaiting_review'].includes(r.status)
  );

  // Fetch ads with intelligent filtering
  const { data: allAds = [] } = useQuery({
    queryKey: ['active-ads', placement, userRole],
    queryFn: async () => {
      const ads = await base44.entities.Advertisement.filter({ status: 'active' });
      const now = new Date();
      const currentHour = now.getHours();
      const currentDay = now.getDay();
      
      return ads.filter(ad => {
        // Placement check
        if (ad.placement !== placement && ad.placement !== 'both') return false;
        
        // Date range check
        if (ad.start_date && new Date(ad.start_date) > now) return false;
        if (ad.end_date && new Date(ad.end_date) < now) return false;
        
        // Time of day targeting
        if (ad.time_of_day_targeting?.length > 0 && !ad.time_of_day_targeting.includes(currentHour)) {
          return false;
        }
        
        // Day of week targeting
        if (ad.days_of_week_targeting?.length > 0 && !ad.days_of_week_targeting.includes(currentDay)) {
          return false;
        }
        
        // Impression frequency cap
        const userImprCount = userImpressions[ad.id] || 0;
        if (userImprCount >= (ad.max_impressions_per_user || 3)) {
          return false;
        }
        
        return true;
      }).sort((a, b) => {
        // AI-based sorting
        if (a.use_ai_selection && !b.use_ai_selection) return -1;
        if (!a.use_ai_selection && b.use_ai_selection) return 1;
        
        // Priority-based sorting
        return (b.priority || 1) - (a.priority || 1);
      });
    },
    enabled: !hasActiveJob && isIdle,
    refetchInterval: 120000,
    retry: 1,
    retryDelay: 15000,
    staleTime: 90000
  });

  const recordImpression = async (adId) => {
    if (!adId) return;
    
    // Update user-specific impression count
    setUserImpressions(prev => ({
      ...prev,
      [adId]: (prev[adId] || 0) + 1
    }));
    
    // Update global impression count
    const ad = allAds.find(a => a.id === adId);
    if (ad) {
      await base44.entities.Advertisement.update(adId, {
        total_impressions: (ad.total_impressions || 0) + 1
      });
    }
  };

  const recordClick = async (adId) => {
    if (!adId) return;
    const ad = allAds.find(a => a.id === adId);
    if (ad) {
      await base44.entities.Advertisement.update(adId, {
        total_clicks: (ad.total_clicks || 0) + 1
      });
    }
  };

  // AI-powered ad selection
  const selectBestAd = async (ads) => {
    if (ads.length === 0) return null;
    
    // Filter AI-enabled ads
    const aiAds = ads.filter(ad => ad.use_ai_selection);
    
    if (aiAds.length > 0) {
      try {
        // Use LLM to select best ad based on context
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `You are an ad selection AI. Based on the current context:
- User role: ${userRole}
- Time: ${new Date().toLocaleTimeString()}
- Idle: ${isIdle}

Select the most relevant ad from these options and return only the ad ID:
${aiAds.map(ad => `ID: ${ad.id}, Title: ${ad.title}, Category: ${ad.category}`).join('\n')}`,
          response_json_schema: {
            type: "object",
            properties: {
              selected_ad_id: { type: "string" }
            }
          }
        });
        
        const selectedAd = aiAds.find(ad => ad.id === result.selected_ad_id);
        if (selectedAd) return selectedAd;
      } catch (error) {
        console.error('AI selection failed, falling back to priority', error);
      }
    }
    
    // Fallback to priority-based selection
    return ads[0];
  };

  return {
    adsEnabled: !hasActiveJob && isIdle,
    ads: hasActiveJob || !isIdle ? [] : allAds,
    recordImpression,
    recordClick,
    selectBestAd,
    isIdle
  };
}