import { base44 } from './base44Client';


export const ServiceRequest = base44.entities.ServiceRequest;

export const TechnicianProfile = base44.entities.TechnicianProfile;

export const Message = base44.entities.Message;

export const Rating = base44.entities.Rating;

export const TechnicianLocation = base44.entities.TechnicianLocation;

export const Notification = base44.entities.Notification;

export const ServiceAttachment = base44.entities.ServiceAttachment;

export const NotificationPreferences = base44.entities.NotificationPreferences;

export const Payment = base44.entities.Payment;

export const Event = base44.entities.Event;

export const SupportConversation = base44.entities.SupportConversation;

export const SupportMessage = base44.entities.SupportMessage;

export const Vehicle = base44.entities.Vehicle;

export const KnowledgeBaseArticle = base44.entities.KnowledgeBaseArticle;

export const PaymentMethod = base44.entities.PaymentMethod;

export const Invoice = base44.entities.Invoice;

export const Partner = base44.entities.Partner;

export const PartnerPayout = base44.entities.PartnerPayout;

export const PartnerStaff = base44.entities.PartnerStaff;

export const PartnerReferral = base44.entities.PartnerReferral;

export const PartnerContract = base44.entities.PartnerContract;

export const Advertisement = base44.entities.Advertisement;

export const SecurityCompany = base44.entities.SecurityCompany;

export const SecurityOfficer = base44.entities.SecurityOfficer;

export const SOSIncident = base44.entities.SOSIncident;

export const SecurityEvent = base44.entities.SecurityEvent;

export const Geofence = base44.entities.Geofence;

export const GPSTrail = base44.entities.GPSTrail;

export const SecurityChat = base44.entities.SecurityChat;

export const Achievement = base44.entities.Achievement;

export const TechnicianJobActivity = base44.entities.TechnicianJobActivity;

export const PreferredTechnician = base44.entities.PreferredTechnician;

export const CustomerReferral = base44.entities.CustomerReferral;

export const ReferralReward = base44.entities.ReferralReward;

export const CustomerProfile = base44.entities.CustomerProfile;

export const PartnerProfile = base44.entities.PartnerProfile;

export const SecurityCompanyProfile = base44.entities.SecurityCompanyProfile;

export const Invitation = base44.entities.Invitation;



// auth sdk:
export const User = base44.auth;