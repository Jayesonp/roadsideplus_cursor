import { base44 } from './base44Client';


export const stripePayment = base44.functions.stripePayment;

export const dispatchServiceRequest = base44.functions.dispatchServiceRequest;

export const enforceJobLocking = base44.functions.enforceJobLocking;

export const autoRetryDispatch = base44.functions.autoRetryDispatch;

export const processReferralReward = base44.functions.processReferralReward;

export const sendInvitation = base44.functions.sendInvitation;

export const verifyInvitation = base44.functions.verifyInvitation;

export const acceptInvitation = base44.functions.acceptInvitation;

